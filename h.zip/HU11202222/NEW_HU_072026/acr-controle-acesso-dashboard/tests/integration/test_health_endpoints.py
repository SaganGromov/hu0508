from pathlib import Path
import sys

from fastapi.testclient import TestClient


sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app import app


client = TestClient(app, base_url="https://testserver")


def test_liveness_health_endpoints_return_ok():
    for path in ("/healthz", "/health", "/health/live"):
        response = client.get(path)
        assert response.status_code == 200
        assert response.json() == {"status": "ok"}


def test_readiness_reports_web_and_dataset_state():
    response = client.get("/health/ready")
    assert response.status_code == 200
    payload = response.json()
    assert payload["status"] == "ok"
    assert payload["web"] == "ready"
    assert "backtest_dataset" in payload
