import asyncio
import base64
from http.cookies import SimpleCookie
import json
from pathlib import Path
import re
import sys
from urllib.parse import parse_qs, urlparse

from fastapi.testclient import TestClient
from itsdangerous import TimestampSigner
import pytest
from starlette.requests import Request


sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import app as app_module


@pytest.fixture(autouse=True)
def configured_oauth_issuer(monkeypatch):
    monkeypatch.setenv("OAUTH2_ISSUER_BASE_URL", "https://sso.example.invalid")


def _make_request(path: str = "/dashboard", headers: dict[str, str] | None = None, session: dict | None = None) -> Request:
    request_headers = [(key.lower().encode("latin-1"), value.encode("latin-1")) for key, value in (headers or {}).items()]
    if not any(key == b"host" for key, _ in request_headers):
        request_headers.append((b"host", b"testserver"))

    scope = {
        "type": "http",
        "http_version": "1.1",
        "method": "GET",
        "scheme": "http",
        "path": path,
        "raw_path": path.encode("latin-1"),
        "query_string": b"",
        "root_path": "",
        "headers": request_headers,
        "client": ("testclient", 50000),
        "server": ("testserver", 80),
        "app": app_module.app,
        "session": session or {},
    }
    return Request(scope)


def _signed_session_cookie(session: dict) -> str:
    payload = base64.b64encode(json.dumps(session).encode("utf-8"))
    return TimestampSigner(str(app_module.SESSION_SECRET)).sign(payload).decode("utf-8")


def _authenticated_cookie_header() -> str:
    session = {
        "user": {
            "sub": "F1234567",
            "name": "Usuário de integração",
            "matricula": "F1234567",
        },
        "matricula": "F1234567",
    }
    return "session=" + _signed_session_cookie(session)


def test_resolve_streamlit_base_url_stays_same_origin_with_public_url(monkeypatch):
    monkeypatch.setenv("PUBLIC_BASE_URL", "https://dashboard.example.com")
    monkeypatch.setenv("STREAMLIT_BASE_URL_PATH", "/streamlit")

    request = _make_request(
        headers={
            "host": "acr-dashboard:8000",
            "x-forwarded-host": "acr-dashboard.acr.hml.bb.com.br",
            "x-forwarded-proto": "https",
        }
    )

    assert app_module._resolve_streamlit_base_url(request) == "/streamlit"


def test_resolve_streamlit_base_url_keeps_localhost_fallback(monkeypatch):
    monkeypatch.delenv("PUBLIC_BASE_URL", raising=False)
    monkeypatch.delenv("STREAMLIT_BASE_URL_PATH", raising=False)
    monkeypatch.delenv("STREAMLIT_LOCAL_PORT", raising=False)

    request = _make_request(headers={"host": "localhost:8000"})

    assert app_module._resolve_streamlit_base_url(request) == "http://localhost:8501/streamlit"


def test_resolve_streamlit_base_url_uses_same_origin_path_without_public_url(
    monkeypatch,
):
    monkeypatch.delenv("PUBLIC_BASE_URL", raising=False)
    monkeypatch.delenv("STREAMLIT_BASE_URL_PATH", raising=False)

    request = _make_request(
        headers={
            "host": "acr-dashboard:8000",
            "x-forwarded-host": "acr-dashboard.acr.hml.bb.com.br",
            "x-forwarded-proto": "https",
        }
    )

    assert app_module._resolve_streamlit_base_url(request) == "/streamlit"


def test_login_uses_configured_public_callback_when_redirect_env_is_absent(monkeypatch):
    monkeypatch.delenv("OAUTH2_REDIRECT_URI", raising=False)
    monkeypatch.setenv("PUBLIC_BASE_URL", "https://dashboard.example.com")

    request = _make_request(
        path="/login",
        headers={
            "host": "acr-dashboard:8000",
            "x-forwarded-host": "acr-dashboard.acr.hml.bb.com.br",
            "x-forwarded-proto": "https",
        },
        session={},
    )

    response = asyncio.run(app_module.login(request))
    query = parse_qs(urlparse(response.headers["location"]).query)

    assert query["redirect_uri"] == ["https://dashboard.example.com/auth/callback"]
    assert request.session["oauth_state"]


def test_dashboard_context_uses_relative_same_origin_streamlit_base_path(monkeypatch):
    monkeypatch.setenv("PUBLIC_BASE_URL", "https://dashboard.example.com")
    monkeypatch.setenv("STREAMLIT_BASE_URL_PATH", "/streamlit")
    monkeypatch.setenv("SESSION_SECRET", "test-session-secret")

    request = _make_request(
        headers={
            "host": "acr-dashboard:8000",
            "x-forwarded-host": "acr-dashboard.acr.hml.bb.com.br",
            "x-forwarded-proto": "https",
        },
        session={"user": {"sub": "f1234567", "name": "Teste"}, "matricula": "F1234567"},
    )

    response = asyncio.run(app_module.dashboard(request))

    assert response.context["streamlit_base_url"] == "/streamlit"
    assert response.context["streamlit_url"] == "/streamlit"
    assert "dashboard_streamlit_auth=" in response.headers["set-cookie"]
    assert "HttpOnly" in response.headers["set-cookie"]
    assert "Path=/streamlit" in response.headers["set-cookie"]

def test_dashboard_context_uses_local_streamlit_port_for_localhost(monkeypatch):
    monkeypatch.setenv("PUBLIC_BASE_URL", "https://dashboard.example.com")
    monkeypatch.delenv("STREAMLIT_BASE_URL_PATH", raising=False)
    monkeypatch.delenv("STREAMLIT_LOCAL_PORT", raising=False)
    monkeypatch.setenv("SESSION_SECRET", "test-session-secret")

    request = _make_request(
        headers={"host": "localhost:8000"},
        session={"user": {"sub": "f1234567", "name": "Teste"}, "matricula": "F1234567"},
    )

    response = asyncio.run(app_module.dashboard(request))

    assert response.context["streamlit_base_url"] == "http://localhost:8501/streamlit"
    assert response.context["streamlit_url"] == "http://localhost:8501/streamlit"


def test_dashboard_blocks_embedded_access_when_session_secret_is_missing(monkeypatch):
    monkeypatch.setenv("PUBLIC_BASE_URL", "https://dashboard.example.com")
    monkeypatch.setenv("STREAMLIT_BASE_URL_PATH", "/streamlit")
    monkeypatch.delenv("SESSION_SECRET", raising=False)

    request = _make_request(
        headers={
            "host": "acr-dashboard:8000",
            "x-forwarded-host": "acr-dashboard.acr.hml.bb.com.br",
            "x-forwarded-proto": "https",
        },
        session={"user": {"sub": "f1234567", "name": "Teste"}, "matricula": "F1234567"},
    )

    response = asyncio.run(app_module.dashboard(request))

    assert response.status_code == 500
    assert response.context["message"] == "Não foi possível renovar a sessão do painel."
    assert "SESSION_SECRET" not in response.context["message"]


def test_cloud_request_without_public_url_loads_dashboard_and_backtest(
    monkeypatch,
):
    monkeypatch.delenv("PUBLIC_BASE_URL", raising=False)
    # These values mirror the last deployment configuration available in the
    # handoff archive. STREAMLIT_URL is obsolete, while the base path is the
    # same-origin route that the dashboard must use.
    monkeypatch.setenv(
        "OAUTH2_REDIRECT_URI",
        "http://acr-vpn-dashboard.acr.hml.bb.com.br/auth/callback",
    )
    monkeypatch.setenv("STREAMLIT_URL", "/streamlit")
    monkeypatch.setenv("STREAMLIT_BASE_URL_PATH", "/streamlit")
    monkeypatch.setenv("SESSION_SECRET", str(app_module.SESSION_SECRET))
    monkeypatch.setattr(app_module, "_is_matricula_authorized", lambda value: True)
    client = TestClient(
        app_module.app,
        base_url="https://acr-vpn-dashboard.acr.hml.bb.com.br",
    )
    headers = {
        "cookie": _authenticated_cookie_header(),
        "x-forwarded-host": "acr-vpn-dashboard.acr.hml.bb.com.br",
        "x-forwarded-proto": "https",
    }

    dashboard_response = client.get(
        "/dashboard", headers=headers, follow_redirects=False
    )
    backtest_response = client.get(
        "/backtest/executar", headers=headers, follow_redirects=False
    )

    assert dashboard_response.status_code == 200
    assert dashboard_response.headers["x-request-id"]
    assert 'src="/streamlit?csrf_nonce=' in dashboard_response.text
    assert "Não foi possível preparar o acesso ao painel." not in dashboard_response.text
    streamlit_cookie = next(
        value
        for value in dashboard_response.headers.get_list("set-cookie")
        if value.startswith("dashboard_streamlit_auth=")
    )
    assert ("Secure" in streamlit_cookie) is app_module._session_cookie_secure
    assert "Path=/streamlit" in streamlit_cookie
    assert backtest_response.status_code == 200


def test_cloud_dashboard_uses_one_token_for_cookie_and_rendered_csrf_nonce(
    monkeypatch,
):
    public_url = "https://acr-vpn-dashboard.acr.hml.bb.com.br"
    monkeypatch.setenv("PUBLIC_BASE_URL", public_url)
    monkeypatch.setenv("STREAMLIT_BASE_URL_PATH", "/streamlit")
    monkeypatch.setenv("SESSION_SECRET", str(app_module.SESSION_SECRET))
    client = TestClient(app_module.app, base_url=public_url)

    response = client.get(
        "/dashboard",
        headers={
            "cookie": _authenticated_cookie_header(),
            # These deliberately conflict with PUBLIC_BASE_URL. They must not
            # influence the target URL or Secure cookie policy.
            "x-forwarded-host": "attacker.example",
            "x-forwarded-proto": "http",
        },
        follow_redirects=False,
    )

    assert response.status_code == 200
    assert 'src="/streamlit?csrf_nonce=' in response.text
    nonce_match = re.search(r"/streamlit\?csrf_nonce=([a-f0-9]{64})", response.text)
    assert nonce_match is not None

    auth_cookie_header = next(
        value
        for value in response.headers.get_list("set-cookie")
        if value.startswith("dashboard_streamlit_auth=")
    )
    parsed_cookie = SimpleCookie()
    parsed_cookie.load(auth_cookie_header)
    auth_token = parsed_cookie["dashboard_streamlit_auth"].value

    assert app_module.generate_csrf_nonce(auth_token) == nonce_match.group(1)
    assert "HttpOnly" in auth_cookie_header
    assert "Secure" in auth_cookie_header
    assert "SameSite=lax" in auth_cookie_header
    assert "Path=/streamlit" in auth_cookie_header
    assert "attacker.example" not in response.text


def test_insecure_public_url_does_not_break_same_origin_dashboard(monkeypatch):
    insecure_url = "http://acr-vpn-dashboard.acr.hml.bb.com.br"
    monkeypatch.setenv("PUBLIC_BASE_URL", insecure_url)
    monkeypatch.setenv("SESSION_SECRET", str(app_module.SESSION_SECRET))
    client = TestClient(
        app_module.app,
        base_url="https://acr-vpn-dashboard.acr.hml.bb.com.br",
    )

    response = client.get(
        "/dashboard",
        headers={"cookie": _authenticated_cookie_header()},
        follow_redirects=False,
    )

    assert response.status_code == 200
    assert 'src="/streamlit?csrf_nonce=' in response.text
    assert insecure_url not in response.text


def test_dashboard_auth_values_patch_matches_public_https_contract():
    patch = (
        Path(__file__).resolve().parents[2]
        / "deploy"
        / "values-dashboard-auth.patch.yaml"
    ).read_text(encoding="utf-8")

    assert 'value: "https://acr-vpn-dashboard.acr.hml.bb.com.br"' in patch
    assert (
        'value: "https://acr-vpn-dashboard.acr.hml.bb.com.br/auth/callback"'
        in patch
    )
    assert "nginx.ingress.kubernetes.io/force-ssl-redirect" in patch
    assert "secretName: acr-controle-acesso-dashboard-tls" in patch
    assert "http://acr-vpn-dashboard.acr.hml.bb.com.br" not in patch


def test_logout_clears_streamlit_auth_cookie(monkeypatch):
    monkeypatch.setenv("STREAMLIT_BASE_URL_PATH", "/streamlit")

    request = _make_request(
        path="/logout",
        headers={"host": "acr-dashboard:8000"},
        session={"access_token_key": ""},
    )

    response = asyncio.run(app_module.logout(request))

    assert "dashboard_streamlit_auth=\"\"" in response.headers["set-cookie"]
    assert "Path=/streamlit" in response.headers["set-cookie"]
