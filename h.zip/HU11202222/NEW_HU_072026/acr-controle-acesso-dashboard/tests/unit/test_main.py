"""Unit tests for acr_controle_acesso_dashboard/__main__.py"""

import signal
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock, call

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import acr_controle_acesso_dashboard.__main__ as main_module


class TestStart:
    def test_start_launches_streamlit_and_uvicorn(self):
        mock_streamlit_proc = MagicMock()

        with patch.object(subprocess, "Popen", return_value=mock_streamlit_proc) as mock_popen, \
             patch.object(subprocess, "run") as mock_run:
            main_module.start()

        # Verify streamlit was launched via Popen
        popen_args = mock_popen.call_args[0][0]
        assert "streamlit" in " ".join(popen_args)
        assert "real_time_dashboard.py" in " ".join(popen_args)

        # Verify uvicorn was launched via subprocess.run
        run_args = mock_run.call_args[0][0]
        assert "uvicorn" in " ".join(run_args)
        assert "app:app" in run_args

        # Verify streamlit was terminated after uvicorn exits
        mock_streamlit_proc.terminate.assert_called_once()

    def test_start_terminates_streamlit_on_uvicorn_failure(self):
        mock_streamlit_proc = MagicMock()

        with patch.object(subprocess, "Popen", return_value=mock_streamlit_proc), \
             patch.object(subprocess, "run", side_effect=subprocess.CalledProcessError(1, "uvicorn")):
            try:
                main_module.start()
            except subprocess.CalledProcessError:
                pass

        mock_streamlit_proc.terminate.assert_called()

    def test_start_uses_env_base_url_path(self, monkeypatch):
        monkeypatch.setenv("STREAMLIT_BASE_URL_PATH", "/custom")
        mock_streamlit_proc = MagicMock()

        with patch.object(subprocess, "Popen", return_value=mock_streamlit_proc) as mock_popen, \
             patch.object(subprocess, "run"):
            main_module.start()

        popen_args = mock_popen.call_args[0][0]
        assert any("/custom" in arg for arg in popen_args)

    def test_cleanup_signal_handler(self):
        mock_streamlit_proc = MagicMock()
        handlers = {}

        def capture_signal(signum, handler):
            handlers[signum] = handler

        with patch.object(subprocess, "Popen", return_value=mock_streamlit_proc), \
             patch.object(subprocess, "run"), \
             patch.object(signal, "signal", side_effect=capture_signal):
            main_module.start()

        # Signal handlers should be registered
        assert signal.SIGTERM in handlers
        assert signal.SIGINT in handlers

        # Calling the handler should terminate streamlit
        try:
            handlers[signal.SIGTERM](signal.SIGTERM, None)
        except SystemExit:
            pass
        mock_streamlit_proc.terminate.assert_called()
