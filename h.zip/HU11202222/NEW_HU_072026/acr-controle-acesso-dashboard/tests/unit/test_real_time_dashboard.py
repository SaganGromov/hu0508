"""Unit tests for streamlit_app/real_time_dashboard.py — render_dashboard function."""

import sys
from datetime import datetime
from pathlib import Path
from unittest.mock import MagicMock, patch

import pandas as pd

# Mock streamlit before importing
sys.path.insert(0, str(Path(__file__).resolve().parent))
from streamlit_mock_helper import install_streamlit_mock, import_page_module, reimport_page_with_session_state, make_sample_logins_df
_mock_st = install_streamlit_mock()

_STREAMLIT_DIR = str(Path(__file__).resolve().parents[2] / "acr_controle_acesso_dashboard" / "streamlit_app")
sys.path.insert(0, _STREAMLIT_DIR)

with patch("auth_token.resolve_authenticated_user", return_value="F0000001"):
    real_time_dashboard = import_page_module(
        "real_time_dashboard",
        str(Path(_STREAMLIT_DIR) / "real_time_dashboard.py"),
    )


def _make_logins_df(n=10):
    return pd.DataFrame({
        "timestamp": [datetime(2025, 1, 1, 10, i) for i in range(n)],
        "chave": [f"F{1000000+i}" for i in range(n)],
        "user": [f"User{i}" for i in range(n)],
        "status": ["Success"] * (n - 2) + ["Failure"] * 2 if n >= 2 else ["Success"] * n,
        "src_ip": [f"10.0.0.{i+1}" for i in range(n)],
        "hostname": [f"host{i%3}" for i in range(n)],
        "os": ["Windows 11"] * n,
        "tunnel": ["IPSec"] * n,
        "login_option": ["certificate"] * n,
        "client_version": ["1.0"] * n,
        "mac_address": [f"AA:BB:CC:DD:EE:{i:02X}" for i in range(n)],
        "office_mode_ip": [f"192.168.1.{i+1}" for i in range(n)],
        "fingerprint": [f"fp{i}" for i in range(n)],
        "user_group": ["group1"] * n,
        "eventos": [1] * n,
    })


class TestRenderDashboard:
    def test_renders_without_error(self):
        df = _make_logins_df(10)
        # Should not raise
        real_time_dashboard.render_dashboard(df, "", 100)

    def test_renders_with_search_filter(self):
        df = _make_logins_df(10)
        real_time_dashboard.render_dashboard(df, "F1000000", 100)

    def test_renders_with_partial_search(self):
        df = _make_logins_df(10)
        real_time_dashboard.render_dashboard(df, "F100", 100)

    def test_renders_with_no_matches(self):
        df = _make_logins_df(10)
        real_time_dashboard.render_dashboard(df, "F9999999", 100)

    def test_renders_with_multi_host_alerts(self):
        df = pd.DataFrame({
            "timestamp": [datetime(2025, 1, 1, 10, i) for i in range(4)],
            "chave": ["F1000000", "F1000000", "F2000000", "F2000000"],
            "user": ["User1", "User1", "User2", "User2"],
            "status": ["Success"] * 4,
            "src_ip": ["10.0.0.1", "10.0.0.2", "10.0.0.3", "10.0.0.4"],
            "hostname": ["hostA", "hostB", "hostC", "hostD"],
            "os": ["Windows 11"] * 4,
            "tunnel": ["IPSec"] * 4,
            "login_option": ["certificate"] * 4,
            "client_version": ["1.0"] * 4,
            "mac_address": ["AA:BB:CC:DD:EE:01"] * 4,
            "office_mode_ip": ["192.168.1.1"] * 4,
            "fingerprint": ["fp1"] * 4,
            "user_group": ["group1"] * 4,
            "eventos": [1] * 4,
        })
        real_time_dashboard.render_dashboard(df, "", 100)


class TestFetchCurioFuncionario:
    def test_calls_curio_service(self):
        with patch.object(real_time_dashboard, "integracao_curio", return_value={"nomeUsuario": "Test"}) as mock:
            result = real_time_dashboard.fetch_curio_funcionario("F1234567")
        assert result == {"nomeUsuario": "Test"}
        mock.assert_called_once()

    def test_returns_none_on_error(self):
        with patch.object(real_time_dashboard, "integracao_curio", return_value=None):
            result = real_time_dashboard.fetch_curio_funcionario("F1234567")
        assert result is None


class TestRenderDashboardCurioBranch:
    """Cover the curio data display branch inside render_dashboard."""

    def test_renders_with_curio_data(self):
        df = _make_logins_df(5)
        with patch.object(
            real_time_dashboard, "fetch_curio_funcionario",
            return_value={"nomeUsuario": "Test User", "codigoPrefixoDependenciaAtual": "1234"},
        ):
            real_time_dashboard.render_dashboard(df, "F1000000", 100)

    def test_renders_with_curio_none(self):
        df = _make_logins_df(5)
        with patch.object(real_time_dashboard, "fetch_curio_funcionario", return_value=None):
            real_time_dashboard.render_dashboard(df, "F1000000", 100)


class TestRenderingCoverage:
    """Re-import with session state to cover retroactive mode code."""

    def test_retroactive_mode_render(self):
        mod = reimport_page_with_session_state(
            "real_time_dashboard",
            str(Path(_STREAMLIT_DIR) / "real_time_dashboard.py"),
            session_state={
                "retro_df": make_sample_logins_df(),
                "retro_msg_count": 100,
                "retro_target_chave": "F1234567",
            },
        )
        assert hasattr(mod, "render_dashboard")
