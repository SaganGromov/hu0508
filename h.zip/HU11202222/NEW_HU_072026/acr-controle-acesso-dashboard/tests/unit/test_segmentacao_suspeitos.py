"""Unit tests for pure helpers used by the Segmentação de Suspeitos page."""

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from streamlit_mock_helper import install_streamlit_mock  # noqa: E402

install_streamlit_mock()
sys.modules.setdefault("requests", MagicMock())

sys.path.insert(
    0,
    str(Path(__file__).resolve().parents[2] / "acr_controle_acesso_dashboard" / "streamlit_app"),
)

from backtest_bundle import (
    curio_coverage,
    group_counts,
    group_rule_by_dimension,
    should_use_org_fallback,
)
from org_enrichment import flatten_org, is_matricula


def _matriculas_bundle_rows() -> list[dict]:
    """Linhas de suspeitos já enriquecidas por curio (mockado)."""
    return [
        {"USER_KEY": "F0000001", "Prefixo Dependência": "1234", "Tipo Usuário": "F",
         "R1": 1, "R2": 0, "R3": 0, "R4": 0, "R5": 1},
        {"USER_KEY": "F0000002", "Prefixo Dependência": "1234", "Tipo Usuário": "F",
         "R1": 1, "R2": 0, "R3": 0, "R4": 0, "R5": 0},
        {"USER_KEY": "F0000003", "Prefixo Dependência": "5678", "Tipo Usuário": "T",
         "R1": 0, "R2": 0, "R3": 0, "R4": 0, "R5": 1},
        {"USER_KEY": "F0000004", "Prefixo Dependência": "1234", "Tipo Usuário": "T",
         "R1": 0, "R2": 1, "R3": 0, "R4": 0, "R5": 0},
    ]


class TestGroupCounts:
    def test_counts_by_prefix(self):
        rows = _matriculas_bundle_rows()
        assert group_counts(rows, "Prefixo Dependência") == [
            ("1234", 3),
            ("5678", 1),
        ]

    def test_counts_by_tipo(self):
        rows = _matriculas_bundle_rows()
        assert group_counts(rows, "Tipo Usuário") == [
            ("F", 2),
            ("T", 2),
        ]

    def test_ignores_nulls(self):
        rows = _matriculas_bundle_rows() + [
            {"USER_KEY": "U-x", "Prefixo Dependência": None, "Tipo Usuário": ""},
        ]
        assert group_counts(rows, "Prefixo Dependência") == [
            ("1234", 3),
            ("5678", 1),
        ]


class TestGroupRuleByDimension:
    def test_prefixo_x_regra_counts(self):
        rows = _matriculas_bundle_rows()
        grouped = {r["Prefixo Dependência"]: r for r in group_rule_by_dimension(rows, "Prefixo Dependência")}
        assert grouped["1234"]["R1"] == 2
        assert grouped["1234"]["R2"] == 1
        assert grouped["1234"]["R5"] == 1
        assert grouped["1234"]["total"] == 4
        assert grouped["5678"]["R5"] == 1
        assert grouped["5678"]["total"] == 1


class TestCurioCoverageAndFallback:
    def test_full_coverage(self):
        rows = _matriculas_bundle_rows()
        assert curio_coverage(rows, "Prefixo Dependência") == 1.0
        assert should_use_org_fallback(rows, "Prefixo Dependência") is False

    def test_below_threshold_triggers_fallback(self):
        rows = [
            {"USER_KEY": "U-a", "Prefixo Dependência": None},
            {"USER_KEY": "U-b", "Prefixo Dependência": None},
            {"USER_KEY": "U-c", "Prefixo Dependência": None},
            {"USER_KEY": "F0000001", "Prefixo Dependência": "1234"},
        ]
        coverage = curio_coverage(rows, "Prefixo Dependência")
        assert coverage == 0.25
        assert should_use_org_fallback(rows, "Prefixo Dependência") is True

    def test_empty_rows(self):
        assert curio_coverage([], "Prefixo Dependência") == 0.0
        assert should_use_org_fallback([], "Prefixo Dependência") is True


class TestCurioMockedIntegration:
    """Confere que fetch_org_data + flatten_org montam a linha esperada quando
    o curio devolve None para uma matrícula pseudonimizada."""

    def test_pseudonymized_users_do_not_hit_network(self):
        from org_enrichment import fetch_org_data
        with patch("org_enrichment.integracao_curio") as mock_curio:
            row = flatten_org(fetch_org_data("U-abcdef"))
        mock_curio.assert_not_called()
        assert row["Prefixo Dependência"] is None
        assert row["Tipo Usuário"] is None

    def test_matricula_returns_flattened_record(self):
        from org_enrichment import fetch_org_data
        curio_payload = {
            "codigoPrefixoDependenciaAtual": "1234",
            "codigoTipoUsuario": "F",
            "numeroMatriculaUsuario": "F0000001",
        }
        with patch("org_enrichment.integracao_curio", return_value=curio_payload):
            row = flatten_org(fetch_org_data("F0000001"))
        assert row["Prefixo Dependência"] == "1234"
        assert row["Tipo Usuário"] == "F"
        assert row["Matrícula"] == "F0000001"
        assert is_matricula("F0000001")
