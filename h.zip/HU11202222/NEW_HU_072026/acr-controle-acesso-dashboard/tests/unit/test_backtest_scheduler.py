"""Política de agendamento de 24 horas: corte, catch-up e marca d'água."""

from datetime import datetime

import pytest

from backtest_vpn.clock import FixedClock
from backtest_vpn.period import CUTOFF_COMPLETED_DAY, CUTOFF_CURRENT_DAY
from backtest_vpn.scheduler import (
    ScheduleConfig,
    evaluate,
    parse_cutoff_time,
    scheduled_period,
    watermark_after_success,
)


def config(**kwargs):
    base = dict(cutoff_time="01:30", cutoff_mode=CUTOFF_COMPLETED_DAY, window_days=33)
    base.update(kwargs)
    return ScheduleConfig(**base)


class TestScheduledPeriod:
    def test_completed_day_ends_yesterday_with_thirty_three_days(self):
        period = scheduled_period(config(), datetime(2026, 7, 30).date())
        assert (period.start_text, period.end_inclusive_text) == ("2026-06-27", "2026-07-29")
        assert period.total_calendar_days == 33

    def test_current_day_ends_today(self):
        period = scheduled_period(config(cutoff_mode=CUTOFF_CURRENT_DAY), datetime(2026, 7, 30).date())
        assert period.end_inclusive_text == "2026-07-30"
        assert period.total_calendar_days == 33

    def test_configured_window_length_is_respected(self):
        period = scheduled_period(config(window_days=7), datetime(2026, 7, 30).date())
        assert period.total_calendar_days == 7
        assert period.start_text == "2026-07-23"


class TestEvaluate:
    def test_disabled_schedule_never_runs(self):
        decision = evaluate(config(enabled=False), FixedClock(datetime(2026, 7, 30, 5)), {})
        assert decision.should_run is False
        assert "desabilitado" in decision.reason

    def test_first_run_without_watermark_is_due(self):
        decision = evaluate(config(), FixedClock(datetime(2026, 7, 30, 5)), {})
        assert decision.should_run is True
        assert decision.period.total_calendar_days == 33
        assert "Nenhum resultado publicado" in decision.reason

    def test_before_cutoff_time_is_not_due(self):
        decision = evaluate(
            config(),
            FixedClock(datetime(2026, 7, 30, 1, 0)),
            {"last_published_end_date": "2026-07-28"},
        )
        assert decision.should_run is False
        assert "horário de corte" in decision.reason
        assert decision.next_due_at.startswith("2026-07-30T01:30")

    def test_after_cutoff_with_new_day_available_is_due(self):
        decision = evaluate(
            config(),
            FixedClock(datetime(2026, 7, 30, 2, 0)),
            {"last_published_end_date": "2026-07-28"},
        )
        assert decision.should_run is True
        assert decision.period.end_inclusive_text == "2026-07-29"
        assert decision.missed_runs == 0

    def test_already_published_window_is_not_rerun(self):
        decision = evaluate(
            config(),
            FixedClock(datetime(2026, 7, 30, 12, 0)),
            {"last_published_end_date": "2026-07-29"},
        )
        assert decision.should_run is False
        assert "já está publicada" in decision.reason
        assert decision.next_due_at.startswith("2026-07-31T01:30")

    def test_missed_runs_are_recovered_by_the_rolling_window(self):
        decision = evaluate(
            config(),
            FixedClock(datetime(2026, 7, 30, 3, 0)),
            {"last_published_end_date": "2026-07-24"},
        )
        assert decision.should_run is True
        assert decision.missed_runs == 4
        assert "Recuperando" in decision.reason
        # Uma única janela rolante cobre todos os dias perdidos.
        assert decision.period.start_text == "2026-06-27"
        assert decision.period.end_inclusive_text == "2026-07-29"

    def test_catch_up_disabled_still_runs_latest_window(self):
        decision = evaluate(
            config(catch_up=False),
            FixedClock(datetime(2026, 7, 30, 3, 0)),
            {"last_published_end_date": "2026-07-20"},
        )
        assert decision.should_run is True
        assert "recuperação desabilitada" in decision.reason
        assert decision.period.end_inclusive_text == "2026-07-29"

    def test_corrupt_watermark_is_treated_as_absent(self):
        decision = evaluate(
            config(), FixedClock(datetime(2026, 7, 30, 3)),
            {"last_published_end_date": "não-uma-data"},
        )
        assert decision.should_run is True
        assert "Nenhum resultado publicado" in decision.reason

    def test_clock_moved_backwards_does_not_rerun_published_window(self):
        # Ajuste de relógio para trás não deve reprocessar o que já está publicado.
        decision = evaluate(
            config(), FixedClock(datetime(2026, 7, 29, 3)),
            {"last_published_end_date": "2026-07-29"},
        )
        assert decision.should_run is False


class TestRetryBackoff:
    @pytest.mark.parametrize(
        "attempt,expected",
        [(1, 300), (2, 600), (3, 1200), (4, 2400), (5, 3600), (20, 3600)],
    )
    def test_bounded_exponential_backoff(self, attempt, expected):
        assert config().retry_delay_seconds(attempt) == expected

    def test_backoff_is_deterministic(self):
        cfg = config()
        assert cfg.retry_delay_seconds(3) == cfg.retry_delay_seconds(3)


class TestWatermarkPayload:
    def test_watermark_records_window_and_cutoff(self):
        period = scheduled_period(config(), datetime(2026, 7, 30).date())
        clock = FixedClock(datetime(2026, 7, 30, 4, 0))
        payload = watermark_after_success(period, "bt-1", clock, report_id="BT-9")
        assert payload["last_published_end_date"] == "2026-07-29"
        assert payload["last_published_window_days"] == 33
        assert payload["last_published_cutoff_mode"] == CUTOFF_COMPLETED_DAY
        assert payload["last_published_data_cutoff"] == "2026-07-30 00:00:00"
        assert payload["last_success_job_id"] == "bt-1"
        assert payload["last_success_report_id"] == "BT-9"


class TestConfigFromEnv:
    def test_defaults_are_conservative(self):
        cfg = ScheduleConfig.from_env({})
        assert cfg.enabled is False
        assert cfg.interval_hours == 24
        assert cfg.window_days == 33
        assert cfg.cutoff_mode == CUTOFF_COMPLETED_DAY
        assert cfg.run_initial_on_startup is False

    def test_environment_overrides(self):
        cfg = ScheduleConfig.from_env({
            "BACKTEST_SCHEDULE_ENABLED": "false",
            "BACKTEST_SCHEDULE_INTERVAL_HOURS": "12",
            "BACKTEST_SCHEDULE_CUTOFF_TIME": "23:45",
            "BACKTEST_SCHEDULE_CUTOFF_MODE": "current_day",
            "BACKTEST_WINDOW_DAYS": "7",
            "BACKTEST_MAX_ATTEMPTS": "5",
        })
        assert cfg.enabled is False
        assert cfg.interval_hours == 12
        assert cfg.cutoff_time == "23:45"
        assert cfg.cutoff_mode == CUTOFF_CURRENT_DAY
        assert cfg.window_days == 7
        assert cfg.max_attempts == 5

    @pytest.mark.parametrize(
        "env,message",
        [
            ({"BACKTEST_SCHEDULE_CUTOFF_MODE": "amanha"}, "CUTOFF_MODE"),
            ({"BACKTEST_SCHEDULE_CUTOFF_TIME": "25:00"}, "Horário de corte"),
            ({"BACKTEST_WINDOW_DAYS": "0"}, "BACKTEST_WINDOW_DAYS"),
            ({"BACKTEST_SCHEDULE_ENABLED": "talvez"}, "booleano"),
        ],
    )
    def test_invalid_environment_is_rejected(self, env, message):
        with pytest.raises(ValueError, match=message):
            ScheduleConfig.from_env(env)

    @pytest.mark.parametrize("value", ["1:2", "abc", "", "12:60", None])
    def test_invalid_cutoff_times(self, value):
        with pytest.raises(ValueError, match="Horário de corte"):
            parse_cutoff_time(value)
