from datetime import datetime
from types import SimpleNamespace

import pytest

pytest.importorskip("ibm_db")

from backtest_vpn.mta import (
    MtaConfig,
    MtaResultLimitExceeded,
    _like_pattern_username,
    find_mta_matches_for_users,
    match_vpn_events,
    normalize_ip as normalize_mta_ip,
)
from backtest_vpn.rules import (
    BacktestCaseResult,
    _r5_occurrence,
    _synthesize_r6_case,
    run_vpn_plus_mta_physical_case,
)


def r5_row(user, suffix):
    return {
        "USER_KEY": user,
        "VPN_TS": datetime(2026, 7, 10, 9, suffix),
        "VPN_CPTV_IP": "10.0.0.{0}".format(suffix + 1),
        "MTA_TS": datetime(2026, 7, 10, 9, suffix + 1),
        "MTA_IP_CLIENTE": "192.168.0.{0}".format(suffix + 1),
        "MTA_CD_IDFR_MTA": 100 + suffix,
        "MTA_CD_UNCO_TRAN": "FLOW-{0}".format(suffix),
        "MTA_CD_CLI_TRAN": 200 + suffix,
        "MTA_NM_ETP": "DecisionNode",
    }


def config():
    return SimpleNamespace(
        mta_table=MtaConfig(delta_minutes=15),
        detection=SimpleNamespace(excluded_user_allowlist=frozenset()),
        distinct_limit=2,
        sample_limit=50,
        start=datetime(2026, 7, 1),
        end=datetime(2026, 7, 31),
        vpn_table=SimpleNamespace(
            schema="DB2PEP", table="AUT_CPTV", user_column="CD_USU_AUT",
            hostname_column="NM_DSVO", device_column="CD_IDFC_DSVO",
            timestamp_column="TS_TRAN",
            source_ip_column="CD_END_LGC_OGM",
            corporate_ip_column="CD_END_LGC_CPTV",
        ),
    )


def test_r5_occurrence_is_evidence_based_and_does_not_claim_simultaneity():
    occurrence = _r5_occurrence(r5_row("T1", 1), config())
    assert occurrence["rule_id"] == "R5"
    assert len(occurrence["supporting_event_identifiers"]) == 2
    assert "não fornece início/fim" in occurrence["explanation"]
    assert occurrence["deduplication_method"].startswith("OpenAM deduplicado")


def test_r5_ip_normalization_rejects_unspecified_and_canonicalizes_ipv6():
    for value in ("0.0.0.0", "::", "::0", "0:0:0:0:0:0:0:0"):
        assert normalize_mta_ip(value) is None
    assert normalize_mta_ip("2001:0db8:0:0::1") == "2001:db8::1"


def test_r5_like_pattern_escapes_wildcards_from_source_username():
    pattern = _like_pattern_username(r"A%_\\B")
    assert r"A\%\_\\\\B" in pattern
    assert pattern.startswith('%"username"%:%"')


def test_r5_fails_closed_when_mta_result_cap_is_exceeded(monkeypatch):
    cfg = MtaConfig(fetch_first_rows=2)
    rows = [
        {
            "CD_IDFR_MTA": index,
            "CD_UNCO_TRAN": "FLOW-{0}".format(index),
            "CD_CLI_TRAN": index,
            "TS_TRAN": datetime(2026, 7, 10, 9, index),
            "NM_ETP": "DecisionNode",
            "JS_INF_CLI": '[{"username":"T1","ipCliente":"192.168.0.1"}]',
        }
        for index in range(3)
    ]
    monkeypatch.setattr("backtest_vpn.mta.fetch_all", lambda *args, **kwargs: rows)
    with pytest.raises(MtaResultLimitExceeded, match="[Nn]enhum resultado parcial"):
        find_mta_matches_for_users(
            object(),
            cfg,
            ["T1"],
            1,
            100,
            datetime(2026, 7, 10, 8),
            datetime(2026, 7, 10, 10),
        )


def test_r5_round_size_does_not_truncate_users(monkeypatch):
    cfg = MtaConfig(max_users_per_run=2, users_per_batch=1)
    timestamp = datetime(2026, 7, 10, 9)
    events = {
        user: [{"ts": timestamp, "cptv_ip": "10.0.0.1"}]
        for user in ("T1", "T2", "T3")
    }
    monkeypatch.setattr(
        "backtest_vpn.mta.estimate_pk_window", lambda *args, **kwargs: (1, 100)
    )

    def fake_find(_conn, _cfg, users, *_args, **_kwargs):
        return [
            {
                "username": user,
                "ip_cliente": "192.168.0.1",
                "ts_tran": timestamp,
                "cd_unco_tran": "FLOW-" + user,
                "cd_cli_tran": user,
                "cd_idfr_mta": index,
                "nm_etp": "DecisionNode",
            }
            for index, user in enumerate(users)
        ]

    monkeypatch.setattr("backtest_vpn.mta.find_mta_matches_for_users", fake_find)
    matched = match_vpn_events(object(), cfg, events)
    assert set(matched) == {"T1", "T2", "T3"}
    assert all(len(matched[user]) == 1 for user in matched)


def test_r5_deduplicates_identical_vpn_rows(monkeypatch):
    cfg = config()
    vpn_row = {
        "USER_KEY": "T1",
        "VPN_TS": datetime(2026, 7, 10, 9, 0),
        "CPTV_IP": "10.0.0.1",
    }
    monkeypatch.setattr(
        "backtest_vpn.rules.fetch_all",
        lambda conn, sql, params: [vpn_row, dict(vpn_row)],
    )

    def fake_match(conn, mta_cfg, events):
        event = events["T1"][0]
        return {"T1": [{
            "ts_vpn": event["ts"], "cptv_ip": event["cptv_ip"],
            "ts_mta": datetime(2026, 7, 10, 9, 1),
            "ip_cliente": "192.168.0.1", "cd_idfr_mta": 10,
            "cd_unco_tran": "FLOW-1", "cd_cli_tran": 20,
            "nm_etp": "DecisionNode",
        }]}

    monkeypatch.setattr("backtest_vpn.rules.mta_mod.match_vpn_events", fake_match)
    result = run_vpn_plus_mta_physical_case(object(), cfg)
    assert result.count == 1
    assert len(result.occurrences) == 1


def test_r6_uses_all_r5_occurrences_not_only_limited_sample(monkeypatch):
    cfg = config()
    rows = [r5_row("T1", 1), r5_row("T2", 2)]
    r5_case = BacktestCaseResult(
        name="vpn_ativa_com_login_em_rede_fisica_mta",
        status="ok",
        count=2,
        sample=[rows[0]],
        occurrences=[_r5_occurrence(row, cfg) for row in rows],
    )

    def fake_fetch_all(conn, sql, params):
        return [
            {"USER_KEY": "T1", "DISTINCT_HOSTNAMES": 3, "DISTINCT_DEVICES": 1, "EVENTS": 3},
            {"USER_KEY": "T2", "DISTINCT_HOSTNAMES": 1, "DISTINCT_DEVICES": 3, "EVENTS": 3},
        ]

    monkeypatch.setattr("backtest_vpn.rules.fetch_all", fake_fetch_all)
    result = _synthesize_r6_case(object(), cfg, r5_case)
    assert result.status == "ok"
    assert result.count == 2
    assert {item["user_id"] for item in result.occurrences} == {"T1", "T2"}
