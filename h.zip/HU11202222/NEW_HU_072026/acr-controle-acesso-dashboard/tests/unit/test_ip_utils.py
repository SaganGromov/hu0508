"""Unit tests for ip_utils.py"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "acr_controle_acesso_dashboard" / "streamlit_app"))

from ip_utils import ip_distance, normalize_ip


class TestIpDistance:
    def test_same_ip_returns_zero(self):
        assert ip_distance("10.0.0.1", "10.0.0.1") == 0

    def test_adjacent_ips(self):
        assert ip_distance("10.0.0.1", "10.0.0.2") == 1

    def test_larger_distance(self):
        assert ip_distance("10.0.0.0", "10.0.1.0") == 256

    def test_order_independent(self):
        assert ip_distance("10.0.0.1", "10.0.0.5") == ip_distance("10.0.0.5", "10.0.0.1")

    def test_unspecified_address_is_not_a_distance_operand(self):
        assert ip_distance("0.0.0.0", "255.255.255.255") == -1

    def test_invalid_ip_returns_negative_one(self):
        assert ip_distance("not_an_ip", "10.0.0.1") == -1

    def test_empty_string_returns_negative_one(self):
        assert ip_distance("", "10.0.0.1") == -1

    def test_both_invalid_returns_negative_one(self):
        assert ip_distance("abc", "def") == -1

    def test_ipv6_returns_negative_one(self):
        assert ip_distance("::1", "::2") == -1


class TestNormalizeIp:
    def test_canonicalizes_ipv4_and_ipv6(self):
        assert normalize_ip(" 192.0.2.1 ") == "192.0.2.1"
        assert normalize_ip("2001:0db8:0:0::1") == "2001:db8::1"

    def test_rejects_all_unspecified_representations(self):
        for value in ("0.0.0.0", "::", "::0", "0:0:0:0:0:0:0:0"):
            assert normalize_ip(value) is None
