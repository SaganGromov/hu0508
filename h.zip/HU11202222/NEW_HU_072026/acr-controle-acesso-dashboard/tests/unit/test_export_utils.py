"""Unit tests for export_utils.py

Streamlit functions (download_button, columns, etc.) are mocked to test the
pure-logic parts: CSV generation, filename building, and audit dispatching.
"""

import hashlib
import os
import sys
from pathlib import Path
from unittest.mock import patch, Mock, MagicMock

import pandas as pd

# We need to mock streamlit before importing export_utils
mock_st = MagicMock()
mock_st.session_state = {}
sys.modules["streamlit"] = mock_st

# Also mock the audit_service import as it appears at module level
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "acr_controle_acesso_dashboard" / "streamlit_app"))

import export_utils
# Ensure export_utils references our mock even if it was already imported
export_utils.st = mock_st


class TestToCsvBytes:
    def test_returns_bytes(self):
        df = pd.DataFrame({"a": [1, 2], "b": [3, 4]})
        result = export_utils.to_csv_bytes(df)
        assert isinstance(result, bytes)

    def test_csv_content(self):
        df = pd.DataFrame({"name": ["Alice", "Bob"], "age": [30, 25]})
        result = export_utils.to_csv_bytes(df)
        text = result.decode("utf-8")
        assert "name,age" in text
        assert "Alice,30" in text
        assert "Bob,25" in text

    def test_empty_dataframe(self):
        df = pd.DataFrame()
        result = export_utils.to_csv_bytes(df)
        assert isinstance(result, bytes)


class TestSetExportAuditContext:
    def test_sets_context_in_session_state(self):
        mock_st.session_state = {}
        export_utils.set_export_audit_context("user1", "page1")
        ctx = mock_st.session_state["_export_audit_context"]
        assert ctx["user_id"] == "user1"
        assert ctx["page"] == "page1"
        assert ctx["details"] == {}

    def test_sets_context_with_details(self):
        mock_st.session_state = {}
        export_utils.set_export_audit_context("user1", "page1", details={"key": "val"})
        ctx = mock_st.session_state["_export_audit_context"]
        assert ctx["details"] == {"key": "val"}


class TestBuildUniqueCsvFilename:
    def test_contains_original_stem(self):
        result = export_utils._build_unique_csv_filename("report.csv", b"data")
        assert result.startswith("report_")
        assert result.endswith(".csv")

    def test_adds_csv_extension_if_missing(self):
        result = export_utils._build_unique_csv_filename("report", b"data")
        assert result.endswith(".csv")

    def test_preserves_non_csv_extension(self):
        result = export_utils._build_unique_csv_filename("report.tsv", b"data")
        assert result.endswith(".tsv")

    def test_unique_per_call(self):
        r1 = export_utils._build_unique_csv_filename("report.csv", b"data1")
        r2 = export_utils._build_unique_csv_filename("report.csv", b"data2")
        assert r1 != r2

    def test_has_timestamp_and_hash(self):
        result = export_utils._build_unique_csv_filename("report.csv", b"data")
        # Format: stem_TIMESTAMP_HASH.ext
        parts = result.replace(".csv", "").split("_")
        assert len(parts) >= 3  # report + timestamp + hash


class TestAuditCsvExport:
    def test_records_export(self):
        mock_st.session_state = {
            "_export_audit_context": {
                "user_id": "user1",
                "page": "relatorio",
                "details": {},
            }
        }
        df = pd.DataFrame({"a": [1, 2, 3]})
        with patch.object(export_utils, "record_csv_export") as mock_record:
            export_utils._audit_csv_export("Test Export", "test.csv", df)
            mock_record.assert_called_once()
            call_kwargs = mock_record.call_args[1]
            assert call_kwargs["user_id"] == "user1"
            assert call_kwargs["page"] == "relatorio"
            assert call_kwargs["row_count"] == 3
            assert call_kwargs["column_count"] == 1

    def test_skips_when_no_context(self):
        mock_st.session_state = {}
        df = pd.DataFrame({"a": [1]})
        with patch.object(export_utils, "record_csv_export") as mock_record:
            export_utils._audit_csv_export("Test", "test.csv", df)
            mock_record.assert_not_called()

    def test_skips_when_user_empty(self):
        mock_st.session_state = {
            "_export_audit_context": {
                "user_id": "",
                "page": "relatorio",
                "details": {},
            }
        }
        df = pd.DataFrame({"a": [1]})
        with patch.object(export_utils, "record_csv_export") as mock_record:
            export_utils._audit_csv_export("Test", "test.csv", df)
            mock_record.assert_not_called()

    def test_merges_details(self):
        mock_st.session_state = {
            "_export_audit_context": {
                "user_id": "user1",
                "page": "relatorio",
                "details": {"base_key": "base_val"},
            }
        }
        df = pd.DataFrame({"a": [1]})
        with patch.object(export_utils, "record_csv_export") as mock_record:
            export_utils._audit_csv_export("Test", "test.csv", df, details={"extra": "val"})
            mock_record.assert_called_once()
            details = mock_record.call_args[1]["details"]
            assert details["base_key"] == "base_val"
            assert details["extra"] == "val"


class TestRenderCsvDownloadButton:
    def test_skips_none_df(self):
        mock_st.download_button.reset_mock()
        export_utils.render_csv_download_button("Export", None, "file.csv")
        mock_st.download_button.assert_not_called()

    def test_skips_empty_df(self):
        mock_st.download_button.reset_mock()
        export_utils.render_csv_download_button("Export", pd.DataFrame(), "file.csv")
        mock_st.download_button.assert_not_called()

    def test_calls_download_button(self):
        mock_st.download_button.reset_mock()
        mock_st.download_button.return_value = False
        df = pd.DataFrame({"a": [1]})
        export_utils.render_csv_download_button("Export", df, "file.csv")
        mock_st.download_button.assert_called_once()


class TestRenderCsvDownloads:
    def test_skips_when_all_empty(self):
        mock_st.markdown.reset_mock()
        export_utils.render_csv_downloads([
            ("Label", pd.DataFrame(), "file.csv"),
            ("Label2", None, "file2.csv"),
        ])
        mock_st.markdown.assert_not_called()

    def test_renders_valid_exports(self):
        mock_st.markdown.reset_mock()
        mock_st.columns.return_value = [MagicMock(), MagicMock(), MagicMock()]
        mock_st.download_button.return_value = False
        df = pd.DataFrame({"a": [1]})
        export_utils.render_csv_downloads([
            ("Label", df, "file.csv"),
        ])
        mock_st.markdown.assert_called_once()
