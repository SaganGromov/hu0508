"""Unit tests for the pure aggregation helpers used by the Sumário Negocial page.

The page itself imports ``streamlit`` and is not covered by unit tests, but
all of its business logic lives in ``backtest_bundle`` (pure Python), and
this module tests that thoroughly.
"""

import io
import json
import sys
from pathlib import Path
from unittest.mock import MagicMock

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from streamlit_mock_helper import install_streamlit_mock  # noqa: E402

install_streamlit_mock()
sys.modules.setdefault("requests", MagicMock())

sys.path.insert(
    0,
    str(Path(__file__).resolve().parents[2] / "acr_controle_acesso_dashboard" / "streamlit_app"),
)

from backtest_bundle import (
    RULE_ORDER,
    affected_users_by_rule,
    all_flagged_users,
    build_rule_user_matrix,
    load_latest_bundle,
    redundancy_count,
    rule_case,
    rule_flagged_counts,
    rule_labels_from_matrix,
    top_reincident_users,
)


def test_latest_bundle_ignores_legacy_results(tmp_path):
    (tmp_path / "results_bundle_20260728_120000.json").write_text(
        json.dumps({"bundle_version": 2, "summary": {"cases": []}}),
        encoding="utf-8",
    )
    (tmp_path / "results_bundle_20260729_120000.json").write_text(
        json.dumps({"bundle_version": 1, "summary": {"cases": []}}),
        encoding="utf-8",
    )
    path, bundle = load_latest_bundle(str(tmp_path))
    assert Path(path).name == "results_bundle_20260728_120000.json"
    assert bundle["bundle_version"] == 2


def _fake_bundle() -> dict:
    """Bundle mínimo com R1 e R5 sinalizados (usuários pseudonimizados)."""
    return {
        "parameters": {"start": "2026-07-18 00:00:00", "end": "2026-07-20 00:00:00"},
        "summary": {
            "metrics": {"total_events_analyzed": 100, "total_users_analyzed": 30},
            "cases": [
                {
                    "name": "ips_distintos_acima_do_limite",
                    "status": "ok",
                    "count": 2,
                    "sample": [
                        {"USER_KEY": "U-aaa", "DISTINCT_CD_END_LGC_OGM": 3, "EVENTS": 4},
                        {"USER_KEY": "U-bbb", "DISTINCT_CD_END_LGC_OGM": 5, "EVENTS": 5},
                    ],
                },
                {
                    "name": "hostnames_distintos_acima_do_limite",
                    "status": "ok",
                    "count": 0,
                    "sample": [],
                },
                {
                    "name": "dispositivos_distintos_acima_do_limite",
                    "status": "ok",
                    "count": 0,
                    "sample": [],
                },
                {
                    "name": "logins_diarios_acima_do_limite",
                    "status": "ok",
                    "count": 0,
                    "sample": [],
                },
                {
                    "name": "vpn_ativa_com_login_em_rede_fisica_mta",
                    "status": "ok",
                    "count": 3,
                    "sample": [
                        {
                            "USER_KEY": "U-aaa",
                            "VPN_TS": "2026-07-19 12:00:00",
                            "MTA_TS": "2026-07-19 12:05:00",
                        },
                        {
                            "USER_KEY": "U-ccc",
                            "VPN_TS": "2026-07-19 13:00:00",
                            "MTA_TS": "2026-07-19 13:05:00",
                        },
                        {
                            "USER_KEY": "U-ccc",
                            "VPN_TS": "2026-07-19 14:30:00",
                            "MTA_TS": "2026-07-19 14:32:00",
                        },
                    ],
                },
            ],
        },
        "rules": {
            "R1": {"flagged": 2, "flagged_users": 2},
            "R2": {"flagged": 0, "flagged_users": 0},
            "R3": {"flagged": 0, "flagged_users": 0},
            "R4": {"flagged": 0, "flagged_users": 0},
            "R5": {"flagged": 3, "flagged_users": 2, "status": "ok"},
        },
    }


class TestRuleCase:
    def test_lookup_by_rule(self):
        bundle = _fake_bundle()
        assert rule_case(bundle, "R1")["name"] == "ips_distintos_acima_do_limite"
        assert rule_case(bundle, "R5")["count"] == 3
        assert rule_case(bundle, "R2")["sample"] == []


class TestFlaggedCounts:
    def test_counts_shape(self):
        counts = rule_flagged_counts(_fake_bundle())
        assert set(counts.keys()) == set(RULE_ORDER)
        assert counts["R1"] == {"events": 2, "users": 2}
        assert counts["R5"] == {"events": 3, "users": 2}
        assert counts["R2"] == {"events": 0, "users": 0}


class TestAffectedUsers:
    def test_r5_aggregates_by_user(self):
        by_rule = affected_users_by_rule(_fake_bundle())
        r5 = {row["USER_KEY"]: row for row in by_rule["R5"]}
        assert r5["U-ccc"]["occurrences"] == 2
        assert r5["U-aaa"]["occurrences"] == 1
        assert r5["U-ccc"]["last_seen"] == "2026-07-19 14:30:00"


class TestMatrix:
    def test_matrix_shape_and_totals(self):
        matrix = build_rule_user_matrix(_fake_bundle())
        by_user = {row["USER_KEY"]: row for row in matrix}
        assert set(by_user.keys()) == {"U-aaa", "U-bbb", "U-ccc"}
        # cada linha deve conter R1..R5 e total_regras
        for row in matrix:
            for rule in RULE_ORDER:
                assert rule in row
            assert row["total_regras"] == sum(row[rule] for rule in RULE_ORDER)
        # U-aaa aparece em R1 e R5 → total 2
        assert by_user["U-aaa"]["R1"] == 1
        assert by_user["U-aaa"]["R5"] == 1
        assert by_user["U-aaa"]["total_regras"] == 2
        # U-bbb só R1
        assert by_user["U-bbb"]["total_regras"] == 1
        # U-ccc só R5
        assert by_user["U-ccc"]["R5"] == 1
        assert by_user["U-ccc"]["total_regras"] == 1

    def test_top_reincident_and_redundancy(self):
        bundle = _fake_bundle()
        rein = top_reincident_users(bundle)
        assert [r["USER_KEY"] for r in rein] == ["U-aaa"]
        assert redundancy_count(bundle) == 1

    def test_unique_flagged_users(self):
        assert set(all_flagged_users(_fake_bundle())) == {"U-aaa", "U-bbb", "U-ccc"}

    def test_labels_string(self):
        matrix = build_rule_user_matrix(_fake_bundle())
        aaa = next(r for r in matrix if r["USER_KEY"] == "U-aaa")
        assert rule_labels_from_matrix(aaa) == "R1, R5"


class TestMatrixCsv:
    def test_matriz_csv_roundtrip(self):
        matrix = build_rule_user_matrix(_fake_bundle())
        df = pd.DataFrame(matrix)
        buf = io.StringIO()
        df.to_csv(buf, index=False)
        parsed = pd.read_csv(io.StringIO(buf.getvalue()))
        for col in ("USER_KEY", "total_regras", *RULE_ORDER):
            assert col in parsed.columns
        # três usuários únicos
        assert len(parsed) == 3
