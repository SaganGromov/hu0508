"""Unit tests for auth_token.py"""

import hashlib
import hmac
import sys
import time
from pathlib import Path
from unittest.mock import patch, MagicMock

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "acr_controle_acesso_dashboard" / "streamlit_app"))

import auth_token


def _make_csrf_nonce(token: str, secret: str = "test-secret") -> str:
    """Helper: compute expected CSRF nonce for a token."""
    return hmac.new(secret.encode(), (token + ":csrf").encode(), hashlib.sha256).hexdigest()


class TestGetSecret:
    def test_returns_secret_when_set(self, monkeypatch):
        monkeypatch.setenv("SESSION_SECRET", "my-secret-key")
        assert auth_token._get_secret() == "my-secret-key"

    def test_strips_whitespace(self, monkeypatch):
        monkeypatch.setenv("SESSION_SECRET", "  my-secret  ")
        assert auth_token._get_secret() == "my-secret"

    def test_raises_when_empty(self, monkeypatch):
        monkeypatch.setenv("SESSION_SECRET", "")
        import pytest
        with pytest.raises(RuntimeError, match="SESSION_SECRET"):
            auth_token._get_secret()

    def test_raises_when_missing(self, monkeypatch):
        monkeypatch.delenv("SESSION_SECRET", raising=False)
        import pytest
        with pytest.raises(RuntimeError, match="SESSION_SECRET"):
            auth_token._get_secret()


class TestGenerateToken:
    def test_generates_valid_token(self, monkeypatch):
        monkeypatch.setenv("SESSION_SECRET", "test-secret")
        token = auth_token.generate_token("F1234567")
        parts = token.split(":")
        assert len(parts) == 3
        assert parts[0] == "F1234567"
        # expiry should be in the future
        assert int(parts[1]) > time.time()

    def test_token_has_correct_hmac(self, monkeypatch):
        monkeypatch.setenv("SESSION_SECRET", "test-secret")
        token = auth_token.generate_token("F1234567")
        user_id, expires_str, sig = token.split(":")
        expected = hmac.new(
            "test-secret".encode(), f"{user_id}:{expires_str}".encode(), hashlib.sha256
        ).hexdigest()
        assert sig == expected

    def test_rejects_invalid_user_id(self, monkeypatch):
        monkeypatch.setenv("SESSION_SECRET", "test-secret")
        import pytest
        with pytest.raises(ValueError):
            auth_token.generate_token("'; DROP TABLE users; --")


class TestValidateToken:
    def test_validates_good_token(self, monkeypatch):
        monkeypatch.setenv("SESSION_SECRET", "test-secret")
        token = auth_token.generate_token("F1234567")
        assert auth_token.validate_token(token) == "F1234567"

    def test_rejects_empty_token(self, monkeypatch):
        monkeypatch.setenv("SESSION_SECRET", "test-secret")
        assert auth_token.validate_token("") is None

    def test_rejects_malformed_token(self, monkeypatch):
        monkeypatch.setenv("SESSION_SECRET", "test-secret")
        assert auth_token.validate_token("only-two:parts") is None

    def test_rejects_expired_token(self, monkeypatch):
        monkeypatch.setenv("SESSION_SECRET", "test-secret")
        # Create a token that expired 1 second ago
        expires = int(time.time()) - 1
        payload = f"F1234567:{expires}"
        sig = hmac.new("test-secret".encode(), payload.encode(), hashlib.sha256).hexdigest()
        token = f"{payload}:{sig}"
        assert auth_token.validate_token(token) is None

    def test_rejects_wrong_signature(self, monkeypatch):
        monkeypatch.setenv("SESSION_SECRET", "test-secret")
        expires = int(time.time()) + 3600
        token = f"F1234567:{expires}:badsignature"
        assert auth_token.validate_token(token) is None

    def test_rejects_non_numeric_expiry(self, monkeypatch):
        monkeypatch.setenv("SESSION_SECRET", "test-secret")
        assert auth_token.validate_token("user:notanumber:sig") is None

    def test_returns_none_when_secret_missing(self, monkeypatch):
        monkeypatch.delenv("SESSION_SECRET", raising=False)
        assert auth_token.validate_token("user:12345:sig") is None

    def test_rejects_user_id_with_invalid_chars(self, monkeypatch):
        monkeypatch.setenv("SESSION_SECRET", "test-secret")
        expires = int(time.time()) + 3600
        payload = "user';--:{}".format(expires)
        sig = hmac.new("test-secret".encode(), payload.encode(), hashlib.sha256).hexdigest()
        assert auth_token.validate_token(f"{payload}:{sig}") is None

    def test_roundtrip_different_users(self, monkeypatch):
        monkeypatch.setenv("SESSION_SECRET", "test-secret")
        for user in ("F1234567", "F9999999", "admin"):
            token = auth_token.generate_token(user)
            assert auth_token.validate_token(token) == user


class TestTokenTTL:
    def test_default_ttl(self, monkeypatch):
        monkeypatch.setenv("AUTH_TOKEN_TTL", "86400")
        # Reimport to pick up env
        import importlib
        importlib.reload(auth_token)
        monkeypatch.setenv("SESSION_SECRET", "test-secret")
        token = auth_token.generate_token("F1234567")
        _, expires_str, _ = token.split(":")
        expires = int(expires_str)
        # Should be approximately 86400 seconds from now
        assert abs(expires - time.time() - 86400) < 5


class TestReadStreamlitContextHeaders:
    def test_returns_empty_when_streamlit_not_available(self, monkeypatch):
        # Ensure streamlit import fails
        import importlib
        monkeypatch.setitem(sys.modules, "streamlit", None)
        result = auth_token._read_streamlit_context_headers()
        assert result == {}

    def test_returns_empty_when_no_context(self, monkeypatch):
        mock_st = type(sys)("streamlit")
        mock_st.context = None
        monkeypatch.setitem(sys.modules, "streamlit", mock_st)
        result = auth_token._read_streamlit_context_headers()
        assert result == {}

    def test_returns_headers_dict(self, monkeypatch):
        mock_st = type(sys)("streamlit")
        mock_headers = {"Cookie": "test=value", "Host": "localhost"}

        class MockContext:
            headers = mock_headers

        mock_st.context = MockContext()
        monkeypatch.setitem(sys.modules, "streamlit", mock_st)
        result = auth_token._read_streamlit_context_headers()
        assert result == {"cookie": "test=value", "host": "localhost"}


class TestGenerateCsrfNonce:
    def test_generates_deterministic_nonce(self, monkeypatch):
        monkeypatch.setenv("SESSION_SECRET", "test-secret")
        token = auth_token.generate_token("F1234567")
        nonce1 = auth_token.generate_csrf_nonce(token)
        nonce2 = auth_token.generate_csrf_nonce(token)
        assert nonce1 == nonce2
        assert len(nonce1) == 64

    def test_different_tokens_produce_different_nonces(self, monkeypatch):
        monkeypatch.setenv("SESSION_SECRET", "test-secret")
        t1 = auth_token.generate_token("F1234567")
        t2 = auth_token.generate_token("F9999999")
        assert auth_token.generate_csrf_nonce(t1) != auth_token.generate_csrf_nonce(t2)


class TestReadCsrfQueryParam:
    def test_returns_empty_when_streamlit_not_available(self, monkeypatch):
        monkeypatch.setitem(sys.modules, "streamlit", None)
        assert auth_token._read_csrf_query_param() == ""

    def test_returns_nonce_from_query_params(self, monkeypatch):
        nonce = "a" * 64
        mock_st = type(sys)("streamlit")
        mock_st.query_params = {"csrf_nonce": nonce}
        monkeypatch.setitem(sys.modules, "streamlit", mock_st)
        assert auth_token._read_csrf_query_param() == nonce

    def test_rejects_invalid_nonce_format(self, monkeypatch):
        mock_st = type(sys)("streamlit")
        mock_st.query_params = {"csrf_nonce": "not-a-hex-nonce"}
        monkeypatch.setitem(sys.modules, "streamlit", mock_st)
        assert auth_token._read_csrf_query_param() == ""

    def test_returns_empty_when_param_missing(self, monkeypatch):
        mock_st = type(sys)("streamlit")
        mock_st.query_params = {}
        monkeypatch.setitem(sys.modules, "streamlit", mock_st)
        assert auth_token._read_csrf_query_param() == ""


class TestReadStreamlitAuthCookie:
    def test_returns_empty_when_no_cookie(self, monkeypatch):
        monkeypatch.setattr(auth_token, "_read_streamlit_context_headers", lambda: {})
        assert auth_token._read_streamlit_auth_cookie() == ""

    def test_returns_empty_when_cookie_header_empty(self, monkeypatch):
        monkeypatch.setattr(auth_token, "_read_streamlit_context_headers", lambda: {"cookie": ""})
        assert auth_token._read_streamlit_auth_cookie() == ""

    def test_extracts_auth_cookie_with_origin(self, monkeypatch):
        monkeypatch.setenv("SESSION_SECRET", "test-secret")
        cookie_val = "user1:9999999999:" + "a" * 64
        csrf_nonce = _make_csrf_nonce(cookie_val)
        monkeypatch.setattr(
            auth_token, "_read_streamlit_context_headers",
            lambda: {"cookie": f"dashboard_streamlit_auth={cookie_val}; other=val",
                     "host": "myapp.example.com", "origin": "https://myapp.example.com"}
        )
        monkeypatch.setattr(auth_token, "_read_csrf_query_param", lambda: csrf_nonce)
        assert auth_token._read_streamlit_auth_cookie() == cookie_val

    def test_extracts_auth_cookie_with_referer(self, monkeypatch):
        monkeypatch.setenv("SESSION_SECRET", "test-secret")
        cookie_val = "user1:9999999999:" + "a" * 64
        csrf_nonce = _make_csrf_nonce(cookie_val)
        monkeypatch.setattr(
            auth_token, "_read_streamlit_context_headers",
            lambda: {"cookie": f"dashboard_streamlit_auth={cookie_val}; other=val",
                     "host": "myapp.example.com", "referer": "https://myapp.example.com/page"}
        )
        monkeypatch.setattr(auth_token, "_read_csrf_query_param", lambda: csrf_nonce)
        assert auth_token._read_streamlit_auth_cookie() == cookie_val

    def test_rejects_auth_cookie_with_sql_payload(self, monkeypatch):
        monkeypatch.setenv("SESSION_SECRET", "test-secret")
        monkeypatch.setattr(
            auth_token, "_read_streamlit_context_headers",
            lambda: {"cookie": "dashboard_streamlit_auth=\"user'; DROP TABLE audit; --\"",
                     "host": "myapp.example.com", "origin": "https://myapp.example.com"}
        )
        monkeypatch.setattr(auth_token, "_read_csrf_query_param", lambda: "a" * 64)
        assert auth_token._read_streamlit_auth_cookie() == ""

    def test_returns_empty_when_auth_cookie_missing(self, monkeypatch):
        monkeypatch.setenv("SESSION_SECRET", "test-secret")
        monkeypatch.setattr(
            auth_token, "_read_streamlit_context_headers",
            lambda: {"cookie": "other=val",
                     "host": "myapp.example.com", "origin": "https://myapp.example.com"}
        )
        monkeypatch.setattr(auth_token, "_read_csrf_query_param", lambda: "a" * 64)
        assert auth_token._read_streamlit_auth_cookie() == ""

    def test_returns_empty_on_malformed_cookie(self, monkeypatch):
        monkeypatch.setenv("SESSION_SECRET", "test-secret")
        monkeypatch.setattr(
            auth_token, "_read_streamlit_context_headers",
            lambda: {"cookie": "\x00\x01\x02",
                     "host": "myapp.example.com", "origin": "https://myapp.example.com"}
        )
        monkeypatch.setattr(auth_token, "_read_csrf_query_param", lambda: "a" * 64)
        # Should not raise
        result = auth_token._read_streamlit_auth_cookie()
        assert isinstance(result, str)

    def test_rejects_cross_origin_request(self, monkeypatch):
        cookie_val = "user1:9999999999:" + "a" * 64
        monkeypatch.setattr(
            auth_token, "_read_streamlit_context_headers",
            lambda: {"cookie": f"dashboard_streamlit_auth={cookie_val}",
                     "host": "myapp.example.com", "origin": "https://evil.com"}
        )
        assert auth_token._read_streamlit_auth_cookie() == ""

    def test_rejects_cross_origin_referer(self, monkeypatch):
        cookie_val = "user1:9999999999:" + "a" * 64
        monkeypatch.setattr(
            auth_token, "_read_streamlit_context_headers",
            lambda: {"cookie": f"dashboard_streamlit_auth={cookie_val}",
                     "host": "myapp.example.com", "referer": "https://evil.com/page"}
        )
        assert auth_token._read_streamlit_auth_cookie() == ""

    def test_rejects_when_no_origin_or_referer(self, monkeypatch):
        cookie_val = "user1:9999999999:" + "a" * 64
        monkeypatch.setattr(
            auth_token, "_read_streamlit_context_headers",
            lambda: {"cookie": f"dashboard_streamlit_auth={cookie_val}",
                     "host": "myapp.example.com"}
        )
        assert auth_token._read_streamlit_auth_cookie() == ""

    def test_rejects_when_csrf_nonce_missing(self, monkeypatch):
        monkeypatch.setenv("SESSION_SECRET", "test-secret")
        cookie_val = "user1:9999999999:" + "a" * 64
        monkeypatch.setattr(
            auth_token, "_read_streamlit_context_headers",
            lambda: {"cookie": f"dashboard_streamlit_auth={cookie_val}",
                     "host": "myapp.example.com", "origin": "https://myapp.example.com"}
        )
        monkeypatch.setattr(auth_token, "_read_csrf_query_param", lambda: "")
        assert auth_token._read_streamlit_auth_cookie() == ""

    def test_rejects_when_csrf_nonce_wrong(self, monkeypatch):
        monkeypatch.setenv("SESSION_SECRET", "test-secret")
        cookie_val = "user1:9999999999:" + "a" * 64
        monkeypatch.setattr(
            auth_token, "_read_streamlit_context_headers",
            lambda: {"cookie": f"dashboard_streamlit_auth={cookie_val}",
                     "host": "myapp.example.com", "origin": "https://myapp.example.com"}
        )
        monkeypatch.setattr(auth_token, "_read_csrf_query_param", lambda: "b" * 64)
        assert auth_token._read_streamlit_auth_cookie() == ""


class TestResolveAuthenticatedUser:
    def test_returns_user_when_valid(self, monkeypatch):
        monkeypatch.setenv("SESSION_SECRET", "test-secret")
        token = auth_token.generate_token("F1234567")
        monkeypatch.setattr(auth_token, "_read_streamlit_auth_cookie", lambda: token)
        assert auth_token.resolve_authenticated_user() == "F1234567"

    def test_returns_none_when_no_cookie(self, monkeypatch):
        monkeypatch.setattr(auth_token, "_read_streamlit_auth_cookie", lambda: "")
        assert auth_token.resolve_authenticated_user() is None
