"""Progresso monotônico, fases indeterminadas, ETA e log estruturado."""

import json
import logging
from datetime import datetime

import pytest

from backtest_vpn.clock import FixedClock
from backtest_vpn.progress import (
    INDETERMINATE_LABEL,
    PHASE_CLAIMED,
    PHASE_DONE,
    PHASE_EVALUATING_RULES,
    PHASE_NORMALIZING,
    PHASE_PUBLISHING,
    PHASE_QUERYING,
    PHASE_VALIDATING_CONFIG,
    PHASE_WEIGHTS,
    EtaEstimator,
    ProgressReporter,
    format_duration_pt,
    queued_progress_payload,
    rebuild_snapshot,
    sanitize_log_value,
)


class Recorder(logging.Handler):
    def __init__(self):
        super().__init__(level=logging.DEBUG)
        self.records = []

    def emit(self, record):
        self.records.append(record)

    @property
    def payloads(self):
        out = []
        for record in self.records:
            message = record.getMessage()
            if "backtest_progress " in message:
                out.append(json.loads(message.split("backtest_progress ", 1)[1]))
        return out


@pytest.fixture
def clock():
    return FixedClock(datetime(2026, 7, 30, 3, 0, 0))


@pytest.fixture
def recorder():
    handler = Recorder()
    logger = logging.getLogger("test.backtest.progress")
    logger.handlers = [handler]
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    return handler, logger


def reporter(clock, logger, **kwargs):
    snapshots = []
    options = dict(
        job_id="bt-1", trigger="scheduled", attempt=1, clock=clock,
        sink=snapshots.append, logger=logger,
        static_fields={"application_version": "2.2.0", "worker": "pod-a"},
    )
    options.update(kwargs)
    return ProgressReporter(**options), snapshots


class TestPhaseWeights:
    def test_weights_sum_to_one_hundred(self):
        assert sum(PHASE_WEIGHTS.values()) == 100


class TestMonotonicity:
    def test_overall_percent_never_decreases(self, clock, recorder):
        handler, logger = recorder
        progress, snapshots = reporter(clock, logger)
        progress.start_phase(PHASE_CLAIMED, total_units=1)
        progress.advance(1)
        progress.start_phase(PHASE_EVALUATING_RULES, total_units=4)
        for _ in range(4):
            clock.advance(1)
            progress.advance(1)
        percents = [item.overall_percent for item in snapshots]
        assert percents == sorted(percents)

    def test_going_back_to_an_earlier_phase_is_ignored(self, clock, recorder):
        handler, logger = recorder
        progress, snapshots = reporter(clock, logger)
        progress.start_phase(PHASE_EVALUATING_RULES, total_units=2)
        before = progress.snapshot.phase
        progress.start_phase(PHASE_VALIDATING_CONFIG, total_units=1)
        assert progress.snapshot.phase == before

    def test_negative_advance_is_rejected(self, clock, recorder):
        handler, logger = recorder
        progress, _ = reporter(clock, logger)
        progress.start_phase(PHASE_EVALUATING_RULES, total_units=2)
        with pytest.raises(ValueError, match="não pode retroceder"):
            progress.advance(-1)

    def test_set_position_never_regresses(self, clock, recorder):
        handler, logger = recorder
        progress, _ = reporter(clock, logger)
        progress.start_phase(PHASE_NORMALIZING, total_units=10)
        progress.set_position(7)
        progress.set_position(3)
        assert progress.snapshot.completed_units == 7

    def test_completed_units_are_capped_at_total(self, clock, recorder):
        handler, logger = recorder
        progress, _ = reporter(clock, logger)
        progress.start_phase(PHASE_NORMALIZING, total_units=3)
        progress.advance(10)
        assert progress.snapshot.completed_units == 3

    def test_percent_never_reaches_hundred_before_publication(self, clock, recorder):
        handler, logger = recorder
        progress, snapshots = reporter(clock, logger)
        for phase in (PHASE_CLAIMED, PHASE_EVALUATING_RULES, PHASE_PUBLISHING):
            progress.start_phase(phase, total_units=1)
            progress.advance(1)
        assert max(item.overall_percent for item in snapshots) < 100.0
        progress.finish()
        assert progress.snapshot.overall_percent == 100.0
        assert progress.snapshot.phase == PHASE_DONE

    def test_unknown_phase_is_rejected(self, clock, recorder):
        handler, logger = recorder
        progress, _ = reporter(clock, logger)
        with pytest.raises(ValueError, match="Fase de progresso desconhecida"):
            progress.start_phase("FASE_INEXISTENTE")


class TestIndeterminatePhases:
    def test_indeterminate_phase_reports_no_percentage(self, clock, recorder):
        handler, logger = recorder
        progress, snapshots = reporter(clock, logger)
        progress.start_phase(PHASE_QUERYING, total_units=None)
        snapshot = snapshots[-1]
        assert snapshot.indeterminate is True
        assert snapshot.phase_percent is None
        assert snapshot.as_payload()["indeterminate_label"] == INDETERMINATE_LABEL

    def test_setting_total_leaves_indeterminate_state(self, clock, recorder):
        handler, logger = recorder
        progress, snapshots = reporter(clock, logger)
        progress.start_phase(PHASE_QUERYING, total_units=None)
        progress.set_total(50)
        assert snapshots[-1].indeterminate is False
        assert snapshots[-1].total_units == 50


class TestFriendlyProgress:
    def test_initial_job_is_friendly_and_visible_immediately_in_queue(self):
        payload = queued_progress_payload(
            job_id="bt-inicial",
            trigger="initial",
            updated_at="2026-07-30T03:00:00-03:00",
        )
        assert payload["friendly_summary"] == "Primeira análise após a implantação: pedido recebido"
        assert "recebido" in payload["friendly_detail"]
        assert payload["progress_bar_indeterminate"] is True
        assert payload["progress_bar_value"] is None

    def test_snapshot_exposes_plain_language_and_accessible_bar_value(self, clock, recorder):
        _handler, logger = recorder
        progress, _snapshots = reporter(clock, logger)
        progress.start_phase(PHASE_EVALUATING_RULES, total_units=4)
        progress.advance(2, rule_id="R4")
        payload = progress.snapshot.as_payload()
        assert "Estamos verificando" in payload["friendly_detail"]
        assert "R4" in payload["friendly_detail"]
        assert payload["progress_bar_indeterminate"] is False
        assert isinstance(payload["progress_bar_value"], float)

    @pytest.mark.parametrize(
        "seconds,expected",
        [(0, "menos de 1 minuto"), (120, "cerca de 2 minutos"), (3900, "cerca de 1 h 5 min")],
    )
    def test_duration_is_human_readable(self, seconds, expected):
        assert format_duration_pt(seconds) == expected


class TestEta:
    def test_eta_requires_minimum_samples(self, clock):
        estimator = EtaEstimator(clock)
        for index in range(1, 3):
            clock.advance(1)
            estimate = estimator.observe(PHASE_EVALUATING_RULES, index, 100)
        assert estimate.seconds_remaining is None
        assert "amostras insuficientes" in estimate.suppressed_reason

    def test_eta_appears_after_enough_samples_and_progress(self, clock):
        estimator = EtaEstimator(clock)
        estimate = None
        for index in range(1, 21):
            clock.advance(1)
            estimate = estimator.observe(PHASE_EVALUATING_RULES, index, 100)
        assert estimate.seconds_remaining is not None
        assert estimate.is_estimate is True
        assert 60 <= estimate.seconds_remaining <= 100
        assert estimate.samples >= 3

    def test_eta_is_suppressed_below_minimum_progress(self, clock):
        estimator = EtaEstimator(clock)
        estimate = None
        for index in range(1, 5):
            clock.advance(1)
            estimate = estimator.observe(PHASE_EVALUATING_RULES, index, 1000)
        assert estimate.seconds_remaining is None
        assert "progresso insuficiente" in estimate.suppressed_reason

    def test_eta_is_none_for_indeterminate_total(self, clock):
        estimator = EtaEstimator(clock)
        for index in range(1, 10):
            clock.advance(1)
            estimate = estimator.observe(PHASE_QUERYING, index, None)
        assert estimate.seconds_remaining is None
        assert "indeterminada" in estimate.suppressed_reason

    def test_zero_total_work_completes_immediately(self, clock):
        estimator = EtaEstimator(clock)
        estimate = estimator.observe(PHASE_EVALUATING_RULES, 0, 0)
        assert estimate.seconds_remaining == 0.0

    def test_eta_resets_when_phase_changes(self, clock):
        estimator = EtaEstimator(clock)
        for index in range(1, 21):
            clock.advance(1)
            estimator.observe(PHASE_NORMALIZING, index, 100)
        clock.advance(1)
        estimate = estimator.observe(PHASE_EVALUATING_RULES, 1, 100)
        assert estimate.seconds_remaining is None
        assert estimate.samples <= 1

    def test_very_fast_tasks_do_not_produce_infinite_throughput(self, clock):
        estimator = EtaEstimator(clock)
        estimate = None
        for index in range(1, 20):
            estimate = estimator.observe(PHASE_EVALUATING_RULES, index, 100)
        # Sem tempo mensurável, nenhuma estimativa é publicada e nada estoura.
        assert estimate.seconds_remaining is None
        assert estimate.throughput_per_second is None

    def test_very_slow_tasks_are_clamped(self, clock):
        estimator = EtaEstimator(clock)
        estimate = None
        for index in range(1, 6):
            clock.advance(10_000_000)
            estimate = estimator.observe(PHASE_EVALUATING_RULES, index, 20)
        assert estimate.seconds_remaining is not None
        # Estimativa bruta seria de anos; é limitada a 30 dias e nunca estoura.
        assert estimate.seconds_remaining == 30 * 24 * 3600

    def test_eta_never_negative(self, clock):
        estimator = EtaEstimator(clock)
        estimate = None
        for index in range(1, 21):
            clock.advance(1)
            estimate = estimator.observe(PHASE_EVALUATING_RULES, index, 20)
        assert estimate.seconds_remaining >= 0


class TestElapsedAndThroughput:
    def test_elapsed_uses_injected_clock(self, clock, recorder):
        handler, logger = recorder
        progress, _ = reporter(clock, logger)
        progress.start_phase(PHASE_EVALUATING_RULES, total_units=2)
        clock.advance(42)
        progress.advance(1)
        assert progress.snapshot.elapsed_seconds == pytest.approx(42, abs=1)


class TestLogging:
    def test_phase_boundaries_are_always_logged(self, clock, recorder):
        handler, logger = recorder
        progress, _ = reporter(clock, logger, log_interval_seconds=10_000, log_percent_step=100)
        progress.start_phase(PHASE_CLAIMED, total_units=1)
        progress.start_phase(PHASE_EVALUATING_RULES, total_units=3)
        phases = [item["phase"] for item in handler.payloads]
        assert PHASE_CLAIMED in phases
        assert PHASE_EVALUATING_RULES in phases

    def test_routine_updates_are_throttled(self, clock, recorder):
        handler, logger = recorder
        progress, _ = reporter(clock, logger, log_interval_seconds=10_000, log_percent_step=100)
        progress.start_phase(PHASE_EVALUATING_RULES, total_units=100)
        before = len(handler.payloads)
        for _ in range(50):
            progress.advance(1)
        assert len(handler.payloads) == before

    def test_required_structured_fields_are_present(self, clock, recorder):
        handler, logger = recorder
        progress, _ = reporter(clock, logger)
        progress.start_phase(PHASE_EVALUATING_RULES, total_units=2, subphase="R1")
        payload = handler.payloads[-1]
        for field in (
            "updated_at", "started_at", "timezone", "application_version",
            "worker", "job_id", "attempt", "trigger", "phase", "phase_label",
            "subphase", "indeterminate", "completed_units", "total_units",
            "overall_percent", "elapsed_seconds", "eta_method", "eta_is_estimate",
            "counters", "occurrences_by_rule", "occurrences_by_severity",
        ):
            assert field in payload, field

    def test_sensitive_and_control_characters_never_reach_logs(self, clock, recorder):
        handler, logger = recorder
        progress, _ = reporter(clock, logger)
        progress.start_phase(
            PHASE_EVALUATING_RULES, total_units=1,
            message="linha1\ninjetada\r\x00 fim",
        )
        payload = handler.payloads[-1]
        assert "\n" not in payload["message"]
        assert "\r" not in payload["message"]
        assert "\x00" not in payload["message"]

    def test_counters_and_occurrence_totals_are_reported(self, clock, recorder):
        handler, logger = recorder
        progress, _ = reporter(clock, logger)
        progress.start_phase(PHASE_EVALUATING_RULES, total_units=2)
        progress.merge_counters({"input_rows": 10, "duplicate_rows": 2, "ignorado": "texto"})
        progress.record_occurrences("R1", ["MÉDIA", "MÉDIA"])
        progress.record_occurrences("R7", ["ALTA"])
        progress.advance(1, force_log=True)
        payload = handler.payloads[-1]
        assert payload["counters"]["input_rows"] == 10
        assert payload["counters"]["duplicate_rows"] == 2
        assert "ignorado" not in payload["counters"]
        assert payload["occurrences_by_rule"] == {"R1": 2, "R7": 1}
        assert payload["occurrences_by_severity"] == {"MÉDIA": 2, "ALTA": 1}

    def test_failure_and_cancellation_are_terminal_and_logged(self, clock, recorder):
        handler, logger = recorder
        progress, _ = reporter(clock, logger)
        progress.start_phase(PHASE_EVALUATING_RULES, total_units=1)
        progress.fail(message="DB2 indisponível")
        assert progress.snapshot.phase == "FALHOU"
        assert progress.snapshot.overall_percent < 100.0
        cancelled, _ = reporter(clock, logger)
        cancelled.start_phase(PHASE_EVALUATING_RULES, total_units=1)
        cancelled.cancel()
        assert cancelled.snapshot.phase == "CANCELADO"


class TestSnapshotRoundTrip:
    def test_snapshot_survives_serialization(self, clock, recorder):
        handler, logger = recorder
        progress, snapshots = reporter(clock, logger)
        progress.start_phase(PHASE_EVALUATING_RULES, total_units=5)
        clock.advance(2)
        progress.advance(2, rule_id="R4")
        payload = snapshots[-1].as_payload()
        restored = rebuild_snapshot(payload)
        assert restored.phase == PHASE_EVALUATING_RULES
        assert restored.completed_units == 2
        assert restored.current_rule == "R4"
        assert restored.as_payload()["eta_method"] == payload["eta_method"]


class TestSanitizer:
    @pytest.mark.parametrize(
        "raw,forbidden",
        [("a\nb", "\n"), ("a\rb", "\r"), ("a\x00b", "\x00"), ("a\x1bb", "\x1b")],
    )
    def test_control_characters_removed(self, raw, forbidden):
        assert forbidden not in sanitize_log_value(raw)

    def test_long_values_are_truncated(self):
        assert len(sanitize_log_value("x" * 5000)) <= 512

    def test_nested_structures_are_sanitized(self):
        out = sanitize_log_value({"a\nb": ["c\rd", {"e\x00f": "g"}]})
        serialized = json.dumps(out, ensure_ascii=False)
        for forbidden in ("\\n", "\\r", "\\u0000"):
            assert forbidden not in serialized
        # Quebras de linha viram espaço; o byte nulo é removido.
        assert list(out) == ["a b"]
        assert out["a b"][0] == "c d"
        assert out["a b"][1] == {"ef": "g"}
