"""Shared Streamlit mock setup for testing page modules."""

import importlib
import importlib.util
import sys
from unittest.mock import MagicMock


class StreamlitStopExecution(Exception):
    """Raised by mocked st.stop() to halt page-level execution."""
    pass


def _passthrough_decorator(*args, **kwargs):
    """Handle both @st.cache_data and @st.cache_data(ttl=300) usage patterns."""
    if args and callable(args[0]):
        return args[0]
    return lambda f: f


def _mock_columns(spec=3):
    """Return a list of MagicMock context managers matching the spec length."""
    if isinstance(spec, (list, tuple)):
        n = len(spec)
    elif isinstance(spec, int):
        n = spec
    else:
        n = 3
    return [MagicMock() for _ in range(n)]


def _mock_tabs(names):
    """Return a list of MagicMock context managers matching the tab count."""
    if isinstance(names, (list, tuple)):
        return [MagicMock() for _ in names]
    return [MagicMock() for _ in range(6)]


def create_streamlit_mock():
    """Create a fully configured Streamlit mock for page module imports."""
    mock_st = MagicMock()
    mock_st.session_state = {}
    mock_st.cache_data = _passthrough_decorator
    mock_st.cache_resource = _passthrough_decorator
    mock_st.fragment = _passthrough_decorator
    mock_st.text_input.return_value = ""
    mock_st.button.return_value = False
    mock_st.selectbox.return_value = ""
    mock_st.radio.return_value = ""
    mock_st.checkbox.return_value = False
    mock_st.number_input.return_value = 0
    mock_st.columns.side_effect = _mock_columns
    mock_st.tabs.side_effect = _mock_tabs
    mock_st.column_config = MagicMock()
    mock_st.stop.side_effect = StreamlitStopExecution
    return mock_st


def install_streamlit_mock():
    """Install a Streamlit mock into sys.modules and return it."""
    mock_st = create_streamlit_mock()
    sys.modules["streamlit"] = mock_st
    return mock_st


def import_page_module(module_name: str, module_path: str):
    """Import a Streamlit page module, tolerating st.stop() calls.

    Uses importlib to preserve the partially-loaded module even if
    st.stop() (mocked to raise StreamlitStopExecution) fires during
    top-level execution. All function/class definitions that precede
    the first st.stop() call will be accessible on the returned module.
    """
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
    except StreamlitStopExecution:
        pass
    return module


def make_sample_logins_df(n=5):
    """Create a sample DataFrame mimicking VPN login data for coverage tests."""
    import pandas as pd
    data = {
        "chave": ["F1234567", "F1234567", "F7654321", "F7654321", "F9999999"],
        "user": ["User A", "User A", "User B", "User B", "User C"],
        "hostname": ["host1", "host2", "host1", "host3", "host1"],
        "src_ip": ["1.1.1.1", "2.2.2.2", "1.1.1.1", "3.3.3.3", "4.4.4.4"],
        "mac_address": ["AA:BB:CC:DD:EE:01", "AA:BB:CC:DD:EE:02",
                        "AA:BB:CC:DD:EE:01", "AA:BB:CC:DD:EE:03", "AA:BB:CC:DD:EE:04"],
        "os": ["Windows 10", "Linux", "Windows 10", "macOS", "Windows 11"],
        "tunnel": ["SSL", "IPSec", "SSL", "SSL", "IPSec"],
        "client_version": ["1.0", "2.0", "1.0", "3.0", "1.0"],
        "login_option": ["cert", "password", "cert", "cert", "password"],
        "office_mode_ip": ["10.0.0.1", "10.0.0.2", "10.0.0.3", "10.0.0.4", "10.0.0.5"],
        "fingerprint": ["fp1", "fp2", "fp1", "fp3", "fp4"],
        "user_group": ["grp1", "grp1", "grp2", "grp2", "grp3"],
        "status": ["Success", "Failed", "Success", "Success", "Failed"],
        "timestamp": pd.to_datetime([
            "2024-01-15 10:00", "2024-01-15 11:00",
            "2024-01-15 12:00", "2024-01-15 13:00", "2024-01-15 14:00",
        ]),
        "eventos": [1, 2, 1, 3, 1],
    }
    return pd.DataFrame({k: v[:n] for k, v in data.items()})


def reimport_page_with_session_state(module_name, module_path, session_state,
                                     auth_user="F0000001"):
    """Re-import a page module with pre-populated session state.

    Creates a fresh Streamlit mock with st.stop() as a no-op so that
    the rendering code (after data checks) can execute for coverage.
    Saves and restores sys.modules state to avoid side-effects.
    """
    from unittest.mock import patch

    saved_st = sys.modules.get("streamlit")
    saved_mod = sys.modules.pop(module_name, None)

    mock_st = create_streamlit_mock()
    mock_st.stop = MagicMock()  # no-op, does NOT raise
    mock_st.session_state = session_state
    sys.modules["streamlit"] = mock_st

    try:
        with patch("auth_token.resolve_authenticated_user", return_value=auth_user):
            spec = importlib.util.spec_from_file_location(module_name, module_path)
            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module
            spec.loader.exec_module(module)
    except Exception:
        pass  # tolerate rendering errors from deeply mocked UI code
    finally:
        if saved_st is not None:
            sys.modules["streamlit"] = saved_st
        if saved_mod is not None:
            sys.modules[module_name] = saved_mod
        elif module_name in sys.modules:
            del sys.modules[module_name]

    return module
