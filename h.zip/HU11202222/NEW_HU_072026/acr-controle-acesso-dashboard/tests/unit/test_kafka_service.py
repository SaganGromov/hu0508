"""Unit tests for kafka_service.py — parsers and KafkaStore."""

import os
import sys
from pathlib import Path
from datetime import datetime
from unittest.mock import Mock, patch
from zoneinfo import ZoneInfo

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "acr_controle_acesso_dashboard" / "streamlit_app"))

from kafka_service import (
    _build_kafka_conf_base,
    extract_username,
    extract_chave,
    parse_timestamp,
    _build_login_dict,
    _merge_login,
    _consume_aggregated_logins,
    _get_topic_partitions,
    _assign_partitions_from_beginning,
    _assign_partitions_from_time,
    _estimate_total_messages,
    build_logins_df,
    search_logins_by_chave_since,
    start_realtime_consumer,
    consume_all_logins,
    consume_logins_since,
    consume_all_messages,
    consume_messages_since,
    KafkaStore,
    BR_TZ,
)


@pytest.fixture(autouse=True)
def configured_kafka_bootstrap(monkeypatch):
    monkeypatch.setitem(
        sys.modules["kafka_service"].KAFKA_CONF_BASE,
        "bootstrap.servers",
        "broker.example:443",
    )


class TestKafkaConfig:
    def test_build_kafka_conf_base_uses_env_values(self):
        env = {
            "KAFKA_BOOTSTRAP_SERVERS": "broker.example:443",
            "KAFKA_SECURITY_PROTOCOL": "SASL_PLAINTEXT",
            "KAFKA_SASL_MECHANISM": "PLAIN",
            "KAFKA_SASL_USERNAME": "user",
            "KAFKA_SASL_PASSWORD": "pass",
            "KAFKA_SSL_CA_LOCATION": "/tmp/ca.crt",
        }
        with patch.dict(os.environ, env, clear=False):
            conf = _build_kafka_conf_base()

        assert conf["bootstrap.servers"] == "broker.example:443"
        assert conf["security.protocol"] == "SASL_PLAINTEXT"
        assert conf["sasl.mechanism"] == "PLAIN"
        assert conf["sasl.username"] == "user"
        assert conf["sasl.password"] == "pass"
        assert conf["ssl.ca.location"] == "/tmp/ca.crt"


class TestExtractUsername:
    def test_empty_returns_desconhecido(self):
        assert extract_username("") == "Desconhecido"

    def test_none_returns_desconhecido(self):
        assert extract_username(None) == "Desconhecido"

    def test_simple_name(self):
        assert extract_username("John Doe") == "John Doe"

    def test_parenthesized_with_matricula(self):
        result = extract_username("john (F1234567 John Doe)")
        assert result == "John Doe"

    def test_parenthesized_without_matricula(self):
        result = extract_username("john (John Doe)")
        assert result == "John Doe"

    def test_parenthesized_only_matricula(self):
        result = extract_username("john (F1234567)")
        assert result == "john"

    def test_parenthesized_empty_after_strip(self):
        result = extract_username("john (F1234567 )")
        assert result == "john"


class TestExtractChave:
    def test_empty_returns_empty(self):
        assert extract_chave("") == ""

    def test_none_returns_empty(self):
        assert extract_chave(None) == ""

    def test_extracts_chave_from_dn(self):
        assert extract_chave("CN=F1234567,OU=users") == "F1234567"

    def test_extracts_lowercase_chave(self):
        assert extract_chave("CN=f1234567,OU=users") == "F1234567"

    def test_no_chave_returns_empty(self):
        assert extract_chave("CN=admin,OU=users") == ""

    def test_multiple_chaves_returns_first(self):
        result = extract_chave("CN=F1234567,OU=F9999999")
        assert result == "F1234567"


class TestParseTimestamp:
    def test_valid_timestamp(self):
        msg = {"login_timestamp": 1700000000}
        result = parse_timestamp(msg)
        assert isinstance(result, datetime)
        assert result.tzinfo is None

    def test_fallback_to_time_field(self):
        msg = {"time": 1700000000}
        result = parse_timestamp(msg)
        assert isinstance(result, datetime)

    def test_zero_timestamp_uses_now(self):
        msg = {"login_timestamp": 0, "time": 0}
        result = parse_timestamp(msg)
        assert isinstance(result, datetime)

    def test_missing_fields_uses_now(self):
        result = parse_timestamp({})
        assert isinstance(result, datetime)

    def test_result_is_naive(self):
        msg = {"login_timestamp": 1700000000}
        result = parse_timestamp(msg)
        assert result.tzinfo is None


class TestBuildLoginDict:
    def test_builds_complete_dict(self):
        msg = {
            "status": "success",
            "src": "10.0.0.1",
            "hostname": "host1",
            "os_name": "Windows",
            "os_version": "11",
            "tunnel_protocol": "IPSec",
            "client_version": "1.0",
            "login_option": "certificate",
            "mac_address": "AA:BB:CC:DD:EE:FF",
            "origin": "internal",
            "session_uid": "sess123",
            "user_group": "group1",
            "fingerprint": "fp123",
            "office_mode_ip": "192.168.1.1",
        }
        ts = datetime(2025, 1, 1, 12, 0)
        result = _build_login_dict(msg, ts, "F1234567", "User", "CN=F1234567", "loguid123")

        assert result["timestamp"] == ts
        assert result["loguid"] == "loguid123"
        assert result["chave"] == "F1234567"
        assert result["user"] == "User"
        assert result["user_dn"] == "CN=F1234567"
        assert result["office_mode_ip"] == "192.168.1.1"
        assert result["eventos"] == 1
        assert result["status"] == "success"
        assert result["src_ip"] == "10.0.0.1"
        assert result["os"] == "Windows 11"
        assert result["tunnel"] == "IPSec"

    def test_unspecified_ips_are_stored_as_missing(self):
        msg = {"src": "0.0.0.0", "office_mode_ip": "::0"}
        result = _build_login_dict(
            msg,
            datetime(2025, 1, 1, 12, 0),
            "F1234567",
            "User",
            "CN=F1234567",
            "loguid123",
        )
        assert result["src_ip"] == ""
        assert result["office_mode_ip"] == ""


class TestMergeLogin:
    def test_increments_event_count(self):
        login = {
            "timestamp": datetime(2025, 1, 1, 12, 0),
            "eventos": 1,
            "chave": "F1234567",
            "user": "User",
            "user_dn": "CN=F1234567",
            "office_mode_ip": "",
            "status": "success",
            "src_ip": "",
            "hostname": "",
            "os": "",
            "tunnel": "",
            "client_version": "",
            "login_option": "",
            "mac_address": "",
            "origin": "",
            "session_uid": "",
            "user_group": "",
            "fingerprint": "",
        }
        msg = {"office_mode_ip": "192.168.1.1", "status": "connected"}
        _merge_login(login, msg, datetime(2025, 1, 1, 12, 5), "F1234567", "User", "CN=F1234567")
        assert login["eventos"] == 2

    def test_takes_earlier_timestamp(self):
        login = {
            "timestamp": datetime(2025, 1, 1, 12, 5),
            "eventos": 1,
            "chave": "",
            "user": "",
            "user_dn": "",
            "office_mode_ip": "",
            "status": "",
            "src_ip": "",
            "hostname": "",
            "os": "",
            "tunnel": "",
            "client_version": "",
            "login_option": "",
            "mac_address": "",
            "origin": "",
            "session_uid": "",
            "user_group": "",
            "fingerprint": "",
        }
        _merge_login(login, {}, datetime(2025, 1, 1, 12, 0), "", "", "")
        assert login["timestamp"] == datetime(2025, 1, 1, 12, 0)

    def test_fills_empty_fields(self):
        login = {
            "timestamp": datetime(2025, 1, 1, 12, 0),
            "eventos": 1,
            "chave": "",
            "user": "",
            "user_dn": "",
            "office_mode_ip": "",
            "status": "",
            "src_ip": "",
            "hostname": "",
            "os": "",
            "tunnel": "",
            "client_version": "",
            "login_option": "",
            "mac_address": "",
            "origin": "",
            "session_uid": "",
            "user_group": "",
            "fingerprint": "",
        }
        msg = {"src": "10.0.0.1", "hostname": "host1"}
        _merge_login(login, msg, datetime(2025, 1, 1, 12, 5), "F1234567", "User", "CN=user")
        assert login["src_ip"] == "10.0.0.1"
        assert login["hostname"] == "host1"
        assert login["chave"] == "F1234567"
        assert login["user"] == "User"
        assert login["user_dn"] == "CN=user"

    def test_updates_office_mode_ip_from_zero(self):
        login = {
            "timestamp": datetime(2025, 1, 1, 12, 0),
            "eventos": 1,
            "chave": "F1234567",
            "user": "User",
            "user_dn": "CN=F1234567",
            "office_mode_ip": "0.0.0.0",
            "status": "",
            "src_ip": "",
            "hostname": "",
            "os": "",
            "tunnel": "",
            "client_version": "",
            "login_option": "",
            "mac_address": "",
            "origin": "",
            "session_uid": "",
            "user_group": "",
            "fingerprint": "",
        }
        msg = {"office_mode_ip": "192.168.1.1"}
        _merge_login(login, msg, datetime(2025, 1, 1, 12, 5), "", "", "")
        assert login["office_mode_ip"] == "192.168.1.1"


class TestKafkaStore:
    def test_initial_state(self):
        store = KafkaStore(max_events=100)
        assert store.event_count == 0
        status = store.get_status()
        assert status["event_count"] == 0
        assert status["last_received_at"] is None
        df = store.get_logins_df()
        assert df.empty

    def test_add_event(self):
        store = KafkaStore(max_events=100)
        store.add_event({
            "loguid": "uid1",
            "user_dn": "CN=F1234567,OU=users",
            "user": "john (F1234567 John Doe)",
            "login_timestamp": 1700000000,
            "status": "success",
        })
        assert store.event_count == 1
        status = store.get_status()
        assert status["event_count"] == 1
        assert status["last_received_at"] is not None
        df = store.get_logins_df()
        assert len(df) == 1
        assert df.iloc[0]["chave"] == "F1234567"

    def test_merge_events_same_loguid(self):
        store = KafkaStore(max_events=100)
        store.add_event({
            "loguid": "uid1",
            "user_dn": "CN=F1234567",
            "user": "john",
            "login_timestamp": 1700000000,
            "status": "connecting",
        })
        store.add_event({
            "loguid": "uid1",
            "user_dn": "CN=F1234567",
            "user": "john",
            "login_timestamp": 1700000001,
            "status": "success",
            "office_mode_ip": "192.168.1.1",
        })
        assert store.event_count == 2
        df = store.get_logins_df()
        assert len(df) == 1  # same loguid — merged
        assert df.iloc[0]["eventos"] == 2

    def test_different_loguids_create_separate_logins(self):
        store = KafkaStore(max_events=100)
        store.add_event({"loguid": "uid1", "login_timestamp": 1700000000})
        store.add_event({"loguid": "uid2", "login_timestamp": 1700000001})
        df = store.get_logins_df()
        assert len(df) == 2

    def test_max_events_eviction(self):
        store = KafkaStore(max_events=5)
        for i in range(10):
            store.add_event({"loguid": f"uid{i}", "login_timestamp": 1700000000 + i})
        assert store.event_count == 10
        df = store.get_logins_df()
        # Only latest 5 events should remain; old loguids evicted
        assert len(df) <= 5

    def test_clear(self):
        store = KafkaStore(max_events=100)
        store.add_event({"loguid": "uid1", "login_timestamp": 1700000000})
        store.clear()
        assert store.event_count == 0
        status = store.get_status()
        assert status["event_count"] == 0
        assert status["last_received_at"] is None
        assert store.get_logins_df().empty

    def test_thread_safety(self):
        """Basic test that concurrent adds don't crash."""
        import threading
        store = KafkaStore(max_events=1000)

        def add_events(start):
            for i in range(100):
                store.add_event({"loguid": f"uid{start+i}", "login_timestamp": 1700000000 + i})

        threads = [threading.Thread(target=add_events, args=(i * 100,)) for i in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert store.event_count == 400


class TestBuildLoginsDf:
    def test_empty_messages(self):
        df = build_logins_df([])
        assert df.empty

    def test_single_message(self):
        msgs = [{
            "loguid": "uid1",
            "user_dn": "CN=F1234567",
            "user": "John",
            "login_timestamp": 1700000000,
            "status": "success",
            "src": "10.0.0.1",
        }]
        df = build_logins_df(msgs)
        assert len(df) == 1
        assert df.iloc[0]["chave"] == "F1234567"

    def test_multiple_messages_same_loguid(self):
        msgs = [
            {"loguid": "uid1", "user_dn": "CN=F1234567", "user": "John", "login_timestamp": 1700000000},
            {"loguid": "uid1", "user_dn": "CN=F1234567", "user": "John", "login_timestamp": 1700000001},
        ]
        df = build_logins_df(msgs)
        assert len(df) == 1
        assert df.iloc[0]["eventos"] == 2

    def test_multiple_messages_different_loguids(self):
        msgs = [
            {"loguid": "uid1", "user_dn": "CN=F1111111", "user": "A", "login_timestamp": 1700000000},
            {"loguid": "uid2", "user_dn": "CN=F2222222", "user": "B", "login_timestamp": 1700000001},
        ]
        df = build_logins_df(msgs)
        assert len(df) == 2


class TestConsumeAggregatedLogins:
    def _make_kafka_msg(self, payload_dict):
        """Create a mock Kafka message."""
        import json
        mock_msg = Mock()
        mock_msg.value.return_value = json.dumps(payload_dict).encode("utf-8")
        mock_msg.error.return_value = None
        return mock_msg

    def test_empty_topic(self):
        consumer = Mock()
        consumer.poll.return_value = None
        df, consumed = _consume_aggregated_logins(consumer, 100)
        assert df.empty
        assert consumed == 0

    def test_consumes_messages(self):
        msgs = [
            self._make_kafka_msg({"loguid": "uid1", "login_timestamp": 1700000000, "user_dn": "CN=F1234567", "user": "John"}),
            self._make_kafka_msg({"loguid": "uid2", "login_timestamp": 1700000001, "user_dn": "CN=F2222222", "user": "Jane"}),
            None,  # signals end
        ]
        consumer = Mock()
        call_count = [0]
        def poll_side_effect(timeout):
            if call_count[0] < len(msgs):
                result = msgs[call_count[0]]
                call_count[0] += 1
                return result
            return None
        consumer.poll.side_effect = poll_side_effect
        df, consumed = _consume_aggregated_logins(consumer, 100)
        assert len(df) == 2
        assert consumed == 2

    def test_filters_by_target_chave(self):
        msgs = [
            self._make_kafka_msg({"loguid": "uid1", "login_timestamp": 1700000000, "user_dn": "CN=F1234567", "user": "John"}),
            self._make_kafka_msg({"loguid": "uid2", "login_timestamp": 1700000001, "user_dn": "CN=F2222222", "user": "Jane"}),
        ]
        all_msgs = msgs + [None] * 15  # enough Nones to trigger empty_polls > 10
        consumer = Mock()
        call_count = [0]
        def poll_side_effect(timeout):
            if call_count[0] < len(all_msgs):
                result = all_msgs[call_count[0]]
                call_count[0] += 1
                return result
            return None
        consumer.poll.side_effect = poll_side_effect
        df, consumed = _consume_aggregated_logins(consumer, 100, target_chave="F1234567")
        # Only uid1 should remain
        assert len(df) == 1
        assert df.iloc[0]["chave"] == "F1234567"

    def test_handles_error_messages(self):
        error_msg = Mock()
        error_msg.error.return_value = True
        consumer = Mock()
        consumer.poll.side_effect = [error_msg] + [None] * 15
        df, consumed = _consume_aggregated_logins(consumer, 100)
        assert df.empty

    def test_handles_invalid_json(self):
        bad_msg = Mock()
        bad_msg.value.return_value = b"not json"
        bad_msg.error.return_value = None
        consumer = Mock()
        consumer.poll.side_effect = [bad_msg] + [None] * 15
        df, consumed = _consume_aggregated_logins(consumer, 100)
        assert df.empty
        assert consumed == 1

    def test_skips_messages_without_loguid(self):
        msg = self._make_kafka_msg({"login_timestamp": 1700000000, "user_dn": "CN=F1234567"})
        consumer = Mock()
        consumer.poll.side_effect = [msg] + [None] * 15
        df, consumed = _consume_aggregated_logins(consumer, 100)
        # loguid is empty string, so still counts as having a loguid
        # but let's verify consumed count
        assert consumed == 1

    def test_progress_callback(self):
        progress_calls = []
        msgs = []
        for i in range(2000):
            msgs.append(self._make_kafka_msg({
                "loguid": f"uid{i}", "login_timestamp": 1700000000 + i,
                "user_dn": f"CN=F{1000000+i}", "user": f"User{i}"
            }))
        msgs += [None] * 15
        consumer = Mock()
        idx = [0]
        def poll_side_effect(timeout):
            if idx[0] < len(msgs):
                result = msgs[idx[0]]
                idx[0] += 1
                return result
            return None
        consumer.poll.side_effect = poll_side_effect
        df, consumed = _consume_aggregated_logins(
            consumer, 2000,
            on_progress=lambda c, t: progress_calls.append((c, t))
        )
        assert len(progress_calls) > 0


class TestGetTopicPartitions:
    def test_returns_partitions(self):
        consumer = Mock()
        mock_meta = Mock()
        mock_topic_meta = Mock()
        mock_topic_meta.error = None
        mock_topic_meta.partitions = {0: Mock(), 1: Mock()}
        mock_meta.topics = {"acr.vpn.redis.logs": mock_topic_meta}
        consumer.list_topics.return_value = mock_meta
        result = _get_topic_partitions(consumer)
        assert len(result) == 2


class TestAssignPartitionsFromBeginning:
    def test_assigns_from_offset_zero(self):
        consumer = Mock()
        partitions = {0: Mock(), 1: Mock()}
        tps = _assign_partitions_from_beginning(consumer, partitions)
        assert len(tps) == 2
        consumer.assign.assert_called_once()
        for tp in tps:
            assert tp.offset == 0


class TestEstimateTotalMessages:
    def test_estimates_correctly(self):
        consumer = Mock()
        from confluent_kafka import TopicPartition
        tps = [TopicPartition("acr.vpn.redis.logs", 0, 10)]
        consumer.get_watermark_offsets.return_value = (0, 100)
        total = _estimate_total_messages(consumer, tps)
        assert total == 90  # 100 - 10


class TestSearchLoginsByChaveSince:
    def test_empty_chave_returns_empty(self):
        df, count = search_logins_by_chave_since("", 60)
        assert df.empty
        assert count == 0

    def test_whitespace_chave_returns_empty(self):
        df, count = search_logins_by_chave_since("   ", 60)
        assert df.empty
        assert count == 0


class TestStartRealtimeConsumer:
    def _make_kafka_msg(self, payload_dict):
        import json as _json
        mock_msg = Mock()
        mock_msg.value.return_value = _json.dumps(payload_dict).encode("utf-8")
        mock_msg.error.return_value = None
        return mock_msg

    def test_consumer_processes_messages_and_stops(self):
        import threading
        store = KafkaStore(max_events=100)
        stop_event = threading.Event()

        msg1 = self._make_kafka_msg({"loguid": "uid1", "login_timestamp": 1700000000})
        msg_error = Mock()
        msg_error.error.return_value = True
        msg_bad = Mock()
        msg_bad.value.return_value = b"not-json"
        msg_bad.error.return_value = None

        call_count = [0]
        def poll_side_effect(timeout):
            call_count[0] += 1
            if call_count[0] == 1:
                return msg1
            elif call_count[0] == 2:
                return msg_error
            elif call_count[0] == 3:
                return msg_bad
            elif call_count[0] == 4:
                return None
            else:
                stop_event.set()
                return None

        mock_consumer = Mock()
        mock_consumer.poll.side_effect = poll_side_effect

        with patch.dict(os.environ, {"KAFKA_REALTIME_LOOKBACK_MINUTES": "0"}, clear=False):
            with patch("kafka_service.Consumer", return_value=mock_consumer):
                start_realtime_consumer(store, stop_event)

        assert store.event_count == 1
        mock_consumer.subscribe.assert_called_once_with(["acr.vpn.redis.logs"])
        mock_consumer.close.assert_called_once()

    def test_consumer_uses_lookback_assignment_when_configured(self):
        import threading
        from confluent_kafka import TopicPartition

        store = KafkaStore(max_events=100)
        stop_event = threading.Event()

        mock_meta = Mock()
        mock_topic_meta = Mock()
        mock_topic_meta.error = None
        mock_topic_meta.partitions = {0: Mock()}
        mock_meta.topics = {"acr.vpn.redis.logs": mock_topic_meta}

        mock_consumer = Mock()
        mock_consumer.list_topics.return_value = mock_meta
        mock_consumer.offsets_for_times.return_value = [
            TopicPartition("acr.vpn.redis.logs", 0, 5)
        ]
        mock_consumer.poll.side_effect = lambda timeout: stop_event.set() or None

        with patch.dict(os.environ, {"KAFKA_REALTIME_LOOKBACK_MINUTES": "60"}, clear=False):
            with patch("kafka_service.Consumer", return_value=mock_consumer):
                start_realtime_consumer(store, stop_event)

        mock_consumer.assign.assert_called_once()
        mock_consumer.subscribe.assert_not_called()
        mock_consumer.close.assert_called_once()

    def test_consumer_assigns_at_end_when_lookback_has_no_offsets(self):
        import threading
        from confluent_kafka import TopicPartition

        store = KafkaStore(max_events=100)
        stop_event = threading.Event()

        mock_meta = Mock()
        mock_topic_meta = Mock()
        mock_topic_meta.error = None
        mock_topic_meta.partitions = {0: Mock()}
        mock_meta.topics = {"acr.vpn.redis.logs": mock_topic_meta}

        mock_consumer = Mock()
        mock_consumer.list_topics.return_value = mock_meta
        mock_consumer.offsets_for_times.return_value = [
            TopicPartition("acr.vpn.redis.logs", 0, -1)
        ]
        mock_consumer.get_watermark_offsets.return_value = (0, 42)
        mock_consumer.poll.side_effect = lambda timeout: stop_event.set() or None

        with patch.dict(os.environ, {"KAFKA_REALTIME_LOOKBACK_MINUTES": "60"}, clear=False):
            with patch("kafka_service.Consumer", return_value=mock_consumer):
                start_realtime_consumer(store, stop_event)

        assigned_tps = mock_consumer.assign.call_args.args[0]
        assert assigned_tps[0].offset == 42
        mock_consumer.subscribe.assert_not_called()
        mock_consumer.close.assert_called_once()


class TestConsumeAllLogins:
    def _make_consumer_mock(self, messages):
        mock_consumer = Mock()

        # list_topics
        mock_meta = Mock()
        mock_topic_meta = Mock()
        mock_topic_meta.error = None
        mock_topic_meta.partitions = {0: Mock()}
        mock_meta.topics = {"acr.vpn.redis.logs": mock_topic_meta}
        mock_consumer.list_topics.return_value = mock_meta

        # watermark offsets
        mock_consumer.get_watermark_offsets.return_value = (0, len(messages))

        # poll
        idx = [0]
        def poll_side_effect(timeout):
            if idx[0] < len(messages):
                result = messages[idx[0]]
                idx[0] += 1
                return result
            return None
        mock_consumer.poll.side_effect = poll_side_effect

        return mock_consumer

    def _make_kafka_msg(self, payload_dict):
        import json as _json
        mock_msg = Mock()
        mock_msg.value.return_value = _json.dumps(payload_dict).encode("utf-8")
        mock_msg.error.return_value = None
        return mock_msg

    def test_consume_all_logins_empty_topic(self):
        mock_consumer = self._make_consumer_mock([])
        with patch("kafka_service.Consumer", return_value=mock_consumer):
            df, consumed = consume_all_logins()
        assert df.empty
        assert consumed == 0

    def test_consume_all_logins_with_messages(self):
        msgs = [
            self._make_kafka_msg({"loguid": "uid1", "login_timestamp": 1700000000, "user_dn": "CN=F1234567"}),
            self._make_kafka_msg({"loguid": "uid2", "login_timestamp": 1700000001, "user_dn": "CN=F2222222"}),
        ]
        mock_consumer = self._make_consumer_mock(msgs)
        with patch("kafka_service.Consumer", return_value=mock_consumer):
            df, consumed = consume_all_logins()
        assert len(df) == 2
        mock_consumer.close.assert_called_once()

    def test_consume_all_logins_with_max_messages(self):
        msgs = [
            self._make_kafka_msg({"loguid": f"uid{i}", "login_timestamp": 1700000000 + i})
            for i in range(10)
        ]
        mock_consumer = self._make_consumer_mock(msgs)
        with patch("kafka_service.Consumer", return_value=mock_consumer):
            df, consumed = consume_all_logins(max_messages=5)
        assert consumed <= 5


class TestConsumeLoginsSince:
    def _make_consumer_mock(self, messages, has_offsets=True):
        from confluent_kafka import TopicPartition
        mock_consumer = Mock()

        mock_meta = Mock()
        mock_topic_meta = Mock()
        mock_topic_meta.error = None
        mock_topic_meta.partitions = {0: Mock()}
        mock_meta.topics = {"acr.vpn.redis.logs": mock_topic_meta}
        mock_consumer.list_topics.return_value = mock_meta

        if has_offsets:
            mock_consumer.offsets_for_times.return_value = [
                TopicPartition("acr.vpn.redis.logs", 0, 0)
            ]
            mock_consumer.get_watermark_offsets.return_value = (0, len(messages))
        else:
            mock_consumer.offsets_for_times.return_value = [
                TopicPartition("acr.vpn.redis.logs", 0, -1)
            ]

        idx = [0]
        def poll_side_effect(timeout):
            if idx[0] < len(messages):
                result = messages[idx[0]]
                idx[0] += 1
                return result
            return None
        mock_consumer.poll.side_effect = poll_side_effect

        return mock_consumer

    def _make_kafka_msg(self, payload_dict):
        import json as _json
        mock_msg = Mock()
        mock_msg.value.return_value = _json.dumps(payload_dict).encode("utf-8")
        mock_msg.error.return_value = None
        return mock_msg

    def test_no_offsets_returns_empty(self):
        mock_consumer = self._make_consumer_mock([], has_offsets=False)
        with patch("kafka_service.Consumer", return_value=mock_consumer):
            df, consumed = consume_logins_since(60)
        assert df.empty
        assert consumed == 0

    def test_consumes_since_minutes_ago(self):
        msgs = [
            self._make_kafka_msg({"loguid": "uid1", "login_timestamp": 1700000000, "user_dn": "CN=F1234567"}),
        ]
        mock_consumer = self._make_consumer_mock(msgs)
        with patch("kafka_service.Consumer", return_value=mock_consumer):
            df, consumed = consume_logins_since(60)
        assert len(df) == 1
        mock_consumer.close.assert_called_once()


class TestConsumeAllMessages:
    def _make_consumer_mock(self, messages):
        mock_consumer = Mock()

        mock_meta = Mock()
        mock_topic_meta = Mock()
        mock_topic_meta.error = None
        mock_topic_meta.partitions = {0: Mock()}
        mock_meta.topics = {"acr.vpn.redis.logs": mock_topic_meta}
        mock_consumer.list_topics.return_value = mock_meta
        mock_consumer.get_watermark_offsets.return_value = (0, len(messages))

        idx = [0]
        def poll_side_effect(timeout):
            if idx[0] < len(messages):
                result = messages[idx[0]]
                idx[0] += 1
                return result
            return None
        mock_consumer.poll.side_effect = poll_side_effect

        return mock_consumer

    def _make_kafka_msg(self, payload_dict):
        import json as _json
        mock_msg = Mock()
        mock_msg.value.return_value = _json.dumps(payload_dict).encode("utf-8")
        mock_msg.error.return_value = None
        return mock_msg

    def test_empty_topic_returns_empty(self):
        mock_consumer = self._make_consumer_mock([])
        with patch("kafka_service.Consumer", return_value=mock_consumer):
            result = consume_all_messages()
        assert result == []
        mock_consumer.close.assert_called_once()

    def test_returns_raw_messages(self):
        msgs = [
            self._make_kafka_msg({"loguid": "uid1", "data": "test1"}),
            self._make_kafka_msg({"loguid": "uid2", "data": "test2"}),
        ]
        mock_consumer = self._make_consumer_mock(msgs)
        with patch("kafka_service.Consumer", return_value=mock_consumer):
            result = consume_all_messages()
        assert len(result) == 2
        assert result[0]["data"] == "test1"

    def test_with_max_messages(self):
        msgs = [
            self._make_kafka_msg({"loguid": f"uid{i}"})
            for i in range(10)
        ]
        mock_consumer = self._make_consumer_mock(msgs)
        with patch("kafka_service.Consumer", return_value=mock_consumer):
            result = consume_all_messages(max_messages=3)
        assert len(result) <= 3

    def test_handles_error_messages(self):
        error_msg = Mock()
        error_msg.error.return_value = True
        good_msg = self._make_kafka_msg({"loguid": "uid1"})
        msgs = [error_msg, good_msg]
        mock_consumer = self._make_consumer_mock(msgs)
        # Adjust watermark to include both
        mock_consumer.get_watermark_offsets.return_value = (0, 2)
        with patch("kafka_service.Consumer", return_value=mock_consumer):
            result = consume_all_messages()
        assert len(result) == 1

    def test_progress_callback(self):
        progress_calls = []
        msgs = [self._make_kafka_msg({"loguid": f"uid{i}"}) for i in range(1000)]
        mock_consumer = self._make_consumer_mock(msgs)
        with patch("kafka_service.Consumer", return_value=mock_consumer):
            result = consume_all_messages(on_progress=lambda c, t: progress_calls.append((c, t)))
        assert len(progress_calls) > 0


class TestConsumeMessagesSince:
    def _make_consumer_mock(self, messages, has_offsets=True):
        from confluent_kafka import TopicPartition
        mock_consumer = Mock()

        mock_meta = Mock()
        mock_topic_meta = Mock()
        mock_topic_meta.error = None
        mock_topic_meta.partitions = {0: Mock()}
        mock_meta.topics = {"acr.vpn.redis.logs": mock_topic_meta}
        mock_consumer.list_topics.return_value = mock_meta

        if has_offsets:
            mock_consumer.offsets_for_times.return_value = [
                TopicPartition("acr.vpn.redis.logs", 0, 0)
            ]
            mock_consumer.get_watermark_offsets.return_value = (0, len(messages))
        else:
            mock_consumer.offsets_for_times.return_value = [
                TopicPartition("acr.vpn.redis.logs", 0, -1)
            ]

        idx = [0]
        def poll_side_effect(timeout):
            if idx[0] < len(messages):
                result = messages[idx[0]]
                idx[0] += 1
                return result
            return None
        mock_consumer.poll.side_effect = poll_side_effect

        return mock_consumer

    def _make_kafka_msg(self, payload_dict):
        import json as _json
        mock_msg = Mock()
        mock_msg.value.return_value = _json.dumps(payload_dict).encode("utf-8")
        mock_msg.error.return_value = None
        return mock_msg

    def test_no_offsets_returns_empty(self):
        mock_consumer = self._make_consumer_mock([], has_offsets=False)
        with patch("kafka_service.Consumer", return_value=mock_consumer):
            result = consume_messages_since(60, max_messages=100)
        assert result == []
        mock_consumer.close.assert_called_once()

    def test_returns_messages_since(self):
        msgs = [
            self._make_kafka_msg({"loguid": "uid1", "data": "recent"}),
        ]
        mock_consumer = self._make_consumer_mock(msgs)
        with patch("kafka_service.Consumer", return_value=mock_consumer):
            result = consume_messages_since(60, max_messages=100)
        assert len(result) == 1

    def test_returns_messages_since_without_max_messages(self):
        msgs = [
            self._make_kafka_msg({"loguid": "uid1", "data": "recent"}),
        ]
        mock_consumer = self._make_consumer_mock(msgs)
        with patch("kafka_service.Consumer", return_value=mock_consumer):
            result = consume_messages_since(60)
        assert len(result) == 1

    def test_empty_topic_returns_empty(self):
        mock_consumer = self._make_consumer_mock([], has_offsets=True)
        mock_consumer.get_watermark_offsets.return_value = (0, 0)
        with patch("kafka_service.Consumer", return_value=mock_consumer):
            result = consume_messages_since(60, max_messages=100)
        assert result == []


class TestAssignPartitionsFromTime:
    def test_assigns_valid_offsets(self):
        from confluent_kafka import TopicPartition
        consumer = Mock()
        consumer.offsets_for_times.return_value = [
            TopicPartition("acr.vpn.redis.logs", 0, 100),
            TopicPartition("acr.vpn.redis.logs", 1, 200),
        ]
        partitions = {0: Mock(), 1: Mock()}
        tps = _assign_partitions_from_time(consumer, partitions, 60)
        assert len(tps) == 2
        consumer.assign.assert_called_once()

    def test_skips_invalid_offsets(self):
        from confluent_kafka import TopicPartition
        consumer = Mock()
        consumer.offsets_for_times.return_value = [
            TopicPartition("acr.vpn.redis.logs", 0, -1),
            TopicPartition("acr.vpn.redis.logs", 1, 200),
        ]
        partitions = {0: Mock(), 1: Mock()}
        tps = _assign_partitions_from_time(consumer, partitions, 60)
        assert len(tps) == 1

    def test_no_valid_offsets(self):
        from confluent_kafka import TopicPartition
        consumer = Mock()
        consumer.offsets_for_times.return_value = [
            TopicPartition("acr.vpn.redis.logs", 0, -1),
        ]
        partitions = {0: Mock()}
        tps = _assign_partitions_from_time(consumer, partitions, 60)
        assert len(tps) == 0
        consumer.assign.assert_not_called()
