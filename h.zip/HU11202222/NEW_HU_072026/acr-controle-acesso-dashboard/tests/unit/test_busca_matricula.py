"""Unit tests for pages/busca_matricula.py — exercising the page module."""

import sys
from datetime import datetime
from pathlib import Path
from unittest.mock import MagicMock, patch

import pandas as pd

# Mock streamlit before importing
sys.path.insert(0, str(Path(__file__).resolve().parent))
from streamlit_mock_helper import install_streamlit_mock, import_page_module, reimport_page_with_session_state, make_sample_logins_df
_mock_st = install_streamlit_mock()

_PAGES_DIR = str(Path(__file__).resolve().parents[2] / "acr_controle_acesso_dashboard" / "streamlit_app" / "pages")
_STREAMLIT_DIR = str(Path(__file__).resolve().parents[2] / "acr_controle_acesso_dashboard" / "streamlit_app")
sys.path.insert(0, _PAGES_DIR)
sys.path.insert(0, _STREAMLIT_DIR)

with patch("auth_token.resolve_authenticated_user", return_value="F0000001"):
    busca_matricula = import_page_module(
        "busca_matricula",
        str(Path(_PAGES_DIR) / "busca_matricula.py"),
    )


class TestFetchCurio:
    def test_calls_curio_service(self):
        with patch.object(busca_matricula, "integracao_curio", return_value={"nomeUsuario": "Test"}) as mock:
            result = busca_matricula.fetch_curio("F1234567")
        assert result == {"nomeUsuario": "Test"}
        mock.assert_called_once()
        payload = mock.call_args[0][1]
        assert payload["codigoClientePesquisa"] == "F1234567"

    def test_returns_none_on_error(self):
        with patch.object(busca_matricula, "integracao_curio", return_value=None):
            result = busca_matricula.fetch_curio("F1234567")
        assert result is None


class TestModuleConstants:
    def test_seven_days_minutes(self):
        assert busca_matricula.SEVEN_DAYS_MINUTES == 7 * 24 * 60


class TestRenderingCoverage:
    """Re-import with session state populated to cover UI rendering code."""

    def test_full_page_render_with_data(self):
        mod = reimport_page_with_session_state(
            "busca_matricula",
            str(Path(_PAGES_DIR) / "busca_matricula.py"),
            session_state={
                "busca_mat_df": make_sample_logins_df(),
                "busca_mat_target": "F1234567",
                "busca_mat_msg_count": 100,
            },
        )
        assert hasattr(mod, "fetch_curio")
        assert hasattr(mod, "SEVEN_DAYS_MINUTES")
