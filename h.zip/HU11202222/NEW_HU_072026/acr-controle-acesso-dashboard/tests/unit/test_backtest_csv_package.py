"""Pacote de detalhamento em CSV: esquema, manifesto, segurança e portabilidade."""

import csv
import hashlib
import json
import shutil

import pytest

from backtest_vpn import csvpackage
from backtest_vpn.report_model import build_report_model, safe_fixture_bundle


@pytest.fixture
def model():
    return build_report_model(safe_fixture_bundle(), "2.2.0")


def read_csv(path):
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.reader(handle))


class TestFormulaInjection:
    @pytest.mark.parametrize("value", ["=1+1", "+CMD", "-2+3", "@SUM(A1:A2)", "=cmd|' /c calc'!A1"])
    def test_dangerous_prefixes_become_text(self, value):
        assert csvpackage.safe_csv_value(value).startswith("'")

    @pytest.mark.parametrize("value", ["texto", "192.0.2.1", "R1-FIX-01"])
    def test_ordinary_values_are_untouched(self, value):
        assert csvpackage.safe_csv_value(value) == value

    def test_control_characters_and_newlines_are_removed(self):
        out = csvpackage.safe_csv_value("linha1\nlinha2\r\x00fim")
        assert "\n" not in out and "\r" not in out and "\x00" not in out

    def test_missing_values_use_the_documented_placeholder(self):
        for value in (None, "", [], {}):
            assert csvpackage.safe_csv_value(value) == "Não informado"

    def test_long_values_respect_the_cell_limit(self):
        assert len(csvpackage.safe_csv_value("x" * 60000)) <= csvpackage.MAX_CELL_LENGTH

    def test_injected_value_flows_through_the_written_package(self, tmp_path):
        bundle = safe_fixture_bundle()
        bundle["summary"]["cases"][0]["occurrences"][0]["evidence_records"][0]["hostname"] = "=CMD()"
        model = build_report_model(bundle, "2.2.0")
        csvpackage.write_package(model, tmp_path)
        rows = read_csv(tmp_path / csvpackage.PACKAGE_DIRNAME / "evidencias_por_ocorrencia.csv")
        hostname_column = rows[0].index("Nome do computador")
        assert any(row[hostname_column].startswith("'=") for row in rows[1:])


class TestFileNames:
    @pytest.mark.parametrize(
        "raw,expected_prefix",
        [("../evil", "evil"), ("a/b", "a-b"), ("nome com espaço", "nome-com-espa")],
    )
    def test_names_are_sanitized(self, raw, expected_prefix):
        assert csvpackage.safe_file_name(raw).startswith(expected_prefix)

    def test_empty_name_gets_a_fallback(self):
        assert csvpackage.safe_file_name("") == "arquivo"

    def test_deterministic_file_names(self, model, tmp_path):
        first = csvpackage.write_package(model, tmp_path / "a")
        second = csvpackage.write_package(model, tmp_path / "b")
        assert [item["file"] for item in first["files"]] == [
            item["file"] for item in second["files"]
        ]


class TestManifest:
    def test_manifest_records_purpose_rows_schema_and_checksum(self, model, tmp_path):
        manifest = csvpackage.write_package(model, tmp_path)
        assert manifest["manifest_version"] == 1
        assert manifest["report_id"] == model["report"]["report_id"]
        assert manifest["job_id"] == model["report"]["job_id"]
        assert manifest["data_cutoff"] == model["report"]["data_cutoff"]
        assert manifest["encoding"] == "UTF-8 sem BOM"
        assert manifest["delimiter"] == ","
        assert manifest["missing_value"] == "Não informado"
        for entry in manifest["files"]:
            assert entry["purpose"]
            assert entry["schema"]
            assert entry["schema_version"] == 1
            assert len(entry["sha256"]) == 64
            assert entry["relative_link"].startswith(csvpackage.PACKAGE_DIRNAME + "/")

    def test_checksums_match_the_written_bytes(self, model, tmp_path):
        manifest = csvpackage.write_package(model, tmp_path)
        package = tmp_path / csvpackage.PACKAGE_DIRNAME
        for entry in manifest["files"]:
            payload = (package / entry["file"]).read_bytes()
            assert hashlib.sha256(payload).hexdigest() == entry["sha256"]

    def test_row_counts_match_the_files(self, model, tmp_path):
        manifest = csvpackage.write_package(model, tmp_path)
        package = tmp_path / csvpackage.PACKAGE_DIRNAME
        for entry in manifest["files"]:
            rows = read_csv(package / entry["file"])
            assert len(rows) - 1 == entry["row_count"]

    def test_describe_datasets_matches_the_written_manifest(self, model, tmp_path):
        described = csvpackage.describe_datasets(model)
        manifest = csvpackage.write_package(model, tmp_path)
        assert [item["file"] for item in described] == [item["file"] for item in manifest["files"]]
        assert [item["row_count"] for item in described] == [
            item["row_count"] for item in manifest["files"]
        ]


class TestVerification:
    def test_intact_package_has_no_problems(self, model, tmp_path):
        csvpackage.write_package(model, tmp_path)
        assert csvpackage.verify_package(tmp_path) == []

    def test_missing_manifest_is_reported(self, tmp_path):
        (tmp_path / csvpackage.PACKAGE_DIRNAME).mkdir(parents=True)
        problems = csvpackage.verify_package(tmp_path)
        assert problems and "não encontrado" in problems[0]

    def test_missing_file_is_reported(self, model, tmp_path):
        csvpackage.write_package(model, tmp_path)
        (tmp_path / csvpackage.PACKAGE_DIRNAME / "cronologia_consolidada.csv").unlink()
        problems = csvpackage.verify_package(tmp_path)
        assert any("Arquivo ausente" in item for item in problems)

    def test_tampered_file_is_detected(self, model, tmp_path):
        csvpackage.write_package(model, tmp_path)
        target = tmp_path / csvpackage.PACKAGE_DIRNAME / "cronologia_consolidada.csv"
        target.write_text(target.read_text(encoding="utf-8") + "adulterado\n", encoding="utf-8")
        problems = csvpackage.verify_package(tmp_path)
        assert any("SHA-256 divergente" in item for item in problems)

    def test_package_still_verifies_after_being_moved(self, model, tmp_path):
        csvpackage.write_package(model, tmp_path / "origem")
        shutil.move(str(tmp_path / "origem"), str(tmp_path / "destino"))
        assert csvpackage.verify_package(tmp_path / "destino") == []

    def test_relative_links_remain_valid_after_move(self, model, tmp_path):
        csvpackage.write_package(model, tmp_path / "origem")
        shutil.move(str(tmp_path / "origem"), str(tmp_path / "destino"))
        manifest = json.loads(
            (tmp_path / "destino" / csvpackage.PACKAGE_DIRNAME / csvpackage.MANIFEST_NAME)
            .read_text(encoding="utf-8")
        )
        for entry in manifest["files"]:
            assert (tmp_path / "destino" / entry["relative_link"]).is_file()

    def test_no_internal_url_is_embedded(self, model, tmp_path):
        csvpackage.write_package(model, tmp_path)
        package = tmp_path / csvpackage.PACKAGE_DIRNAME
        for item in package.iterdir():
            text = item.read_text(encoding="utf-8")
            assert "http://" not in text and "https://" not in text
            assert "jdbc:" not in text


class TestContent:
    def test_r1_sequence_is_exported_per_user_and_day(self, model, tmp_path):
        csvpackage.write_package(model, tmp_path)
        rows = read_csv(tmp_path / csvpackage.PACKAGE_DIRNAME / "r1_sequencia_de_ips.csv")
        header, data = rows[0], rows[1:]
        assert header[:5] == ["Ocorrência", "Usuário", "Data local", "Posição", "Timestamp local"]
        assert data, "a fixture R1 precisa produzir sequência de IPs"
        for row in data:
            assert row[2].count("-") == 2  # data local AAAA-MM-DD

    def test_r4_exports_every_qualifying_login_timestamp(self, model, tmp_path):
        csvpackage.write_package(model, tmp_path)
        rows = read_csv(tmp_path / csvpackage.PACKAGE_DIRNAME / "r4_logins_vpn_por_dia.csv")
        data = rows[1:]
        assert len(data) == 3
        assert {row[3] for row in data} == {"3"}

    def test_device_usage_uses_the_rule_computation(self, model, tmp_path):
        csvpackage.write_package(model, tmp_path)
        rows = read_csv(tmp_path / csvpackage.PACKAGE_DIRNAME / "r7_uso_de_dispositivo_por_usuario.csv")
        data = rows[1:]
        assert {row[0] for row in data} == {"DEV-SHARED"}
        assert {row[1] for row in data} == {"T0000001", "T0000003"}

    def test_timeline_is_sorted_by_local_timestamp(self, model, tmp_path):
        csvpackage.write_package(model, tmp_path)
        rows = read_csv(tmp_path / csvpackage.PACKAGE_DIRNAME / "cronologia_consolidada.csv")
        timestamps = [row[0] for row in rows[1:]]
        assert timestamps == sorted(timestamps)

    def test_dictionary_defines_the_missing_value_marker(self, model, tmp_path):
        csvpackage.write_package(model, tmp_path)
        rows = read_csv(tmp_path / csvpackage.PACKAGE_DIRNAME / csvpackage.DICTIONARY_NAME)
        terms = {row[0] for row in rows[1:]}
        assert "Não informado" in terms
        assert "Alerta UOR" in terms


class TestEncoding:
    def test_default_encoding_has_no_bom(self, model, tmp_path):
        csvpackage.write_package(model, tmp_path)
        payload = (tmp_path / csvpackage.PACKAGE_DIRNAME / "cronologia_consolidada.csv").read_bytes()
        assert not payload.startswith(b"\xef\xbb\xbf")

    def test_bom_is_written_only_when_requested(self, model, tmp_path):
        manifest = csvpackage.write_package(model, tmp_path, use_bom=True)
        payload = (tmp_path / csvpackage.PACKAGE_DIRNAME / "cronologia_consolidada.csv").read_bytes()
        assert payload.startswith(b"\xef\xbb\xbf")
        assert manifest["encoding"] == "UTF-8 com BOM"
        assert csvpackage.verify_package(tmp_path) == []

    def test_line_terminator_is_lf(self, model, tmp_path):
        csvpackage.write_package(model, tmp_path)
        payload = (tmp_path / csvpackage.PACKAGE_DIRNAME / "cronologia_consolidada.csv").read_bytes()
        assert b"\r\n" not in payload


class TestSplitting:
    def test_large_datasets_are_split_deterministically(self, model, tmp_path, monkeypatch):
        monkeypatch.setattr(csvpackage, "MAX_ROWS_PER_FILE", 2)
        manifest = csvpackage.write_package(model, tmp_path)
        parts = [entry for entry in manifest["files"] if entry["total_parts"] > 1]
        assert parts, "com o limite reduzido a divisão precisa ocorrer"
        for entry in parts:
            assert entry["file"].endswith(".csv")
            assert "_parte" in entry["file"]
            assert entry["row_count"] <= 2
        assert csvpackage.verify_package(tmp_path) == []

    def test_empty_dataset_still_emits_a_header_only_file(self, tmp_path):
        bundle = safe_fixture_bundle()
        # Sem ocorrências R7, o dataset de uso por dispositivo fica vazio.
        bundle["summary"]["cases"] = [
            case for case in bundle["summary"]["cases"] if case["rule_id"] != "R7"
        ]
        model = build_report_model(bundle, "2.2.0")
        manifest = csvpackage.write_package(model, tmp_path)
        entry = next(
            item for item in manifest["files"]
            if item["file"] == "r7_uso_de_dispositivo_por_usuario.csv"
        )
        assert entry["row_count"] == 0
        rows = read_csv(tmp_path / csvpackage.PACKAGE_DIRNAME / entry["file"])
        assert len(rows) == 1
        assert csvpackage.verify_package(tmp_path) == []


class TestRegeneration:
    def test_stale_files_are_removed_before_rewriting(self, model, tmp_path):
        package = tmp_path / csvpackage.PACKAGE_DIRNAME
        package.mkdir(parents=True)
        (package / "arquivo_antigo.csv").write_text("obsoleto\n", encoding="utf-8")
        csvpackage.write_package(model, tmp_path)
        assert not (package / "arquivo_antigo.csv").exists()
        assert csvpackage.verify_package(tmp_path) == []
