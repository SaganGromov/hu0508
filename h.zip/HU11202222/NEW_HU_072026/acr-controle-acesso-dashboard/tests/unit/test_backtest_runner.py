"""Unit tests for acr_controle_acesso_dashboard/backtest_runner.py

O CLI real do backtest não é executado; usamos um script Python fake
(shell/heredoc) que emite as linhas esperadas para exercitar o parser.
"""

import os
import sys
import textwrap
import time
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from acr_controle_acesso_dashboard.backtest_runner import (  # noqa: E402
    BacktestBusy,
    BacktestJob,
    BacktestRunner,
    BacktestUnavailable,
    _int_in_range,
    _validate_job_id,
    _validate_rules,
    _validate_ts,
)

DURABLE_JOB_ID = "bt-" + "a" * 40


class TestValidators:
    def test_validate_ts_accepts_iso(self):
        _validate_ts("2026-07-20 17:29:04", "start")  # não levanta

    def test_validate_ts_rejects_wrong(self):
        for bad in ("2026-07-20T17:29:04", "20/07/2026 17:29:04", "abc", "", None):
            with pytest.raises(ValueError):
                _validate_ts(bad, "start")

    def test_int_in_range(self):
        assert _int_in_range(5, 1, 10, "x") == 5
        assert _int_in_range("7", 1, 10, "x") == 7
        with pytest.raises(ValueError):
            _int_in_range(11, 1, 10, "x")
        with pytest.raises(ValueError):
            _int_in_range("abc", 1, 10, "x")

    def test_validate_rules(self):
        assert _validate_rules("R7,R1,R4") == "R1,R4,R7"
        with pytest.raises(ValueError):
            _validate_rules("")
        with pytest.raises(ValueError):
            _validate_rules("R10")

    def test_validate_job_id_accepts_only_command_layer_identifiers(self):
        assert _validate_job_id(DURABLE_JOB_ID) == DURABLE_JOB_ID
        assert _validate_job_id("f" * 32) == "f" * 32
        for bad in ("", None, "../etc/passwd", "bt-" + "z" * 40, "a" * 31, "bt-abc", "a" * 33):
            with pytest.raises(ValueError, match="job_id"):
                _validate_job_id(bad)


class TestAvailability:
    def test_unavailable_without_bin(self, monkeypatch):
        monkeypatch.delenv("BACKTEST_VPN_BIN", raising=False)
        runner = BacktestRunner()
        monkeypatch.setattr(runner, "_candidate_bin_paths", lambda: ("/nao/existe/backtest-vpn",))
        assert runner.bin_path() is None
        assert runner.is_available() is False
        with pytest.raises(BacktestUnavailable):
            runner.submit("2026-07-18 00:00:00", "2026-07-19 00:00:00")

    def test_unavailable_without_credentials(self, monkeypatch, tmp_path):
        fake_bin = tmp_path / "fake-bin"
        fake_bin.write_text("#!/bin/sh\nexit 0\n")
        fake_bin.chmod(0o755)
        monkeypatch.delenv("DB2_CREDENTIALS_FILE", raising=False)
        runner = BacktestRunner(bin_path_override=str(fake_bin))
        assert runner.is_available() is True
        assert runner.credentials_ok() is False
        with pytest.raises(BacktestUnavailable):
            runner.submit("2026-07-18 00:00:00", "2026-07-19 00:00:00")


class TestSubmitValidation:
    def test_invalid_window_order(self, monkeypatch, tmp_path):
        fake_bin = tmp_path / "fake-bin"
        fake_bin.write_text("#!/bin/sh\nexit 0\n")
        fake_bin.chmod(0o755)
        creds = tmp_path / "creds.json"
        creds.write_text('{"username":"u","password":"p"}')
        monkeypatch.setenv("DB2_CREDENTIALS_FILE", str(creds))
        runner = BacktestRunner(bin_path_override=str(fake_bin))
        with pytest.raises(ValueError):
            runner.submit("2026-07-19 00:00:00", "2026-07-18 00:00:00")


def _make_fake_backtest_bin(tmp_path: Path, static_dir: Path) -> Path:
    """Cria um binário fake do backtest-vpn que emite logs e escreve bundle+HTM.

    Comportamento esperado:
    * Ao ser chamado com ``full ...`` ou ``run-job ...`` imprime as linhas de
      progresso, cria o arquivo ``reports/results_bundle_<stamp>.json`` e a
      linha ``Bundle gerado: reports/results_bundle_<stamp>.json``; para
      ``run-job`` também registra o ``--job-id`` recebido.
    * Ao ser chamado com ``report-html ...`` cria arquivos vazios em
      ``reports/html/`` correspondentes ao stamp.
    """
    reports = tmp_path / "reports"
    html = reports / "html"
    reports.mkdir()
    html.mkdir()
    script = tmp_path / "fake-backtest-vpn"
    script.write_text(textwrap.dedent(f"""\
        #!/usr/bin/env python3
        import json, os, pathlib, sys, time
        REPORTS = pathlib.Path({str(reports)!r})
        HTML    = REPORTS / "html"
        STAMP = "20260721_120000"
        if sys.argv[1] in ("full", "run-job"):
            print(f"[fake] iniciando {{sys.argv[1]}} com args={{sys.argv[2:]}}", flush=True)
            if sys.argv[1] == "run-job":
                print(f"[fake] job-id={{sys.argv[sys.argv.index('--job-id') + 1]}}", flush=True)
            print("[labelfree] base_stats ... ok (0.0s)", flush=True)
            b = REPORTS / f"results_bundle_{{STAMP}}.json"
            b.write_text(json.dumps({{
                "rules": {{ "R1": {{ "flagged": 0, "flagged_users": 0 }} }},
                "summary": {{ "cases": [], "metrics": {{}} }},
                "parameters": {{ "start": "x", "end": "y" }},
            }}))
            print(f"Bundle gerado: {{b}}", flush=True)
            sys.exit(0)
        elif sys.argv[1] == "report-html":
            (HTML / f"relatorio_backtest_vpn_{{STAMP}}.htm").write_text("<html/>")
            (HTML / f"relatorio_backtest_vpn_{{STAMP}}.fragment.htm").write_text("<div/>")
            print("HTML gerado", flush=True)
            sys.exit(0)
        else:
            sys.exit(2)
    """))
    script.chmod(0o755)
    return script


class TestFullRun:
    def test_end_to_end_publishes_artifacts(self, monkeypatch, tmp_path):
        static_dir = tmp_path / "static"
        static_dir.mkdir()
        bin_path = _make_fake_backtest_bin(tmp_path, static_dir)
        creds = tmp_path / "creds.json"
        creds.write_text('{"username":"u","password":"p"}')
        monkeypatch.setenv("DB2_CREDENTIALS_FILE", str(creds))
        monkeypatch.setenv("BACKTEST_VPN_REPORTS_DIR", str(tmp_path / "reports"))

        runner = BacktestRunner(bin_path_override=str(bin_path))
        # aponta static_dir para o tmp
        monkeypatch.setattr(runner, "static_dir", lambda: str(static_dir))

        job = runner.submit("2026-07-18 00:00:00", "2026-07-19 00:00:00")
        # aguarda término (máx 10s)
        deadline = time.time() + 10
        while time.time() < deadline and runner.get_job(job.job_id).status in ("pending", "running"):
            time.sleep(0.1)
        job = runner.get_job(job.job_id)
        assert job.status == "success", f"logs: {job.log_lines}"
        assert job.stamp == "20260721_120000"
        assert (static_dir / "results_bundle_20260721_120000.json").is_file()
        assert (static_dir / "relatorio_backtest_vpn_20260721_120000.htm").is_file()
        assert (static_dir / "latest.htm").is_file()
        assert (static_dir / "latest.fragment.htm").is_file()
        # o log deve conter a linha "Bundle gerado"
        assert any("Bundle gerado" in line for line in job.log_lines)

    def test_durable_job_id_is_used_and_run_job_is_invoked(self, monkeypatch, tmp_path):
        """A rota HTTP passa o job_id durável; o subprocesso executa run-job."""
        static_dir = tmp_path / "static"
        static_dir.mkdir()
        bin_path = _make_fake_backtest_bin(tmp_path, static_dir)
        creds = tmp_path / "creds.json"
        creds.write_text('{"username":"u","password":"p"}')
        monkeypatch.setenv("DB2_CREDENTIALS_FILE", str(creds))
        monkeypatch.setenv("BACKTEST_VPN_REPORTS_DIR", str(tmp_path / "reports"))

        runner = BacktestRunner(bin_path_override=str(bin_path))
        monkeypatch.setattr(runner, "static_dir", lambda: str(static_dir))
        job = runner.submit(
            "2026-06-27 00:00:00", "2026-07-30 00:00:00", job_id=DURABLE_JOB_ID
        )
        assert job.job_id == DURABLE_JOB_ID
        assert job.subcommand == "run-job"
        deadline = time.time() + 10
        while time.time() < deadline and runner.get_job(job.job_id).status in ("pending", "running"):
            time.sleep(0.1)
        job = runner.get_job(job.job_id)
        assert job.status == "success", f"logs: {job.log_lines}"
        assert any("run-job" in line for line in job.log_lines)
        assert any(DURABLE_JOB_ID in line for line in job.log_lines)

    def test_invalid_durable_job_id_is_refused_before_launching(self, monkeypatch, tmp_path):
        fake_bin = tmp_path / "fake-bin"
        fake_bin.write_text("#!/bin/sh\nexit 0\n")
        fake_bin.chmod(0o755)
        creds = tmp_path / "creds.json"
        creds.write_text('{"username":"u","password":"p"}')
        monkeypatch.setenv("DB2_CREDENTIALS_FILE", str(creds))
        runner = BacktestRunner(bin_path_override=str(fake_bin))
        with pytest.raises(ValueError, match="job_id"):
            runner.submit(
                "2026-06-27 00:00:00", "2026-07-30 00:00:00", job_id="../etc/passwd",
            )

    def test_busy_when_active_job_pending(self, monkeypatch, tmp_path):
        # binário que dorme para simular concorrência
        bin_path = tmp_path / "sleepy"
        bin_path.write_text("#!/bin/sh\nsleep 2\n")
        bin_path.chmod(0o755)
        creds = tmp_path / "creds.json"
        creds.write_text('{}')
        monkeypatch.setenv("DB2_CREDENTIALS_FILE", str(creds))

        runner = BacktestRunner(bin_path_override=str(bin_path))
        monkeypatch.setattr(runner, "static_dir", lambda: str(tmp_path / "static"))
        os.makedirs(tmp_path / "reports", exist_ok=True)
        monkeypatch.setenv("BACKTEST_VPN_REPORTS_DIR", str(tmp_path / "reports"))

        runner.submit("2026-07-18 00:00:00", "2026-07-19 00:00:00")
        with pytest.raises(BacktestBusy):
            runner.submit("2026-07-18 00:00:00", "2026-07-19 00:00:00")


class TestPublicView:
    def test_serializable_shape(self):
        job = BacktestJob(
            job_id="abc",
            start_window="2026-07-18 00:00:00",
            end_window="2026-07-19 00:00:00",
            params={"mta_delta_minutes": 15},
        )
        view = job.public_view()
        for key in ("job_id", "status", "start_window", "end_window", "params",
                    "started_at", "finished_at", "stamp", "bundle", "html",
                    "fragment", "error", "exit_code", "log_size", "subcommand"):
            assert key in view
