"""Semântica do período padrão de 33 dias e das conversões de janela."""

from datetime import date, datetime, timedelta, timezone

import pytest

from backtest_vpn.clock import FixedClock
from backtest_vpn.period import (
    CUTOFF_COMPLETED_DAY,
    DEFAULT_WINDOW_DAYS,
    build_period,
    default_period,
    inclusive_dates_to_window,
    parse_local_date,
    parse_window_days,
    window_to_period,
)


def clock_at(moment):
    return FixedClock(moment)


class TestDefaultWindow:
    def test_default_is_thirty_three_days(self):
        assert DEFAULT_WINDOW_DAYS == 33

    @pytest.mark.parametrize(
        "value,expected",
        [(None, 33), ("", 33), ("1", 1), ("7", 7), ("400", 400)],
    )
    def test_window_days_parser(self, value, expected):
        assert parse_window_days(value) == expected

    @pytest.mark.parametrize("value", ["0", "-1", "401", "seven"])
    def test_window_days_parser_rejects_invalid_values(self, value):
        with pytest.raises(ValueError, match="BACKTEST_WINDOW_DAYS"):
            parse_window_days(value)

    def test_exactly_thirty_three_distinct_local_dates(self):
        period = default_period(clock_at(datetime(2026, 7, 29, 15, 30)))
        assert period.start_text == "2026-06-27"
        assert period.end_inclusive_text == "2026-07-29"
        assert period.total_calendar_days == 33
        assert len(set(period.local_dates())) == 33

    def test_start_is_current_date_minus_thirty_two_days(self):
        reference = date(2026, 7, 29)
        period = default_period(clock_at(datetime(2026, 7, 29, 0, 0)))
        assert period.start_date == reference - timedelta(days=32)
        assert period.end_date_inclusive == reference

    @pytest.mark.parametrize(
        "moment,expected",
        [
            # Virada de mês
            (datetime(2026, 3, 1, 12), ("2026-01-28", "2026-03-01")),
            # Virada de ano
            (datetime(2026, 1, 5, 12), ("2025-12-04", "2026-01-05")),
            # Ano bissexto: 29/02 existe em 2024 e entra na contagem
            (datetime(2024, 3, 1, 12), ("2024-01-29", "2024-03-01")),
            (datetime(2024, 3, 5, 12), ("2024-02-02", "2024-03-05")),
        ],
    )
    def test_month_year_and_leap_boundaries(self, moment, expected):
        period = default_period(clock_at(moment))
        assert (period.start_text, period.end_inclusive_text) == expected
        assert period.total_calendar_days == 33

    def test_leap_day_is_inside_the_window(self):
        period = default_period(clock_at(datetime(2024, 3, 1, 12)))
        assert "2024-02-29" in period.local_dates()

    def test_local_date_not_utc_date_drives_default(self):
        # 01/01 02:30 UTC ainda é 31/12 em America/Sao_Paulo.
        period = default_period(clock_at(datetime(2026, 1, 1, 2, 30, tzinfo=timezone.utc)))
        assert period.end_inclusive_text == "2025-12-31"
        assert period.start_text == "2025-11-29"
        assert period.total_calendar_days == 33

    def test_midnight_boundary_keeps_thirty_three_days(self):
        just_after = default_period(clock_at(datetime(2026, 7, 30, 0, 0, 0)))
        just_before = default_period(clock_at(datetime(2026, 7, 29, 23, 59, 59)))
        assert just_after.end_inclusive_text == "2026-07-30"
        assert just_before.end_inclusive_text == "2026-07-29"
        assert just_after.total_calendar_days == just_before.total_calendar_days == 33

    def test_completed_day_cutoff_ends_yesterday(self):
        period = default_period(
            clock_at(datetime(2026, 7, 30, 3, 0)), cutoff_mode=CUTOFF_COMPLETED_DAY
        )
        assert period.end_inclusive_text == "2026-07-29"
        assert period.start_text == "2026-06-27"
        assert period.total_calendar_days == 33

    def test_cutoff_description_is_explicit(self):
        completed = default_period(
            clock_at(datetime(2026, 7, 30, 3, 0)), cutoff_mode=CUTOFF_COMPLETED_DAY
        )
        current = default_period(clock_at(datetime(2026, 7, 30, 3, 0)))
        assert "completo" in completed.data_cutoff_description
        assert "parcial" in current.data_cutoff_description

    def test_invalid_cutoff_mode(self):
        with pytest.raises(ValueError, match="Corte de dados inválido"):
            default_period(clock_at(datetime(2026, 7, 30)), cutoff_mode="ontem")


class TestWindowConversion:
    def test_inclusive_dates_become_half_open_window(self):
        assert inclusive_dates_to_window("2026-06-27", "2026-07-29") == (
            "2026-06-27 00:00:00",
            "2026-07-30 00:00:00",
        )

    def test_single_day_window_covers_one_full_day(self):
        start, end = inclusive_dates_to_window("2026-07-29", "2026-07-29")
        assert (start, end) == ("2026-07-29 00:00:00", "2026-07-30 00:00:00")

    def test_round_trip_preserves_inclusive_dates(self):
        original = default_period(clock_at(datetime(2026, 7, 29, 12)))
        restored = window_to_period(
            original.start_timestamp, original.end_exclusive_timestamp
        )
        assert restored.start_text == original.start_text
        assert restored.end_inclusive_text == original.end_inclusive_text
        assert restored.total_calendar_days == 33

    def test_payload_records_boundaries_and_cutoff(self):
        payload = default_period(clock_at(datetime(2026, 7, 29, 12))).as_payload()
        assert payload["start_date"] == "2026-06-27"
        assert payload["end_date_inclusive"] == "2026-07-29"
        assert payload["end_exclusive"] == "2026-07-30 00:00:00"
        assert payload["total_calendar_days"] == 33
        assert payload["data_cutoff"] == "2026-07-30 00:00:00"
        assert "[início, fim)" in payload["boundary_semantics"]

    @pytest.mark.parametrize(
        "start,end",
        [("2026-07-30", "2026-07-29"), ("2026-02-30", "2026-03-01"), ("", "2026-03-01")],
    )
    def test_invalid_ranges_are_rejected(self, start, end):
        with pytest.raises(ValueError, match="Período inválido"):
            build_period(start, end)

    def test_absurdly_long_range_is_rejected(self):
        with pytest.raises(ValueError, match="excedem o limite"):
            build_period("2020-01-01", "2026-01-01")

    def test_inverted_technical_window_is_rejected(self):
        with pytest.raises(ValueError, match="Janela inválida"):
            window_to_period("2026-07-30 00:00:00", "2026-07-29 00:00:00")

    def test_parse_local_date_accepts_date_objects(self):
        assert parse_local_date(date(2026, 7, 29), "x") == date(2026, 7, 29)
        assert parse_local_date(datetime(2026, 7, 29, 10), "x") == date(2026, 7, 29)
