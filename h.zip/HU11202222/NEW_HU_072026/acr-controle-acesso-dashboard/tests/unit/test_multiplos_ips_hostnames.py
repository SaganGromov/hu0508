"""Unit tests for pages/multiplos_ips_hostnames.py — render_multi_analysis function."""

import sys
from datetime import datetime
from pathlib import Path
from unittest.mock import MagicMock, patch

import pandas as pd

# Mock streamlit before importing
sys.path.insert(0, str(Path(__file__).resolve().parent))
from streamlit_mock_helper import install_streamlit_mock, import_page_module, reimport_page_with_session_state, make_sample_logins_df
_mock_st = install_streamlit_mock()

_PAGES_DIR = str(Path(__file__).resolve().parents[2] / "acr_controle_acesso_dashboard" / "streamlit_app" / "pages")
_STREAMLIT_DIR = str(Path(__file__).resolve().parents[2] / "acr_controle_acesso_dashboard" / "streamlit_app")
sys.path.insert(0, _PAGES_DIR)
sys.path.insert(0, _STREAMLIT_DIR)

with patch("auth_token.resolve_authenticated_user", return_value="F0000001"):
    multiplos_ips_hostnames = import_page_module(
        "multiplos_ips_hostnames",
        str(Path(_PAGES_DIR) / "multiplos_ips_hostnames.py"),
    )


def _make_logins_df():
    """Create a sample DataFrame with multi-IP and multi-hostname users."""
    return pd.DataFrame({
        "timestamp": [
            datetime(2025, 1, 1, 10, 0),
            datetime(2025, 1, 1, 11, 0),
            datetime(2025, 1, 1, 12, 0),
            datetime(2025, 1, 1, 13, 0),
            datetime(2025, 1, 1, 14, 0),
        ],
        "chave": ["F1000000", "F1000000", "F1000000", "F2000000", "F2000000"],
        "user": ["User1", "User1", "User1", "User2", "User2"],
        "status": ["Success"] * 5,
        "src_ip": ["10.0.0.1", "10.0.0.2", "10.0.0.3", "10.0.0.4", "10.0.0.4"],
        "hostname": ["hostA", "hostB", "hostC", "hostD", "hostD"],
        "os": ["Windows 11"] * 5,
        "tunnel": ["IPSec"] * 5,
        "login_option": ["certificate"] * 5,
        "client_version": ["1.0"] * 5,
        "mac_address": ["AA:BB:CC:DD:EE:01", "AA:BB:CC:DD:EE:02", "AA:BB:CC:DD:EE:03", "AA:BB:CC:DD:EE:04", "AA:BB:CC:DD:EE:04"],
        "office_mode_ip": ["192.168.1.1"] * 5,
        "fingerprint": ["fp1"] * 5,
        "user_group": ["group1"] * 5,
        "eventos": [1] * 5,
    })


class TestRenderMultiAnalysis:
    def test_renders_with_data(self):
        df = _make_logins_df()
        # Should not raise
        multiplos_ips_hostnames.render_multi_analysis(df)

    def test_renders_with_empty_df(self):
        df = pd.DataFrame()
        multiplos_ips_hostnames.render_multi_analysis(df)

    def test_renders_with_single_user_no_alerts(self):
        df = pd.DataFrame({
            "timestamp": [datetime(2025, 1, 1, 10, 0)],
            "chave": ["F1000000"],
            "user": ["User1"],
            "src_ip": ["10.0.0.1"],
            "hostname": ["host1"],
            "mac_address": ["AA:BB:CC:DD:EE:01"],
        })
        multiplos_ips_hostnames.render_multi_analysis(df)

    def test_renders_with_both_multi_ip_and_hostname(self):
        df = _make_logins_df()
        multiplos_ips_hostnames.render_multi_analysis(df)
        # Verify streamlit calls were made
        _mock_st.columns.assert_called()


class TestRenderingCoverage:
    """Re-import with session state to cover retroactive mode code."""

    def test_retroactive_mode_render(self):
        mod = reimport_page_with_session_state(
            "multiplos_ips_hostnames",
            str(Path(_PAGES_DIR) / "multiplos_ips_hostnames.py"),
            session_state={
                "multi_df": make_sample_logins_df(),
                "multi_msg_count": 100,
            },
        )
        assert hasattr(mod, "render_multi_analysis")
