"""Unit tests for curio_service.py"""

import sys
from pathlib import Path
from unittest.mock import patch, Mock

import requests

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "acr_controle_acesso_dashboard" / "streamlit_app"))

import curio_service
from curio_service import integracao_curio


class TestIntegracaoCurio:
    def setup_method(self):
        curio_service._mark_connection_available()

    def test_successful_call(self, monkeypatch):
        monkeypatch.setenv("CURIO_BASE_URL", "http://curio:8081")
        mock_resp = Mock()
        mock_resp.json.return_value = {"codigoErro": 0, "nomeUsuario": "Teste"}
        mock_resp.raise_for_status = Mock()

        with patch("curio_service.requests.post", return_value=mock_resp) as mock_post:
            result = integracao_curio("op292018v3", {"codigoClientePesquisa": "F1234567"})

        assert result == {"codigoErro": 0, "nomeUsuario": "Teste"}
        mock_post.assert_called_once()
        call_args = mock_post.call_args
        assert call_args[0][0] == "http://curio:8081/op292018v3"

    def test_defaults_to_same_pod_sidecar(self, monkeypatch):
        monkeypatch.delenv("CURIO_BASE_URL", raising=False)
        mock_resp = Mock()
        mock_resp.json.return_value = {}
        mock_resp.raise_for_status = Mock()

        with patch("curio_service.requests.post", return_value=mock_resp) as mock_post:
            integracao_curio("op292018v3", {})

        assert mock_post.call_args[0][0] == "http://localhost:8081/op292018v3"

    def test_timeout_returns_none(self):
        with patch("curio_service.requests.post", side_effect=requests.exceptions.Timeout()):
            result = integracao_curio("op292018v3", {})
        assert result is None

    def test_disabled_integration_does_not_call_http(self, monkeypatch):
        monkeypatch.setenv("CURIO_ENABLED", "false")
        with patch("curio_service.requests.post") as mock_post:
            assert integracao_curio("op292018v3", {}) is None
        mock_post.assert_not_called()

    def test_connection_error_pauses_following_calls(self):
        error = requests.exceptions.ConnectionError("connection refused")
        with patch("curio_service.requests.post", side_effect=error) as mock_post:
            assert integracao_curio("op292018v3", {}) is None
            assert integracao_curio("op292018v3", {}) is None
        mock_post.assert_called_once()

    def test_http_error_returns_none(self):
        with patch("curio_service.requests.post", side_effect=requests.exceptions.HTTPError("500")):
            result = integracao_curio("op292018v3", {})
        assert result is None

    def test_unexpected_error_returns_none(self):
        with patch("curio_service.requests.post", side_effect=Exception("connection refused")):
            result = integracao_curio("op292018v3", {})
        assert result is None

    def test_url_is_composed_from_base_and_operation(self):
        mock_resp = Mock()
        mock_resp.json.return_value = {}
        mock_resp.raise_for_status = Mock()

        with patch("curio_service.requests.post", return_value=mock_resp) as mock_post:
            integracao_curio("op2076328v2", {"key": "value"})

        url = mock_post.call_args[0][0]
        assert url.endswith("/op2076328v2")

    def test_payload_is_sent_as_json(self):
        mock_resp = Mock()
        mock_resp.json.return_value = {}
        mock_resp.raise_for_status = Mock()
        payload = {"codigoClientePesquisa": "F9999999"}

        with patch("curio_service.requests.post", return_value=mock_resp) as mock_post:
            integracao_curio("op292018v3", payload)

        assert mock_post.call_args[1]["json"] == payload

    def test_rejects_operation_path_injection_without_http_call(self):
        with patch("curio_service.requests.post") as mock_post:
            assert integracao_curio("../admin", {}) is None
        mock_post.assert_not_called()
