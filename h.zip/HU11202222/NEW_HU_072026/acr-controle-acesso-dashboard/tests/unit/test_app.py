"""Unit tests for app.py — helper functions, auth logic, and FastAPI endpoints."""

import asyncio
import base64
import hashlib
import hmac
import os
import sys
from pathlib import Path
from unittest.mock import patch, AsyncMock, Mock, MagicMock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import app as app_module


@pytest.fixture(autouse=True)
def configured_oauth_issuer(monkeypatch):
    monkeypatch.setenv("OAUTH2_ISSUER_BASE_URL", "https://sso.example.invalid")
    monkeypatch.setenv("OAUTH2_REDIRECT_URI", "https://dashboard.example.invalid/auth/callback")
    monkeypatch.setenv("PUBLIC_BASE_URL", "https://dashboard.example.invalid")


# ── Helper function tests ────────────────────────────────────


class TestStripTrailingSlash:
    def test_strips_trailing_slash(self):
        assert app_module._strip_trailing_slash("http://example.com/") == "http://example.com"

    def test_no_trailing_slash(self):
        assert app_module._strip_trailing_slash("http://example.com") == "http://example.com"

    def test_only_slash(self):
        assert app_module._strip_trailing_slash("/") == ""

    def test_empty_string(self):
        assert app_module._strip_trailing_slash("") == ""


class TestNormalizeBasePath:
    def test_normalizes_path(self):
        assert app_module._normalize_base_path("/streamlit/") == "/streamlit"

    def test_adds_leading_slash(self):
        assert app_module._normalize_base_path("streamlit") == "/streamlit"

    def test_empty_returns_empty(self):
        assert app_module._normalize_base_path("") == ""

    def test_only_slashes_returns_empty(self):
        assert app_module._normalize_base_path("///") == ""

    def test_whitespace_stripped(self):
        assert app_module._normalize_base_path("  /streamlit/  ") == "/streamlit"


class TestParseAllowedMatriculas:
    def test_parses_comma_separated(self):
        result = app_module._parse_allowed_matriculas("F1234567,F7654321")
        assert result == {"F1234567", "F7654321"}

    def test_parses_semicolon_separated(self):
        result = app_module._parse_allowed_matriculas("F1234567;F7654321")
        assert result == {"F1234567", "F7654321"}

    def test_parses_space_separated(self):
        result = app_module._parse_allowed_matriculas("F1234567 F7654321")
        assert result == {"F1234567", "F7654321"}

    def test_ignores_invalid_entries(self):
        result = app_module._parse_allowed_matriculas("F1234567,INVALID,F7654321,123")
        assert result == {"F1234567", "F7654321"}

    def test_uppercases_entries(self):
        result = app_module._parse_allowed_matriculas("f1234567")
        assert result == {"F1234567"}

    def test_empty_returns_empty_set(self):
        result = app_module._parse_allowed_matriculas("")
        assert result == set()


class TestExtractMatricula:
    def test_extracts_from_chave_usuario(self):
        assert app_module._extract_matricula({"chave_usuario": "F1234567"}) == "F1234567"

    def test_extracts_from_uid(self):
        assert app_module._extract_matricula({"uid": "F1234567"}) == "F1234567"

    def test_extracts_from_email(self):
        assert app_module._extract_matricula({"email": "f1234567@bb.com.br"}) == "F1234567"

    def test_extracts_from_subname(self):
        assert app_module._extract_matricula({"subname": "F1234567"}) == "F1234567"

    def test_extracts_lowercase(self):
        assert app_module._extract_matricula({"chave_usuario": "f1234567"}) == "F1234567"

    def test_returns_empty_when_not_found(self):
        assert app_module._extract_matricula({"name": "John Doe"}) == ""

    def test_returns_empty_for_empty_dict(self):
        assert app_module._extract_matricula({}) == ""

    def test_extracts_from_name_with_embedded_chave(self):
        assert app_module._extract_matricula({"name": "F1234567 John Doe"}) == "F1234567"

    def test_priority_order(self):
        # chave_usuario has higher priority
        result = app_module._extract_matricula({
            "chave_usuario": "F1111111",
            "uid": "F2222222",
        })
        assert result == "F1111111"


class TestBuildSessionUser:
    def test_builds_from_userinfo(self):
        userinfo = {"sub": "sub123", "name": "John Doe", "email": "john@bb.com.br"}
        result = app_module._build_session_user(userinfo, "F1234567")
        assert result == {
            "sub": "sub123",
            "name": "John Doe",
            "email": "john@bb.com.br",
            "matricula": "F1234567",
        }

    def test_defaults_to_matricula(self):
        result = app_module._build_session_user({}, "F1234567")
        assert result["sub"] == "F1234567"
        assert result["name"] == "F1234567"
        assert result["email"] == ""


class TestAccessTokenStore:
    def test_store_and_pop(self):
        key = app_module._store_access_token("my-access-token")
        assert key  # non-empty
        assert app_module._pop_access_token(key) == "my-access-token"

    def test_pop_missing_key_returns_empty(self):
        assert app_module._pop_access_token("nonexistent") == ""

    def test_pop_empty_key_returns_empty(self):
        assert app_module._pop_access_token("") == ""

    def test_double_pop_returns_empty(self):
        key = app_module._store_access_token("token")
        app_module._pop_access_token(key)
        assert app_module._pop_access_token(key) == ""


class TestIsMatriculaAuthorized:
    def test_authorized_when_digest_matches(self, monkeypatch):
        hmac_key = b"test-key"
        matricula = "F1234567"
        digest = hmac.new(hmac_key, matricula.encode("utf-8"), hashlib.sha256).hexdigest()
        monkeypatch.setattr(app_module, "MATRICULA_HMAC_KEY", hmac_key)
        monkeypatch.setattr(app_module, "ALLOWED_MATRICULA_DIGESTS", {digest})
        assert app_module._is_matricula_authorized(matricula) is True

    def test_not_authorized_when_digest_doesnt_match(self, monkeypatch):
        monkeypatch.setattr(app_module, "MATRICULA_HMAC_KEY", b"test-key")
        monkeypatch.setattr(app_module, "ALLOWED_MATRICULA_DIGESTS", {"wronghash" * 4})
        assert app_module._is_matricula_authorized("F1234567") is False

    def test_not_authorized_when_no_key(self, monkeypatch):
        monkeypatch.setattr(app_module, "MATRICULA_HMAC_KEY", b"")
        monkeypatch.setattr(app_module, "ALLOWED_MATRICULA_DIGESTS", {"somedigest"})
        assert app_module._is_matricula_authorized("F1234567") is False

    def test_not_authorized_when_no_digests(self, monkeypatch):
        monkeypatch.setattr(app_module, "MATRICULA_HMAC_KEY", b"test-key")
        monkeypatch.setattr(app_module, "ALLOWED_MATRICULA_DIGESTS", set())
        assert app_module._is_matricula_authorized("F1234567") is False


class TestLoadSecretFile:
    def test_reads_file_content(self, tmp_path):
        secret_file = tmp_path / "secret"
        secret_file.write_text("my-secret-value\n")
        result = app_module._load_secret_file(str(secret_file))
        assert result == "my-secret-value"

    def test_returns_empty_on_missing_file(self):
        result = app_module._load_secret_file("/nonexistent/path")
        assert result == ""


class TestLoadMatriculaHmacKey:
    def test_from_env(self, monkeypatch):
        monkeypatch.setenv("MATRICULA_HMAC_KEY", "env-key")
        result = app_module._load_matricula_hmac_key()
        assert result == b"env-key"

    def test_from_file(self, monkeypatch, tmp_path):
        monkeypatch.delenv("MATRICULA_HMAC_KEY", raising=False)
        key_file = tmp_path / "key"
        key_file.write_text("file-key")
        monkeypatch.setenv("MATRICULA_HMAC_KEY_FILE", str(key_file))
        result = app_module._load_matricula_hmac_key()
        assert result == b"file-key"

    def test_returns_empty_when_no_source(self, monkeypatch, tmp_path):
        monkeypatch.delenv("MATRICULA_HMAC_KEY", raising=False)
        monkeypatch.setenv("MATRICULA_HMAC_KEY_FILE", str(tmp_path / "nonexistent"))
        result = app_module._load_matricula_hmac_key()
        assert result == b""


class TestLoadAllowedMatriculaDigests:
    def test_from_env(self, monkeypatch):
        digest = "a" * 64
        monkeypatch.setenv("ALLOWED_MATRICULA_DIGESTS", digest)
        result = app_module._load_allowed_matricula_digests()
        assert result == {digest}

    def test_from_env_ignores_invalid(self, monkeypatch):
        monkeypatch.setenv("ALLOWED_MATRICULA_DIGESTS", "short,invalid")
        result = app_module._load_allowed_matricula_digests()
        assert result == set()

    def test_from_file(self, monkeypatch, tmp_path):
        monkeypatch.delenv("ALLOWED_MATRICULA_DIGESTS", raising=False)
        digest = "b" * 64
        digest_file = tmp_path / "digests"
        digest_file.write_text(digest)
        monkeypatch.setenv("ALLOWED_MATRICULA_DIGESTS_FILE", str(digest_file))
        result = app_module._load_allowed_matricula_digests()
        assert result == {digest}

    def test_returns_empty_when_no_source(self, monkeypatch, tmp_path):
        monkeypatch.delenv("ALLOWED_MATRICULA_DIGESTS", raising=False)
        monkeypatch.setenv("ALLOWED_MATRICULA_DIGESTS_FILE", str(tmp_path / "nonexistent"))
        result = app_module._load_allowed_matricula_digests()
        assert result == set()


# ── Logging tests ─────────────────────────────────────────────


class TestHealthCheckFilter:
    def test_filters_health_check_info_log(self):
        import logging
        f = app_module._HealthCheckFilter()
        record = logging.LogRecord(
            name="uvicorn.access", level=logging.INFO, pathname="", lineno=0,
            msg='GET /healthz HTTP/1.1', args=(), exc_info=None,
        )
        assert f.filter(record) is False

    def test_passes_non_health_info_log(self):
        import logging
        f = app_module._HealthCheckFilter()
        record = logging.LogRecord(
            name="uvicorn.access", level=logging.INFO, pathname="", lineno=0,
            msg='GET /dashboard HTTP/1.1', args=(), exc_info=None,
        )
        assert f.filter(record) is True

    def test_passes_health_warning_log(self):
        import logging
        f = app_module._HealthCheckFilter()
        record = logging.LogRecord(
            name="uvicorn.access", level=logging.WARNING, pathname="", lineno=0,
            msg='GET /healthz HTTP/1.1', args=(), exc_info=None,
        )
        assert f.filter(record) is True


class TestBrasiliaFormatter:
    def test_formats_time_in_brasilia(self):
        import logging
        fmt = app_module._BrasiliaFormatter()
        record = logging.LogRecord(
            name="test", level=logging.INFO, pathname="", lineno=0,
            msg="test", args=(), exc_info=None,
        )
        result = fmt.formatTime(record)
        # Should be a valid ISO format string
        assert "T" in result or "-" in result

    def test_formats_with_custom_datefmt(self):
        import logging
        fmt = app_module._BrasiliaFormatter()
        record = logging.LogRecord(
            name="test", level=logging.INFO, pathname="", lineno=0,
            msg="test", args=(), exc_info=None,
        )
        result = fmt.formatTime(record, datefmt="%Y-%m-%d")
        assert len(result) == 10  # YYYY-MM-DD


# ── URL resolution tests ─────────────────────────────────────


def _make_request(path="/", headers=None, session=None):
    """Create a minimal Starlette Request for testing."""
    from starlette.requests import Request

    request_headers = [
        (key.lower().encode("latin-1"), value.encode("latin-1"))
        for key, value in (headers or {}).items()
    ]
    if not any(key == b"host" for key, _ in request_headers):
        request_headers.append((b"host", b"testserver"))

    scope = {
        "type": "http",
        "http_version": "1.1",
        "method": "GET",
        "scheme": "http",
        "path": path,
        "raw_path": path.encode("latin-1"),
        "query_string": b"",
        "root_path": "",
        "headers": request_headers,
        "client": ("testclient", 50000),
        "server": ("testserver", 80),
        "app": app_module.app,
        "session": session or {},
    }
    return Request(scope)


class TestRequestOrigin:
    def test_uses_public_base_url_when_set(self, monkeypatch):
        monkeypatch.setenv("PUBLIC_BASE_URL", "https://public.example.com")
        request = _make_request()
        assert app_module._request_origin(request) == "https://public.example.com"

    def test_request_origin_rejects_untrusted_forwarded_headers(self, monkeypatch):
        monkeypatch.delenv("PUBLIC_BASE_URL", raising=False)
        request = _make_request(headers={
            "x-forwarded-proto": "https",
            "x-forwarded-host": "proxy.example.com",
        })
        with pytest.raises(RuntimeError, match="PUBLIC_BASE_URL"):
            app_module._request_origin(request)

    def test_rejects_untrusted_forwarded_prefix(self, monkeypatch):
        monkeypatch.delenv("PUBLIC_BASE_URL", raising=False)
        request = _make_request(headers={
            "x-forwarded-proto": "https",
            "x-forwarded-host": "proxy.example.com",
            "x-forwarded-prefix": "/app",
        })
        with pytest.raises(RuntimeError, match="PUBLIC_BASE_URL"):
            app_module._request_origin(request)

    def test_rejects_non_local_host_header(self, monkeypatch):
        monkeypatch.delenv("PUBLIC_BASE_URL", raising=False)
        request = _make_request(headers={"host": "direct.example.com:8000"})
        with pytest.raises(RuntimeError, match="PUBLIC_BASE_URL"):
            app_module._request_origin(request)


class TestRequestHost:
    def test_does_not_trust_forwarded_host(self):
        request = _make_request(headers={"x-forwarded-host": "proxy.example.com"})
        assert app_module._request_host(request) == "testserver"

    def test_extracts_from_host_with_port(self):
        request = _make_request(headers={"host": "example.com:8000"})
        assert app_module._request_host(request) == "example.com"

    def test_handles_ipv6(self):
        request = _make_request(headers={"host": "[::1]:8000"})
        assert app_module._request_host(request) == "::1"


class TestForwardedHeader:
    def test_returns_first_value(self):
        request = _make_request(headers={"x-forwarded-for": "10.0.0.1, 10.0.0.2"})
        assert app_module._forwarded_header(request, "x-forwarded-for") == "10.0.0.1"

    def test_returns_empty_when_missing(self):
        request = _make_request()
        assert app_module._forwarded_header(request, "x-forwarded-for") == ""


class TestResolveRedirectUri:
    def test_uses_env_when_set(self, monkeypatch):
        monkeypatch.setenv("OAUTH2_REDIRECT_URI", "https://example.com/callback")
        request = _make_request()
        assert app_module._resolve_redirect_uri(request) == "https://example.com/callback"

    def test_uses_localhost_default(self, monkeypatch):
        monkeypatch.delenv("OAUTH2_REDIRECT_URI", raising=False)
        request = _make_request(headers={"host": "localhost:8000"})
        assert app_module._resolve_redirect_uri(request) == "http://localhost:8000/auth/callback"

    def test_requires_configured_origin_for_non_local(self, monkeypatch):
        monkeypatch.delenv("OAUTH2_REDIRECT_URI", raising=False)
        monkeypatch.delenv("PUBLIC_BASE_URL", raising=False)
        request = _make_request(headers={
            "host": "example.com",
            "x-forwarded-proto": "https",
            "x-forwarded-host": "example.com",
        })
        with pytest.raises(RuntimeError, match="PUBLIC_BASE_URL"):
            app_module._resolve_redirect_uri(request)

    def test_rejects_insecure_external_redirect(self, monkeypatch):
        monkeypatch.setenv("OAUTH2_REDIRECT_URI", "http://example.com/callback")
        with pytest.raises(RuntimeError, match="HTTPS"):
            app_module._resolve_redirect_uri(_make_request())


class TestStreamlitBasePath:
    def test_default_path(self, monkeypatch):
        monkeypatch.delenv("STREAMLIT_BASE_URL_PATH", raising=False)
        assert app_module._streamlit_base_path() == "/streamlit"

    def test_custom_path(self, monkeypatch):
        monkeypatch.setenv("STREAMLIT_BASE_URL_PATH", "/custom")
        assert app_module._streamlit_base_path() == "/custom"


class TestStreamlitCookieSecure:
    def test_matches_secure_session_cookie_policy(self, monkeypatch):
        monkeypatch.setattr(app_module, "_session_cookie_secure", True)
        request = _make_request(headers={"x-forwarded-proto": "http"})
        assert app_module._streamlit_cookie_secure(request) is True

    def test_matches_explicit_insecure_local_policy(self, monkeypatch):
        monkeypatch.setattr(app_module, "_session_cookie_secure", False)
        request = _make_request(headers={"x-forwarded-proto": "https"})
        assert app_module._streamlit_cookie_secure(request) is False


# ── FastAPI endpoint tests ────────────────────────────────────

from fastapi.testclient import TestClient

client = TestClient(app_module.app, base_url="https://testserver")


class TestHealthEndpoints:
    def test_healthz(self):
        resp = client.get("/healthz")
        assert resp.status_code == 200
        assert resp.json() == {"status": "ok"}

    def test_health(self):
        assert client.get("/health").status_code == 200

    def test_health_live(self):
        assert client.get("/health/live").status_code == 200

    def test_health_ready(self):
        assert client.get("/health/ready").status_code == 200


class TestIndexEndpoint:
    def test_unauthenticated_shows_login(self):
        resp = client.get("/", follow_redirects=False)
        assert resp.status_code == 200

    def test_authenticated_redirects_to_dashboard(self):
        # Inject session data directly
        with client:
            # Use session middleware
            resp = client.get("/")
            # By default no session user — should show login
            assert resp.status_code == 200


class TestDashboardEndpoint:
    def test_unauthenticated_redirects(self):
        resp = client.get("/dashboard", follow_redirects=False)
        assert resp.status_code == 307
        assert resp.headers["location"] == "/"


class TestLogoutEndpoint:
    def test_logout_redirects_to_root(self):
        resp = client.get("/logout", follow_redirects=False)
        assert resp.status_code == 307
        assert resp.headers["location"] == "/"

    def test_logout_clears_auth_cookie(self):
        resp = client.get("/logout", follow_redirects=False)
        cookie_header = resp.headers.get("set-cookie", "")
        assert "dashboard_streamlit_auth" in cookie_header


class TestAuditSearchEndpoint:
    def test_unauthenticated_returns_error(self):
        resp = client.post("/api/audit/search", json={"query": "test", "page": "page1"})
        assert resp.status_code == 401
        assert resp.json()["ok"] is False
        assert resp.json()["reason"] == "unauthenticated"


class TestLoginEndpoint:
    def test_login_redirects_to_authorize(self):
        resp = client.get("/login", follow_redirects=False)
        assert resp.status_code == 307
        location = resp.headers["location"]
        assert "authorize" in location
        assert "response_type=code" in location


class TestAuthCallbackEndpoint:
    def test_missing_state_returns_403(self):
        resp = client.get("/auth/callback?code=abc&state=wrong")
        assert resp.status_code == 403

    def test_missing_code_returns_400(self):
        # First set up a valid state in the session
        with client:
            # Get a login redirect to set the state
            login_resp = client.get("/login", follow_redirects=False)
            # Now callback without code
            resp = client.get("/auth/callback?state=fake")
            assert resp.status_code in (400, 403)


class TestAuthCallbackOAuthFlow:
    """Test the full auth callback flow with mocked HTTP calls."""

    def _setup_session_with_state(self, state_value="test-state"):
        """Helper to create a client with a pre-set oauth_state in session."""
        with client:
            # Set session by hitting login which sets oauth_state
            resp = client.get("/login", follow_redirects=False)
            # Extract state from redirect URL
            import urllib.parse
            location = resp.headers["location"]
            query = urllib.parse.parse_qs(urllib.parse.urlparse(location).query)
            return query.get("state", [""])[0]

    def test_token_exchange_failure(self):
        """Test handling of failed token exchange."""
        import httpx

        with client:
            # First set up a session with a valid state
            login_resp = client.get("/login", follow_redirects=False)
            import urllib.parse
            location = login_resp.headers["location"]
            query = urllib.parse.parse_qs(urllib.parse.urlparse(location).query)
            state = query["state"][0]

            # Mock the token exchange to fail
            mock_response = httpx.Response(500, json={"error": "server_error"})
            with patch("app.httpx.AsyncClient") as mock_client_cls:
                mock_client_instance = AsyncMock()
                mock_client_instance.post.return_value = mock_response
                mock_client_instance.__aenter__ = AsyncMock(return_value=mock_client_instance)
                mock_client_instance.__aexit__ = AsyncMock(return_value=False)
                mock_client_cls.return_value = mock_client_instance

                resp = client.get(f"/auth/callback?code=testcode&state={state}")
                assert resp.status_code == 502

    def test_missing_access_token_in_response(self):
        """Test handling when token response has no access_token."""
        import httpx

        with client:
            login_resp = client.get("/login", follow_redirects=False)
            import urllib.parse
            location = login_resp.headers["location"]
            query = urllib.parse.parse_qs(urllib.parse.urlparse(location).query)
            state = query["state"][0]

            mock_response = httpx.Response(200, json={"token_type": "bearer"})
            with patch("app.httpx.AsyncClient") as mock_client_cls:
                mock_client_instance = AsyncMock()
                mock_client_instance.post.return_value = mock_response
                mock_client_instance.__aenter__ = AsyncMock(return_value=mock_client_instance)
                mock_client_instance.__aexit__ = AsyncMock(return_value=False)
                mock_client_cls.return_value = mock_client_instance

                resp = client.get(f"/auth/callback?code=testcode&state={state}")
                assert resp.status_code == 502

    def test_userinfo_failure(self):
        """Test handling of failed userinfo fetch."""
        import httpx

        with client:
            login_resp = client.get("/login", follow_redirects=False)
            import urllib.parse
            location = login_resp.headers["location"]
            query = urllib.parse.parse_qs(urllib.parse.urlparse(location).query)
            state = query["state"][0]

            token_response = httpx.Response(200, json={"access_token": "test-token"})
            userinfo_response = httpx.Response(401, json={"error": "unauthorized"})

            with patch("app.httpx.AsyncClient") as mock_client_cls:
                mock_client_instance = AsyncMock()
                mock_client_instance.post.return_value = token_response
                mock_client_instance.get.return_value = userinfo_response
                mock_client_instance.__aenter__ = AsyncMock(return_value=mock_client_instance)
                mock_client_instance.__aexit__ = AsyncMock(return_value=False)
                mock_client_cls.return_value = mock_client_instance

                resp = client.get(f"/auth/callback?code=testcode&state={state}")
                assert resp.status_code == 502

    def test_matricula_not_found(self):
        """Test handling when matrícula can't be extracted from userinfo."""
        import httpx

        with client:
            login_resp = client.get("/login", follow_redirects=False)
            import urllib.parse
            location = login_resp.headers["location"]
            query = urllib.parse.parse_qs(urllib.parse.urlparse(location).query)
            state = query["state"][0]

            token_response = httpx.Response(200, json={"access_token": "test-token"})
            userinfo_response = httpx.Response(200, json={"name": "No Matricula User"})

            with patch("app.httpx.AsyncClient") as mock_client_cls:
                mock_client_instance = AsyncMock()
                mock_client_instance.post.return_value = token_response
                mock_client_instance.get.return_value = userinfo_response
                mock_client_instance.__aenter__ = AsyncMock(return_value=mock_client_instance)
                mock_client_instance.__aexit__ = AsyncMock(return_value=False)
                mock_client_cls.return_value = mock_client_instance

                resp = client.get(f"/auth/callback?code=testcode&state={state}")
                assert resp.status_code == 403

    def test_matricula_not_authorized(self, monkeypatch):
        """Test handling when matrícula is not in the authorized list."""
        import httpx

        monkeypatch.setattr(app_module, "MATRICULA_HMAC_KEY", b"test-key")
        monkeypatch.setattr(app_module, "ALLOWED_MATRICULA_DIGESTS", {"wrong" * 16})

        with client:
            login_resp = client.get("/login", follow_redirects=False)
            import urllib.parse
            location = login_resp.headers["location"]
            query = urllib.parse.parse_qs(urllib.parse.urlparse(location).query)
            state = query["state"][0]

            token_response = httpx.Response(200, json={"access_token": "test-token"})
            userinfo_response = httpx.Response(200, json={
                "chave_usuario": "F1234567",
                "name": "Test User",
                "sub": "sub123",
            })

            with patch("app.httpx.AsyncClient") as mock_client_cls:
                mock_client_instance = AsyncMock()
                mock_client_instance.post.return_value = token_response
                mock_client_instance.get.return_value = userinfo_response
                mock_client_instance.__aenter__ = AsyncMock(return_value=mock_client_instance)
                mock_client_instance.__aexit__ = AsyncMock(return_value=False)
                mock_client_cls.return_value = mock_client_instance

                resp = client.get(f"/auth/callback?code=testcode&state={state}")
                assert resp.status_code == 403

    def test_successful_login(self, monkeypatch):
        """Test full successful login flow."""
        import httpx

        matricula = "F1234567"
        hmac_key = b"test-key"
        digest = hmac.new(hmac_key, matricula.encode("utf-8"), hashlib.sha256).hexdigest()
        monkeypatch.setattr(app_module, "MATRICULA_HMAC_KEY", hmac_key)
        monkeypatch.setattr(app_module, "ALLOWED_MATRICULA_DIGESTS", {digest})
        monkeypatch.setenv("SESSION_SECRET", "test-session-secret")

        with client:
            login_resp = client.get("/login", follow_redirects=False)
            import urllib.parse
            location = login_resp.headers["location"]
            query = urllib.parse.parse_qs(urllib.parse.urlparse(location).query)
            state = query["state"][0]

            token_response = httpx.Response(200, json={"access_token": "test-token"})
            userinfo_response = httpx.Response(200, json={
                "chave_usuario": matricula,
                "name": "Test User",
                "sub": "sub123",
                "email": "test@bb.com.br",
            })

            with patch("app.httpx.AsyncClient") as mock_client_cls:
                mock_client_instance = AsyncMock()
                mock_client_instance.post.return_value = token_response
                mock_client_instance.get.return_value = userinfo_response
                mock_client_instance.__aenter__ = AsyncMock(return_value=mock_client_instance)
                mock_client_instance.__aexit__ = AsyncMock(return_value=False)
                mock_client_cls.return_value = mock_client_instance

                with patch("app.record_login"):
                    resp = client.get(f"/auth/callback?code=testcode&state={state}", follow_redirects=False)
                    assert resp.status_code == 307
                    assert resp.headers["location"] == "/dashboard"


class TestLogTimestamp:
    def test_returns_string(self):
        result = app_module._log_timestamp()
        assert isinstance(result, str)
        assert "T" in result


class TestOnStartup:
    def test_startup_does_not_enqueue_or_access_backtest_runtime(self, monkeypatch):
        def fail_if_called():
            raise AssertionError("startup must not access the backtest runtime")

        monkeypatch.setattr(app_module, "_backtest_runtime_instance", fail_if_called)
        asyncio.run(app_module._on_startup())
