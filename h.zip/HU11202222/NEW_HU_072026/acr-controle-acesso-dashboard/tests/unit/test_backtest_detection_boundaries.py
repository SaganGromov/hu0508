"""Fronteiras diárias, semântica de login e determinismo das regras.

Complementa ``test_backtest_detection.py`` cobrindo especificamente as
fronteiras de meia-noite, a semântica de refresh/retry/reconexão que a fonte
consultada **não** permite distinguir, e a estabilidade dos identificadores.
"""

from datetime import datetime, timedelta, timezone

import pytest

from backtest_vpn.detection import (
    APP_TIMEZONE,
    EVENT_RULE_IDS,
    DetectionConfig,
    normalize_events,
    run_event_rules,
)


def row(user, timestamp, source=None, corporate=None, hostname="EST-1", device="DEV-1"):
    return {
        "USER_KEY": user,
        "EVENT_TS": timestamp,
        "SOURCE_IP": source,
        "CORPORATE_IP": corporate,
        "HOSTNAME": hostname,
        "DEVICE_ID": device,
    }


def rules_for(rows, cfg=None):
    detected, quality = run_event_rules(rows, cfg or DetectionConfig())
    return detected, quality


class TestR1Boundaries:
    def test_change_across_midnight_creates_two_separate_days(self):
        rows = [
            row("T1", "2026-07-10 23:59:59", source="192.0.2.1"),
            row("T1", "2026-07-11 00:00:00", source="192.0.2.2"),
        ]
        detected, _ = rules_for(rows)
        # Um IP em cada dia local: nenhum dia atinge o limiar de 2.
        assert detected["R1"] == []

    def test_two_ips_just_before_midnight_flag_the_same_day(self):
        rows = [
            row("T1", "2026-07-10 23:58:00", source="192.0.2.1"),
            row("T1", "2026-07-10 23:59:59", source="192.0.2.2"),
        ]
        detected, _ = rules_for(rows)
        assert len(detected["R1"]) == 1
        assert detected["R1"][0]["local_date"] == "2026-07-10"

    def test_many_same_day_switches_are_one_occurrence_with_full_sequence(self):
        rows = [
            row("T1", "2026-07-10 {0:02d}:00:00".format(hour), source="192.0.2.{0}".format(hour))
            for hour in range(8, 18)
        ]
        detected, _ = rules_for(rows)
        assert len(detected["R1"]) == 1
        occurrence = detected["R1"][0]
        assert occurrence["triggering_value"]["source_ip_count"] == 10
        assert len(occurrence["details"]["ip_sequence"]) == 10
        assert occurrence["details"]["distinct_source_ips"] == sorted(
            occurrence["details"]["distinct_source_ips"]
        )

    def test_ip_sequence_is_chronological(self):
        rows = [
            row("T1", "2026-07-10 12:00:00", source="192.0.2.9"),
            row("T1", "2026-07-10 08:00:00", source="192.0.2.1"),
            row("T1", "2026-07-10 10:00:00", source="192.0.2.5"),
        ]
        detected, _ = rules_for(rows)
        sequence = detected["R1"][0]["details"]["ip_sequence"]
        assert [item["timestamp"] for item in sequence] == sorted(
            item["timestamp"] for item in sequence
        )

    def test_evidence_contains_required_fields(self):
        rows = [
            row("T1", "2026-07-10 08:00:00", source="192.0.2.1", corporate="10.0.0.1"),
            row("T1", "2026-07-10 09:00:00", source="192.0.2.2", corporate="10.0.0.1"),
        ]
        detected, _ = rules_for(rows)
        occurrence = detected["R1"][0]
        assert occurrence["first_event_timestamp"] and occurrence["last_event_timestamp"]
        assert occurrence["supporting_event_identifiers"]
        assert occurrence["details"]["distinct_source_ips"] == ["192.0.2.1", "192.0.2.2"]
        assert occurrence["details"]["distinct_corporate_ips"] == ["10.0.0.1"]
        for step in occurrence["details"]["ip_sequence"]:
            assert step["source_classification"]
            assert step["corporate_classification"]
            assert step["event_id"]

    def test_corporate_field_alone_can_trigger(self):
        rows = [
            row("T1", "2026-07-10 08:00:00", source="192.0.2.1", corporate="10.0.0.1"),
            row("T1", "2026-07-10 09:00:00", source="192.0.2.1", corporate="10.0.0.2"),
        ]
        detected, _ = rules_for(rows)
        assert len(detected["R1"]) == 1
        assert "corporativo" in detected["R1"][0]["explanation"]


class TestR4LoginSemantics:
    def test_midnight_resets_the_daily_count(self):
        rows = [
            row("T1", "2026-07-10 22:00:00", source="192.0.2.1"),
            row("T1", "2026-07-10 23:00:00", source="192.0.2.2"),
            row("T1", "2026-07-11 00:30:00", source="192.0.2.3"),
            row("T1", "2026-07-11 01:00:00", source="192.0.2.4"),
        ]
        detected, _ = rules_for(rows)
        # Dois em cada dia: nenhum dia excede dois.
        assert detected["R4"] == []

    def test_three_on_one_side_of_midnight_flags_only_that_day(self):
        rows = [
            row("T1", "2026-07-10 21:00:00", source="192.0.2.1"),
            row("T1", "2026-07-10 22:00:00", source="192.0.2.2"),
            row("T1", "2026-07-10 23:00:00", source="192.0.2.3"),
            row("T1", "2026-07-11 00:30:00", source="192.0.2.4"),
        ]
        detected, _ = rules_for(rows)
        assert len(detected["R4"]) == 1
        assert detected["R4"][0]["local_date"] == "2026-07-10"
        assert detected["R4"][0]["triggering_value"] == 3

    def test_exactly_identical_rows_are_deduplicated_as_one_login(self):
        """Linhas exatamente idênticas são duplicatas do banco, não logins novos."""
        base = row("T1", "2026-07-10 09:00:00", source="192.0.2.1", corporate="10.0.0.1")
        rows = [dict(base) for _ in range(5)]
        detected, quality = rules_for(rows)
        assert quality["duplicate_rows"] == 4
        assert quality["deduplicated_events"] == 1
        assert detected["R4"] == []

    def test_same_second_with_any_different_field_stays_a_distinct_event(self):
        """Sem semântica de sessão na fonte, refresh/retry não é descartável.

        Dois registros no mesmo segundo que diferem em qualquer campo continuam
        eventos distintos: a fonte consultada não expõe identificador de login,
        sessão, refresh, retry, heartbeat ou reconexão. A decisão de tratá-los
        de outra forma depende do dono da fonte.
        """
        rows = [
            row("T1", "2026-07-10 09:00:00", source="192.0.2.1", corporate="10.0.0.1"),
            row("T1", "2026-07-10 09:00:00", source="192.0.2.1", corporate="10.0.0.2"),
            row("T1", "2026-07-10 09:00:00", source="192.0.2.2", corporate="10.0.0.1"),
        ]
        detected, quality = rules_for(rows)
        assert quality["duplicate_rows"] == 0
        assert quality["deduplicated_events"] == 3
        assert detected["R4"][0]["triggering_value"] == 3

    def test_login_timestamps_are_reported_in_order(self):
        rows = [
            row("T1", "2026-07-10 11:00:00", source="192.0.2.3"),
            row("T1", "2026-07-10 09:00:00", source="192.0.2.1"),
            row("T1", "2026-07-10 10:00:00", source="192.0.2.2"),
        ]
        detected, _ = rules_for(rows)
        timestamps = detected["R4"][0]["details"]["login_timestamps"]
        assert timestamps == sorted(timestamps)
        assert len(timestamps) == 3

    @pytest.mark.parametrize("count,flagged", [(0, False), (1, False), (2, False), (3, True), (7, True)])
    def test_threshold_is_strictly_more_than_two(self, count, flagged):
        rows = [
            row("T1", "2026-07-10 {0:02d}:00:00".format(8 + index), source="192.0.2.{0}".format(index + 1))
            for index in range(count)
        ]
        detected, _ = rules_for(rows)
        assert bool(detected["R4"]) is flagged
        if flagged:
            assert detected["R4"][0]["triggering_value"] == count


class TestR7Boundaries:
    def test_same_device_across_midnight_is_not_a_same_day_association(self):
        rows = [
            row("T1", "2026-07-10 23:50:00", device="DEV-X"),
            row("T2", "2026-07-11 00:10:00", device="DEV-X"),
        ]
        detected, _ = rules_for(rows)
        assert len(detected["R7"]) == 1
        occurrence = detected["R7"][0]
        assert occurrence["details"]["same_day_association"] is False
        assert occurrence["triggering_value"]["horizon"] == "7_DIAS"

    def test_users_more_than_thirty_days_apart_are_not_associated(self):
        rows = [
            row("T1", "2026-06-01 09:00:00", device="DEV-X"),
            row("T2", "2026-07-20 09:00:00", device="DEV-X"),
        ]
        detected, _ = rules_for(rows)
        assert detected["R7"] == []

    def test_per_user_detail_is_complete(self):
        rows = [
            row("T1", "2026-07-10 09:00:00", source="192.0.2.1", corporate="10.0.0.1", device="DEV-X"),
            row("T1", "2026-07-10 10:00:00", source="192.0.2.2", corporate="10.0.0.1", device="DEV-X"),
            row("T2", "2026-07-10 15:00:00", source="192.0.2.3", corporate="10.0.0.2", device="DEV-X"),
        ]
        detected, _ = rules_for(rows)
        details = detected["R7"][0]["details"]
        assert sorted(details["users"]) == ["T1", "T2"]
        assert details["per_user"]["T1"]["event_count"] == 2
        assert details["per_user"]["T1"]["source_ips"] == ["192.0.2.1", "192.0.2.2"]
        assert details["per_user"]["T2"]["event_count"] == 1
        assert details["minimum_cross_user_interval_seconds"] is not None
        assert "não determin" in details["organizational_context_changes"].lower()

    def test_severity_reflects_the_shortest_observed_horizon(self):
        same_day, _ = rules_for([
            row("T1", "2026-07-10 09:00:00", device="DEV-X"),
            row("T2", "2026-07-10 10:00:00", device="DEV-X"),
        ])
        week, _ = rules_for([
            row("T1", "2026-07-10 09:00:00", device="DEV-Y"),
            row("T2", "2026-07-13 09:00:00", device="DEV-Y"),
        ])
        month, _ = rules_for([
            row("T1", "2026-07-01 09:00:00", device="DEV-Z"),
            row("T2", "2026-07-20 09:00:00", device="DEV-Z"),
        ])
        assert same_day["R7"][0]["severity"] == "ALTA"
        assert week["R7"][0]["severity"] == "MÉDIA"
        assert month["R7"][0]["severity"] == "BAIXA"

    def test_concurrency_is_never_asserted(self):
        rows = [
            row("T1", "2026-07-10 09:00:00", device="DEV-X"),
            row("T2", "2026-07-10 09:00:30", device="DEV-X"),
        ]
        detected, _ = rules_for(rows)
        assert "não determinável" in detected["R7"][0]["details"]["usage_pattern"]


class TestTimezoneBoundaries:
    def test_utc_events_are_grouped_by_local_date(self):
        rows = [
            row("T1", datetime(2026, 7, 11, 2, 0, tzinfo=timezone.utc), source="192.0.2.1"),
            row("T1", datetime(2026, 7, 11, 2, 30, tzinfo=timezone.utc), source="192.0.2.2"),
            row("T1", datetime(2026, 7, 11, 3, 0, tzinfo=timezone.utc), source="192.0.2.3"),
        ]
        events, _ = normalize_events(rows, DetectionConfig())
        # 02:00/02:30 UTC = 23:00/23:30 do dia 10 local; 03:00 UTC = 00:00 do dia 11.
        assert [event["local_date"] for event in events] == [
            "2026-07-10", "2026-07-10", "2026-07-11",
        ]

    def test_daily_rules_use_local_dates_not_utc_dates(self):
        rows = [
            row("T1", datetime(2026, 7, 11, 1, 0, tzinfo=timezone.utc), source="192.0.2.1"),
            row("T1", datetime(2026, 7, 11, 2, 0, tzinfo=timezone.utc), source="192.0.2.2"),
            row("T1", datetime(2026, 7, 11, 2, 30, tzinfo=timezone.utc), source="192.0.2.3"),
        ]
        detected, _ = rules_for(rows)
        assert len(detected["R4"]) == 1
        assert detected["R4"][0]["local_date"] == "2026-07-10"

    def test_historical_daylight_saving_is_honoured_when_tzdata_exists(self):
        pytest.importorskip("zoneinfo")
        try:
            from zoneinfo import ZoneInfo

            ZoneInfo(APP_TIMEZONE)
        except Exception:  # pragma: no cover - imagem sem tzdata
            pytest.skip("tzdata indisponível nesta imagem")
        # 2018 ainda tinha horário de verão no Brasil (UTC-02 em fevereiro).
        events, _ = normalize_events(
            [row("T1", "2018-02-10 12:00:00", source="192.0.2.1")], DetectionConfig()
        )
        assert events[0]["timestamp"].utcoffset() == timedelta(hours=-2)


class TestDeterminism:
    def test_input_order_does_not_change_the_result(self):
        rows = [
            row("T{0}".format(user), "2026-07-10 {0:02d}:00:00".format(hour), source="192.0.2.{0}".format(hour), device="DEV-{0}".format(hour % 2))
            for user in range(1, 4) for hour in range(8, 14)
        ]
        forward, quality_forward = rules_for(rows)
        backward, quality_backward = rules_for(list(reversed(rows)))
        assert quality_forward == quality_backward
        for rule_id in EVENT_RULE_IDS:
            assert [item["occurrence_id"] for item in forward[rule_id]] == [
                item["occurrence_id"] for item in backward[rule_id]
            ]

    def test_occurrence_ids_are_stable_across_runs(self):
        rows = [
            row("T1", "2026-07-10 09:00:00", source="192.0.2.1"),
            row("T1", "2026-07-10 10:00:00", source="192.0.2.2"),
        ]
        first, _ = rules_for(rows)
        second, _ = rules_for(rows)
        assert first["R1"][0]["occurrence_id"] == second["R1"][0]["occurrence_id"]
        assert first["R1"][0]["deduplication_key"] == second["R1"][0]["deduplication_key"]

    def test_every_occurrence_carries_the_common_result_model(self):
        rows = [
            row("T1", "2026-07-10 09:00:00", source="192.0.2.1", device="DEV-X"),
            row("T1", "2026-07-10 09:30:00", source="192.0.2.2", device="DEV-Y"),
            row("T2", "2026-07-10 15:00:00", source="192.0.2.3", device="DEV-X"),
        ]
        detected, _ = rules_for(rows)
        for occurrences in detected.values():
            for occurrence in occurrences:
                for field in (
                    "occurrence_id", "rule_id", "rule_title", "rule_version", "severity",
                    "local_date", "window_start", "window_end", "triggering_value",
                    "configured_threshold", "explanation", "supporting_event_identifiers",
                    "evidence_records", "relevant_ips", "relevant_devices",
                    "relevant_sessions", "deduplication_key", "deduplication_method",
                    "first_event_timestamp", "last_event_timestamp",
                    "applicable_exclusions", "details",
                ):
                    assert field in occurrence, (occurrence["rule_id"], field)

    def test_explanations_never_assert_wrongdoing(self):
        rows = [
            row("T1", "2026-07-10 09:00:00", source="192.0.2.1", device="DEV-X"),
            row("T1", "2026-07-10 09:30:00", source="192.0.2.2", device="DEV-Y"),
            row("T2", "2026-07-10 15:00:00", source="192.0.2.3", device="DEV-X"),
        ]
        detected, _ = rules_for(rows)
        forbidden = ("fraude", "irregularidade", "má conduta", "comprova")
        for occurrences in detected.values():
            for occurrence in occurrences:
                lowered = occurrence["explanation"].lower()
                for term in forbidden:
                    assert term not in lowered, occurrence["explanation"]
