"""Camada de comandos, concorrência limitada, publicação atômica e worker."""

import json
import threading
from dataclasses import replace
from datetime import datetime

import pytest

from backtest_vpn import publication, runtime as runtime_mod
from backtest_vpn.clock import FixedClock
from backtest_vpn.commands import (
    CommandValidationError,
    ExecuteBacktestHandler,
    GenerateBacktestReportsCommand,
    JobNotClaimable,
    PublishBacktestResultCommand,
    ResumeOrRetryBacktestCommand,
    RunInitialBacktestCommand,
    RunManualBacktestCommand,
    RunScheduledBacktestCommand,
    normalize_rules,
    worker_identity,
)
from backtest_vpn.concurrency import (
    CancellationToken,
    TaskCancelled,
    WorkerLimits,
    merge_rule_results,
    run_bounded,
)
from backtest_vpn.detection import DetectionConfig, run_event_rules
from backtest_vpn.jobstore import (
    STATE_FAILED_RETRYABLE,
    STATE_QUEUED,
    STATE_SUCCEEDED,
    InMemoryJobStore,
)
from backtest_vpn.period import default_period
from backtest_vpn.pipeline import FixtureBacktestPipeline, synthetic_rows


@pytest.fixture
def clock():
    return FixedClock(datetime(2026, 7, 30, 3, 0, 0))


@pytest.fixture
def store(clock):
    return InMemoryJobStore(clock=clock)


def build_runtime(clock, store, tmp_path, *, pipeline=None, formats=("tex", "csv")):
    runtime = runtime_mod.build_runtime(
        application_version="2.2.0",
        clock=clock,
        store=store,
        pipeline=pipeline or FixtureBacktestPipeline(),
        reports_dir=tmp_path,
    )
    # Automatic-run tests opt in explicitly; deployment defaults are
    # manual-only.
    runtime.schedule = replace(
        runtime.schedule,
        enabled=True,
        run_initial_on_startup=True,
    )
    runtime.report_formats = formats
    return runtime


# ── Validação de comandos ────────────────────────────────────────────────
class TestCommandValidation:
    def test_rules_are_normalized_and_ordered(self):
        assert normalize_rules("r7,R1,r4") == ("R1", "R4", "R7")
        assert normalize_rules(["R9", "R2"]) == ("R2", "R9")
        assert normalize_rules(None) == (
            "R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8", "R9",
        )

    @pytest.mark.parametrize("value", ["", [], "R10", ["R0"], "R1,R99"])
    def test_invalid_rules_are_rejected(self, value):
        with pytest.raises(CommandValidationError):
            normalize_rules(value)

    def test_period_must_be_validated_object(self, clock):
        with pytest.raises(CommandValidationError, match="Período inválido"):
            RunInitialBacktestCommand(
                period="2026-07-29", rules=("R1",), config_snapshot={},
                application_version="2.2.0",
            )

    def test_application_version_is_required(self, clock):
        with pytest.raises(CommandValidationError, match="Versão da aplicação"):
            RunInitialBacktestCommand(
                period=default_period(clock), rules=("R1",), config_snapshot={},
                application_version="",
            )

    def test_manual_command_requires_nonce(self, clock):
        with pytest.raises(CommandValidationError, match="nonce"):
            RunManualBacktestCommand(
                period=default_period(clock), rules=("R1",), config_snapshot={},
                application_version="2.2.0",
            )

    def test_triggers_are_fixed_per_command_type(self, clock):
        period = default_period(clock)
        common = dict(rules=("R1",), config_snapshot={}, application_version="2.2.0")
        assert RunInitialBacktestCommand(period=period, **common).trigger == "initial"
        assert RunScheduledBacktestCommand(period=period, **common).trigger == "scheduled"
        assert RunManualBacktestCommand(period=period, nonce="n1", **common).trigger == "manual"

    def test_initial_record_has_progress_before_a_worker_claims_it(self, clock):
        command = RunInitialBacktestCommand(
            period=default_period(clock),
            rules=("R1",),
            config_snapshot={},
            application_version="2.4.0",
        )
        record = command.to_record(clock)
        assert record.state == STATE_QUEUED
        assert record.progress["phase"] == "ENFILEIRADO"
        assert record.progress["progress_bar_indeterminate"] is True
        assert "Primeira análise" in record.progress["friendly_summary"]

    def test_same_command_yields_same_job_id(self, clock):
        period = default_period(clock)
        common = dict(rules=("R1", "R4"), config_snapshot={"a": 1}, application_version="2.2.0")
        first = RunScheduledBacktestCommand(period=period, **common)
        second = RunScheduledBacktestCommand(period=period, **common)
        assert first.job_id == second.job_id
        assert first.config_hash == second.config_hash

    def test_report_command_rejects_unknown_format(self, tmp_path):
        with pytest.raises(CommandValidationError, match="Formatos"):
            GenerateBacktestReportsCommand(
                bundle={"bundle_version": 2}, output_dir=tmp_path,
                application_version="2.2.0", formats=("docx",),
            )

    def test_publish_command_rejects_bad_fence(self, tmp_path):
        with pytest.raises(CommandValidationError, match="fence"):
            PublishBacktestResultCommand(
                job_id="bt-1", fence=-1, reports_dir=tmp_path, artifacts={"a": "b"},
            )

    def test_resume_command_validates_lease_bounds(self):
        with pytest.raises(CommandValidationError, match="lease_seconds"):
            ResumeOrRetryBacktestCommand(job_id="bt-1", owner="pod-a", lease_seconds=1)

    def test_worker_identity_is_stable_within_process(self, clock):
        assert worker_identity(clock) == worker_identity(clock)


# ── Concorrência limitada ────────────────────────────────────────────────
class TestBoundedConcurrency:
    def test_defaults_to_single_worker(self):
        limits = WorkerLimits.from_env({})
        assert limits.rule_workers == 1
        assert limits.report_workers == 1
        assert limits.db_pool_limit == 1

    def test_environment_overrides_are_bounded(self):
        limits = WorkerLimits.from_env({
            "BACKTEST_RULE_WORKERS": "4", "BACKTEST_REPORT_WORKERS": "2",
            "BACKTEST_DB2_POOL_LIMIT": "3",
        })
        assert (limits.rule_workers, limits.report_workers, limits.db_pool_limit) == (4, 2, 3)

    @pytest.mark.parametrize(
        "env", [{"BACKTEST_RULE_WORKERS": "0"}, {"BACKTEST_RULE_WORKERS": "99"}, {"BACKTEST_RULE_WORKERS": "x"}]
    )
    def test_invalid_worker_counts_are_rejected(self, env):
        with pytest.raises(ValueError, match="BACKTEST_RULE_WORKERS"):
            WorkerLimits.from_env(env)

    def test_results_follow_submission_order_not_completion_order(self):
        import time as _time

        def make(index, delay):
            def task():
                _time.sleep(delay)
                return index
            return task

        tasks = [make(0, 0.05), make(1, 0.0), make(2, 0.02), make(3, 0.0)]
        assert run_bounded(tasks, max_workers=4) == [0, 1, 2, 3]

    def test_one_worker_and_many_workers_are_equivalent(self):
        tasks = [lambda index=index: index * 3 for index in range(20)]
        assert run_bounded(tasks, max_workers=1) == run_bounded(tasks, max_workers=8)

    def test_backpressure_limits_simultaneous_tasks(self):
        active = {"current": 0, "peak": 0}
        guard = threading.Lock()
        release = threading.Event()

        def task():
            with guard:
                active["current"] += 1
                active["peak"] = max(active["peak"], active["current"])
            release.wait(0.05)
            with guard:
                active["current"] -= 1
            return True

        run_bounded([task] * 12, max_workers=3)
        assert active["peak"] <= 3

    def test_first_exception_propagates_and_cancels(self):
        token = CancellationToken()

        def boom():
            raise RuntimeError("falha da tarefa")

        with pytest.raises(RuntimeError, match="falha da tarefa"):
            run_bounded([boom] * 4, max_workers=2, cancellation=token)
        assert token.cancelled is True

    def test_cancellation_stops_before_running_more_tasks(self):
        token = CancellationToken()
        token.cancel()
        with pytest.raises(TaskCancelled):
            run_bounded([lambda: 1] * 3, max_workers=1, cancellation=token)

    @pytest.mark.parametrize("workers", [0, 9])
    def test_worker_count_is_bounded(self, workers):
        with pytest.raises(ValueError, match="max_workers"):
            run_bounded([lambda: 1], max_workers=workers)

    def test_empty_task_list_is_safe(self):
        assert run_bounded([], max_workers=4) == []

    def test_merge_is_stable_by_rule_identifier(self):
        merged = merge_rule_results(["R9", "R1", "R10", "R2"], [9, 1, 10, 2])
        assert list(merged) == ["R1", "R2", "R9", "R10"]


class TestRuleEvaluationEquivalence:
    def test_sequential_and_parallel_rules_produce_identical_results(self, clock):
        rows = [
            {
                "USER_KEY": "T000000{0}".format(user), "EVENT_TS": "2026-07-10 {0:02d}:00:00".format(hour),
                "SOURCE_IP": "192.0.2.{0}".format(hour), "CORPORATE_IP": "10.0.0.1",
                "HOSTNAME": "EST-{0}".format(user), "DEVICE_ID": "DEV-{0}".format(hour % 3),
            }
            for user in range(1, 4) for hour in range(8, 14)
        ]
        cfg = DetectionConfig()
        sequential, quality_one = run_event_rules(rows, cfg, max_workers=1)
        parallel, quality_many = run_event_rules(rows, cfg, max_workers=6)
        assert list(sequential) == list(parallel)
        assert json.dumps(sequential, sort_keys=True, default=str) == json.dumps(
            parallel, sort_keys=True, default=str
        )
        assert quality_one == quality_many

    def test_on_rule_done_callback_fires_once_per_rule_in_both_modes(self, clock):
        rows = synthetic_rows(
            type("R", (), {"period": default_period(clock)})()
        )
        for workers in (1, 4):
            seen = []
            run_event_rules(
                rows, DetectionConfig(), max_workers=workers,
                on_rule_done=lambda rule_id, occurrences: seen.append(rule_id),
            )
            assert sorted(seen) == sorted(set(seen))
            assert len(seen) == 7


# ── Publicação atômica ───────────────────────────────────────────────────
class TestPublication:
    def test_publication_is_atomic_and_pointer_is_commit_point(self, tmp_path):
        target = publication.prepare(tmp_path, "bt-abc", 1)
        (target.staging_dir / "a.tex").write_text("conteudo", encoding="utf-8")
        pointer = publication.publish(
            target, required_files=["a.tex"], metadata={"report_id": "BT-1"}
        )
        assert pointer["files"] == ["a.tex"]
        assert publication.read_pointer(tmp_path)["report_id"] == "BT-1"
        assert not target.staging_dir.exists()

    def test_incomplete_output_is_refused(self, tmp_path):
        target = publication.prepare(tmp_path, "bt-abc", 1)
        (target.staging_dir / "a.tex").write_text("", encoding="utf-8")
        with pytest.raises(publication.PublicationError, match="ausentes ou vazios"):
            publication.publish(target, required_files=["a.tex"], metadata={})

    def test_failed_publication_preserves_previous_result(self, tmp_path):
        first = publication.prepare(tmp_path, "bt-abc", 1)
        (first.staging_dir / "a.tex").write_text("v1", encoding="utf-8")
        publication.publish(first, required_files=["a.tex"], metadata={"report_id": "BT-1"})
        second = publication.prepare(tmp_path, "bt-abc", 2)
        (second.staging_dir / "a.tex").write_text("", encoding="utf-8")
        with pytest.raises(publication.PublicationError):
            publication.publish(second, required_files=["a.tex"], metadata={"report_id": "BT-2"})
        publication.discard(second)
        assert publication.read_pointer(tmp_path)["report_id"] == "BT-1"
        assert publication.resolve_published_file(tmp_path, "a.tex").read_text(encoding="utf-8") == "v1"

    def test_stale_fence_cannot_overwrite_newer_publication(self, tmp_path):
        newer = publication.prepare(tmp_path, "bt-abc", 5)
        (newer.staging_dir / "a.tex").write_text("novo", encoding="utf-8")
        publication.publish(newer, required_files=["a.tex"], metadata={"report_id": "novo"})
        stale = publication.prepare(tmp_path, "bt-abc", 2)
        (stale.staging_dir / "a.tex").write_text("antigo", encoding="utf-8")
        with pytest.raises(publication.PublicationError, match="mais novo"):
            publication.publish(stale, required_files=["a.tex"], metadata={"report_id": "antigo"})
        assert publication.read_pointer(tmp_path)["report_id"] == "novo"

    def test_nested_package_files_are_listed_and_resolvable(self, tmp_path):
        target = publication.prepare(tmp_path, "bt-abc", 1)
        (target.staging_dir / "a.tex").write_text("x", encoding="utf-8")
        nested = target.staging_dir / "detalhamento_csv"
        nested.mkdir()
        (nested / "dados.csv").write_text("a,b\n1,2\n", encoding="utf-8")
        pointer = publication.publish(target, required_files=["a.tex"], metadata={})
        assert "detalhamento_csv/dados.csv" in pointer["files"]
        assert publication.resolve_published_file(tmp_path, "detalhamento_csv/dados.csv") is not None

    @pytest.mark.parametrize(
        "name",
        ["../../etc/passwd", "detalhamento_csv/../../../etc/passwd", "/etc/passwd", "nao-publicado.tex"],
    )
    def test_only_pointer_listed_names_resolve(self, tmp_path, name):
        target = publication.prepare(tmp_path, "bt-abc", 1)
        (target.staging_dir / "a.tex").write_text("x", encoding="utf-8")
        publication.publish(target, required_files=["a.tex"], metadata={})
        assert publication.resolve_published_file(tmp_path, name) is None

    def test_symlink_is_not_served(self, tmp_path):
        secret = tmp_path / "segredo.txt"
        secret.write_text("nao-expor", encoding="utf-8")
        target = publication.prepare(tmp_path, "bt-abc", 1)
        (target.staging_dir / "a.tex").write_text("x", encoding="utf-8")
        publication.publish(target, required_files=["a.tex"], metadata={})
        published = tmp_path / publication.PUBLISHED_DIRNAME / "bt-abc"
        link = published / "link.tex"
        link.symlink_to(secret)
        assert publication.resolve_published_file(tmp_path, "link.tex") is None

    @pytest.mark.parametrize("job_id", ["", "..", "../evil", "com/barra", "a" * 200])
    def test_unsafe_job_identifiers_are_refused(self, tmp_path, job_id):
        with pytest.raises(publication.PublicationError):
            publication.prepare(tmp_path, job_id, 1)

    def test_retention_zero_never_deletes(self, tmp_path):
        for fence, job in enumerate(["bt-a", "bt-b", "bt-c"], start=1):
            target = publication.prepare(tmp_path, job, fence)
            (target.staging_dir / "a.tex").write_text("x", encoding="utf-8")
            publication.publish(target, required_files=["a.tex"], metadata={})
        assert publication.apply_retention(tmp_path, 0) == []
        directories = {
            item.name for item in (tmp_path / publication.PUBLISHED_DIRNAME).iterdir() if item.is_dir()
        }
        assert directories == {"bt-a", "bt-b", "bt-c"}

    def test_retention_keeps_pointer_target(self, tmp_path):
        for fence, job in enumerate(["bt-a", "bt-b", "bt-c"], start=1):
            target = publication.prepare(tmp_path, job, fence)
            (target.staging_dir / "a.tex").write_text("x", encoding="utf-8")
            publication.publish(target, required_files=["a.tex"], metadata={})
        publication.apply_retention(tmp_path, 1)
        remaining = {
            item.name for item in (tmp_path / publication.PUBLISHED_DIRNAME).iterdir() if item.is_dir()
        }
        assert "bt-c" in remaining


# ── Fluxo completo com comandos ──────────────────────────────────────────
class TestExecuteHandler:
    def test_initial_job_runs_publishes_and_advances_watermark(self, clock, store, tmp_path):
        runtime = build_runtime(clock, store, tmp_path)
        job = runtime_mod.ensure_initial_job(runtime)
        assert job.period["total_calendar_days"] == 33
        final = runtime.claim_and_run(job.job_id)
        assert final.state == STATE_SUCCEEDED
        assert final.progress["phase"] == "CONCLUIDO"
        assert final.progress["overall_percent"] == 100.0
        assert runtime.watermark()["last_published_end_date"] == job.period["end_date_inclusive"]
        pointer = publication.read_pointer(tmp_path)
        assert pointer["job_id"] == job.job_id
        assert "backtesting_dossier.tex" in pointer["files"]

    def test_several_simulated_pods_create_one_effect(self, clock, store, tmp_path):
        runtime = build_runtime(clock, store, tmp_path)
        jobs = [runtime.enqueue_initial() for _ in range(5)]
        assert len({job.job_id for job in jobs}) == 1
        assert len(store.list_recent(50)) == 1

    def test_manual_and_scheduled_jobs_coexist_without_corruption(self, clock, store, tmp_path):
        runtime = build_runtime(clock, store, tmp_path)
        scheduled = runtime.enqueue_scheduled(runtime.default_period_for("scheduled"))
        manual = runtime.enqueue_manual(runtime.default_period_for("manual"), nonce="n1")
        assert scheduled.job_id != manual.job_id
        runtime.claim_and_run(scheduled.job_id)
        runtime.claim_and_run(manual.job_id)
        assert store.get(scheduled.job_id).state == STATE_SUCCEEDED
        assert store.get(manual.job_id).state == STATE_SUCCEEDED
        # Somente o automático move a marca d'água.
        assert runtime.watermark()["last_success_job_id"] == scheduled.job_id

    def test_second_claim_of_running_job_is_refused(self, clock, store, tmp_path):
        runtime = build_runtime(clock, store, tmp_path)
        job = runtime.enqueue_initial()
        store.claim(job.job_id, "pod-outro", lease_seconds=600)
        with pytest.raises(JobNotClaimable):
            runtime.claim_and_run(job.job_id)

    def test_failure_keeps_previous_successful_result_available(self, clock, store, tmp_path):
        runtime = build_runtime(clock, store, tmp_path)
        good = runtime.enqueue_manual(runtime.default_period_for("manual"), nonce="ok")
        runtime.claim_and_run(good.job_id)
        published_before = publication.read_pointer(tmp_path)

        class Broken(FixtureBacktestPipeline):
            def execute(self, request):
                raise RuntimeError("DB2 indisponível")

        clock.advance(60)
        broken_runtime = build_runtime(clock, store, tmp_path, pipeline=Broken())
        bad = broken_runtime.enqueue_manual(broken_runtime.default_period_for("manual"), nonce="ruim")
        with pytest.raises(RuntimeError, match="DB2 indisponível"):
            broken_runtime.claim_and_run(bad.job_id)
        assert store.get(bad.job_id).state == STATE_FAILED_RETRYABLE
        assert publication.read_pointer(tmp_path) == published_before
        assert store.last_successful().job_id == good.job_id

    def test_error_summary_is_short_and_has_no_evidence_rows(self, clock, store, tmp_path):
        class Leaky(FixtureBacktestPipeline):
            def execute(self, request):
                raise RuntimeError("falha ao ler linha do usuario T0000001 ip 192.0.2.1")

        runtime = build_runtime(clock, store, tmp_path, pipeline=Leaky())
        job = runtime.enqueue_manual(runtime.default_period_for("manual"), nonce="n")
        with pytest.raises(RuntimeError):
            runtime.claim_and_run(job.job_id)
        summary = store.get(job.job_id).error_summary
        assert summary.startswith("RuntimeError:")
        assert len(summary) <= 500
        assert "T0000001" not in summary
        assert "192.0.2.1" not in summary

    def test_cancellation_requeues_instead_of_failing(self, clock, store, tmp_path):
        class Cancelling(FixtureBacktestPipeline):
            def execute(self, request):
                request.cancellation.cancel()
                request.cancellation.raise_if_cancelled()

        runtime = build_runtime(clock, store, tmp_path, pipeline=Cancelling())
        job = runtime.enqueue_manual(runtime.default_period_for("manual"), nonce="n")
        with pytest.raises(TaskCancelled):
            runtime.claim_and_run(job.job_id)
        record = store.get(job.job_id)
        assert record.state == STATE_QUEUED
        assert record.state != STATE_SUCCEEDED

    def test_status_is_readable_from_a_different_simulated_pod(self, clock, store, tmp_path):
        writer = build_runtime(clock, store, tmp_path)
        job = writer.enqueue_initial()
        writer.claim_and_run(job.job_id)
        # "Outro pod": novo runtime, mesmo estado durável, nenhum estado local.
        reader = build_runtime(clock, InMemoryJobStore(clock=clock), tmp_path)
        reader.store = store
        view = reader.status(job.job_id)
        assert view["state"] == STATE_SUCCEEDED
        assert view["progress"]["phase"] == "CONCLUIDO"

    def test_report_workers_do_not_change_the_generated_artifacts(self, clock, tmp_path):
        """1 worker e N workers geram exatamente o mesmo conteúdo de relatório."""
        from backtest_vpn.commands import GenerateReportsHandler
        from backtest_vpn.progress import NullProgressReporter
        from backtest_vpn.report_model import safe_fixture_bundle

        outputs = {}
        for workers in (1, 3):
            directory = tmp_path / "w{0}".format(workers)
            handler = GenerateReportsHandler(clock=clock)
            artifacts = handler.generate(
                GenerateBacktestReportsCommand(
                    bundle=safe_fixture_bundle(), output_dir=directory,
                    application_version="2.2.0", formats=("tex", "csv"),
                    report_workers=workers,
                ),
                progress=NullProgressReporter(clock=clock),
            )
            outputs[workers] = {
                "report_id": artifacts["report_id"],
                "occurrences": artifacts["occurrences"],
                "tex": (directory / "backtesting_dossier.tex").read_text(encoding="utf-8"),
                "csv": sorted(
                    (item.name, item.read_bytes())
                    for item in (directory / "detalhamento_csv").glob("*.csv")
                ),
            }
        assert outputs[1] == outputs[3]

    def test_worker_limits_participate_in_the_configuration_hash(self, clock, store, tmp_path):
        """Mudar a concorrência muda a identidade lógica da execução."""
        one = build_runtime(clock, store, tmp_path)
        many = runtime_mod.build_runtime(
            application_version="2.2.0", clock=clock, store=store,
            pipeline=FixtureBacktestPipeline(), reports_dir=tmp_path,
            limits=WorkerLimits(rule_workers=4, report_workers=2),
        )
        assert one.enqueue_initial().job_id != many.enqueue_initial().job_id


class TestWorkerLoop:
    def test_worker_drains_the_queue_once(self, clock, store, tmp_path):
        runtime = build_runtime(clock, store, tmp_path)
        runtime.enqueue_manual(runtime.default_period_for("manual"), nonce="a")
        loop = runtime_mod.WorkerLoop(runtime, install_signal_handlers=False, sleep=lambda _: None)
        assert loop.run(idle_limit=1, poll_seconds=0) == 1
        assert loop.run(idle_limit=1, poll_seconds=0) == 0

    def test_worker_returns_none_when_queue_is_empty(self, clock, store, tmp_path):
        runtime = build_runtime(clock, store, tmp_path)
        loop = runtime_mod.WorkerLoop(runtime, install_signal_handlers=False, sleep=lambda _: None)
        assert loop.run_once() is None

    def test_graceful_shutdown_does_not_mark_success(self, clock, store, tmp_path):
        class Slow(FixtureBacktestPipeline):
            def __init__(self, token):
                super().__init__()
                self._token = token

            def execute(self, request):
                self._token.cancel()
                request.cancellation.raise_if_cancelled()

        runtime = build_runtime(clock, store, tmp_path)
        loop = runtime_mod.WorkerLoop(runtime, install_signal_handlers=False, sleep=lambda _: None)
        runtime.execute = ExecuteBacktestHandler(
            store=store,
            pipeline=Slow(loop.cancellation),
            report_generator=runtime.execute._report_generator,
            publisher=runtime.execute._publisher,
            clock=clock,
            schedule=runtime.schedule,
        )
        job = runtime.enqueue_manual(runtime.default_period_for("manual"), nonce="n")
        assert loop.run_once() is None
        assert store.get(job.job_id).state == STATE_QUEUED


class TestScheduleIntegration:
    def test_scheduled_run_is_skipped_when_window_is_published(self, clock, store, tmp_path):
        runtime = build_runtime(clock, store, tmp_path)
        first = runtime_mod.run_scheduled_if_due(runtime)
        assert first["should_run"] is True
        assert first.get("final_state") == STATE_SUCCEEDED
        second = runtime_mod.run_scheduled_if_due(runtime)
        assert second["should_run"] is False
        assert "já está publicada" in second["reason"]

    def test_next_day_produces_a_new_logical_job(self, clock, store, tmp_path):
        runtime = build_runtime(clock, store, tmp_path)
        first = runtime_mod.run_scheduled_if_due(runtime)
        clock.set(datetime(2026, 7, 31, 3, 0, 0))
        second = runtime_mod.run_scheduled_if_due(runtime)
        assert second["should_run"] is True
        assert second["job_id"] != first["job_id"]
        assert second["period"]["end_date_inclusive"] == "2026-07-30"

    def test_initial_job_is_not_recreated_once_a_result_exists(self, clock, store, tmp_path):
        runtime = build_runtime(clock, store, tmp_path)
        job = runtime_mod.ensure_initial_job(runtime)
        runtime.claim_and_run(job.job_id)
        assert runtime_mod.ensure_initial_job(runtime) is None

    def test_initial_job_can_be_disabled_by_configuration(self, clock, store, tmp_path):
        from dataclasses import replace as _replace

        runtime = build_runtime(clock, store, tmp_path)
        runtime.schedule = _replace(runtime.schedule, run_initial_on_startup=False)
        assert runtime_mod.ensure_initial_job(runtime) is None
        assert store.list_recent(10) == []

    def test_dashboard_state_reports_pending_initial_dataset(self, clock, store, tmp_path):
        runtime = build_runtime(clock, store, tmp_path)
        runtime.enqueue_initial()
        state = runtime.dashboard_state()
        assert state["initial_dataset_pending"] is True
        assert state["last_successful"] is None
        assert "andamento" in runtime_mod.summarize_active(runtime)

    def test_dashboard_state_declares_cluster_safety(self, clock, store, tmp_path):
        runtime = build_runtime(clock, store, tmp_path)
        assert runtime.dashboard_state()["store_cluster_safe"] is False


class TestReportFormatsFromEnv:
    @pytest.mark.parametrize(
        "value,expected",
        [("", ("tex", "xlsx", "csv")), ("csv,tex", ("tex", "csv")), ("xlsx", ("xlsx",))],
    )
    def test_valid_values(self, monkeypatch, value, expected):
        monkeypatch.setenv("BACKTEST_REPORT_FORMATS", value)
        assert runtime_mod._report_formats_env() == expected

    def test_invalid_value_is_rejected(self, monkeypatch):
        monkeypatch.setenv("BACKTEST_REPORT_FORMATS", "pdf")
        with pytest.raises(ValueError, match="BACKTEST_REPORT_FORMATS"):
            runtime_mod._report_formats_env()
