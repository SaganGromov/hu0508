"""Unit tests for curio_models.py"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "acr_controle_acesso_dashboard" / "streamlit_app"))

from curio_models import (
    PAYLOAD_OP292018V3,
    PAYLOAD_OP2076328V2,
    RESPONSE_OP292018V3,
    RESPONSE_OP2076328V2,
)


class TestCurioModels:
    def test_payload_op292018v3_structure(self):
        assert isinstance(PAYLOAD_OP292018V3, dict)
        assert "codigoClientePesquisa" in PAYLOAD_OP292018V3

    def test_payload_op2076328v2_structure(self):
        assert isinstance(PAYLOAD_OP2076328V2, dict)
        assert "codigoMatriculaFuncionarioPesquisa" in PAYLOAD_OP2076328V2
        assert "dataInicioPerPesquisa" in PAYLOAD_OP2076328V2
        assert "dataFimPerPesquisa" in PAYLOAD_OP2076328V2
        assert "codigoChaveUsuario" in PAYLOAD_OP2076328V2

    def test_response_op292018v3_structure(self):
        assert isinstance(RESPONSE_OP292018V3, dict)
        assert "codigoChaveCliente" in RESPONSE_OP292018V3
        assert "nomeUsuario" in RESPONSE_OP292018V3
        assert "numeroMatriculaUsuario" in RESPONSE_OP292018V3

    def test_response_op2076328v2_structure(self):
        assert isinstance(RESPONSE_OP2076328V2, dict)
        assert "codigoErro" in RESPONSE_OP2076328V2
        assert "listaAusencia" in RESPONSE_OP2076328V2
        assert isinstance(RESPONSE_OP2076328V2["listaAusencia"], list)

    def test_payload_op292018v3_can_be_spread(self):
        new_payload = {**PAYLOAD_OP292018V3, "codigoClientePesquisa": "F1234567"}
        assert new_payload["codigoClientePesquisa"] == "F1234567"
        # Original is unchanged
        assert PAYLOAD_OP292018V3["codigoClientePesquisa"] == ""

    def test_payload_op2076328v2_can_be_spread(self):
        new_payload = {**PAYLOAD_OP2076328V2, "codigoMatriculaFuncionarioPesquisa": 12345}
        assert new_payload["codigoMatriculaFuncionarioPesquisa"] == 12345
        assert PAYLOAD_OP2076328V2["codigoMatriculaFuncionarioPesquisa"] == 0
