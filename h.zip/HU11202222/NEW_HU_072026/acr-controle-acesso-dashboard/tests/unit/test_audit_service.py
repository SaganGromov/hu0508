"""Unit tests for audit_service.py"""

import sys
from pathlib import Path
from unittest.mock import patch, Mock, MagicMock
from datetime import datetime

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "acr_controle_acesso_dashboard" / "streamlit_app"))

import audit_service


class TestGetCollection:
    def setup_method(self):
        """Reset module-level state before each test."""
        audit_service._client = None
        audit_service._collection = None
        audit_service._warned_no_uri = False

    def test_returns_none_when_no_uri(self, monkeypatch):
        monkeypatch.setattr(audit_service, "MONGODB_AUDIT_URI", "")
        result = audit_service._get_collection()
        assert result is None

    def test_warns_only_once_when_no_uri(self, monkeypatch):
        monkeypatch.setattr(audit_service, "MONGODB_AUDIT_URI", "")
        audit_service._get_collection()
        assert audit_service._warned_no_uri is True
        # Second call should not warn again but still return None
        result = audit_service._get_collection()
        assert result is None

    def test_returns_cached_collection(self, monkeypatch):
        mock_collection = Mock()
        audit_service._collection = mock_collection
        result = audit_service._get_collection()
        assert result is mock_collection

    def test_connects_when_uri_set(self, monkeypatch):
        monkeypatch.setattr(audit_service, "MONGODB_AUDIT_URI", "mongodb://localhost:27017")
        mock_client = MagicMock()
        mock_db = MagicMock()
        mock_db.list_collection_names.return_value = ["AUDIT_LOGINS_DASHBOARD_VPN"]
        mock_client.__getitem__.return_value = mock_db

        with patch("audit_service.MongoClient", return_value=mock_client):
            result = audit_service._get_collection()

        assert result is not None

    def test_returns_none_on_connection_error(self, monkeypatch):
        monkeypatch.setattr(audit_service, "MONGODB_AUDIT_URI", "mongodb://localhost:27017")

        with patch("audit_service.MongoClient", side_effect=Exception("connection failed")):
            result = audit_service._get_collection()

        assert result is None

    def test_creates_collection_if_not_exists(self, monkeypatch):
        monkeypatch.setattr(audit_service, "MONGODB_AUDIT_URI", "mongodb://localhost:27017")
        mock_client = MagicMock()
        mock_db = MagicMock()
        mock_db.list_collection_names.return_value = []
        mock_client.__getitem__.return_value = mock_db

        with patch("audit_service.MongoClient", return_value=mock_client):
            audit_service._get_collection()

        mock_db.create_collection.assert_called_once_with("AUDIT_LOGINS_DASHBOARD_VPN")


class TestSanitizeValue:
    def test_plain_dict_unchanged(self):
        doc = {"tipo": "TEST", "data": "value"}
        assert audit_service._sanitize_value(doc) == doc

    def test_strips_dollar_prefixed_keys(self):
        doc = {"tipo": "TEST", "$set": {"x": 1}, "safe": "ok"}
        result = audit_service._sanitize_value(doc)
        assert "$set" not in result
        assert result == {"tipo": "TEST", "safe": "ok"}

    def test_strips_mongo_special_field_names(self):
        doc = {"safe": "ok", "profile.name": "bad", "bad\x00key": "bad"}
        result = audit_service._sanitize_value(doc)
        assert result == {"safe": "ok"}

    def test_strips_nested_dollar_keys(self):
        doc = {"outer": {"$gt": 0, "valid": "yes"}}
        result = audit_service._sanitize_value(doc)
        assert result == {"outer": {"valid": "yes"}}

    def test_sanitizes_lists(self):
        doc = {"items": [{"$ne": None, "a": 1}, "plain"]}
        result = audit_service._sanitize_value(doc)
        assert result == {"items": [{"a": 1}, "plain"]}

    def test_enforces_max_depth(self):
        # Build a deeply nested structure (depth > 5)
        deep = "leaf"
        for _ in range(8):
            deep = {"nested": deep}
        result = audit_service._sanitize_value(deep)
        # Depths 0-5 are kept as dicts; depth 6+ is stringified
        cursor = result
        for _ in range(6):
            assert isinstance(cursor, dict)
            cursor = cursor["nested"]
        assert isinstance(cursor, str)

    def test_preserves_primitives(self):
        assert audit_service._sanitize_value(42) == 42
        assert audit_service._sanitize_value("hello") == "hello"
        assert audit_service._sanitize_value(None) is None
        assert audit_service._sanitize_value(True) is True

    def test_removes_control_chars_from_strings(self):
        assert audit_service._sanitize_value("ok\x00bad\x1f") == "okbad"


class TestInsert:
    def setup_method(self):
        audit_service._client = None
        audit_service._collection = None
        audit_service._warned_no_uri = False

    def test_insert_does_nothing_when_collection_is_none(self, monkeypatch):
        monkeypatch.setattr(audit_service, "MONGODB_AUDIT_URI", "")
        # Should not raise
        audit_service._insert({"tipo": "TEST"})

    def test_insert_calls_insert_one(self):
        mock_col = Mock()
        audit_service._collection = mock_col
        doc = {"tipo": "TEST", "data": "value"}
        audit_service._insert(doc)
        mock_col.insert_one.assert_called_once()
        # Verify it's a sanitized copy (not the original dict)
        inserted_doc = mock_col.insert_one.call_args[0][0]
        assert inserted_doc == doc
        assert inserted_doc is not doc

    def test_insert_strips_operator_keys(self):
        mock_col = Mock()
        audit_service._collection = mock_col
        doc = {"tipo": "TEST", "$set": {"evil": True}}
        audit_service._insert(doc)
        inserted_doc = mock_col.insert_one.call_args[0][0]
        assert "$set" not in inserted_doc
        assert inserted_doc == {"tipo": "TEST"}

    def test_insert_swallows_exceptions(self):
        mock_col = Mock()
        mock_col.insert_one.side_effect = Exception("write error")
        audit_service._collection = mock_col
        # Should not raise
        audit_service._insert({"tipo": "TEST"})


class TestRecordLogin:
    def setup_method(self):
        audit_service._collection = Mock()

    def test_record_login_inserts_correct_doc(self):
        with patch.object(audit_service, "_now_brasilia", return_value=datetime(2025, 1, 1, 12, 0)):
            audit_service.record_login("F1234567", {"name": "User"}, ip="10.0.0.1")

        doc = audit_service._collection.insert_one.call_args[0][0]
        assert doc["tipo"] == "LOGIN"
        assert doc["matricula"] == "F1234567"
        assert doc["userinfo"] == {"name": "User"}
        assert doc["ip"] == "10.0.0.1"
        assert doc["timestamp"] == datetime(2025, 1, 1, 12, 0)


class TestRecordSearch:
    def setup_method(self):
        audit_service._collection = Mock()

    def test_record_search_inserts_correct_doc(self):
        with patch.object(audit_service, "_now_brasilia", return_value=datetime(2025, 1, 1, 12, 0)):
            audit_service.record_search("F1234567", {"name": "User"}, "query", "page1", ip="10.0.0.1")

        doc = audit_service._collection.insert_one.call_args[0][0]
        assert doc["tipo"] == "SEARCH"
        assert doc["matricula"] == "F1234567"
        assert doc["busca"] == "query"
        assert doc["pagina"] == "page1"


class TestRecordAction:
    def setup_method(self):
        audit_service._collection = Mock()

    def test_record_action_basic(self):
        with patch.object(audit_service, "_now_brasilia", return_value=datetime(2025, 1, 1, 12, 0)):
            audit_service.record_action("user1", "BUSCA_MATRICULA", "tempo_real")

        doc = audit_service._collection.insert_one.call_args[0][0]
        assert doc["tipo"] == "ACTION"
        assert doc["user_id"] == "user1"
        assert doc["acao"] == "BUSCA_MATRICULA"
        assert doc["pagina"] == "tempo_real"
        assert "detalhes" not in doc

    def test_record_action_with_details(self):
        with patch.object(audit_service, "_now_brasilia", return_value=datetime(2025, 1, 1, 12, 0)):
            audit_service.record_action("user1", "FILTRO", "page", details={"filtro": "valor"})

        doc = audit_service._collection.insert_one.call_args[0][0]
        assert doc["detalhes"] == {"filtro": "valor"}


class TestRecordCsvExport:
    def setup_method(self):
        audit_service._collection = Mock()

    def test_record_csv_export_basic(self):
        with patch.object(audit_service, "_now_brasilia", return_value=datetime(2025, 1, 1, 12, 0)):
            audit_service.record_csv_export(
                user_id="user1",
                page="relatorio",
                export_label="Logins",
                filename="logins.csv",
                row_count=100,
                column_count=5,
            )

        doc = audit_service._collection.insert_one.call_args[0][0]
        assert doc["tipo"] == "CSV_EXPORT"
        assert doc["user_id"] == "user1"
        assert doc["row_count"] == 100
        assert doc["column_count"] == 5
        assert "detalhes" not in doc

    def test_record_csv_export_with_details(self):
        with patch.object(audit_service, "_now_brasilia", return_value=datetime(2025, 1, 1, 12, 0)):
            audit_service.record_csv_export(
                user_id="user1",
                page="relatorio",
                export_label="Logins",
                filename="logins.csv",
                row_count=50,
                column_count=3,
                details={"filtro": "ativo"},
            )

        doc = audit_service._collection.insert_one.call_args[0][0]
        assert doc["detalhes"] == {"filtro": "ativo"}


class TestNowBrasilia:
    def test_returns_datetime(self):
        result = audit_service._now_brasilia()
        assert isinstance(result, datetime)
        assert result.tzinfo is not None
