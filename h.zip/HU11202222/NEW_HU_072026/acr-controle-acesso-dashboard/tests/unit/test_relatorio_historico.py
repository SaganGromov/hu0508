"""Unit tests for pages/relatorio_historico.py — utility functions."""

import io
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pandas as pd

# Mock streamlit before importing
sys.path.insert(0, str(Path(__file__).resolve().parent))
from streamlit_mock_helper import install_streamlit_mock, import_page_module, reimport_page_with_session_state, make_sample_logins_df
_mock_st = install_streamlit_mock()

_PAGES_DIR = str(Path(__file__).resolve().parents[2] / "acr_controle_acesso_dashboard" / "streamlit_app" / "pages")
_STREAMLIT_DIR = str(Path(__file__).resolve().parents[2] / "acr_controle_acesso_dashboard" / "streamlit_app")
sys.path.insert(0, _PAGES_DIR)
sys.path.insert(0, _STREAMLIT_DIR)

with patch("auth_token.resolve_authenticated_user", return_value="F0000001"):
    relatorio_historico = import_page_module(
        "relatorio_historico",
        str(Path(_PAGES_DIR) / "relatorio_historico.py"),
    )


class TestToCsv:
    def test_returns_bytes(self):
        df = pd.DataFrame({"a": [1, 2], "b": [3, 4]})
        result = relatorio_historico._to_csv(df)
        assert isinstance(result, bytes)

    def test_csv_content(self):
        df = pd.DataFrame({"name": ["Alice", "Bob"]})
        result = relatorio_historico._to_csv(df)
        text = result.decode("utf-8")
        assert "name" in text
        assert "Alice" in text
        assert "Bob" in text

    def test_empty_dataframe(self):
        df = pd.DataFrame()
        result = relatorio_historico._to_csv(df)
        assert isinstance(result, bytes)


class TestToExcel:
    def test_returns_bytes(self):
        df = pd.DataFrame({"a": [1, 2], "b": [3, 4]})
        result = relatorio_historico._to_excel(df)
        assert isinstance(result, bytes)

    def test_valid_excel_content(self):
        df = pd.DataFrame({"name": ["Alice", "Bob"], "age": [30, 25]})
        result = relatorio_historico._to_excel(df)
        # Excel files start with PK (zip format)
        assert result[:2] == b"PK"

    def test_empty_dataframe(self):
        df = pd.DataFrame()
        result = relatorio_historico._to_excel(df)
        assert isinstance(result, bytes)

    def test_can_be_read_back(self):
        df = pd.DataFrame({"col1": [1, 2, 3], "col2": ["a", "b", "c"]})
        excel_bytes = relatorio_historico._to_excel(df)
        df_back = pd.read_excel(io.BytesIO(excel_bytes), sheet_name="Dados")
        assert list(df_back.columns) == ["col1", "col2"]
        assert len(df_back) == 3


class TestRenderingCoverage:
    """Re-import the module with session state populated to cover rendering code."""

    def test_full_page_render_with_data(self):
        mod = reimport_page_with_session_state(
            "relatorio_historico",
            str(Path(_PAGES_DIR) / "relatorio_historico.py"),
            session_state={
                "hist_df": make_sample_logins_df(),
                "hist_msg_count": 100,
            },
        )
        assert hasattr(mod, "_to_csv")
        assert hasattr(mod, "_to_excel")
