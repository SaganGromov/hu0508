"""Enriquecimento organizacional do dossiê de backtesting via Curio."""

from backtest_vpn import org_lookup
from backtest_vpn.report_model import _employee_record


def _bundle(*user_ids):
    return {
        "summary": {
            "cases": [
                {
                    "rule_id": "R1",
                    "occurrences": [
                        {
                            "user_id": user_id,
                            "details": {"users": [user_id]},
                        }
                        for user_id in user_ids
                    ],
                }
            ]
        }
    }


CURIO_RECORD = {
    "nomeUsuario": "FULANO DE TAL",
    "numeroMatriculaUsuario": "F8351026",
    "codigoUnidadeOrganizacionalDependenciaUsuario": "12345",
    "codigoPrefixoDependenciaAtual": "4321",
    "codigoComissaoUsuario": "701",
    "codigoTipoUsuario": "1",
}


class TestIsMatricula:
    def test_accepts_real_registration(self):
        assert org_lookup.is_matricula("F8351026") is True

    def test_rejects_pseudonymized_key(self):
        assert org_lookup.is_matricula("U-9f2c1ab3") is False

    def test_rejects_empty(self):
        assert org_lookup.is_matricula("") is False
        assert org_lookup.is_matricula(None) is False


class TestCollectUserIds:
    def test_collects_from_occurrences_and_details(self):
        bundle = _bundle("F8351026", "F1112223")
        assert org_lookup.collect_user_ids(bundle) == ["F1112223", "F8351026"]

    def test_collects_from_legacy_sample_shape(self):
        bundle = {"summary": {"cases": [{"sample": [{"USER_KEY": "F8351026"}]}]}}
        assert org_lookup.collect_user_ids(bundle) == ["F8351026"]

    def test_tolerates_missing_summary(self):
        assert org_lookup.collect_user_ids({}) == []


class TestFetchEmployeeDetails:
    def test_pseudonymized_users_never_reach_curio(self):
        calls = []

        def fake(matricula):
            calls.append(matricula)
            return CURIO_RECORD

        details = org_lookup.fetch_employee_details(
            _bundle("U-9f2c1ab3", "U-aaaa1111"), curio_client=fake
        )
        assert calls == []
        assert details == {}

    def test_queries_each_registration_once(self):
        calls = []

        def fake(matricula):
            calls.append(matricula)
            return CURIO_RECORD

        details = org_lookup.fetch_employee_details(
            _bundle("F8351026", "F8351026", "U-abc"), curio_client=fake
        )
        assert calls == ["F8351026"]
        assert details == {"F8351026": CURIO_RECORD}

    def test_individual_failure_does_not_break_pipeline(self):
        def fake(matricula):
            raise RuntimeError("sidecar fora do ar")

        assert org_lookup.fetch_employee_details(_bundle("F8351026"), curio_client=fake) == {}

    def test_unavailable_client_degrades_to_empty(self, monkeypatch):
        monkeypatch.setattr(org_lookup, "load_org_fetcher", lambda: None)
        assert org_lookup.fetch_employee_details(_bundle("F8351026")) == {}


class TestReportModelIntegration:
    def test_curio_record_populates_dossier_fields(self):
        details = org_lookup.fetch_employee_details(
            _bundle("F8351026"), curio_client=lambda _m: CURIO_RECORD
        )
        record = _employee_record(details, "F8351026")
        assert record["full_name"] == "FULANO DE TAL"
        assert record["registration"] == "F8351026"
        assert record["uor"] == "12345"
        assert record["prefix"] == "4321"
        assert record["function"] == "701"
        assert record["user_type"] == "1"

    def test_lotacao_fields_populate_workplace_and_position(self):
        record = dict(CURIO_RECORD)
        record.update(
            {
                "nomeDependenciaLotacao": "DITEC - UST 2 DF",
                "nomeFuncaoLotacao": "GER EQUIPE UE",
                "department": "DITEC",
                "unit": "UST 2 DF",
                "organizational_hierarchy": "DITEC > UST 2 DF",
            }
        )
        profile = _employee_record({"F8351026": record}, "F8351026")
        assert profile["workplace"] == "DITEC - UST 2 DF"
        assert profile["position"] == "GER EQUIPE UE"
        assert profile["department"] == "DITEC"
        assert profile["unit"] == "UST 2 DF"
        assert profile["organizational_hierarchy"] == "DITEC > UST 2 DF"

    def test_unsourced_fields_are_no_longer_part_of_the_model(self):
        record = _employee_record({"F8351026": CURIO_RECORD}, "F8351026")
        for field in ("uor_name", "parent_uor", "cost_center", "account_status", "managerial_status"):
            assert field not in record


class TestExecuteHandlerWiring:
    """A execução real (web, worker, agendada) precisa enriquecer sozinha."""

    def test_handler_resolves_details_from_bundle(self, monkeypatch):
        from backtest_vpn.commands import ExecuteBacktestHandler

        monkeypatch.setattr(
            org_lookup,
            "load_org_fetcher",
            lambda: (lambda matriculas: {item: CURIO_RECORD for item in matriculas}),
        )
        resolved = ExecuteBacktestHandler._resolve_employee_details(
            object(), _bundle("F8351026")
        )
        assert resolved == {"F8351026": CURIO_RECORD}

    def test_handler_returns_none_when_curio_unavailable(self, monkeypatch):
        from backtest_vpn.commands import ExecuteBacktestHandler

        monkeypatch.setattr(org_lookup, "load_org_fetcher", lambda: None)
        assert ExecuteBacktestHandler._resolve_employee_details(object(), _bundle("F8351026")) is None
