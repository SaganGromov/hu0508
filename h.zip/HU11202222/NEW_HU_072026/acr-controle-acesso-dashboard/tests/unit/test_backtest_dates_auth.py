import asyncio
from datetime import datetime, timezone
from types import SimpleNamespace

import pytest
from starlette.requests import Request

import app as app_module


def request(path, session=None, method="GET"):
    scope = {
        "type": "http",
        "method": method,
        "path": path,
        "headers": [],
        "query_string": b"",
        "server": ("testserver", 80),
        "client": ("127.0.0.1", 1234),
        "scheme": "http",
        "session": session or {},
    }
    return Request(scope)


AUTHORIZED_SESSION = {"user": {"sub": "T", "matricula": "F1234567"}, "matricula": "F1234567"}
DURABLE_JOB_ID = "bt-" + "a" * 40
LOCAL_JOB_ID = "b" * 32


class TestDefaultPeriod:
    @pytest.mark.parametrize(
        "now,expected",
        [
            (datetime(2026, 7, 29, 12), ("2026-06-27", "2026-07-29")),
            (datetime(2026, 3, 1, 12), ("2026-01-28", "2026-03-01")),
            (datetime(2026, 1, 5, 12), ("2025-12-04", "2026-01-05")),
            (datetime(2024, 3, 1, 12), ("2024-01-29", "2024-03-01")),
        ],
    )
    def test_thirty_three_inclusive_calendar_days(self, now, expected):
        assert app_module._executar_defaults(now) == expected

    def test_default_window_covers_exactly_thirty_three_dates(self):
        start, end = app_module._executar_defaults(datetime(2026, 7, 29, 12))
        start_day = datetime.strptime(start, "%Y-%m-%d").date()
        end_day = datetime.strptime(end, "%Y-%m-%d").date()
        assert (end_day - start_day).days + 1 == 33

    def test_default_window_uses_environment_configuration(self, monkeypatch):
        monkeypatch.setenv("BACKTEST_WINDOW_DAYS", "7")
        assert app_module._executar_defaults(
            datetime(2026, 7, 29, 12)
        ) == ("2026-07-23", "2026-07-29")
        assert app_module._backtest_window_days() == 7

    @pytest.mark.parametrize("value", ["0", "401", "not-a-number"])
    def test_invalid_environment_window_is_rejected(self, monkeypatch, value):
        monkeypatch.setenv("BACKTEST_WINDOW_DAYS", value)
        with pytest.raises(ValueError, match="BACKTEST_WINDOW_DAYS"):
            app_module._executar_defaults(datetime(2026, 7, 29, 12))

    def test_ui_and_backend_agree_on_the_default_window(self):
        from backtest_vpn.clock import FixedClock
        from backtest_vpn.period import default_period

        moment = datetime(2026, 7, 29, 12)
        ui = app_module._executar_defaults(moment)
        backend = default_period(FixedClock(moment))
        assert ui == (backend.start_text, backend.end_inclusive_text)

    def test_inclusive_dates_become_half_open_window(self):
        assert app_module._inclusive_dates_to_window("2026-06-27", "2026-07-29") == (
            "2026-06-27 00:00:00",
            "2026-07-30 00:00:00",
        )

    def test_current_local_date_not_utc_date_drives_default(self):
        # 01/01 02:30 UTC ainda é 31/12 em America/Sao_Paulo.
        assert app_module._executar_defaults(
            datetime(2026, 1, 1, 2, 30, tzinfo=timezone.utc)
        ) == ("2025-11-29", "2025-12-31")

    @pytest.mark.parametrize("start,end", [("2026-07-30", "2026-07-29"), ("2026-02-30", "2026-03-01")])
    def test_invalid_ranges(self, start, end):
        with pytest.raises(ValueError, match="Período inválido"):
            app_module._inclusive_dates_to_window(start, end)


class TestBacktestProgressTemplateCompatibility:
    def test_status_template_does_not_require_progress_context(self):
        """Reproduz o UndefinedError observado em rollout/jobs antigos."""
        rendered = app_module.templates.env.get_template(
            "backtest_executar_status.html"
        ).render(
            user={},
            job_id=DURABLE_JOB_ID,
            shared={
                "state": "QUEUED",
                "state_label": "Na fila",
                "period": {},
                "attempt": 0,
                "max_attempts": 3,
            },
            job=None,
            dataset={"available": True, "last_successful_at": None},
            local_log_available=False,
        )
        assert "<progress" in rendered
        assert "Preparando acompanhamento" in rendered
        assert "Em andamento" in rendered

    def test_execution_list_accepts_legacy_jobs_without_progress(self):
        legacy_job = {
            "job_id": DURABLE_JOB_ID,
            "trigger_label": "Execução inicial após implantação",
            "state_label": "Na fila",
            "period": {},
            "attempt": 0,
            "max_attempts": 3,
            "created_at": "2026-07-30T03:00:00-03:00",
        }
        rendered = app_module.templates.env.get_template(
            "backtest_executar.html"
        ).render(
            user={},
            dataset={
                "available": True,
                "active_jobs": [legacy_job],
                "schedule": {"schedule_enabled": False},
                "last_successful_at": None,
                "store_cluster_safe": True,
                "store_backend": "legacy",
                "initial_dataset_pending": True,
                "dataset_message": "Preparando",
            },
            active_job=DURABLE_JOB_ID,
            available=True,
            availability_reason="",
            error=None,
            csrf_token="test",
            default_start="2026-06-27",
            default_end="2026-07-29",
            window_days=33,
            rule_choices=[],
            shared_jobs=[legacy_job],
            recent_jobs=[],
        )
        assert rendered.count("<progress") == 2
        assert "em andamento" in rendered.lower()


class TestBacktestAuthGuards:
    @pytest.mark.parametrize(
        "endpoint,path",
        [
            (app_module.backtest_vpn_report, "/backtest/vpn"),
            (app_module.backtest_sumario, "/backtest/sumario"),
            (app_module.backtest_segmentacao, "/backtest/segmentacao"),
            (app_module.backtest_executar_form, "/backtest/executar"),
        ],
    )
    def test_unauthenticated_pages_redirect(self, endpoint, path):
        response = asyncio.run(endpoint(request(path)))
        assert response.status_code in (302, 307)
        assert response.headers["location"] == "/"

    def test_unauthenticated_status_api_returns_401(self):
        response = asyncio.run(app_module.backtest_executar_status_json(
            request("/backtest/executar/" + DURABLE_JOB_ID + "/status"), DURABLE_JOB_ID
        ))
        assert response.status_code == 401

    def test_unauthenticated_status_overview_returns_401(self):
        response = asyncio.run(
            app_module.backtest_status_overview(request("/backtest/status"))
        )
        assert response.status_code == 401

    def test_unauthenticated_report_index_returns_401(self):
        response = asyncio.run(
            app_module.backtest_report_index(request("/backtest/reports"))
        )
        assert response.status_code == 401

    def test_unauthenticated_report_download_redirects(self):
        response = asyncio.run(app_module.backtest_report_download(
            request("/backtest/reports/backtesting_dossier.xlsx"),
            "backtesting_dossier.xlsx",
        ))
        assert response.status_code in (302, 307)

    def test_unauthenticated_csv_package_download_redirects(self):
        response = asyncio.run(app_module.backtest_report_download(
            request("/backtest/reports/detalhamento_csv/cronologia_consolidada.csv"),
            "detalhamento_csv/cronologia_consolidada.csv",
        ))
        assert response.status_code in (302, 307)

    @pytest.mark.parametrize(
        "call,path",
        [
            (lambda req: app_module.backtest_vpn_report_raw(req), "/backtest/vpn/raw"),
            (lambda req: app_module.backtest_vpn_report_fragment(req), "/backtest/vpn/fragment"),
            (lambda req: app_module.backtest_sumario_csv(req, "matriz_regras.csv"), "/backtest/sumario/csv/matriz_regras.csv"),
            (lambda req: app_module.backtest_segmentacao_csv(req, "segmentacao_suspeitos.csv"), "/backtest/segmentacao/csv/segmentacao_suspeitos.csv"),
            (lambda req: app_module.backtest_executar_status_page(req, LOCAL_JOB_ID), "/backtest/executar/" + LOCAL_JOB_ID),
        ],
    )
    def test_unauthenticated_auxiliary_endpoints_redirect(self, call, path):
        response = asyncio.run(call(request(path)))
        assert response.status_code in (302, 307)
        assert response.headers["location"] == "/"

    def test_unauthorized_role_receives_forbidden_on_status_api(self, monkeypatch):
        session = dict(AUTHORIZED_SESSION)
        monkeypatch.setattr(app_module, "_is_matricula_authorized", lambda value: False)
        response = asyncio.run(app_module.backtest_executar_status_json(
            request("/backtest/executar/x/status", session), DURABLE_JOB_ID
        ))
        assert response.status_code == 403

    def test_unauthorized_role_receives_forbidden_on_status_overview(self, monkeypatch):
        session = dict(AUTHORIZED_SESSION)
        monkeypatch.setattr(app_module, "_is_matricula_authorized", lambda value: False)
        response = asyncio.run(
            app_module.backtest_status_overview(request("/backtest/status", session))
        )
        assert response.status_code == 403

    def test_unauthorized_session_is_revoked_and_leaks_nothing(self, monkeypatch):
        session = dict(AUTHORIZED_SESSION)
        monkeypatch.setattr(app_module, "_is_matricula_authorized", lambda value: False)
        response = asyncio.run(
            app_module.backtest_status_overview(request("/backtest/status", session))
        )
        assert response.status_code == 403
        assert session == {}
        assert b"period" not in bytes(response.body)
        assert b"job_id" not in bytes(response.body)

    def test_authorized_guard_preserves_session(self, monkeypatch):
        session = dict(AUTHORIZED_SESSION)
        monkeypatch.setattr(app_module, "_is_matricula_authorized", lambda value: True)
        user, response = app_module._require_backtest_user(request("/backtest/executar", session))
        assert response is None
        assert user["sub"] == "T"
        assert session["matricula"] == "F1234567"

    def test_execute_workflow_preserves_authenticated_session(self, monkeypatch):
        session = dict(AUTHORIZED_SESSION)
        session["backtest_form_csrf"] = "a" * 43
        captured = {}

        def submit(**kwargs):
            captured.update(kwargs)
            return SimpleNamespace(job_id=DURABLE_JOB_ID)

        monkeypatch.setattr(app_module, "_is_matricula_authorized", lambda value: True)
        monkeypatch.setattr(app_module._BACKTEST_RUNNER, "submit", submit)
        monkeypatch.setattr(
            app_module, "_enqueue_manual_backtest_job",
            lambda *args, **kwargs: DURABLE_JOB_ID,
        )
        response = asyncio.run(app_module.backtest_executar_submit(
            request("/backtest/executar", session, method="POST"),
            csrf_token="a" * 43,
            start_date="2026-06-27",
            end_date="2026-07-29",
            enabled_rules=["R1", "R4", "R7"],
        ))
        assert response.status_code == 303
        assert captured["start_window"] == "2026-06-27 00:00:00"
        assert captured["end_window"] == "2026-07-30 00:00:00"
        assert captured["enabled_rules"] == "R1,R4,R7"
        assert captured["job_id"] == DURABLE_JOB_ID
        assert response.headers["location"] == "/backtest/executar/" + DURABLE_JOB_ID
        assert session["matricula"] == "F1234567"

    def test_execute_workflow_uses_full_when_store_is_process_local(self, monkeypatch):
        session = dict(AUTHORIZED_SESSION)
        session["backtest_form_csrf"] = "a" * 43
        captured = {}

        class ProcessLocalRuntime:
            store = SimpleNamespace(cluster_safe=False, backend_name="memória de teste")

            def enqueue_manual(self, *args, **kwargs):
                pytest.fail("a process-local job must not be passed to run-job")

        def submit(**kwargs):
            captured.update(kwargs)
            return SimpleNamespace(job_id=LOCAL_JOB_ID)

        monkeypatch.setattr(app_module, "_is_matricula_authorized", lambda value: True)
        monkeypatch.setattr(
            app_module, "_backtest_runtime_instance", lambda: ProcessLocalRuntime()
        )
        monkeypatch.setattr(app_module._BACKTEST_RUNNER, "submit", submit)

        response = asyncio.run(app_module.backtest_executar_submit(
            request("/backtest/executar", session, method="POST"),
            csrf_token="a" * 43,
            start_date="2026-07-28",
            end_date="2026-07-30",
            enabled_rules=["R1", "R4", "R9"],
        ))

        assert response.status_code == 303
        assert captured["job_id"] is None
        assert response.headers["location"] == "/backtest/executar/" + LOCAL_JOB_ID

    def test_execute_workflow_enqueues_before_run_job_on_cluster_store(self, monkeypatch):
        session = dict(AUTHORIZED_SESSION)
        session["backtest_form_csrf"] = "a" * 43
        events = []

        class ClusterRuntime:
            store = SimpleNamespace(cluster_safe=True)

            def enqueue_manual(self, period, *, rules, requested_by):
                events.append(("enqueue", period.start_text, period.end_inclusive_text, rules))
                return SimpleNamespace(job_id=DURABLE_JOB_ID)

        def submit(**kwargs):
            events.append(("submit", kwargs["job_id"]))
            return SimpleNamespace(job_id=kwargs["job_id"])

        monkeypatch.setattr(app_module, "_is_matricula_authorized", lambda value: True)
        monkeypatch.setattr(app_module, "_backtest_runtime_instance", lambda: ClusterRuntime())
        monkeypatch.setattr(app_module._BACKTEST_RUNNER, "submit", submit)

        response = asyncio.run(app_module.backtest_executar_submit(
            request("/backtest/executar", session, method="POST"),
            csrf_token="a" * 43,
            start_date="2026-07-28",
            end_date="2026-07-30",
            enabled_rules=["R1", "R4", "R9"],
        ))

        assert response.status_code == 303
        assert events == [
            ("enqueue", "2026-07-28", "2026-07-30", ["R1", "R4", "R9"]),
            ("submit", DURABLE_JOB_ID),
        ]

    def test_execute_workflow_rejects_unavailable_runtime_before_launch(self, monkeypatch):
        session = dict(AUTHORIZED_SESSION)
        session["backtest_form_csrf"] = "a" * 43

        monkeypatch.setattr(app_module, "_is_matricula_authorized", lambda value: True)
        monkeypatch.setattr(app_module, "_backtest_runtime_instance", lambda: None)
        monkeypatch.setattr(
            app_module._BACKTEST_RUNNER,
            "submit",
            lambda **kwargs: pytest.fail("subprocess must not start without a runtime"),
        )

        response = asyncio.run(app_module.backtest_executar_submit(
            request("/backtest/executar", session, method="POST"),
            csrf_token="a" * 43,
            start_date="2026-07-28",
            end_date="2026-07-30",
            enabled_rules=["R1"],
        ))

        assert response.status_code == 303
        assert response.headers["location"].startswith("/backtest/executar?error=")

    def test_execute_workflow_rejects_invalid_csrf_before_enqueue(self, monkeypatch):
        from fastapi import HTTPException

        session = dict(AUTHORIZED_SESSION)
        session["backtest_form_csrf"] = "a" * 43
        monkeypatch.setattr(app_module, "_is_matricula_authorized", lambda value: True)
        monkeypatch.setattr(
            app_module,
            "_enqueue_manual_backtest_job",
            lambda *args, **kwargs: pytest.fail("job must not be enqueued"),
        )

        with pytest.raises(HTTPException) as caught:
            asyncio.run(app_module.backtest_executar_submit(
                request("/backtest/executar", session, method="POST"),
                csrf_token="b" * 43,
                start_date="2026-06-27",
                end_date="2026-07-29",
                enabled_rules=["R1"],
            ))

        assert caught.value.status_code == 403

    def test_unauthorized_guard_returns_forbidden_json(self, monkeypatch):
        session = dict(AUTHORIZED_SESSION)
        monkeypatch.setattr(app_module, "_is_matricula_authorized", lambda value: False)
        _, response = app_module._require_backtest_user_json(request("/backtest/api", session))
        assert response.status_code == 403


class TestJobIdValidation:
    @pytest.mark.parametrize(
        "job_id",
        ["", "abc", "../etc/passwd", "bt-" + "z" * 40, "a" * 31, "a" * 33, "bt-" + "a" * 39],
    )
    def test_malformed_job_ids_are_rejected(self, job_id):
        from fastapi import HTTPException

        with pytest.raises(HTTPException) as excinfo:
            app_module._validated_job_id(job_id)
        assert excinfo.value.status_code == 400

    @pytest.mark.parametrize("job_id", [DURABLE_JOB_ID, LOCAL_JOB_ID])
    def test_well_formed_job_ids_are_accepted(self, job_id):
        assert app_module._validated_job_id(job_id) == job_id


class TestReportNameValidation:
    @pytest.mark.parametrize(
        "name",
        [
            "../../etc/passwd",
            "detalhamento_csv/../../../etc/passwd",
            "/etc/passwd",
            "backtesting_dossier.exe",
            "detalhamento_csv/sub/dir/arquivo.csv",
            "",
            "arquivo.tex\x00.png",
        ],
    )
    def test_unsafe_report_names_are_rejected(self, name):
        assert app_module._REPORT_NAME_RE.match(name) is None

    @pytest.mark.parametrize(
        "name",
        [
            "backtesting_dossier.tex",
            "backtesting_dossier.xlsx",
            "backtesting_report_model.json",
            "detalhamento_csv/cronologia_consolidada.csv",
            "detalhamento_csv/manifest.json",
        ],
    )
    def test_expected_report_names_are_accepted(self, name):
        assert app_module._REPORT_NAME_RE.match(name) is not None

    def test_pdf_report_is_not_exposed(self):
        assert app_module._REPORT_NAME_RE.match("backtesting_dossier.pdf") is None

    def test_unknown_report_name_is_not_served_even_when_authorized(self, monkeypatch):
        from fastapi import HTTPException

        session = dict(AUTHORIZED_SESSION)
        monkeypatch.setattr(app_module, "_is_matricula_authorized", lambda value: True)
        with pytest.raises(HTTPException) as excinfo:
            asyncio.run(app_module.backtest_report_download(
                request("/backtest/reports/x", session), "../../etc/passwd"
            ))
        assert excinfo.value.status_code == 404


class TestHealthEndpoints:
    def test_liveness_never_depends_on_the_backtest(self):
        payload = asyncio.run(app_module.healthz())
        assert payload == {"status": "ok"}

    def test_readiness_reports_dataset_state_without_blocking(self):
        payload = asyncio.run(app_module.health_ready())
        assert payload["status"] == "ok"
        assert payload["web"] == "ready"
        assert "backtest_dataset" in payload


class TestSharedStatusView:
    def test_status_view_is_built_from_the_shared_store(self, monkeypatch):
        session = dict(AUTHORIZED_SESSION)
        monkeypatch.setattr(app_module, "_is_matricula_authorized", lambda value: True)
        monkeypatch.setattr(app_module._BACKTEST_RUNNER, "get_job", lambda job_id: None)
        monkeypatch.setattr(
            app_module, "_shared_job_view",
            lambda job_id: {
                "state": "RUNNING",
                "state_label": "Em execução",
                "attempt": 1,
                "max_attempts": 3,
                "heartbeat_at": "2026-07-30T03:00:00-03:00",
                "error_summary": None,
                "period": {"start_date": "2026-06-27", "end_date_inclusive": "2026-07-29"},
                "data_cutoff": "2026-07-30 00:00:00",
                "progress": {
                    "phase": "AVALIANDO_REGRAS",
                    "phase_label": "Avaliando as regras selecionadas",
                    "overall_percent": 42.0,
                    "indeterminate": False,
                    "completed_units": 3,
                    "total_units": 7,
                    "elapsed_seconds": 30,
                    "eta_seconds_remaining": 40,
                    "eta_is_estimate": True,
                    "eta_suppressed_reason": None,
                    "current_rule": "R4",
                },
            },
        )
        response = asyncio.run(app_module.backtest_executar_status_json(
            request("/backtest/executar/x/status", session), DURABLE_JOB_ID
        ))
        assert response.status_code == 200
        import json

        payload = json.loads(bytes(response.body))
        # Requisição atendida por um pod sem log local: o progresso vem do
        # estado compartilhado.
        assert payload["local_pod_log"] is False
        assert payload["phase"] == "AVALIANDO_REGRAS"
        assert payload["overall_percent"] == 42.0
        assert payload["completed_units"] == 3
        assert payload["total_units"] == 7
        assert payload["eta_seconds_remaining"] == 40
        assert payload["eta_is_estimate"] is True
        assert payload["current_rule"] == "R4"
        assert payload["heartbeat_at"] == "2026-07-30T03:00:00-03:00"
        assert payload["state_label"] == "Em execução"

    def test_missing_job_returns_terminal_response_that_stops_polling(self, monkeypatch):
        session = dict(AUTHORIZED_SESSION)
        monkeypatch.setattr(app_module, "_is_matricula_authorized", lambda value: True)
        monkeypatch.setattr(app_module._BACKTEST_RUNNER, "get_job", lambda job_id: None)
        monkeypatch.setattr(app_module, "_shared_job_view", lambda job_id: None)
        monkeypatch.setattr(app_module, "_backtest_dashboard_state", lambda: {"available": True})
        response = asyncio.run(app_module.backtest_executar_status_json(
            request("/backtest/executar/x/status", session), DURABLE_JOB_ID, since=5000
        ))
        assert response.status_code == 200
        import json
        payload = json.loads(response.body)
        assert payload["state"] == "CANCELLED"
        assert payload["status"] == "cancelled"
        assert payload["log_size"] == 5000
