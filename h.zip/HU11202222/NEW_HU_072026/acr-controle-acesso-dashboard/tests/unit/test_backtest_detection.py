from datetime import datetime
import ipaddress
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import pytest

from backtest_vpn.detection import (
    DetectionConfig,
    normalize_ip,
    normalize_events,
    normalize_timestamp,
    run_event_rules,
)


def event(user, ts, source="192.0.2.1", corporate="10.0.0.1", device="DEV-A", host="HOST-A", **extra):
    return {
        "USER_KEY": user,
        "EVENT_TS": ts,
        "SOURCE_IP": source,
        "CORPORATE_IP": corporate,
        "DEVICE_ID": device,
        "HOSTNAME": host,
        **extra,
    }


class TestR1:
    def test_one_ip_in_day_not_flagged(self):
        rules, _ = run_event_rules([
            event("T1", "2026-07-10 09:00:00"),
            event("T1", "2026-07-10 10:00:00"),
        ])
        assert rules["R1"] == []

    def test_two_source_ips_same_day_flagged(self):
        rules, _ = run_event_rules([
            event("T1", "2026-07-10 09:00:00", source="192.0.2.1"),
            event("T1", "2026-07-10 10:00:00", source="192.0.2.2"),
        ])
        assert len(rules["R1"]) == 1
        assert rules["R1"][0]["local_date"] == "2026-07-10"

    def test_different_days_not_combined(self):
        rules, _ = run_event_rules([
            event("T1", "2026-07-10 23:59:59", source="192.0.2.1"),
            event("T1", "2026-07-11 00:00:00", source="192.0.2.2"),
        ])
        assert rules["R1"] == []

    def test_ipv6_normalization_and_repeats(self):
        rules, quality = run_event_rules([
            event("T1", "2026-07-10 09:00:00", source="2001:0db8::1"),
            event("T1", "2026-07-10 10:00:00", source="2001:db8:0:0::1"),
            event("T1", "2026-07-10 11:00:00", source="2001:db8::2"),
            event("T1", "2026-07-10 11:00:00", source="2001:db8::2"),
        ])
        assert len(rules["R1"]) == 1
        assert rules["R1"][0]["triggering_value"]["source_ip_count"] == 2
        assert quality["duplicate_rows"] == 1
        assert quality["distinct_valid_users"] == 1

    def test_malformed_and_null_ips_are_safe(self):
        rules, quality = run_event_rules([
            event("T1", "2026-07-10 09:00:00", source=None, corporate=None),
            event("T1", "2026-07-10 10:00:00", source="not-an-ip", corporate="::"),
        ])
        assert rules["R1"] == []
        assert quality["invalid_source_ip_rows"] == 2

    @pytest.mark.parametrize(
        "value",
        ["0.0.0.0", "::", "::0", "0:0:0:0:0:0:0:0", " 0.0.0.0 "],
    )
    def test_unspecified_ip_representations_are_ignored(self, value):
        assert normalize_ip(value) is None
        rules, quality = run_event_rules([
            event("T1", "2026-07-10 09:00:00", source=value, corporate=value),
            event("T1", "2026-07-10 10:00:00", source="192.0.2.1", corporate="10.0.0.1"),
        ])
        assert rules["R1"] == []
        assert rules["R9"] == []
        assert quality["unspecified_source_ip_rows"] == 1
        assert quality["unspecified_corporate_ip_rows"] == 1

    def test_source_and_corporate_fields_are_not_mixed(self):
        rules, _ = run_event_rules([
            event("T1", "2026-07-10 09:00:00", source="192.0.2.1", corporate="10.0.0.1"),
            event("T1", "2026-07-10 10:00:00", source="192.0.2.1", corporate="10.0.0.1"),
        ])
        assert rules["R1"] == []

    def test_configured_corporate_vpn_external_classifications_are_preserved(self):
        cfg = DetectionConfig(
            corporate_ip_networks=(ipaddress.ip_network("10.0.0.0/8"),),
            vpn_ip_networks=(ipaddress.ip_network("172.16.0.0/12"),),
        )
        rules, _ = run_event_rules([
            event("T1", "2026-07-10 09:00:00", source="10.1.1.1"),
            event("T1", "2026-07-10 10:00:00", source="172.16.1.1"),
            event("T1", "2026-07-10 11:00:00", source="203.0.113.1"),
        ], cfg)
        classifications = {
            item["source_classification"]
            for item in rules["R1"][0]["details"]["ip_sequence"]
        }
        assert classifications == {
            "rede corporativa configurada",
            "VPN configurada",
            "externa às faixas configuradas",
        }


class TestR4:
    def test_two_logins_not_flagged_and_three_flagged(self):
        two, _ = run_event_rules([
            event("T1", "2026-07-10 09:00:00"),
            event("T1", "2026-07-10 10:00:00"),
        ])
        three, _ = run_event_rules([
            event("T1", "2026-07-10 09:00:00"),
            event("T1", "2026-07-10 10:00:00"),
            event("T1", "2026-07-10 11:00:00"),
        ])
        assert two["R4"] == []
        assert three["R4"][0]["triggering_value"] == 3
        assert len(three["R4"][0]["details"]["login_timestamps"]) == 3

    def test_more_than_three_has_exact_count(self):
        rows = [
            event("T1", "2026-07-10 {0:02d}:00:00".format(hour))
            for hour in (8, 9, 10, 11, 12)
        ]
        rules, _ = run_event_rules(rows)
        assert rules["R4"][0]["triggering_value"] == 5

    def test_daily_reset_and_duplicate(self):
        rows = [
            event("T1", "2026-07-10 09:00:00"),
            event("T1", "2026-07-10 10:00:00"),
            event("T1", "2026-07-11 09:00:00"),
            event("T1", "2026-07-11 10:00:00"),
            event("T1", "2026-07-11 10:00:00"),
        ]
        rules, quality = run_event_rules(rows)
        assert rules["R4"] == []
        assert quality["duplicate_rows"] == 1

    @pytest.mark.parametrize(
        "count,expected_severity",
        [(3, "MÉDIA"), (10, "MÉDIA"), (11, "ALTA"), (20, "ALTA"), (21, "CRÍTICA")],
    )
    def test_graduated_severity_boundaries(self, count, expected_severity):
        rows = [
            event(
                "T1",
                "2026-07-10 {0:02d}:{1:02d}:00".format(8 + index // 60, index % 60),
                source="192.0.2.{0}".format(index + 1),
            )
            for index in range(count)
        ]
        occurrence = run_event_rules(rows)[0]["R4"][0]
        assert occurrence["triggering_value"] == count
        assert occurrence["severity"] == expected_severity
        assert occurrence["configured_threshold"] == {
            "operator": ">",
            "value": 2,
            "high_severity_above": 10,
            "critical_severity_above": 20,
        }

    def test_graduated_thresholds_must_be_strictly_ordered(self):
        with pytest.raises(ValueError, match="maior que r4_vpn_login_limit"):
            DetectionConfig.from_mapping({"r4_high_severity_above": 2})
        with pytest.raises(ValueError, match="maior que r4_high_severity_above"):
            DetectionConfig.from_mapping({
                "r4_high_severity_above": 10,
                "r4_critical_severity_above": 10,
            })


class TestR2AndR3:
    def test_exactly_two_values_do_not_flag_but_three_do(self):
        two, _ = run_event_rules([
            event("T1", "2026-07-10 09:00:00", host="HOST-A", device="DEV-A"),
            event("T1", "2026-07-10 10:00:00", host="HOST-B", device="DEV-B"),
        ])
        three, _ = run_event_rules([
            event("T1", "2026-07-10 09:00:00", host="HOST-A", device="DEV-A"),
            event("T1", "2026-07-10 10:00:00", host="HOST-B", device="DEV-B"),
            event("T1", "2026-07-10 11:00:00", host="HOST-C", device="DEV-C"),
        ])
        assert two["R2"] == [] and two["R3"] == []
        assert three["R2"][0]["triggering_value"] == 3
        assert three["R3"][0]["triggering_value"] == 3

    def test_placeholders_and_duplicate_rows_do_not_raise_distinct_counts(self):
        rules, quality = run_event_rules([
            event("T1", "2026-07-10 09:00:00", host="NULL", device="UNKNOWN"),
            event("T1", "2026-07-10 10:00:00", host="HOST-A", device="DEV-A"),
            event("T1", "2026-07-10 10:00:00", host="HOST-A", device="DEV-A"),
        ])
        assert rules["R2"] == [] and rules["R3"] == []
        assert quality["duplicate_rows"] == 1


class TestR7:
    def test_same_device_two_users_same_day(self):
        rules, _ = run_event_rules([
            event("T1", "2026-07-10 09:00:00", device="DEV-X"),
            event("T2", "2026-07-10 10:00:00", device="DEV-X"),
        ])
        assert len(rules["R7"]) == 1
        assert rules["R7"][0]["severity"] == "ALTA"
        assert rules["R7"][0]["details"]["users"] == ["T1", "T2"]

    def test_same_user_repeated_and_two_devices_not_flagged(self):
        rules, _ = run_event_rules([
            event("T1", "2026-07-10 09:00:00", device="DEV-A"),
            event("T1", "2026-07-10 10:00:00", device="DEV-A"),
            event("T1", "2026-07-10 11:00:00", device="DEV-B"),
        ])
        assert rules["R7"] == []

    def test_seven_day_and_over_thirty_days(self):
        seven, _ = run_event_rules([
            event("T1", "2026-07-01 09:00:00", device="DEV-X"),
            event("T2", "2026-07-07 09:00:00", device="DEV-X"),
        ])
        far, _ = run_event_rules([
            event("T1", "2026-06-01 09:00:00", device="DEV-X"),
            event("T2", "2026-07-02 09:00:01", device="DEV-X"),
        ])
        assert seven["R7"][0]["triggering_value"]["horizon"] == "7_DIAS"
        assert far["R7"] == []

    def test_broader_windows_are_configurable(self):
        rules, _ = run_event_rules([
            event("T1", "2026-07-01 09:00:00", device="DEV-X"),
            event("T2", "2026-07-11 09:00:00", device="DEV-X"),
        ], DetectionConfig(device_windows_days=(1, 14, 30)))
        assert rules["R7"][0]["triggering_value"]["horizon"] == "14_DIAS"

    def test_invalid_device_and_allowlist(self):
        invalid, _ = run_event_rules([
            event("T1", "2026-07-10 09:00:00", device="NULL"),
            event("T2", "2026-07-10 10:00:00", device="NULL"),
        ])
        allowed, _ = run_event_rules([
            event("T1", "2026-07-10 09:00:00", device="DEV-SHARED"),
            event("T2", "2026-07-10 10:00:00", device="DEV-SHARED"),
        ], DetectionConfig(shared_device_allowlist=frozenset({"DEV-SHARED"})))
        assert invalid["R7"] == []
        assert allowed["R7"] == []

    def test_overlapping_windows_are_consolidated(self):
        rules, _ = run_event_rules([
            event("T1", "2026-07-10 09:00:00", device="DEV-X"),
            event("T2", "2026-07-10 10:00:00", device="DEV-X"),
            event("T1", "2026-07-11 09:00:00", device="DEV-X"),
            event("T2", "2026-07-11 10:00:00", device="DEV-X"),
        ])
        assert len(rules["R7"]) == 1


class TestAdditionalRulesAndStability:
    def test_configuration_requires_at_least_one_enabled_rule(self):
        with pytest.raises(ValueError, match="pelo menos uma"):
            DetectionConfig.from_mapping({"enabled_rules": []})

    def test_r8_and_r9(self):
        rules, _ = run_event_rules([
            event("T1", "2026-07-10 09:00:00", device="DEV-A", source="192.0.2.1"),
            event("T1", "2026-07-10 09:30:00", device="DEV-B", source="192.0.2.2"),
            event("T1", "2026-07-10 10:00:00", device="DEV-B", source="192.0.2.3"),
        ])
        assert len(rules["R8"]) == 1
        assert len(rules["R9"]) == 1

    def test_overlapping_short_windows_do_not_inflate_triggering_value(self):
        cfg = DetectionConfig(
            enabled_rules=("R9",),
            rapid_ip_window_minutes=60,
            rapid_ip_min_distinct=2,
        )
        rows = [
            event("T1", "2026-07-10 09:00:00", source="192.0.2.1"),
            event("T1", "2026-07-10 09:50:00", source="192.0.2.2"),
            event("T1", "2026-07-10 10:40:00", source="192.0.2.3"),
            event("T1", "2026-07-10 11:30:00", source="192.0.2.4"),
        ]
        occurrence = run_event_rules(rows, cfg)[0]["R9"][0]
        assert occurrence["triggering_value"] == 2
        assert occurrence["details"]["distinct_values"] == [
            "192.0.2.1",
            "192.0.2.2",
            "192.0.2.3",
            "192.0.2.4",
        ]
        assert occurrence["details"]["maximum_distinct_in_qualifying_window"] == 2

    def test_stable_occurrence_ids_and_ordering(self):
        rows = [
            event("T2", "2026-07-10 10:00:00", source="192.0.2.2"),
            event("T1", "2026-07-10 09:00:00", source="192.0.2.1"),
            event("T1", "2026-07-10 10:00:00", source="192.0.2.2"),
        ]
        first, _ = run_event_rules(rows)
        second, _ = run_event_rules(reversed(rows))
        assert first["R1"] == second["R1"]

    def test_excluded_service_account_is_removed_from_all_event_rules(self):
        rows = [
            event("SVC-TEST", "2026-07-10 09:00:00", source="192.0.2.1"),
            event("SVC-TEST", "2026-07-10 09:10:00", source="192.0.2.2"),
            event("SVC-TEST", "2026-07-10 09:20:00", source="192.0.2.3"),
        ]
        rules, quality = run_event_rules(
            rows,
            DetectionConfig(excluded_user_allowlist=frozenset({"SVC-TEST"})),
        )
        assert all(not occurrences for occurrences in rules.values())
        assert quality["excluded_user_events"] == 3

    def test_aware_utc_events_cross_local_midnight(self):
        rules, _ = run_event_rules([
            event("T1", datetime.fromisoformat("2026-07-11T02:59:59+00:00"), source="192.0.2.1"),
            event("T1", datetime.fromisoformat("2026-07-11T03:00:00+00:00"), source="192.0.2.2"),
        ])
        assert rules["R1"] == []

    def test_historical_daylight_saving_offset_when_tzdata_is_available(self):
        try:
            ZoneInfo("America/Sao_Paulo")
        except ZoneInfoNotFoundError:
            pytest.skip("base IANA tzdata indisponível")
        normalized = normalize_timestamp(
            datetime.fromisoformat("2018-11-04T03:00:00+00:00")
        )
        assert normalized.utcoffset().total_seconds() == -2 * 3600

    def test_large_fixture_has_stable_deduplication(self):
        rows = [
            event(
                "T{0:04d}".format(index % 100),
                "2026-07-{0:02d} {1:02d}:{2:02d}:00".format(
                    1 + (index % 20), index % 24, index % 60
                ),
                source="192.0.2.{0}".format(1 + (index % 200)),
                device="DEV-{0}".format(index % 50),
            )
            for index in range(5000)
        ]
        _, quality = run_event_rules(rows)
        assert quality["input_rows"] == 5000
        assert quality["deduplicated_events"] <= 5000
