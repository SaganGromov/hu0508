from pathlib import Path

import pytest

from backtest_vpn.dossier import (
    NOTICE,
    TIMELINE_SAMPLE_LIMIT,
    latex_escape,
    latex_escape_breakable,
    normalize_report_formats,
    render_latex,
    safe_excel_value,
    write_latex,
    write_reports,
    write_xlsx,
)
from backtest_vpn.bundle import _pseudonymize_obj
from backtest_vpn.htmlreport import _limit_occurrences_for_presentation
from backtest_vpn.report_model import (
    RULE_GUIDE,
    build_report_model,
    classify_uor,
    normalize_uor,
    safe_fixture_bundle,
)
from backtest_vpn.report_selection import REPORT_OCCURRENCE_LIMIT

class TestUorClassification:
    @pytest.mark.parametrize("value", [20259, "20259", " 20259 ", "020259"])
    def test_yellow(self, value):
        assert classify_uor(value)["uor_alert_code"] == "YELLOW_UOR_20259"

    @pytest.mark.parametrize("value", [1, 12345, "99999", " 12345 ", 20258, 202590])
    def test_red(self, value):
        assert classify_uor(value)["uor_alert_code"] == "RED_OTHER_UOR"

    @pytest.mark.parametrize(
        "value",
        [None, "", " ", "ABC", "20X59", 0, -1, 20259.5, True, False, "20259.0", "2 0259", []],
    )
    def test_gray(self, value):
        assert classify_uor(value)["uor_alert_code"] == "GRAY_UNKNOWN_UOR"

    def test_missing_or_invalid_is_never_red(self):
        for value in (None, "", "ABC", 0, -1):
            assert classify_uor(value)["uor_alert_code"] != "RED_OTHER_UOR"

    def test_normalization_strips_whitespace_and_leading_zeros(self):
        assert normalize_uor(" 020259 ") == "20259"
        assert normalize_uor(20259.0) == "20259"

    def test_code_label_and_reason_are_consistent(self):
        for value, code in ((20259, "YELLOW_UOR_20259"), (1, "RED_OTHER_UOR"), (None, "GRAY_UNKNOWN_UOR")):
            payload = classify_uor(value)
            assert payload["uor_alert_code"] == code
            assert payload["uor_alert_label"]
            assert payload["uor_alert_reason"]

    def test_conflicting_values_stay_gray(self):
        # Duas representações incompatíveis para a mesma pessoa não viram UOR.
        assert classify_uor("20259/12345")["uor_alert_code"] == "GRAY_UNKNOWN_UOR"


class TestSafety:
    def test_latex_escape_all_special_characters(self):
        escaped = latex_escape(r"\%$#_{}&~^<>|")
        for expected in (
            r"\textbackslash{}", r"\%", r"\$", r"\#", r"\_",
            r"\{", r"\}", r"\&", r"\textasciitilde{}", r"\textasciicircum{}",
            r"\textless{}", r"\textgreater{}", r"\textbar{}",
        ):
            assert expected in escaped

    @pytest.mark.parametrize(
        "payload",
        [
            r"\input{/etc/passwd}",
            r"\write18{rm -rf /}",
            r"\immediate\write18{id}",
            r"\csname relax\endcsname",
            r"\catcode`\@=11",
            "\\end{document}\\section{injetado}",
        ],
    )
    def test_no_latex_command_can_be_injected(self, payload):
        escaped = latex_escape(payload)
        assert "\\input" not in escaped
        assert "\\write18" not in escaped
        assert "\\end{document}" not in escaped
        assert "\\csname" not in escaped

    def test_control_characters_are_stripped_from_latex(self):
        assert "\x00" not in latex_escape("a\x00b")

    @pytest.mark.parametrize(
        "payload",
        [
            r"\input{/etc/passwd}",
            r"\write18{id}",
            "\\end{document}",
            "a" * 200,
            '{"chave_longa": "valor", "outra": 2}',
        ],
    )
    def test_breakable_escaping_never_weakens_escaping(self, payload):
        breakable = latex_escape_breakable(payload)
        assert "\\input" not in breakable
        assert "\\write18" not in breakable
        assert "\\end{document}" not in breakable
        # O texto legível é preservado: removendo as marcas de quebra, o
        # resultado é exatamente o escape normal.
        assert breakable.replace(r"\allowbreak{}", "") == latex_escape(payload)

    def test_breakable_escaping_adds_break_points_to_long_runs(self):
        out = latex_escape_breakable("A" * 60)
        assert out.count(r"\allowbreak{}") >= 4

    def test_breakable_escaping_breaks_after_escaped_separators(self):
        out = latex_escape_breakable("MESMO_DIA")
        assert r"\_\allowbreak{}" in out

    def test_breakable_escaping_keeps_missing_placeholder(self):
        assert latex_escape_breakable(None) == "Não informado"

    @pytest.mark.parametrize("value", ["=1+1", "+CMD", "-2+3", "@SUM(A1:A2)"])
    def test_formula_injection_is_text(self, value):
        assert safe_excel_value(value).startswith("'")

    def test_occurrence_user_fields_are_pseudonymized_consistently(self):
        class FakePseudonymizer:
            key_id = "test"

            @staticmethod
            def pseudonymize(value):
                text = str(value)
                return "P-HASH" if "|" in text else "P-" + text

        value = {
            "user_id": "T1",
            "deduplication_key": "R1|T1|2026-07-10",
            "details": {
                "users": ["T1", "T2"],
                "per_user": {"T1": {"event_count": 1}, "T2": {"event_count": 2}},
            },
        }
        result = _pseudonymize_obj(value, FakePseudonymizer())
        assert result["user_id"] == "P-T1"
        assert result["details"]["users"] == ["P-T1", "P-T2"]
        assert sorted(result["details"]["per_user"]) == ["P-T1", "P-T2"]
        assert "T1" not in result["deduplication_key"]


class TestModelStructure:
    def test_fixture_totals_and_uor_counts(self):
        model = build_report_model(safe_fixture_bundle(), "2.2.0")
        assert model["executive"]["total_occurrences"] == len(model["occurrences"]) == 4
        assert model["executive"]["flagged_users"] == len(model["users"]) == 3
        assert model["executive"]["uor_alert_user_totals"] == {
            "YELLOW_UOR_20259": 1,
            "RED_OTHER_UOR": 1,
            "GRAY_UNKNOWN_UOR": 1,
        }

    def test_readable_formats_keep_only_ten_priority_occurrences_per_rule(self):
        bundle = safe_fixture_bundle()
        base = bundle["summary"]["cases"][1]["occurrences"][0]
        occurrences = []
        for index in range(15):
            clone = dict(base)
            clone["occurrence_id"] = "R4-BULK-{0:02d}".format(index)
            clone["user_id"] = "U-BULK-{0:02d}".format(index)
            clone["severity"] = "MÉDIA"
            clone["triggering_value"] = index
            occurrences.append(clone)
        occurrences[-1]["severity"] = "CRÍTICA"
        occurrences[-1]["triggering_value"] = 999
        bundle["summary"]["cases"][1]["occurrences"] = occurrences

        model = build_report_model(bundle, "2.4.0")
        shown = [item for item in model["occurrences"] if item["rule_id"] == "R4"]

        assert len(shown) == REPORT_OCCURRENCE_LIMIT
        assert "R4-BULK-14" in {item["occurrence_id"] for item in shown}
        assert model["executive"]["findings_by_rule"]["R4"] == 15
        assert model["executive"]["presented_by_rule"]["R4"] == REPORT_OCCURRENCE_LIMIT
        assert model["executive"]["omitted_occurrences"] == 5
        assert model["executive"]["flagged_users"] > len(model["users"])
        assert sum(model["executive"]["uor_alert_user_totals"].values()) == (
            model["executive"]["flagged_users"]
        )

    def test_execution_metadata_is_carried_into_the_report(self):
        model = build_report_model(safe_fixture_bundle(), "2.2.0")
        report = model["report"]
        assert report["job_id"]
        assert report["trigger_type"] == "manual"
        assert report["period_start_date"] == "2026-06-27"
        assert report["period_end_inclusive"] == "2026-07-29"
        assert report["total_calendar_days"] == 33
        assert report["data_cutoff"] == "2026-07-30 00:00:00"
        assert report["data_cutoff_description"]
        assert report["configuration_hash"]
        assert report["rule_versions"]["R1"] == "2.1.0"

    def test_period_end_inclusive_is_derived_when_absent(self):
        bundle = safe_fixture_bundle()
        bundle.pop("execution")
        model = build_report_model(bundle, "2.2.0")
        assert model["report"]["period_end_inclusive"] == "2026-07-29"
        assert model["report"]["period_start_date"] == "2026-06-27"

    def test_model_is_deterministic_for_equivalent_input(self):
        import json

        first = build_report_model(safe_fixture_bundle(), "2.2.0")
        second = build_report_model(safe_fixture_bundle(), "2.2.0")
        assert json.dumps(first, sort_keys=True, default=str) == json.dumps(
            second, sort_keys=True, default=str
        )

    def test_occurrences_are_sorted_stably(self):
        model = build_report_model(safe_fixture_bundle(), "2.2.0")
        keys = [
            (int(item["rule_id"][1:]), str(item.get("window_start") or ""), item["occurrence_id"])
            for item in model["occurrences"]
        ]
        assert keys == sorted(keys)

    def test_no_unexpected_duplicate_occurrence(self):
        model = build_report_model(safe_fixture_bundle(), "2.2.0")
        identifiers = [item["occurrence_id"] for item in model["occurrences"]]
        assert len(identifiers) == len(set(identifiers))

    def test_cross_rule_consolidation_requires_shared_evidence(self):
        model = build_report_model(safe_fixture_bundle(), "2.2.0")
        consolidations = model["cross_rule_consolidations"]
        assert len(consolidations) == 1
        assert consolidations[0]["rules"] == ["R1", "R4"]
        assert "T0000002" in consolidations[0]["entities"]
        assert model["executive"]["cross_rule_consolidations"] == 1

    def test_unrelated_occurrences_are_not_merged(self):
        model = build_report_model(safe_fixture_bundle(), "2.2.0")
        merged_ids = {
            item for group in model["cross_rule_consolidations"] for item in group["occurrence_ids"]
        }
        # A ocorrência R7 não compartilha eventos com nenhuma outra.
        assert "R7-FIX-03" not in merged_ids

    def test_multirule_users_are_detected(self):
        model = build_report_model(safe_fixture_bundle(), "2.2.0")
        assert {item["user_id"] for item in model["multirule_users"]} == {"T0000001", "T0000002"}

    def test_timeline_is_complete_and_sorted(self):
        model = build_report_model(safe_fixture_bundle(), "2.2.0")
        timeline = model["timeline"]
        evidence_total = sum(len(item["evidence_records"]) for item in model["occurrences"])
        assert len(timeline) == evidence_total == model["executive"]["timeline_entries"]
        assert [item["timestamp"] for item in timeline] == sorted(
            item["timestamp"] for item in timeline
        )

    def test_rule_catalog_carries_business_guidance(self):
        model = build_report_model(safe_fixture_bundle(), "2.2.0")
        for rule in model["rule_catalog"]:
            assert rule["question"] != "Não informado"
            assert rule["condition"] != "Não informado"
            assert rule["legitimate_causes"] != "Não informado"
            assert rule["limitation"] != "Não informado"
            assert rule["rule_id"] in RULE_GUIDE

    def test_device_usage_prefers_the_rule_computation(self):
        model = build_report_model(safe_fixture_bundle(), "2.2.0")
        shared = next(item for item in model["devices"] if item["device_id"] == "DEV-SHARED")
        assert sorted(shared["per_user_usage"]) == ["T0000001", "T0000003"]
        assert shared["per_user_usage"]["T0000001"]["event_count"] == 2
        assert shared["distinct_users"] == 2

    def test_missing_data_indicators_are_reported(self):
        bundle = safe_fixture_bundle()
        bundle.pop("employee_details")
        model = build_report_model(bundle, "2.2.0")
        indicators = model["missing_data_indicators"]
        assert indicators["users_without_employee_details"] == 3
        assert indicators["users_without_determined_uor"] == 3

    def test_reading_guide_and_review_guidance_exist(self):
        model = build_report_model(safe_fixture_bundle(), "2.2.0")
        assert model["reading_guide"]
        assert model["human_review_guidance"]
        assert any("análise humana" in item for item in model["reading_guide"])

    def test_missing_employee_data_is_not_fabricated(self):
        bundle = safe_fixture_bundle()
        bundle.pop("employee_details")
        model = build_report_model(bundle, "2.2.0")
        assert all(user["full_name"] is None for user in model["users"])
        assert all(user["uor_alert_code"] == "GRAY_UNKNOWN_UOR" for user in model["users"])

    def test_malformed_bundle_fails_clearly(self):
        with pytest.raises(ValueError, match="Bundle legado"):
            build_report_model({}, "2.2.0")

    def test_legacy_bundle_is_rejected_instead_of_relabelled(self):
        bundle = safe_fixture_bundle()
        bundle["bundle_version"] = 1
        with pytest.raises(ValueError, match="Bundle legado"):
            build_report_model(bundle, "2.2.0")

    def test_sensitive_values_are_removed_from_report_model(self):
        bundle = safe_fixture_bundle()
        bundle["parameters"].update({
            "jdbc_url": "jdbc:db2://sistema-interno/banco",
            "credentials_file": "/segredo/credenciais.json",
            "password": "nao-incluir",
        })
        bundle["summary"]["cases"][0]["occurrences"][0]["evidence_records"][0][
            "cookie"
        ] = "nao-incluir"
        model = build_report_model(bundle, "2.2.0")
        serialized = str(model)
        assert "nao-incluir" not in serialized
        assert "sistema-interno" not in serialized

    def test_fixture_contains_no_real_person_data(self):
        bundle = safe_fixture_bundle()
        assert bundle["safe_fixture"] is True
        for payload in bundle["employee_details"].values():
            assert "Teste" in payload["nomeUsuario"]
        model = build_report_model(bundle, "2.2.0")
        assert model["report"]["safe_fixture"] is True
        for user in model["users"]:
            assert user["user_id"].startswith("T00000")


class TestLatexDossier:
    @pytest.fixture
    def text(self):
        return render_latex(build_report_model(safe_fixture_bundle(), "2.2.0"))

    def test_uor_commands_and_legend_are_defined(self, text):
        assert r"\newcommand{\UORYellowBadge}" in text
        assert r"\newcommand{\UORRedBadge}" in text
        assert r"\newcommand{\UORGrayBadge}" in text
        # A cor nunca é o único sinal: o rótulo textual acompanha o selo.
        assert "ALERTA AMARELO --- UOR 20259" in text
        assert "ALERTA VERMELHO --- UOR diferente de 20259" in text
        assert "UOR NÃO INFORMADA OU NÃO DETERMINADA" in text

    def test_severity_badges_include_critical_and_are_used_in_findings(self, text):
        for command in (
            r"\newcommand{\SevCriticalBadge}",
            r"\newcommand{\SevHighBadge}",
            r"\newcommand{\SevMediumBadge}",
            r"\newcommand{\SevLowBadge}",
        ):
            assert command in text
        assert r"\SevMediumBadge" in text
        assert "CRÍTICA" in text

    def test_required_sections_are_present(self, text):
        for section in (
            r"\section{Como ler este relatório}",
            r"\section{Resumo executivo}",
            r"\section{Catálogo de regras}",
            r"\section{Achados consolidados entre regras}",
            r"\section{Ocorrências por regra}",
            r"\section{Usuários sinalizados por múltiplas regras}",
            r"\section{Dispositivos associados a múltiplos usuários}",
            r"\section{Perfis detalhados de usuários}",
            r"\section{Perfis detalhados de dispositivos}",
            r"\section{Cronologia das evidências}",
            r"\section{Metodologia}",
            r"\section{Qualidade dos dados}",
            r"\section{Limitações e orientação de interpretação}",
            r"\section{Pacote de detalhamento em CSV}",
            r"\section{Revisão humana}",
        ):
            assert section in text, section

    def test_navigation_features_are_enabled(self, text):
        assert r"\tableofcontents" in text
        assert "bookmarks=true" in text
        assert r"\pagestyle{fancy}" in text
        assert r"Página \thepage" in text

    def test_long_tables_repeat_headers_and_announce_continuation(self, text):
        assert r"\endfirsthead" in text
        assert r"\endhead" in text
        assert "Continua na próxima página" in text
        assert "Continuação da tabela anterior" in text

    def test_landscape_is_used_for_the_wide_timeline(self, text):
        assert r"\begin{landscape}" in text
        assert r"\end{landscape}" in text

    def test_mandatory_notice_is_present(self, text):
        assert latex_escape(NOTICE) in text

    def test_executive_totals_match_the_model(self):
        model = build_report_model(safe_fixture_bundle(), "2.2.0")
        text = render_latex(model)
        assert "Ocorrências consolidadas & {0}".format(
            model["executive"]["total_occurrences"]
        ) in text
        assert "Usuários sinalizados & {0}".format(model["executive"]["flagged_users"]) in text

    def test_metadata_includes_job_cutoff_and_config_hash(self, text):
        for label in (
            "Identificador da execução",
            "Origem da execução",
            "Corte de dados",
            "Critério do corte de dados",
            "Hash da configuração",
            "Total de dias de calendário",
        ):
            assert latex_escape(label) in text

    def test_every_occurrence_detail_is_printed(self):
        model = build_report_model(safe_fixture_bundle(), "2.2.0")
        text = render_latex(model)
        for occurrence in model["occurrences"]:
            assert latex_escape(occurrence["occurrence_id"]) in text

    def test_legitimate_causes_and_thresholds_accompany_findings(self, text):
        assert "Causas legítimas comuns" in text
        assert "Limiar/janela configurados" in text
        assert "Revisão humana & Pendente" in text

    def test_csv_package_files_are_printed_visibly(self, text):
        # O nome do arquivo é impresso (com escape LaTeX do sublinhado), para
        # que continue legível em leitores que bloqueiam links locais.
        assert latex_escape("detalhamento_csv/cronologia_consolidada.csv") in text
        assert latex_escape("detalhamento_csv/manifest.json") in text
        assert "bloqueiam links para arquivos locais" in text

    def test_no_internal_url_is_embedded(self, text):
        assert "http://" not in text
        assert "https://" not in text
        assert "jdbc:" not in text

    def test_empty_sections_render_a_message_instead_of_a_broken_table(self):
        bundle = safe_fixture_bundle()
        for case in bundle["summary"]["cases"]:
            case["occurrences"] = []
            case["count"] = 0
        text = render_latex(build_report_model(bundle, "2.2.0"))
        assert "Nenhuma ocorrência sinalizada para esta regra" in text
        assert "Nenhum usuário foi sinalizado por mais de uma regra" in text
        assert "Nenhum dispositivo foi associado a dois ou mais usuários" in text
        assert "Nenhum registro de evidência foi produzido" in text
        assert r"\begin{longtable}" in text

    def test_timeline_contains_only_evidence_from_priority_occurrences(self):
        bundle = safe_fixture_bundle()
        base = bundle["summary"]["cases"][1]["occurrences"][0]
        extra = []
        for index in range(TIMELINE_SAMPLE_LIMIT + 25):
            clone = dict(base)
            clone["occurrence_id"] = "R4-BULK-{0:04d}".format(index)
            clone["evidence_records"] = [{
                "event_id": "EVT-BULK-{0:04d}".format(index),
                "timestamp": "2026-07-11T{0:02d}:{1:02d}:00-03:00".format(index // 60, index % 60),
                "user_id": "T0000002",
                "device_id": "DEV-B",
            }]
            clone["supporting_event_identifiers"] = ["EVT-BULK-{0:04d}".format(index)]
            extra.append(clone)
        bundle["summary"]["cases"][1]["occurrences"] = extra
        model = build_report_model(bundle, "2.2.0")
        text = render_latex(model)
        r4_occurrences = [
            item for item in model["occurrences"] if item["rule_id"] == "R4"
        ]
        assert len(r4_occurrences) == REPORT_OCCURRENCE_LIMIT
        assert len(model["timeline"]) <= REPORT_OCCURRENCE_LIMIT + 3
        assert "no máximo 10 das ocorrências mais prioritárias" in text

    def test_html_data_island_limits_occurrence_lists_without_changing_totals(self):
        bundle = safe_fixture_bundle()
        base = bundle["summary"]["cases"][0]["occurrences"][0]
        bundle["summary"]["cases"][0]["occurrences"] = [
            {**base, "occurrence_id": "R1-HTML-{0:02d}".format(index)}
            for index in range(25)
        ]
        bundle["summary"]["cases"][0]["count"] = 25
        safe = _limit_occurrences_for_presentation(bundle)
        case = safe["summary"]["cases"][0]
        assert len(case["occurrences"]) == REPORT_OCCURRENCE_LIMIT
        assert case["count"] == 25
        assert safe["presentation"]["complete_totals_preserved"] is True

    def test_written_file_is_utf8(self, tmp_path):
        model = build_report_model(safe_fixture_bundle(), "2.2.0")
        path = write_latex(model, tmp_path / "backtesting_dossier.tex")
        assert path.read_text(encoding="utf-8").startswith(r"\documentclass")


class TestXlsxWorkbook:
    @pytest.fixture
    def workbook_path(self, tmp_path):
        pytest.importorskip(
            "openpyxl",
            reason="openpyxl não está instalado; instale as dependências do projeto.",
        )
        bundle = safe_fixture_bundle()
        bundle["employee_details"]["T0000001"]["nomeUsuario"] = "=CMD()"
        bundle["summary"]["cases"][0]["occurrences"][0]["window_start"] = (
            "2026-06-27T12:00:00+00:00"
        )
        model = build_report_model(bundle, "2.2.0")
        return write_xlsx(model, tmp_path / "backtesting_dossier.xlsx"), model

    def test_workbook_reopens_without_repair_and_has_required_sheets(self, workbook_path):
        from openpyxl import load_workbook

        path, _ = workbook_path
        workbook = load_workbook(path)
        for name in (
            "Índice", "Resumo Executivo", "Catálogo de Regras", "Usuários Sinalizados",
            "Dispositivos Sinalizados", "Ocorrências", "Evidências", "Cronologia",
            "Usuários Multirregra", "Consolidações", "Parâmetros", "Metodologia",
            "Qualidade dos Dados", "Dicionário de Dados", "Detalhamento CSV",
        ):
            assert name in workbook.sheetnames, name
        workbook.close()

    def test_index_sheet_is_first_and_links_internally(self, workbook_path):
        from openpyxl import load_workbook

        path, _ = workbook_path
        workbook = load_workbook(path)
        assert workbook.sheetnames[0] == "Índice"
        index = workbook["Índice"]
        links = [
            index.cell(row, 1).hyperlink.location or index.cell(row, 1).hyperlink.target
            for row in range(3, index.max_row + 1)
            if index.cell(row, 1).hyperlink is not None
        ]
        assert links, "o índice precisa oferecer navegação interna"
        workbook.close()

    def test_totals_match_the_model(self, workbook_path):
        from openpyxl import load_workbook

        path, model = workbook_path
        workbook = load_workbook(path)
        summary = workbook["Resumo Executivo"]
        values = {
            summary.cell(row, 1).value: summary.cell(row, 2).value
            for row in range(3, summary.max_row + 1)
        }
        assert values["Ocorrências"] == model["executive"]["total_occurrences"]
        assert values["Usuários sinalizados"] == model["executive"]["flagged_users"]
        assert values["Dispositivos sinalizados"] == model["executive"]["flagged_devices"]
        assert values["Usuários com UOR 20259"] == 1
        assert values["Usuários com outra UOR válida"] == 1
        assert values["Usuários sem UOR determinada"] == 1
        assert values["Consolidações entre regras"] == model["executive"]["cross_rule_consolidations"]
        occurrences = workbook["Ocorrências"]
        assert occurrences.max_row - 2 == model["executive"]["total_occurrences"]
        workbook.close()

    def test_uor_formatting_and_severity_survive_reopen(self, workbook_path):
        from openpyxl import load_workbook

        path, _ = workbook_path
        workbook = load_workbook(path)
        ws = workbook["Usuários Sinalizados"]
        headers = {cell.value: cell.column for cell in ws[2]}
        alert_col = headers["Alerta UOR"]
        name_col = headers["Nome"]
        by_user = {ws.cell(row, 1).value: row for row in range(3, ws.max_row + 1)}
        assert ws.cell(by_user["T0000001"], name_col).value.startswith("'=")
        assert ws.cell(by_user["T0000001"], alert_col).fill.fgColor.rgb.endswith("FFF2CC")
        assert ws.cell(by_user["T0000002"], alert_col).fill.fgColor.rgb.endswith("F4CCCC")
        assert ws.cell(by_user["T0000003"], alert_col).fill.fgColor.rgb.endswith("D9D9D9")
        occurrences = workbook["Ocorrências"]
        occurrence_headers = {cell.value: cell.column for cell in occurrences[2]}
        r4_row = next(
            row for row in range(3, occurrences.max_row + 1)
            if occurrences.cell(row, occurrence_headers["Regra"]).value == "R4"
        )
        # Severidade e Alerta UOR são colunas independentes e não se sobrescrevem.
        assert occurrences.cell(r4_row, occurrence_headers["Severidade"]).fill.fgColor.rgb.endswith("FFF2CC")
        assert occurrences.cell(r4_row, occurrence_headers["Alerta UOR"]).fill.fgColor.rgb.endswith("F4CCCC")
        workbook.close()

    def test_critical_r4_style_is_dark_red_with_readable_text(self, tmp_path):
        load_workbook = pytest.importorskip(
            "openpyxl",
            reason="openpyxl não está instalado; instale as dependências do projeto.",
        ).load_workbook

        bundle = safe_fixture_bundle()
        r4 = next(
            case for case in bundle["summary"]["cases"]
            if case.get("rule_id") == "R4"
        )["occurrences"][0]
        r4["severity"] = "CRÍTICA"
        r4["triggering_value"] = 21
        model = build_report_model(bundle, "2.3.0")
        path = write_xlsx(model, tmp_path / "critical-r4.xlsx")
        workbook = load_workbook(path)
        occurrences = workbook["Ocorrências"]
        headers = {cell.value: cell.column for cell in occurrences[2]}
        row = next(
            current for current in range(3, occurrences.max_row + 1)
            if occurrences.cell(current, headers["Regra"]).value == "R4"
        )
        cell = occurrences.cell(row, headers["Severidade"])
        assert cell.value == "CRÍTICA"
        assert cell.fill.fgColor.rgb.endswith("C00000")
        assert cell.font.color.rgb.endswith("FFFFFF")
        workbook.close()

    def test_timezone_is_applied_to_datetime_cells(self, workbook_path):
        from openpyxl import load_workbook

        path, _ = workbook_path
        workbook = load_workbook(path)
        occurrences = workbook["Ocorrências"]
        headers = {cell.value: cell.column for cell in occurrences[2]}
        first_r1 = next(
            row for row in range(3, occurrences.max_row + 1)
            if occurrences.cell(row, headers["Regra"]).value == "R1"
        )
        # 12:00 UTC equivale a 09:00 em America/Sao_Paulo.
        assert occurrences.cell(first_r1, headers["Início"]).value.hour == 9
        workbook.close()

    def test_brazilian_number_and_date_formats(self, workbook_path):
        from openpyxl import load_workbook

        path, _ = workbook_path
        workbook = load_workbook(path)
        occurrences = workbook["Ocorrências"]
        headers = {cell.value: cell.column for cell in occurrences[2]}
        assert occurrences.cell(3, headers["Início"]).number_format == "dd/mm/yyyy hh:mm:ss"
        assert occurrences.cell(3, headers["Data local"]).number_format == "dd/mm/yyyy"
        workbook.close()

    def test_frozen_panes_filters_and_print_titles(self, workbook_path):
        from openpyxl import load_workbook

        path, _ = workbook_path
        workbook = load_workbook(path)
        for name in ("Ocorrências", "Usuários Sinalizados", "Evidências"):
            ws = workbook[name]
            assert ws.freeze_panes == "B3"
            assert ws.auto_filter.ref is not None
            assert ws.print_title_rows == "$1:$2"
            assert ws.sheet_view.showGridLines is False
        workbook.close()

    def test_rule_sheets_exist_only_for_rules_with_findings(self, workbook_path):
        from openpyxl import load_workbook

        path, model = workbook_path
        workbook = load_workbook(path)
        assert "R1 - Alterações de IP" in workbook.sheetnames
        assert "R4 - Logins VPN" in workbook.sheetnames
        assert "R7 - Dispositivo Compart." in workbook.sheetnames
        assert not any(name.startswith("R2 ") for name in workbook.sheetnames)
        workbook.close()

    def test_csv_index_sheet_lists_relative_paths(self, workbook_path):
        from openpyxl import load_workbook

        path, model = workbook_path
        workbook = load_workbook(path)
        ws = workbook["Detalhamento CSV"]
        headers = {cell.value: cell.column for cell in ws[2]}
        paths = [
            ws.cell(row, headers["Caminho relativo"]).value
            for row in range(3, ws.max_row + 1)
        ]
        assert all(str(item).startswith("detalhamento_csv/") for item in paths)
        workbook.close()

    def test_no_macros_and_metadata_carries_the_notice(self, workbook_path):
        from openpyxl import load_workbook

        path, _ = workbook_path
        assert path.suffix == ".xlsx"
        workbook = load_workbook(path, keep_vba=False)
        assert workbook.properties.subject == NOTICE
        workbook.close()

    def test_sheet_row_limit_is_enforced(self, tmp_path):
        pytest.importorskip("openpyxl")
        import backtest_vpn.dossier as dossier

        bundle = safe_fixture_bundle()
        model = build_report_model(bundle, "2.2.0")
        original = dossier.SHEET_ROW_LIMIT
        dossier.SHEET_ROW_LIMIT = 1
        try:
            with pytest.raises(ValueError, match="limite operacional"):
                dossier.write_xlsx(model, tmp_path / "grande.xlsx")
        finally:
            dossier.SHEET_ROW_LIMIT = original

    def test_xlsx_dependency_failure_is_clear(self, monkeypatch, tmp_path):
        import backtest_vpn.dossier as dossier

        monkeypatch.setattr(dossier, "Workbook", None)
        with pytest.raises(RuntimeError, match="openpyxl"):
            dossier.write_xlsx(
                build_report_model(safe_fixture_bundle(), "2.2.0"),
                tmp_path / "report.xlsx",
            )


class TestCrossFormatConsistency:
    def test_uor_code_label_and_reason_are_identical_across_formats(self, tmp_path):
        from backtest_vpn import csvpackage

        model = build_report_model(safe_fixture_bundle(), "2.2.0")
        latex = render_latex(model)
        csvpackage.write_package(model, tmp_path)
        chronology = (
            tmp_path / csvpackage.PACKAGE_DIRNAME / "cronologia_consolidada.csv"
        ).read_text(encoding="utf-8")
        for entry in model["uor_alert_legend"]:
            assert entry["label"] in latex or latex_escape(entry["label"]) in latex
        assert "ALERTA AMARELO — UOR 20259" in chronology
        assert "ALERTA VERMELHO — UOR diferente de 20259" in chronology

    @pytest.mark.parametrize(
        "value,expected",
        [
            (None, ("tex", "xlsx", "csv")),
            ("csv,tex", ("tex", "csv")),
            (["XLSX"], ("xlsx",)),
        ],
    )
    def test_format_selection_is_normalized(self, value, expected):
        assert normalize_report_formats(value) == expected

    @pytest.mark.parametrize("value", ["pdf", "", []])
    def test_invalid_format_selection_is_rejected(self, value):
        with pytest.raises(ValueError):
            normalize_report_formats(value)

    def test_partial_format_selection_still_writes_the_model(self, tmp_path):
        from backtest_vpn import csvpackage

        model = build_report_model(safe_fixture_bundle(), "2.2.0")
        paths = write_reports(model, tmp_path, formats="tex,csv")
        assert set(paths) == {"model", "tex", "csv_package", "csv_manifest"}
        assert "xlsx" not in paths
        assert csvpackage.verify_package(tmp_path) == []

    def test_all_formats_derive_from_a_single_model(self, tmp_path):
        from backtest_vpn import csvpackage

        model = build_report_model(safe_fixture_bundle(), "2.2.0")
        pytest.importorskip("openpyxl")
        paths = write_reports(model, tmp_path)
        assert set(paths) >= {"tex", "xlsx", "model", "csv_manifest"}
        manifest_report_id = __import__("json").loads(
            Path(paths["csv_manifest"]).read_text(encoding="utf-8")
        )["report_id"]
        assert manifest_report_id == model["report"]["report_id"]
        assert csvpackage.verify_package(tmp_path) == []
