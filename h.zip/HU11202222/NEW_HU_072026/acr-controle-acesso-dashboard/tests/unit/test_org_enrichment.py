"""Unit tests for streamlit_app/org_enrichment.py"""

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from streamlit_mock_helper import install_streamlit_mock  # noqa: E402

install_streamlit_mock()
sys.modules.setdefault("requests", MagicMock())

sys.path.insert(
    0,
    str(Path(__file__).resolve().parents[2] / "acr_controle_acesso_dashboard" / "streamlit_app"),
)

from org_enrichment import (
    ORG_COLUMNS_PT,
    fetch_org_data,
    flatten_org,
    is_matricula,
)


class TestIsMatricula:
    def test_accepts_valid_matricula(self):
        assert is_matricula("F1234567") is True
        assert is_matricula("f1234567") is True
        assert is_matricula(" A0000001 ") is True

    def test_rejects_pseudonymized_key(self):
        assert is_matricula("U-abc123def456") is False

    def test_rejects_empty_and_none(self):
        assert is_matricula("") is False
        assert is_matricula(None) is False

    def test_rejects_wrong_format(self):
        assert is_matricula("F12345") is False
        assert is_matricula("F12345678") is False
        assert is_matricula("12345678") is False


class TestFlattenOrg:
    def test_none_returns_dict_with_all_labels(self):
        result = flatten_org(None)
        assert set(result.keys()) == set(ORG_COLUMNS_PT.values())
        assert all(v is None for v in result.values())

    def test_empty_returns_dict_with_all_labels(self):
        result = flatten_org({})
        assert set(result.keys()) == set(ORG_COLUMNS_PT.values())
        assert all(v is None for v in result.values())

    def test_maps_all_source_keys(self):
        record = {source: f"val-{source}" for source in ORG_COLUMNS_PT.keys()}
        result = flatten_org(record)
        for source, label in ORG_COLUMNS_PT.items():
            assert result[label] == f"val-{source}"

    def test_missing_source_becomes_none(self):
        record = {"codigoPrefixoDependenciaAtual": 9999}
        result = flatten_org(record)
        assert result["Prefixo Dependência"] == 9999
        # outros ficam None
        assert result["Tipo Usuário"] is None


class TestFetchOrgData:
    def test_invalid_key_returns_none_without_network(self):
        with patch("org_enrichment.integracao_curio") as mock_curio:
            assert fetch_org_data("U-abc") is None
            assert fetch_org_data("") is None
            assert fetch_org_data(None) is None  # type: ignore[arg-type]
        mock_curio.assert_not_called()

    def test_valid_key_calls_curio_with_payload(self):
        with patch("org_enrichment.integracao_curio", return_value={"nomeUsuario": "T"}) as mock_curio:
            result = fetch_org_data("F1234567")
        assert result == {"nomeUsuario": "T"}
        mock_curio.assert_called_once()
        args, _ = mock_curio.call_args
        assert args[0] == "op292018v3"
        assert args[1]["codigoClientePesquisa"] == "F1234567"


class TestOrgColumnsPt:
    def test_contains_all_business_relevant_fields(self):
        # Campos citados pelo prompt para as tabelas negociais.
        expected = {
            "codigoPrefixoDependenciaAtual",
            "codigoUnidadeOrganizacionalDependenciaUsuario",
            "codigoInstituicaoOrganizacionalUsuario",
            "codigoTipoUsuario",
            "codigoComissaoUsuario",
            "codigoReferenciaOrganizacionalPerfil",
            "numeroMatriculaUsuario",
        }
        assert expected.issubset(set(ORG_COLUMNS_PT.keys()))


# ── op5360402v1 (ARH): lotação e função ──────────────────────────────────────

from org_enrichment import (  # noqa: E402
    fetch_employee_profile,
    fetch_employee_profiles,
    fetch_lotacao_batch,
    fetch_lotacao_data,
    split_dependencia,
)

_PADDING = {
    "nomeDependenciaLotacao": "",
    "codigoCategoria": "0",
    "nomeFuncionario": "",
    "codigoDependenciaLotacao": "0",
    "codigoMatriculaFuncionarioPesquisa": "0",
    "nomeFuncaoLotacao": "",
    "codigoFuncaoLotacao": "0",
}

_REAL = {
    "nomeDependenciaLotacao": "DITEC - UST 2 DF",
    "codigoCategoria": "1126",
    "nomeFuncionario": "DALTRO PAES LANDIM RIBEIRO JUNIOR",
    "codigoDependenciaLotacao": "9909",
    "codigoMatriculaFuncionarioPesquisa": "2243159",
    "nomeFuncaoLotacao": "GER EQUIPE UE",
    "codigoFuncaoLotacao": "19138",
}


def _resposta(*registros):
    return {
        "listaDadoFuncionario": list(registros),
        "retornoPrograma": {"codigoRetornoPrograma": "0", "textoMensagemErro": ""},
    }


class TestFetchLotacaoData:
    def test_discards_fixed_size_padding_records(self):
        alvo = dict(_REAL, codigoMatriculaFuncionarioPesquisa="2243101")
        resposta = _resposta(alvo, *[dict(_PADDING) for _ in range(99)])
        with patch("org_enrichment.integracao_curio", return_value=resposta):
            assert fetch_lotacao_data("F2243101") == alvo

    def test_selects_the_record_matching_the_requested_registration(self):
        outro = dict(_REAL, codigoMatriculaFuncionarioPesquisa="9999999", nomeFuncionario="OUTRA PESSOA")
        alvo = dict(_REAL, codigoMatriculaFuncionarioPesquisa="2243104")
        with patch("org_enrichment.integracao_curio", return_value=_resposta(outro, alvo)):
            assert fetch_lotacao_data("F2243104") == alvo

    def test_sends_numeric_registration_to_arh(self):
        with patch("org_enrichment.integracao_curio", return_value=_resposta(_REAL)) as mock_curio:
            fetch_lotacao_data("F2243102")
        args, _ = mock_curio.call_args
        assert args[0] == "op5360402v1"
        assert args[1] == {"listaFuncionario": [{"codigoMatriculaFuncionario": "2243102"}]}

    def test_returns_none_when_only_padding(self):
        resposta = _resposta(*[dict(_PADDING) for _ in range(100)])
        with patch("org_enrichment.integracao_curio", return_value=resposta):
            assert fetch_lotacao_data("F2243103") is None

    def test_pseudonymized_key_never_reaches_curio(self):
        with patch("org_enrichment.integracao_curio") as mock_curio:
            assert fetch_lotacao_data("U-9f2c1ab3") is None
        mock_curio.assert_not_called()

    def test_sidecar_failure_returns_none(self):
        with patch("org_enrichment.integracao_curio", side_effect=RuntimeError("fora do ar")):
            assert fetch_lotacao_data("F2243105") is None


class TestBulkEnrichment:
    def test_lotacao_uses_one_request_for_many_employees(self):
        first = dict(_REAL, codigoMatriculaFuncionarioPesquisa="2243101")
        second = dict(
            _REAL,
            codigoMatriculaFuncionarioPesquisa="2243102",
            nomeFuncionario="SEGUNDA PESSOA",
        )
        with patch(
            "org_enrichment.integracao_curio",
            return_value=_resposta(first, second, *[dict(_PADDING) for _ in range(98)]),
        ) as mock_curio:
            result = fetch_lotacao_batch(["F2243101", "F2243102"])
        assert result["F2243101"]["nomeFuncionario"] == first["nomeFuncionario"]
        assert result["F2243102"]["nomeFuncionario"] == "SEGUNDA PESSOA"
        mock_curio.assert_called_once()
        assert len(mock_curio.call_args.args[1]["listaFuncionario"]) == 2

    def test_lotacao_rejects_batches_larger_than_contract(self):
        with pytest.raises(ValueError, match="máximo 100"):
            fetch_lotacao_batch([
                "F{0:07d}".format(index) for index in range(101)
            ])

    def test_profiles_merge_parallel_atc_with_batched_arh(self):
        atc = {
            "F2243101": {"nomeUsuario": "PRIMEIRA", "codigoPrefixoDependenciaAtual": 1},
            "F2243102": {"nomeUsuario": "SEGUNDA", "codigoPrefixoDependenciaAtual": 2},
        }
        lotacao = {
            "F2243101": dict(_REAL, codigoMatriculaFuncionarioPesquisa="2243101"),
            "F2243102": dict(
                _REAL,
                codigoMatriculaFuncionarioPesquisa="2243102",
                nomeDependenciaLotacao="PTT/PLAT. GEST DF",
            ),
        }
        with patch("org_enrichment.fetch_org_data", side_effect=lambda key: atc[key]), \
             patch("org_enrichment.fetch_lotacao_batch", return_value=lotacao) as batch:
            result = fetch_employee_profiles(["F2243101", "F2243102"], max_workers=2)
        batch.assert_called_once_with(["F2243101", "F2243102"])
        assert result["F2243101"]["nomeUsuario"] == "PRIMEIRA"
        assert result["F2243102"]["department"] == "PTT"


class TestSplitDependencia:
    def test_splits_department_and_unit(self):
        assert split_dependencia("DITEC - UST 2 DF") == {
            "department": "DITEC",
            "unit": "UST 2 DF",
            "organizational_hierarchy": "DITEC > UST 2 DF",
        }

    def test_single_segment_has_no_unit(self):
        assert split_dependencia("DITEC") == {
            "department": "DITEC",
            "unit": None,
            "organizational_hierarchy": "DITEC",
        }

    def test_empty_name_yields_no_fields(self):
        assert split_dependencia("") == {
            "department": None,
            "unit": None,
            "organizational_hierarchy": None,
        }


class TestFetchEmployeeProfile:
    def test_merges_both_operations(self):
        with patch("org_enrichment.fetch_org_data", return_value={"nomeUsuario": "T", "codigoPrefixoDependenciaAtual": "4321"}), \
             patch("org_enrichment.fetch_lotacao_data", return_value=_REAL):
            perfil = fetch_employee_profile("F2243159")
        assert perfil["codigoPrefixoDependenciaAtual"] == "4321"
        assert perfil["nomeDependenciaLotacao"] == "DITEC - UST 2 DF"
        assert perfil["nomeFuncaoLotacao"] == "GER EQUIPE UE"
        assert perfil["department"] == "DITEC"
        assert perfil["unit"] == "UST 2 DF"

    def test_padding_values_never_overwrite_real_data(self):
        with patch("org_enrichment.fetch_org_data", return_value={"nomeUsuario": "REAL"}), \
             patch("org_enrichment.fetch_lotacao_data", return_value=dict(_PADDING, nomeFuncionario="")):
            perfil = fetch_employee_profile("F2243159")
        assert perfil["nomeUsuario"] == "REAL"
        assert perfil.get("codigoDependenciaLotacao") is None

    def test_survives_when_one_operation_fails(self):
        with patch("org_enrichment.fetch_org_data", return_value=None), \
             patch("org_enrichment.fetch_lotacao_data", return_value=_REAL):
            perfil = fetch_employee_profile("F2243159")
        assert perfil["nomeFuncaoLotacao"] == "GER EQUIPE UE"

    def test_returns_empty_when_both_fail(self):
        with patch("org_enrichment.fetch_org_data", return_value=None), \
             patch("org_enrichment.fetch_lotacao_data", return_value=None):
            assert fetch_employee_profile("F2243159") == {}

    def test_splits_slash_separated_names(self):
        # Formato observado em produção: "PTT/PLAT. GEST DF".
        assert split_dependencia("PTT/PLAT. GEST DF") == {
            "department": "PTT",
            "unit": "PLAT. GEST DF",
            "organizational_hierarchy": "PTT > PLAT. GEST DF",
        }
