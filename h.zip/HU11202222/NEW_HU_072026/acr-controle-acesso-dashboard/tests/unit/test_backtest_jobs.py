"""Estado durável de jobs: idempotência, reserva atômica, lease e fencing."""

import threading
from datetime import datetime

import pytest

from backtest_vpn.clock import FixedClock
from backtest_vpn.jobstore import (
    STATE_FAILED_RETRYABLE,
    STATE_FAILED_TERMINAL,
    STATE_QUEUED,
    STATE_RUNNING,
    STATE_SUCCEEDED,
    TRIGGER_INITIAL,
    TRIGGER_MANUAL,
    TRIGGER_SCHEDULED,
    InMemoryJobStore,
    JobRecord,
    build_job_store,
    configuration_hash,
    idempotency_key,
)


def make_record(job_id="bt-test", trigger=TRIGGER_INITIAL, **kwargs):
    payload = {
        "job_id": job_id,
        "trigger": trigger,
        "period": {
            "start_date": "2026-06-27",
            "end_date_inclusive": "2026-07-29",
            "start": "2026-06-27 00:00:00",
            "end_exclusive": "2026-07-30 00:00:00",
            "timezone": "America/Sao_Paulo",
            "total_calendar_days": 33,
            "cutoff_mode": "completed_day",
        },
        "rules": ["R1", "R4"],
        "rule_versions": {"R1": "2.1.0", "R4": "2.1.0"},
        "config_hash": "a" * 64,
        "application_version": "2.2.0",
        "max_attempts": 3,
    }
    payload.update(kwargs)
    return JobRecord(**payload)


@pytest.fixture
def clock():
    return FixedClock(datetime(2026, 7, 30, 2, 0, 0))


@pytest.fixture
def store(clock):
    return InMemoryJobStore(clock=clock)


class TestIdempotencyKey:
    def test_same_logical_window_yields_same_key(self):
        args = dict(
            trigger=TRIGGER_SCHEDULED, start_date="2026-06-27",
            end_date_inclusive="2026-07-29", timezone_name="America/Sao_Paulo",
            rules=["R4", "R1"], rule_versions={"R1": "2.1.0", "R4": "2.1.0"},
            config_hash="abc",
        )
        # Ordem das regras não altera a chave.
        other = dict(args, rules=["R1", "R4"])
        assert idempotency_key(**args) == idempotency_key(**other)

    @pytest.mark.parametrize(
        "override",
        [
            {"trigger": TRIGGER_INITIAL},
            {"start_date": "2026-06-28"},
            {"end_date_inclusive": "2026-07-30"},
            {"timezone_name": "UTC"},
            {"rules": ["R1"]},
            {"rule_versions": {"R1": "9.9.9", "R4": "2.1.0"}},
            {"config_hash": "xyz"},
        ],
    )
    def test_changing_any_dimension_changes_the_key(self, override):
        base = dict(
            trigger=TRIGGER_SCHEDULED, start_date="2026-06-27",
            end_date_inclusive="2026-07-29", timezone_name="America/Sao_Paulo",
            rules=["R1", "R4"], rule_versions={"R1": "2.1.0", "R4": "2.1.0"},
            config_hash="abc",
        )
        assert idempotency_key(**base) != idempotency_key(**{**base, **override})

    def test_manual_nonce_allows_intentional_repetition(self):
        base = dict(
            trigger=TRIGGER_MANUAL, start_date="2026-06-27",
            end_date_inclusive="2026-07-29", timezone_name="America/Sao_Paulo",
            rules=["R1"], rule_versions={"R1": "2.1.0"}, config_hash="abc",
        )
        assert idempotency_key(**base, nonce="a") != idempotency_key(**base, nonce="b")

    def test_configuration_hash_is_order_independent(self):
        assert configuration_hash({"a": 1, "b": 2}) == configuration_hash({"b": 2, "a": 1})

    def test_unknown_trigger_is_rejected(self):
        with pytest.raises(ValueError, match="Gatilho desconhecido"):
            idempotency_key(
                trigger="qualquer", start_date="2026-06-27",
                end_date_inclusive="2026-07-29", timezone_name="UTC",
                rules=["R1"], rule_versions={}, config_hash="abc",
            )


class TestEnqueueIdempotency:
    def test_second_enqueue_does_not_create_a_new_job(self, store):
        first = store.enqueue(make_record())
        second = store.enqueue(make_record())
        assert first.job_id == second.job_id
        assert len(store.list_recent(50)) == 1

    def test_concurrent_pods_produce_one_effect(self, store):
        """Vários "pods" simulados chamando enqueue criam um único job."""
        barrier = threading.Barrier(8)
        results = []
        lock = threading.Lock()

        def worker():
            barrier.wait()
            record = store.enqueue(make_record())
            with lock:
                results.append(record.job_id)

        threads = [threading.Thread(target=worker) for _ in range(8)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        assert len(set(results)) == 1
        assert len(store.list_recent(50)) == 1


class TestAtomicClaim:
    def test_only_one_worker_claims(self, store):
        store.enqueue(make_record())
        first = store.claim("bt-test", "pod-a", lease_seconds=600)
        second = store.claim("bt-test", "pod-b", lease_seconds=600)
        assert first is not None and first.owner == "pod-a"
        assert second is None

    def test_concurrent_claims_yield_exactly_one_winner(self, store):
        store.enqueue(make_record())
        barrier = threading.Barrier(6)
        winners = []
        lock = threading.Lock()

        def worker(index):
            barrier.wait()
            claimed = store.claim("bt-test", "pod-{0}".format(index), lease_seconds=600)
            if claimed is not None:
                with lock:
                    winners.append(claimed.owner)

        threads = [threading.Thread(target=worker, args=(i,)) for i in range(6)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        assert len(winners) == 1

    def test_claim_increments_attempt_and_fence(self, store):
        store.enqueue(make_record())
        claimed = store.claim("bt-test", "pod-a", lease_seconds=600)
        assert claimed.attempt == 1
        assert claimed.fence == 1
        assert claimed.state == STATE_RUNNING

    def test_claim_next_picks_oldest_and_filters_trigger(self, store, clock):
        store.enqueue(make_record("bt-old", trigger=TRIGGER_SCHEDULED, created_at="2026-07-01T00:00:00-03:00"))
        store.enqueue(make_record("bt-new", trigger=TRIGGER_MANUAL, created_at="2026-07-20T00:00:00-03:00"))
        claimed = store.claim_next("pod-a", lease_seconds=600, triggers=[TRIGGER_MANUAL])
        assert claimed.job_id == "bt-new"

    def test_claim_next_returns_none_when_queue_is_empty(self, store):
        assert store.claim_next("pod-a", lease_seconds=600) is None


class TestLeaseAndRecovery:
    def test_expired_lease_is_taken_over_by_another_pod(self, store, clock):
        store.enqueue(make_record())
        store.claim("bt-test", "pod-a", lease_seconds=60)
        assert store.claim("bt-test", "pod-b", lease_seconds=60) is None
        clock.advance(61)
        taken = store.claim("bt-test", "pod-b", lease_seconds=60)
        assert taken is not None
        assert taken.owner == "pod-b"
        assert taken.attempt == 2
        assert taken.fence == 2

    def test_heartbeat_extends_lease_and_blocks_takeover(self, store, clock):
        store.enqueue(make_record())
        claimed = store.claim("bt-test", "pod-a", lease_seconds=60)
        clock.advance(50)
        assert store.heartbeat(
            "bt-test", "pod-a", fence=claimed.fence, lease_seconds=60,
            progress={"phase": "AVALIANDO_REGRAS"},
        ) is True
        clock.advance(30)
        assert store.claim("bt-test", "pod-b", lease_seconds=60) is None
        assert store.get("bt-test").progress["phase"] == "AVALIANDO_REGRAS"

    def test_heartbeat_from_stale_fence_is_rejected(self, store, clock):
        store.enqueue(make_record())
        stale = store.claim("bt-test", "pod-a", lease_seconds=60)
        clock.advance(61)
        store.claim("bt-test", "pod-b", lease_seconds=60)
        assert store.heartbeat(
            "bt-test", "pod-a", fence=stale.fence, lease_seconds=60
        ) is False

    def test_attempts_are_bounded_and_reach_terminal_failure(self, store, clock):
        store.enqueue(make_record(max_attempts=2))
        for index in range(2):
            claimed = store.claim("bt-test", "pod-{0}".format(index), lease_seconds=60)
            assert claimed is not None
            store.mark_failed(
                "bt-test", claimed.owner, fence=claimed.fence, error_summary="falha",
            )
        assert store.get("bt-test").state == STATE_FAILED_TERMINAL
        assert store.claim("bt-test", "pod-x", lease_seconds=60) is None

    def test_retry_delay_blocks_immediate_reclaim(self, store, clock):
        store.enqueue(make_record())
        claimed = store.claim("bt-test", "pod-a", lease_seconds=60)
        store.mark_failed(
            "bt-test", "pod-a", fence=claimed.fence, error_summary="falha",
            retry_delay_seconds=300,
        )
        assert store.get("bt-test").state == STATE_FAILED_RETRYABLE
        assert store.claim("bt-test", "pod-b", lease_seconds=60) is None
        clock.advance(301)
        assert store.claim("bt-test", "pod-b", lease_seconds=60) is not None

    def test_release_requeues_without_consuming_terminal_state(self, store):
        store.enqueue(make_record())
        claimed = store.claim("bt-test", "pod-a", lease_seconds=60)
        assert store.release("bt-test", "pod-a", fence=claimed.fence, reason="SIGTERM") is True
        assert store.get("bt-test").state == STATE_QUEUED
        assert store.claim("bt-test", "pod-b", lease_seconds=60) is not None


class TestFencing:
    def test_stale_worker_cannot_publish_over_newer_result(self, store, clock):
        store.enqueue(make_record())
        stale = store.claim("bt-test", "pod-a", lease_seconds=60)
        clock.advance(61)
        fresh = store.claim("bt-test", "pod-b", lease_seconds=600)
        assert store.mark_succeeded(
            "bt-test", "pod-b", fence=fresh.fence,
            result_reference={"report_id": "novo"}, report_status={}, progress={},
        ) is True
        # O worker antigo tenta publicar depois: recusado pelo fencing.
        assert store.mark_succeeded(
            "bt-test", "pod-a", fence=stale.fence,
            result_reference={"report_id": "antigo"}, report_status={}, progress={},
        ) is False
        assert store.get("bt-test").result_reference["report_id"] == "novo"

    def test_failure_does_not_erase_previous_successful_result(self, store, clock):
        store.enqueue(make_record("bt-ok"))
        ok = store.claim("bt-ok", "pod-a", lease_seconds=600)
        store.mark_succeeded(
            "bt-ok", "pod-a", fence=ok.fence,
            result_reference={"report_id": "BT-1"}, report_status={}, progress={},
        )
        clock.advance(3600)
        store.enqueue(make_record("bt-fail"))
        bad = store.claim("bt-fail", "pod-b", lease_seconds=600)
        store.mark_failed("bt-fail", "pod-b", fence=bad.fence, error_summary="DB2 fora")
        last = store.last_successful()
        assert last is not None and last.job_id == "bt-ok"
        assert last.result_reference["report_id"] == "BT-1"


class TestWatermark:
    def test_watermark_round_trip(self, store):
        assert store.read_watermark() == {}
        store.write_watermark({"last_published_end_date": "2026-07-29"})
        assert store.read_watermark()["last_published_end_date"] == "2026-07-29"


class TestStoreSelection:
    def test_memory_store_declares_itself_not_cluster_safe(self, store):
        assert store.cluster_safe is False
        assert "não coordena" in store.backend_name

    def test_missing_uri_without_requirement_falls_back_to_memory(self):
        built = build_job_store(uri="", require_cluster_store=False)
        assert isinstance(built, InMemoryJobStore)

    def test_missing_uri_with_requirement_fails_loudly(self):
        with pytest.raises(RuntimeError, match="BACKTEST_REQUIRE_CLUSTER_STORE"):
            build_job_store(uri="", require_cluster_store=True)


class TestPublicView:
    def test_public_view_has_operational_fields_and_no_config_by_default(self, store):
        store.enqueue(make_record(config_snapshot={"segredo": "não expor"}))
        view = store.get("bt-test").public_view()
        for key in (
            "job_id", "trigger", "trigger_label", "state", "state_label", "period",
            "rules", "rule_versions", "config_hash", "attempt", "max_attempts",
            "progress", "error_summary", "report_status", "data_cutoff",
            "heartbeat_at", "lease_expires_at",
        ):
            assert key in view
        assert "config_snapshot" not in view

    def test_result_reference_is_limited_to_safe_keys(self, store):
        store.enqueue(make_record())
        claimed = store.claim("bt-test", "pod-a", lease_seconds=600)
        store.mark_succeeded(
            "bt-test", "pod-a", fence=claimed.fence,
            result_reference={
                "report_id": "BT-1", "bundle_name": "b.json",
                "directory": "/caminho/absoluto/nao-expor",
            },
            report_status={}, progress={},
        )
        view = store.get("bt-test").public_view()
        assert view["result_reference"] == {"report_id": "BT-1", "bundle_name": "b.json"}
        assert view["state"] == STATE_SUCCEEDED
