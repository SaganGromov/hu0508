"""Unit tests for pages/logins_suspeitos.py — pure detection functions."""

import sys
from datetime import datetime
from pathlib import Path
from unittest.mock import MagicMock, patch
from zoneinfo import ZoneInfo

import pandas as pd

# Mock streamlit before importing the page module
sys.path.insert(0, str(Path(__file__).resolve().parent))
from streamlit_mock_helper import install_streamlit_mock, import_page_module, reimport_page_with_session_state, make_sample_logins_df
_mock_st = install_streamlit_mock()

_PAGES_DIR = str(Path(__file__).resolve().parents[2] / "acr_controle_acesso_dashboard" / "streamlit_app" / "pages")
_STREAMLIT_DIR = str(Path(__file__).resolve().parents[2] / "acr_controle_acesso_dashboard" / "streamlit_app")
sys.path.insert(0, _PAGES_DIR)
sys.path.insert(0, _STREAMLIT_DIR)

with patch("auth_token.resolve_authenticated_user", return_value="F0000001"):
    logins_suspeitos = import_page_module(
        "logins_suspeitos",
        str(Path(_PAGES_DIR) / "logins_suspeitos.py"),
    )

BR_TZ = ZoneInfo("America/Sao_Paulo")


# ── _parse_curio_date ────────────────────────────────────────

class TestParseCurioDate:
    def test_dot_format(self):
        result = logins_suspeitos._parse_curio_date("15.03.2025")
        assert result == datetime(2025, 3, 15)

    def test_iso_format(self):
        result = logins_suspeitos._parse_curio_date("2025-03-15")
        assert result == datetime(2025, 3, 15)

    def test_slash_format(self):
        result = logins_suspeitos._parse_curio_date("15/03/2025")
        assert result == datetime(2025, 3, 15)

    def test_empty_string(self):
        assert logins_suspeitos._parse_curio_date("") is None

    def test_none_value(self):
        assert logins_suspeitos._parse_curio_date(None) is None

    def test_invalid_format(self):
        assert logins_suspeitos._parse_curio_date("not-a-date") is None

    def test_partial_date(self):
        assert logins_suspeitos._parse_curio_date("2025-13-45") is None


# ── fetch_absences ───────────────────────────────────────────

class TestFetchAbsences:
    def test_returns_absences_on_success(self):
        absences = [
            {"dataInicioAusencia": "01.01.2025", "dataFimAusencia": "10.01.2025", "nomeAusencia": "Ferias"},
        ]
        with patch.object(logins_suspeitos, "integracao_curio", return_value={"listaAusencia": absences}):
            result = logins_suspeitos.fetch_absences("F1234567", 2025)
        assert len(result) == 1
        assert result[0]["nomeAusencia"] == "Ferias"

    def test_returns_empty_on_none_response(self):
        with patch.object(logins_suspeitos, "integracao_curio", return_value=None):
            result = logins_suspeitos.fetch_absences("F1234567", 2025)
        assert result == []

    def test_returns_empty_when_no_lista(self):
        with patch.object(logins_suspeitos, "integracao_curio", return_value={"codigoErro": 0}):
            result = logins_suspeitos.fetch_absences("F1234567", 2025)
        assert result == []

    def test_filters_entries_without_start_date(self):
        absences = [
            {"dataInicioAusencia": "01.01.2025", "dataFimAusencia": "10.01.2025"},
            {"dataInicioAusencia": "", "dataFimAusencia": "20.01.2025"},
        ]
        with patch.object(logins_suspeitos, "integracao_curio", return_value={"listaAusencia": absences}):
            result = logins_suspeitos.fetch_absences("F1234567", 2025)
        assert len(result) == 1

    def test_strips_non_numeric_from_matricula(self):
        with patch.object(logins_suspeitos, "integracao_curio", return_value=None) as mock_curio:
            logins_suspeitos.fetch_absences("F1234567", 2025)
        payload = mock_curio.call_args[0][1]
        assert payload["codigoMatriculaFuncionarioPesquisa"] == "1234567"


# ── check_login_during_absence ───────────────────────────────

class TestCheckLoginDuringAbsence:
    def test_login_during_absence(self):
        absences = [{
            "dataInicioAusencia": "01.01.2025",
            "dataFimAusencia": "15.01.2025",
            "nomeAusencia": "Ferias",
        }]
        ts = datetime(2025, 1, 10, 14, 30)
        result = logins_suspeitos.check_login_during_absence(ts, absences)
        assert result is not None
        assert result["nomeAusencia"] == "Ferias"

    def test_login_outside_absence(self):
        absences = [{
            "dataInicioAusencia": "01.01.2025",
            "dataFimAusencia": "15.01.2025",
        }]
        ts = datetime(2025, 2, 1, 14, 30)
        result = logins_suspeitos.check_login_during_absence(ts, absences)
        assert result is None

    def test_login_on_absence_start_date(self):
        absences = [{
            "dataInicioAusencia": "01.01.2025",
            "dataFimAusencia": "15.01.2025",
        }]
        ts = datetime(2025, 1, 1, 8, 0)
        result = logins_suspeitos.check_login_during_absence(ts, absences)
        assert result is not None

    def test_login_on_absence_end_date(self):
        absences = [{
            "dataInicioAusencia": "01.01.2025",
            "dataFimAusencia": "15.01.2025",
        }]
        ts = datetime(2025, 1, 15, 23, 59)
        result = logins_suspeitos.check_login_during_absence(ts, absences)
        assert result is not None

    def test_empty_absences_list(self):
        ts = datetime(2025, 1, 10, 14, 30)
        result = logins_suspeitos.check_login_during_absence(ts, [])
        assert result is None

    def test_absence_with_invalid_dates(self):
        absences = [{
            "dataInicioAusencia": "invalid",
            "dataFimAusencia": "also-invalid",
        }]
        ts = datetime(2025, 1, 10, 14, 30)
        result = logins_suspeitos.check_login_during_absence(ts, absences)
        assert result is None

    def test_multiple_absences_matches_first(self):
        absences = [
            {"dataInicioAusencia": "01.01.2025", "dataFimAusencia": "10.01.2025", "nomeAusencia": "Ferias"},
            {"dataInicioAusencia": "01.01.2025", "dataFimAusencia": "15.01.2025", "nomeAusencia": "Licenca"},
        ]
        ts = datetime(2025, 1, 5, 12, 0)
        result = logins_suspeitos.check_login_during_absence(ts, absences)
        assert result["nomeAusencia"] == "Ferias"


# ── detect_shared_fingerprints ───────────────────────────────

class TestDetectSharedFingerprints:
    def test_detects_shared_fingerprint(self):
        df = pd.DataFrame({
            "fingerprint": ["fp1", "fp1", "fp2"],
            "chave": ["F1111111", "F2222222", "F3333333"],
            "user": ["User1", "User2", "User3"],
            "hostname": ["host1", "host2", "host3"],
            "src_ip": ["10.0.0.1", "10.0.0.2", "10.0.0.3"],
            "timestamp": [
                datetime(2025, 1, 1, 10, 0),
                datetime(2025, 1, 1, 11, 0),
                datetime(2025, 1, 1, 12, 0),
            ],
        })
        result = logins_suspeitos.detect_shared_fingerprints(df)
        assert not result.empty
        assert len(result) == 2  # Two users share fp1
        assert set(result["chave"]) == {"F1111111", "F2222222"}

    def test_no_shared_fingerprints(self):
        df = pd.DataFrame({
            "fingerprint": ["fp1", "fp2", "fp3"],
            "chave": ["F1111111", "F2222222", "F3333333"],
            "user": ["User1", "User2", "User3"],
            "hostname": ["host1", "host2", "host3"],
            "src_ip": ["10.0.0.1", "10.0.0.2", "10.0.0.3"],
            "timestamp": [datetime(2025, 1, 1)] * 3,
        })
        result = logins_suspeitos.detect_shared_fingerprints(df)
        assert result.empty

    def test_ignores_empty_fingerprints(self):
        df = pd.DataFrame({
            "fingerprint": ["", "", ""],
            "chave": ["F1111111", "F2222222", "F3333333"],
            "user": ["User1", "User2", "User3"],
            "hostname": ["host1", "host2", "host3"],
            "src_ip": ["10.0.0.1", "10.0.0.2", "10.0.0.3"],
            "timestamp": [datetime(2025, 1, 1)] * 3,
        })
        result = logins_suspeitos.detect_shared_fingerprints(df)
        assert result.empty

    def test_empty_dataframe(self):
        df = pd.DataFrame(columns=["fingerprint", "chave", "user", "hostname", "src_ip", "timestamp"])
        result = logins_suspeitos.detect_shared_fingerprints(df)
        assert result.empty

    def test_same_user_same_fingerprint_not_flagged(self):
        df = pd.DataFrame({
            "fingerprint": ["fp1", "fp1"],
            "chave": ["F1111111", "F1111111"],
            "user": ["User1", "User1"],
            "hostname": ["host1", "host2"],
            "src_ip": ["10.0.0.1", "10.0.0.2"],
            "timestamp": [datetime(2025, 1, 1), datetime(2025, 1, 2)],
        })
        result = logins_suspeitos.detect_shared_fingerprints(df)
        assert result.empty


# ── detect_shared_macs ──────────────────────────────────────

class TestDetectSharedMacs:
    def test_detects_shared_mac(self):
        df = pd.DataFrame({
            "mac_address": ["AA:BB:CC:DD:EE:FF", "AA:BB:CC:DD:EE:FF", "11:22:33:44:55:66"],
            "chave": ["F1111111", "F2222222", "F3333333"],
            "user": ["User1", "User2", "User3"],
            "hostname": ["host1", "host2", "host3"],
            "timestamp": [datetime(2025, 1, 1)] * 3,
        })
        result = logins_suspeitos.detect_shared_macs(df)
        assert not result.empty
        assert len(result) == 2

    def test_no_shared_macs(self):
        df = pd.DataFrame({
            "mac_address": ["AA:BB:CC:DD:EE:01", "AA:BB:CC:DD:EE:02"],
            "chave": ["F1111111", "F2222222"],
            "user": ["User1", "User2"],
            "hostname": ["host1", "host2"],
            "timestamp": [datetime(2025, 1, 1)] * 2,
        })
        result = logins_suspeitos.detect_shared_macs(df)
        assert result.empty

    def test_ignores_empty_and_zero_macs(self):
        df = pd.DataFrame({
            "mac_address": ["", "00:00:00:00:00:00", ""],
            "chave": ["F1111111", "F2222222", "F3333333"],
            "user": ["User1", "User2", "User3"],
            "hostname": ["host1", "host2", "host3"],
            "timestamp": [datetime(2025, 1, 1)] * 3,
        })
        result = logins_suspeitos.detect_shared_macs(df)
        assert result.empty

    def test_empty_dataframe(self):
        df = pd.DataFrame(columns=["mac_address", "chave", "user", "hostname", "timestamp"])
        result = logins_suspeitos.detect_shared_macs(df)
        assert result.empty


# ── detect_off_hours ─────────────────────────────────────────

class TestDetectOffHours:
    def test_detects_late_night_login(self):
        df = pd.DataFrame({
            "timestamp": [datetime(2025, 1, 6, 23, 30)],  # Monday 23:30
            "chave": ["F1111111"],
            "user": ["User1"],
        })
        result = logins_suspeitos.detect_off_hours(df)
        assert not result.empty
        assert "Horario atipico" in result["motivo"].values[0]

    def test_detects_early_morning_login(self):
        df = pd.DataFrame({
            "timestamp": [datetime(2025, 1, 6, 4, 0)],  # Monday 04:00
            "chave": ["F1111111"],
            "user": ["User1"],
        })
        result = logins_suspeitos.detect_off_hours(df)
        assert not result.empty

    def test_detects_weekend_login(self):
        df = pd.DataFrame({
            "timestamp": [datetime(2025, 1, 4, 14, 0)],  # Saturday 14:00
            "chave": ["F1111111"],
            "user": ["User1"],
        })
        result = logins_suspeitos.detect_off_hours(df)
        assert not result.empty
        assert "semana" in result["motivo"].values[0].lower()

    def test_detects_weekend_late(self):
        df = pd.DataFrame({
            "timestamp": [datetime(2025, 1, 4, 23, 30)],  # Saturday 23:30
            "chave": ["F1111111"],
            "user": ["User1"],
        })
        result = logins_suspeitos.detect_off_hours(df)
        assert not result.empty
        assert "semana" in result["motivo"].values[0].lower()
        assert "horario" in result["motivo"].values[0].lower()

    def test_normal_hours_not_flagged(self):
        df = pd.DataFrame({
            "timestamp": [datetime(2025, 1, 6, 10, 0)],  # Monday 10:00
            "chave": ["F1111111"],
            "user": ["User1"],
        })
        result = logins_suspeitos.detect_off_hours(df)
        assert result.empty

    def test_boundary_hour_6_not_flagged(self):
        df = pd.DataFrame({
            "timestamp": [datetime(2025, 1, 6, 6, 0)],  # Monday 06:00
            "chave": ["F1111111"],
            "user": ["User1"],
        })
        result = logins_suspeitos.detect_off_hours(df)
        assert result.empty

    def test_boundary_hour_22_flagged(self):
        df = pd.DataFrame({
            "timestamp": [datetime(2025, 1, 6, 22, 0)],  # Monday 22:00
            "chave": ["F1111111"],
            "user": ["User1"],
        })
        result = logins_suspeitos.detect_off_hours(df)
        assert not result.empty

    def test_empty_dataframe(self):
        df = pd.DataFrame({"timestamp": pd.Series(dtype="datetime64[ns]"), "chave": [], "user": []})
        result = logins_suspeitos.detect_off_hours(df)
        assert result.empty


# ── detect_rapid_ip_switching ────────────────────────────────

class TestDetectRapidIpSwitching:
    def test_detects_rapid_switching(self):
        df = pd.DataFrame({
            "chave": ["F1111111"] * 4,
            "user": ["User1"] * 4,
            "src_ip": ["10.0.0.1", "10.0.0.2", "10.0.0.3", "10.0.0.4"],
            "hostname": ["host1"] * 4,
            "timestamp": [
                datetime(2025, 1, 1, 10, 0),
                datetime(2025, 1, 1, 10, 15),
                datetime(2025, 1, 1, 10, 30),
                datetime(2025, 1, 1, 10, 45),
            ],
        })
        result = logins_suspeitos.detect_rapid_ip_switching(df, window_hours=2, min_ips=3)
        assert not result.empty
        assert result.iloc[0]["chave"] == "F1111111"

    def test_no_switching_below_threshold(self):
        df = pd.DataFrame({
            "chave": ["F1111111"] * 2,
            "user": ["User1"] * 2,
            "src_ip": ["10.0.0.1", "10.0.0.2"],
            "hostname": ["host1"] * 2,
            "timestamp": [
                datetime(2025, 1, 1, 10, 0),
                datetime(2025, 1, 1, 10, 15),
            ],
        })
        result = logins_suspeitos.detect_rapid_ip_switching(df, window_hours=2, min_ips=3)
        assert result.empty

    def test_switching_outside_window_not_flagged(self):
        df = pd.DataFrame({
            "chave": ["F1111111"] * 3,
            "user": ["User1"] * 3,
            "src_ip": ["10.0.0.1", "10.0.0.2", "10.0.0.3"],
            "hostname": ["host1"] * 3,
            "timestamp": [
                datetime(2025, 1, 1, 10, 0),
                datetime(2025, 1, 1, 14, 0),  # 4 hours later
                datetime(2025, 1, 1, 18, 0),  # 8 hours later
            ],
        })
        result = logins_suspeitos.detect_rapid_ip_switching(df, window_hours=2, min_ips=3)
        assert result.empty

    def test_empty_dataframe(self):
        df = pd.DataFrame(columns=["chave", "user", "src_ip", "hostname", "timestamp"])
        result = logins_suspeitos.detect_rapid_ip_switching(df)
        assert result.empty

    def test_includes_ip_distances(self):
        df = pd.DataFrame({
            "chave": ["F1111111"] * 3,
            "user": ["User1"] * 3,
            "src_ip": ["10.0.0.1", "10.0.0.2", "10.0.0.3"],
            "hostname": ["host1"] * 3,
            "timestamp": [
                datetime(2025, 1, 1, 10, 0),
                datetime(2025, 1, 1, 10, 15),
                datetime(2025, 1, 1, 10, 30),
            ],
        })
        result = logins_suspeitos.detect_rapid_ip_switching(df, window_hours=2, min_ips=3)
        assert not result.empty
        assert "ip_dist_min" in result.columns
        assert "ip_dist_max" in result.columns
        assert result.iloc[0]["ip_dist_min"] is not None

    def test_unspecified_and_invalid_ips_never_contribute(self):
        df = pd.DataFrame({
            "chave": ["F1111111"] * 5,
            "user": ["User1"] * 5,
            "src_ip": ["0.0.0.0", "::", "::0", "not-an-ip", "10.0.0.1"],
            "hostname": ["host1"] * 5,
            "timestamp": [
                datetime(2025, 1, 1, 10, minute) for minute in range(5)
            ],
        })
        result = logins_suspeitos.detect_rapid_ip_switching(
            df, window_hours=2, min_ips=3
        )
        assert result.empty


# ── detect_high_failure_rate ─────────────────────────────────

class TestDetectHighFailureRate:
    def test_detects_high_failure(self):
        df = pd.DataFrame({
            "chave": ["F1111111"] * 10,
            "user": ["User1"] * 10,
            "status": ["Failure"] * 8 + ["Success"] * 2,
        })
        result = logins_suspeitos.detect_high_failure_rate(df, min_attempts=5, min_fail_pct=50.0)
        assert not result.empty
        assert result.iloc[0]["taxa_falha_pct"] == 80.0

    def test_low_failure_not_flagged(self):
        df = pd.DataFrame({
            "chave": ["F1111111"] * 10,
            "user": ["User1"] * 10,
            "status": ["Success"] * 9 + ["Failure"],
        })
        result = logins_suspeitos.detect_high_failure_rate(df, min_attempts=5, min_fail_pct=50.0)
        assert result.empty

    def test_too_few_attempts_not_flagged(self):
        df = pd.DataFrame({
            "chave": ["F1111111"] * 3,
            "user": ["User1"] * 3,
            "status": ["Failure"] * 3,
        })
        result = logins_suspeitos.detect_high_failure_rate(df, min_attempts=5, min_fail_pct=50.0)
        assert result.empty

    def test_empty_dataframe(self):
        df = pd.DataFrame(columns=["chave", "user", "status"])
        result = logins_suspeitos.detect_high_failure_rate(df)
        assert result.empty

    def test_multiple_users(self):
        df = pd.DataFrame({
            "chave": ["F1111111"] * 10 + ["F2222222"] * 10,
            "user": ["User1"] * 10 + ["User2"] * 10,
            "status": ["Failure"] * 8 + ["Success"] * 2 + ["Success"] * 9 + ["Failure"],
        })
        result = logins_suspeitos.detect_high_failure_rate(df, min_attempts=5, min_fail_pct=50.0)
        assert len(result) == 1
        assert result.iloc[0]["chave"] == "F1111111"

    def test_exactly_at_threshold(self):
        df = pd.DataFrame({
            "chave": ["F1111111"] * 10,
            "user": ["User1"] * 10,
            "status": ["Failure"] * 5 + ["Success"] * 5,
        })
        result = logins_suspeitos.detect_high_failure_rate(df, min_attempts=5, min_fail_pct=50.0)
        assert not result.empty


# ── Module constants ─────────────────────────────────────────

class TestModuleConstants:
    def test_restrict_matriculas_flag(self):
        assert isinstance(logins_suspeitos.RESTRICT_MATRICULAS, bool)

    def test_target_matriculas(self):
        if logins_suspeitos.RESTRICT_MATRICULAS:
            assert isinstance(logins_suspeitos.TARGET_MATRICULAS, list)
            assert logins_suspeitos.TARGET_MATRICULAS == logins_suspeitos._DEFAULT_MATRICULAS


class TestRenderingCoverage:
    """Re-import with fully populated suspect_results to cover display/tab code."""

    @staticmethod
    def _build_suspect_results():
        ts = pd.Timestamp("2024-01-15 10:00")
        shared_fp = pd.DataFrame({
            "fingerprint": ["fp1", "fp1"],
            "chave": ["F1234567", "F7654321"],
            "usuario": ["User A", "User B"],
            "hostnames": ["host1", "host2"],
            "ips": ["1.1.1.1", "2.2.2.2"],
            "logins": [3, 2],
            "primeiro_login": [ts, ts],
            "ultimo_login": [ts, ts],
        })
        shared_mac = pd.DataFrame({
            "mac_address": ["AA:BB:CC:DD:EE:01", "AA:BB:CC:DD:EE:01"],
            "chave": ["F1234567", "F7654321"],
            "usuario": ["User A", "User B"],
            "hostnames": ["host1", "host2"],
            "logins": [3, 2],
            "primeiro_login": [ts, ts],
            "ultimo_login": [ts, ts],
        })
        off_hours = pd.DataFrame({
            "hora_local": pd.to_datetime(["2024-01-15 03:00", "2024-01-13 14:00"]),
            "chave": ["F1234567", "F7654321"],
            "user": ["User A", "User B"],
            "motivo": ["Horario atipico", "Fim de semana"],
            "src_ip": ["1.1.1.1", "2.2.2.2"],
            "hostname": ["host1", "host2"],
            "os": ["Windows", "Linux"],
            "tunnel": ["SSL", "IPSec"],
        })
        rapid_ip = pd.DataFrame({
            "chave": ["F1234567"],
            "usuario": ["User A"],
            "timestamp": [ts],
            "ip_atual": ["1.1.1.1"],
            "ips_na_janela": ["1.1.1.1 | 2.2.2.2 | 3.3.3.3"],
            "qtd_ips": [3],
            "hostname": ["host1"],
            "ip_dist_min": [100],
            "ip_dist_max": [50000],
        })
        high_fail = pd.DataFrame({
            "chave": ["F9999999"],
            "usuario": ["User C"],
            "total_tentativas": [10],
            "falhas": [8],
            "taxa_falha_pct": [80.0],
        })
        absence_logins = [
            {
                "chave": "F1234567",
                "usuario": "User A",
                "timestamp_login": datetime(2024, 1, 15, 10, 0),
                "hostname": "host1",
                "src_ip": "1.1.1.1",
                "os": "Windows",
                "ausencia": "Ferias",
                "inicio_ausencia": "10.01.2024",
                "fim_ausencia": "20.01.2024",
                "dias_ausencia": 10,
            }
        ]
        return {
            "consumed_messages": 500,
            "total_logins": 100,
            "shared_fingerprints": shared_fp,
            "shared_macs": shared_mac,
            "off_hours": off_hours,
            "rapid_ip": rapid_ip,
            "high_failure": high_fail,
            "absence_logins": absence_logins,
            "absence_matriculas_checked": 8,
            "suspect_check_abs": True,
        }

    def test_full_page_render_with_findings(self):
        mod = reimport_page_with_session_state(
            "logins_suspeitos",
            str(Path(_PAGES_DIR) / "logins_suspeitos.py"),
            session_state={"suspect_results": self._build_suspect_results()},
        )
        assert hasattr(mod, "detect_shared_fingerprints")

    def test_full_page_render_empty_results(self):
        results = {
            "consumed_messages": 100,
            "total_logins": 50,
            "shared_fingerprints": pd.DataFrame(),
            "shared_macs": pd.DataFrame(),
            "off_hours": pd.DataFrame(),
            "rapid_ip": pd.DataFrame(),
            "high_failure": pd.DataFrame(),
            "absence_logins": [],
        }
        mod = reimport_page_with_session_state(
            "logins_suspeitos",
            str(Path(_PAGES_DIR) / "logins_suspeitos.py"),
            session_state={"suspect_results": results},
        )
        assert hasattr(mod, "_parse_curio_date")
