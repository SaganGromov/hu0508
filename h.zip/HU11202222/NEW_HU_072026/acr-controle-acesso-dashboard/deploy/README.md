# Descritores de implantação do backtesting

Estes arquivos **não** são aplicados por nenhum script deste repositório.
Eles devem ser revisados e aplicados por um operador autorizado, na máquina da
rede interna, depois de substituir os placeholders.

## Arquivos

| Arquivo | Finalidade |
| --- | --- |
| `backtest-scheduler-cronjob.yaml` | `CronJob` suspenso, mantido apenas para eventual reativação explícita do processamento agendado. |
| `values-backtest.patch.yaml` | Trecho de variáveis de ambiente para mesclar no `values.yaml` do chart, com placeholders seguros. |
| `values-dashboard-auth.patch.yaml` | Correção local para origem pública/callback HTTPS, cookie seguro, rota Streamlit e TLS do ingress. |

`values-dashboard-auth.patch.yaml` é um fragmento para merge revisado, não um
manifesto aplicável isoladamente. Substitua as entradas OAuth existentes em
vez de duplicá-las e confirme o nome do Secret TLS no namespace. A aplicação
não aceita derivar a origem pública de cabeçalhos encaminhados pelo cliente.

## Mecanismo de coordenação escolhido

O chart usa `hpa.minReplicas: 2`, portanto **vários pods sobem juntos**. Um
temporizador em memória, um booleano de processo, um lock de arquivo local ou um
`threading.Lock` não coordenam pods distintos e não foram usados como mecanismo
de agendamento.

O mecanismo adotado é o menos invasivo que o projeto sustenta:

1. **Execução manual pela página `Executar`.** A pessoa usuária escolhe a
   janela e inicia o backtest; a aplicação não enfileira trabalho na subida.
   O `CronJob` legado fica suspenso e o ciclo automático desativado.
2. **Estado durável compartilhado em MongoDB** (`telemetria.BACKTEST_VPN_JOBS`),
   reaproveitando a instância já provisionada para auditoria. Fornece:
   - `_id` = chave de idempotência (gatilho + janela + fuso + regras/versões + hash de configuração);
   - reserva atômica via `find_one_and_update`;
   - *lease* com expiração e *heartbeat*;
   - retomada de *lease* expirado por outro pod, com limite de tentativas;
   - token de *fencing* que impede um worker antigo de sobrescrever resultado novo;
   - marca d'água gravada **somente** após publicação validada.

O DB2 **não** foi usado como tabela de jobs porque o acesso concedido é somente
leitura. Isso está registrado como decisão pendente do dono da fonte em
`docs/internal_handoff.md`, caso a instituição prefira uma tabela DB2 dedicada.

## Ordem de aplicação sugerida

```sh
# 1. Confirmar que o Secret com a URI do MongoDB de auditoria existe.
oc get secret acr-dashboard-auth-secrets -o jsonpath='{.data.mongodb_audit_uri}' >/dev/null

# 2. Confirmar as credenciais DB2 somente leitura.
oc get secret db2-credentials -o jsonpath='{.data.DB2_USERNAME}' >/dev/null

# 3. Mesclar deploy/values-backtest.patch.yaml no values.yaml do chart e
#    implantar a aplicação normalmente pelo pipeline vigente.

# 4. Criar o ConfigMap do sidecar Curio consumido pelos pods de backtesting.
#    Sem ele o dossiê sai com nome, matrícula e UOR em branco.
oc create configmap curio-sidecar-config --from-env-file=.env_curio

# 5. Opcional: substituir REGISTRO/…:SUBSTITUA_A_TAG e a URL JDBC no CronJob.
#    Ele é criado suspenso e não executa backtests até uma reativação explícita:
oc apply -f deploy/backtest-scheduler-cronjob.yaml

# 6. Confirmar que o ciclo automático está desativado:
oc exec deploy/acr-controle-acesso-dashboard -- /app/scripts/backtest-vpn schedule-status
```

## Enriquecimento organizacional (Curio)

O dossiê preenche nome, matrícula, UOR, prefixo, comissão, tipo de usuário,
local de trabalho, cargo, departamento, unidade e hierarquia consultando duas
operações do Curio, uma vez por matrícula: `op292018v3` (ATC, códigos
organizacionais) e `op5360402v1` (ARH, `nomeDependenciaLotacao` e
`nomeFuncaoLotacao`). Para isso:

- os pods de backtesting sobem `curio-sidecar` como **sidecar nativo**
  (`initContainers` com `restartPolicy: Always`), que termina junto com o
  container principal — um container comum deixaria o Job preso em `Running`.
  Requer Kubernetes 1.29+ / OpenShift 4.16+;
- o ConfigMap `curio-sidecar-config` segue o contrato de
  [`.env_curio.example`](../.env_curio.example) e **precisa** manter as duas
  operações em `CURIO_OP_CONSUMIDOR`;
- chaves pseudonimizadas (`U-<hash>`) nunca são enviadas ao Curio;
- se o sidecar estiver indisponível o relatório continua sendo gerado, apenas
  com os campos organizacionais em branco. Para desligar a consulta de
  propósito, defina `CURIO_ENABLED=false`.

Campos sem fonte em nenhuma das duas operações — nome da UOR, UOR pai, centro
de custo e status da conta — foram removidos dos relatórios em vez de exibidos
como "Não informado". No dossiê, qualquer campo sem valor é omitido da tabela
do perfil: o relatório mostra apenas o que o Curio efetivamente devolveu, sem
fabricar dado organizacional.

## Reversão

```sh
# Desliga o ciclo automático sem remover nada do histórico publicado.
oc patch cronjob acr-controle-acesso-dashboard-backtest-diario \
  -p '{"spec":{"suspend":true}}'

# Ou, pela aplicação, sem alterar o CronJob:
#   BACKTEST_SCHEDULE_ENABLED=false
```

Remover o `CronJob` não apaga resultados: as publicações ficam em
`<reports>/published/<job_id>/` e o ponteiro `published/latest.json` continua
apontando para o último resultado válido. A retenção automática está desativada
por padrão (`BACKTEST_REPORTS_RETENTION_KEEP=0`).
