import logging
import os
import base64
import hashlib
import hmac
import re
import secrets
import sys
import urllib.parse
from datetime import datetime
from zoneinfo import ZoneInfo

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse, PlainTextResponse
from fastapi.templating import Jinja2Templates
from pathlib import Path as _Path
from starlette.middleware.sessions import SessionMiddleware

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "acr_controle_acesso_dashboard", "streamlit_app"))
from auth_token import STREAMLIT_AUTH_COOKIE_NAME, CSRF_QUERY_PARAM, TOKEN_TTL, generate_token, generate_csrf_nonce
from audit_service import record_login, record_search

load_dotenv()

APP_TZ = ZoneInfo("America/Sao_Paulo")

# ── Logging configuration ────────────────────────────────────
# Suppress noisy health-check lines from uvicorn access logs and
# format all timestamps in Brasilia time.

_HEALTH_PATHS = {"/healthz", "/health", "/health/live", "/health/ready"}


class _HealthCheckFilter(logging.Filter):
    """Drop INFO-level access log lines for health-check endpoints."""

    def filter(self, record: logging.LogRecord) -> bool:
        msg = record.getMessage()
        if record.levelno <= logging.INFO:
            for path in _HEALTH_PATHS:
                if f'"{path} ' in msg or f'"{path} HTTP' in msg or f"GET {path} " in msg:
                    return False
        return True


class _BrasiliaFormatter(logging.Formatter):
    """Formatter that uses America/Sao_Paulo timezone."""

    def formatTime(self, record: logging.LogRecord, datefmt: str | None = None) -> str:
        dt = datetime.fromtimestamp(record.created, tz=APP_TZ)
        if datefmt:
            return dt.strftime(datefmt)
        return dt.isoformat(timespec="seconds")


def _configure_logging() -> None:
    brasilia_fmt = _BrasiliaFormatter(
        fmt="%(asctime)s | %(levelname)s | %(message)s",
    )
    health_filter = _HealthCheckFilter()

    for name in ("uvicorn.access", "uvicorn.error", "uvicorn"):
        lg = logging.getLogger(name)
        lg.addFilter(health_filter)
        for handler in lg.handlers:
            handler.setFormatter(brasilia_fmt)


_configure_logging()

logger = logging.getLogger("uvicorn.error")
logger.setLevel(logging.INFO)

_ACCESS_TOKENS: dict[str, str] = {}
# ``0.0.0.0`` aqui é apenas reconhecido como marcador local em configuração;
# este conjunto não abre socket nem decide autorização.
_LOCAL_HOSTS = {"localhost", "127.0.0.1", "::1", "0.0.0.0"}  # nosec B104
_DEFAULT_LOCAL_REDIRECT_URI = "http://localhost:8000/auth/callback"
_DEFAULT_STREAMLIT_PROXY_PATH = "/streamlit"
_DEFAULT_LOCAL_STREAMLIT_PORT = "8501"
_RE_SPLIT_SEPARATORS = r"[,;\s]+"
_TEMPLATE_ERROR = "error.html"
_BACKTEST_FORM_CSRF_SESSION_KEY = "backtest_form_csrf"
_BACKTEST_FORM_CSRF_RE = re.compile(r"^[A-Za-z0-9_-]{32,128}$")
_REQUEST_ID_RE = re.compile(r"^[A-Za-z0-9._-]{8,128}$")
_session_cookie_secure = os.environ.get(
    "SESSION_COOKIE_SECURE", "true"
).strip().lower() not in {"false", "0", "no", "off"}


class AppConfigurationError(RuntimeError):
    """Configuration failure with a safe operational classification."""

    def __init__(self, code: str, setting: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.setting = setting


def _log_timestamp() -> str:
    return datetime.now(APP_TZ).isoformat(timespec="seconds")


def _strip_trailing_slash(value: str) -> str:
    return value[:-1] if value.endswith("/") else value


def _forwarded_header(request: Request, header_name: str) -> str:
    raw_value = request.headers.get(header_name, "")
    if not raw_value:
        return ""
    return raw_value.split(",", 1)[0].strip()


def _normalize_base_path(raw_value: str) -> str:
    cleaned = raw_value.strip().strip("/")
    return f"/{cleaned}" if cleaned else ""


def _validated_external_url(value: str, label: str) -> str:
    """Valida uma URL configurada sem aceitar credencial ou fragmento."""
    parsed = urllib.parse.urlsplit(value.strip())
    if (
        parsed.scheme not in {"http", "https"}
        or not parsed.hostname
        or parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
    ):
        raise AppConfigurationError(
            "EXTERNAL_URL_INVALID",
            label,
            "{0} deve ser uma URL HTTP(S) absoluta, sem credencial, query ou "
            "fragmento.".format(label),
        )
    if parsed.scheme != "https" and parsed.hostname not in _LOCAL_HOSTS:
        raise AppConfigurationError(
            "EXTERNAL_URL_INSECURE",
            label,
            "{0} deve usar HTTPS fora do ambiente local.".format(label),
        )
    return _strip_trailing_slash(value.strip())


def _request_origin(request: Request) -> str:
    configured_public_base = os.environ.get("PUBLIC_BASE_URL", "").strip()
    if configured_public_base:
        return _validated_external_url(configured_public_base, "PUBLIC_BASE_URL")
    if _request_host(request) in _LOCAL_HOSTS:
        return "{0}://{1}".format(
            request.url.scheme,
            request.headers.get("host", request.url.netloc),
        )
    raise AppConfigurationError(
        "PUBLIC_BASE_URL_MISSING",
        "PUBLIC_BASE_URL",
        "PUBLIC_BASE_URL deve ser configurada fora do ambiente local; cabeçalhos "
        "Host/X-Forwarded-* não são usados como origem confiável.",
    )


def _request_host(request: Request) -> str:
    host = request.headers.get("host", request.url.netloc)
    if host.startswith("[") and "]" in host:
        return host[1:host.index("]")].lower()
    return host.split(":", 1)[0].lower()


def _resolve_redirect_uri(request: Request) -> str:
    configured_redirect_uri = os.environ.get("OAUTH2_REDIRECT_URI", "").strip()
    if configured_redirect_uri:
        return _validated_external_url(
            configured_redirect_uri, "OAUTH2_REDIRECT_URI"
        )
    if _request_host(request) in _LOCAL_HOSTS:
        return _DEFAULT_LOCAL_REDIRECT_URI
    return f"{_request_origin(request)}/auth/callback"


def _resolve_streamlit_base_url(request: Request) -> str:
    base_path = _streamlit_base_path()
    if _request_host(request) in _LOCAL_HOSTS:
        scheme = request.url.scheme
        host = request.url.hostname or _request_host(request)
        host_display = f"[{host}]" if ":" in host and not host.startswith("[") else host
        port = os.environ.get("STREAMLIT_LOCAL_PORT", _DEFAULT_LOCAL_STREAMLIT_PORT).strip() or _DEFAULT_LOCAL_STREAMLIT_PORT
        return _strip_trailing_slash(f"{scheme}://{host_display}:{port}{base_path}")
    # The Streamlit ingress is deliberately same-origin. A relative URL is
    # sufficient and safer than reconstructing an external origin from
    # client-controlled Host/X-Forwarded-* headers. It also prevents an old or
    # malformed absolute public URL from breaking this unrelated boundary.
    # PUBLIC_BASE_URL remains relevant for OAuth callback generation when no
    # explicit redirect URI is configured.
    return base_path


def _streamlit_base_path() -> str:
    return _normalize_base_path(os.environ.get("STREAMLIT_BASE_URL_PATH", _DEFAULT_STREAMLIT_PROXY_PATH)) or "/"


def _streamlit_cookie_secure(request: Request) -> bool:
    # Keep both authentication cookies on the same explicit policy. Inferring
    # this flag from request/proxy headers would let an untrusted client weaken
    # or alter the browser policy.
    del request
    return _session_cookie_secure


def _new_streamlit_auth(user_id: str) -> tuple[str, str]:
    """Return one token and the CSRF nonce derived from that exact token."""
    token = generate_token(user_id)
    return token, generate_csrf_nonce(token)


def _write_streamlit_auth_cookie(response, request: Request, token: str) -> None:
    response.set_cookie(
        key=STREAMLIT_AUTH_COOKIE_NAME,
        value=token,
        max_age=TOKEN_TTL,
        httponly=True,
        secure=_streamlit_cookie_secure(request),
        samesite="lax",
        path=_streamlit_base_path(),
    )


def _set_streamlit_auth_cookie(response, request: Request, user_id: str) -> str:
    token, csrf_nonce = _new_streamlit_auth(user_id)
    _write_streamlit_auth_cookie(response, request, token)
    return csrf_nonce


def _backtest_form_csrf_token(request: Request) -> str:
    """Return a per-session token used by state-changing backtest forms."""
    current = request.session.get(_BACKTEST_FORM_CSRF_SESSION_KEY, "")
    if isinstance(current, str) and _BACKTEST_FORM_CSRF_RE.fullmatch(current):
        return current
    token = secrets.token_urlsafe(32)
    request.session[_BACKTEST_FORM_CSRF_SESSION_KEY] = token
    return token


def _valid_backtest_form_csrf(request: Request, supplied: str) -> bool:
    """Validate a form token without exposing it through logs or responses."""
    expected = request.session.get(_BACKTEST_FORM_CSRF_SESSION_KEY, "")
    return (
        isinstance(expected, str)
        and isinstance(supplied, str)
        and _BACKTEST_FORM_CSRF_RE.fullmatch(expected) is not None
        and _BACKTEST_FORM_CSRF_RE.fullmatch(supplied) is not None
        and hmac.compare_digest(expected, supplied)
    )


def _clear_streamlit_auth_cookie(response) -> None:
    response.delete_cookie(key=STREAMLIT_AUTH_COOKIE_NAME, path=_streamlit_base_path())


def _parse_allowed_matriculas(raw_value: str) -> set[str]:
    entries = [item.strip().upper() for item in re.split(_RE_SPLIT_SEPARATORS, raw_value) if item.strip()]
    return {item for item in entries if re.fullmatch(r"F\d{7}", item)}


def _load_secret_file(secret_file_path: str) -> str:
    try:
        with open(secret_file_path, "r", encoding="utf-8") as secret_file:
            return secret_file.read().strip()
    except OSError:
        logger.warning("Falha ao ler arquivo de segredo configurado.")
        return ""


def _load_matricula_hmac_key() -> bytes:
    key_from_env = os.environ.get("MATRICULA_HMAC_KEY", "").strip()
    if key_from_env:
        return key_from_env.encode("utf-8")

    key_file_path = os.environ.get("MATRICULA_HMAC_KEY_FILE", "/run/secrets/matricula_hmac_key")
    key_material = _load_secret_file(key_file_path)
    if not key_material:
        logger.warning("Chave HMAC de matrícula ausente; todos os logins serão negados.")
        return b""
    return key_material.encode("utf-8")


def _load_allowed_matricula_digests() -> set[str]:
    raw_digests_env = os.environ.get("ALLOWED_MATRICULA_DIGESTS", "").strip()
    if raw_digests_env:
        entries = [item.strip().lower() for item in re.split(_RE_SPLIT_SEPARATORS, raw_digests_env) if item.strip()]
        valid_digests = {item for item in entries if re.fullmatch(r"[a-f0-9]{64}", item)}
        if not valid_digests:
            logger.warning("Nenhum hash de matrícula válido foi configurado em ALLOWED_MATRICULA_DIGESTS; todos os logins serão negados.")
        return valid_digests

    digests_file_path = os.environ.get("ALLOWED_MATRICULA_DIGESTS_FILE", "/run/secrets/allowed_matricula_digests")
    raw_digests = _load_secret_file(digests_file_path)
    if not raw_digests:
        logger.warning("Lista de hashes de matrícula ausente; todos os logins serão negados.")
        return set()

    entries = [item.strip().lower() for item in re.split(_RE_SPLIT_SEPARATORS, raw_digests) if item.strip()]
    valid_digests = {item for item in entries if re.fullmatch(r"[a-f0-9]{64}", item)}

    if not valid_digests:
        logger.warning("Nenhum hash de matrícula válido foi configurado; todos os logins serão negados.")

    return valid_digests


def _is_matricula_authorized(matricula: str) -> bool:
    if not MATRICULA_HMAC_KEY or not ALLOWED_MATRICULA_DIGESTS:
        return False

    digest = hmac.new(MATRICULA_HMAC_KEY, matricula.encode("utf-8"), hashlib.sha256).hexdigest()
    return any(hmac.compare_digest(digest, allowed_digest) for allowed_digest in ALLOWED_MATRICULA_DIGESTS)


def _log_subject(matricula: str) -> str:
    """Return a stable pseudonymous subject suitable for operational logs."""
    normalized = str(matricula or "").strip().upper()
    if not normalized or not MATRICULA_HMAC_KEY:
        return "indisponível"
    return hmac.new(
        MATRICULA_HMAC_KEY,
        normalized.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()[:12]


def _extract_matricula(userinfo: dict) -> str:
    fields = ("chave_usuario", "uid", "subname", "email_usuario", "email", "name")

    for field in fields:
        raw_value = str(userinfo.get(field, "")).strip()
        if not raw_value:
            continue

        normalized = raw_value.split("@", 1)[0].upper()
        if re.fullmatch(r"F\d{7}", normalized):
            return normalized

        match = re.search(r"\bF\d{7}\b", raw_value.upper())
        if match:
            return match.group(0)

    return ""


def _build_session_user(userinfo: dict, matricula: str) -> dict:
    """Keep the cookie-backed session small and stable after OAuth login."""
    sub = str(userinfo.get("sub", "")).strip() or matricula
    name = str(userinfo.get("name", "")).strip() or matricula
    return {
        "sub": sub,
        "name": name,
        "email": str(userinfo.get("email", "")).strip(),
        "matricula": matricula,
    }


def _store_access_token(access_token: str) -> str:
    token_key = secrets.token_urlsafe(16)
    _ACCESS_TOKENS[token_key] = access_token
    return token_key


def _pop_access_token(token_key: str) -> str:
    if not token_key:
        return ""
    return _ACCESS_TOKENS.pop(token_key, "")

CLIENT_ID = os.environ.get("OAUTH2_CLIENT_ID", "")
CLIENT_SECRET = os.environ.get("OAUTH2_CLIENT_SECRET", "")
SCOPE = os.environ.get("OAUTH2_SCOPE", "openid profile email bbprofile bbrole")
SESSION_SECRET = os.environ.get("SESSION_SECRET", secrets.token_urlsafe(32))
OAUTH2_AMBIENTE = os.environ.get("OAUTH2_AMBIENTE", "intranet").strip() or "intranet"
_DEFAULT_OAUTH2_ISSUER_BASE_URL = f"https://login.{OAUTH2_AMBIENTE}.bb.com.br"

_OAUTH_PATHS = {
    "authorize": "/sso/oauth2/authorize",
    # Caminho público do endpoint OAuth; não é senha nem contém credencial.
    "token": "/sso/oauth2/access_token",  # nosec B105
    "userinfo": "/sso/oauth2/userinfo",
    "end_session": "/sso/oauth2/connect/endSession",
}


def _oauth_endpoint(name: str) -> str:
    """Monta endpoint apenas a partir do emissor HTTPS configurado."""
    try:
        path = _OAUTH_PATHS[name]
    except KeyError as exc:
        raise RuntimeError("Endpoint OAuth desconhecido.") from exc
    raw_base = (
        os.environ.get("OAUTH2_ISSUER_BASE_URL", "").strip()
        or _DEFAULT_OAUTH2_ISSUER_BASE_URL
    )
    return _validated_external_url(
        raw_base, "OAUTH2_ISSUER_BASE_URL"
    ) + path

MATRICULA_HMAC_KEY = _load_matricula_hmac_key()
ALLOWED_MATRICULA_DIGESTS = _load_allowed_matricula_digests()

_ssl_verify_env = os.environ.get("SSL_CA_BUNDLE", "").strip()
if _ssl_verify_env.lower() in {"false", "0", "no", "off"}:
    raise RuntimeError(
        "SSL_CA_BUNDLE não pode desativar a validação TLS. Informe o caminho "
        "de uma CA confiável ou deixe vazio para usar o trust store do sistema."
    )
SSL_VERIFY = _ssl_verify_env or True

app = FastAPI(title="Controle de acesso - Dashboard")
app.add_middleware(
    SessionMiddleware,
    secret_key=SESSION_SECRET,
    https_only=_session_cookie_secure,
    same_site="lax",
)
templates = Jinja2Templates(directory="acr_controle_acesso_dashboard/templates")


def _request_correlation_id(request: Request) -> str:
    existing = getattr(request.state, "correlation_id", "")
    if isinstance(existing, str) and _REQUEST_ID_RE.fullmatch(existing):
        return existing
    supplied = request.headers.get("x-request-id", "").strip()
    request_id = (
        supplied
        if _REQUEST_ID_RE.fullmatch(supplied)
        else secrets.token_hex(16)
    )
    request.state.correlation_id = request_id
    return request_id


def _safe_runtime_label(value: str, fallback: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]", "_", str(value or ""))[:128]
    return cleaned or fallback


def _log_configuration_failure(
    request: Request,
    *,
    phase: str,
    exc: AppConfigurationError,
    authenticated: bool,
) -> str:
    request_id = _request_correlation_id(request)
    logger.error(
        "auth_configuration_error correlation_id=%s pod=%s pid=%s "
        "method=%s path=%s authenticated=%s phase=%s code=%s setting=%s",
        request_id,
        _safe_runtime_label(os.environ.get("HOSTNAME", ""), "unknown"),
        os.getpid(),
        request.method,
        request.url.path,
        str(authenticated).lower(),
        phase,
        exc.code,
        exc.setting,
    )
    return request_id


def _configuration_error_response(
    request: Request,
    *,
    message: str,
    status_code: int,
    error_code: str,
    request_id: str,
):
    response = templates.TemplateResponse(
        request,
        _TEMPLATE_ERROR,
        context={
            "message": message,
            "error_code": error_code,
            "request_id": request_id,
            "action_url": "/logout",
            "action_label": "Encerrar sessão",
        },
        status_code=status_code,
    )
    response.headers["Cache-Control"] = "no-store"
    response.headers["X-Application-Error-Code"] = error_code
    response.headers["X-Request-ID"] = request_id
    return response


@app.middleware("http")
async def _correlation_id_middleware(request: Request, call_next):
    request_id = _request_correlation_id(request)
    response = await call_next(request)
    response.headers["X-Request-ID"] = request_id
    return response


try:
    from acr_controle_acesso_dashboard import __version__ as _APP_VERSION
except Exception:  # pragma: no cover
    _APP_VERSION = "dev"
templates.env.globals["release_tag"] = _APP_VERSION


@app.on_event("startup")
async def _on_startup():
    """Re-apply log filters. Nenhum backtest é enfileirado na subida.

    O backtest é sempre solicitado explicitamente pela pessoa usuária em
    "Executar", com a janela que ela escolher. Enfileirar um job na subida
    criava um pedido que ficava eternamente "na fila": o pod web não executa
    backtests (só o worker/CronJob fala com o DB2), então a mensagem de espera
    nunca correspondia a trabalho real em andamento.
    """
    _configure_logging()
    if not os.environ.get("SESSION_SECRET", "").strip():
        logger.error("SESSION_SECRET não configurado; o dashboard embutido permanecerá bloqueado por segurança.")


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    """Home page — redirect to dashboard if authenticated, else show login."""
    user = request.session.get("user")
    if user:
        return RedirectResponse(url="/dashboard")
    return templates.TemplateResponse(request, "login.html")


@app.get("/login")
async def login(request: Request):
    """Initiate OAuth2 authorization code flow."""
    state = secrets.token_urlsafe(32)
    request.session["oauth_state"] = state
    try:
        redirect_uri = _resolve_redirect_uri(request)
        authorize_url = _oauth_endpoint("authorize")
    except AppConfigurationError as exc:
        request.session.pop("oauth_state", None)
        request_id = _log_configuration_failure(
            request,
            phase="login_redirect",
            exc=exc,
            authenticated=False,
        )
        return _configuration_error_response(
            request,
            message="Provedor de autenticação não configurado.",
            status_code=503,
            error_code="AUTH_CONFIGURATION_INVALID",
            request_id=request_id,
        )
    params = urllib.parse.urlencode({
        "scope": SCOPE,
        "response_type": "code",
        "redirect_uri": redirect_uri,
        "client_id": CLIENT_ID,
        "state": state,
    })
    return RedirectResponse(url=f"{authorize_url}?{params}")


@app.get("/auth/callback")
async def auth_callback(request: Request, code: str = "", state: str = ""):
    """OAuth2 callback — exchange code for token, fetch user info."""
    expected_state = request.session.pop("oauth_state", None)
    if (
        not expected_state
        or not state
        or not secrets.compare_digest(str(state), str(expected_state))
    ):
        return templates.TemplateResponse(
            request, _TEMPLATE_ERROR,
            context={"message": "Estado OAuth inválido. Possível ataque CSRF."},
            status_code=403,
        )

    if not code:
        return templates.TemplateResponse(
            request, _TEMPLATE_ERROR,
            context={"message": "Código de autorização não recebido."},
            status_code=400,
        )

    try:
        redirect_uri = _resolve_redirect_uri(request)
        token_url = _oauth_endpoint("token")
        userinfo_url = _oauth_endpoint("userinfo")
    except AppConfigurationError as exc:
        request_id = _log_configuration_failure(
            request,
            phase="oauth_callback",
            exc=exc,
            authenticated=False,
        )
        return _configuration_error_response(
            request,
            message="Provedor de autenticação não configurado.",
            status_code=503,
            error_code="AUTH_CONFIGURATION_INVALID",
            request_id=request_id,
        )

    credentials = f"{CLIENT_ID}:{CLIENT_SECRET}"
    basic_auth = base64.b64encode(credentials.encode()).decode()

    async with httpx.AsyncClient(timeout=15, verify=SSL_VERIFY) as client:
        token_resp = await client.post(
            token_url,
            data={
                "code": code,
                "grant_type": "authorization_code",
                "redirect_uri": redirect_uri,
            },
            headers={
                "Authorization": f"Basic {basic_auth}",
                "Content-Type": "application/x-www-form-urlencoded",
            },
        )

    if token_resp.status_code != 200:
        return templates.TemplateResponse(
            request, _TEMPLATE_ERROR,
            context={"message": f"Falha ao obter token (HTTP {token_resp.status_code})."},
            status_code=502,
        )

    token_data = token_resp.json()
    access_token = token_data.get("access_token")
    if not access_token:
        return templates.TemplateResponse(
            request, _TEMPLATE_ERROR,
            context={"message": "Token de acesso ausente na resposta."},
            status_code=502,
        )

    async with httpx.AsyncClient(timeout=10, verify=SSL_VERIFY) as client:
        userinfo_resp = await client.get(
            userinfo_url,
            headers={"Authorization": f"Bearer {access_token}"},
        )

    if userinfo_resp.status_code != 200:
        return templates.TemplateResponse(
            request, _TEMPLATE_ERROR,
            context={"message": "Falha ao obter informações do usuário."},
            status_code=502,
        )

    userinfo = userinfo_resp.json()
    matricula = _extract_matricula(userinfo)
    if not matricula:
        logger.warning("Login negado: matrícula não encontrada no retorno do OAuth.")
        request.session.clear()
        return templates.TemplateResponse(
            request, _TEMPLATE_ERROR,
            context={"message": "Acesso negado. Matrícula não identificada."},
            status_code=403,
        )

    if not _is_matricula_authorized(matricula):
        logger.warning(
            "Login negado para sujeito %s: não autorizado.",
            _log_subject(matricula),
        )
        request.session.clear()
        return templates.TemplateResponse(
            request, _TEMPLATE_ERROR,
            context={"message": "Acesso negado. Usuário não autorizado para este dashboard."},
            status_code=403,
        )

    client_ip = request.headers.get("x-forwarded-for", request.client.host if request.client else "")
    logger.info(
        "Login autorizado | ts=%s | sujeito=%s",
        _log_timestamp(),
        _log_subject(matricula),
    )
    record_login(matricula, userinfo, ip=client_ip)

    previous_token_key = request.session.get("access_token_key", "")
    _pop_access_token(previous_token_key)

    request.session["user"] = _build_session_user(userinfo, matricula)
    request.session["matricula"] = matricula
    request.session["access_token_key"] = _store_access_token(access_token)
    request.session.pop("oauth_state", None)
    response = RedirectResponse(url="/dashboard")
    try:
        csrf_nonce = _set_streamlit_auth_cookie(response, request, request.session["user"]["sub"])
        request.session["csrf_nonce"] = csrf_nonce
    except RuntimeError as exc:
        logger.error(
            "Falha ao preparar cookie autenticado do Streamlit (%s).",
            type(exc).__name__,
        )
        return templates.TemplateResponse(
            request,
            _TEMPLATE_ERROR,
            context={"message": "Não foi possível preparar a sessão do painel."},
            status_code=500,
        )
    return response


@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request):
    """Protected dashboard page — embeds Streamlit via iframe."""
    user = request.session.get("user")
    if not user:
        return RedirectResponse(url="/")
    user_id = user.get("sub", user.get("name", "unknown"))
    if not request.session.get("dashboard_access_logged"):
        logger.info(
            "Dashboard acessado | ts=%s | sujeito=%s",
            _log_timestamp(),
            _log_subject(request.session.get("matricula", "")),
        )
        request.session["dashboard_access_logged"] = True
    try:
        streamlit_base_url = _resolve_streamlit_base_url(request)
    except AppConfigurationError as exc:
        request_id = _log_configuration_failure(
            request,
            phase="dashboard_public_url",
            exc=exc,
            authenticated=True,
        )
        return _configuration_error_response(
            request,
            message="Não foi possível preparar o acesso ao painel.",
            status_code=500,
            error_code="DASHBOARD_PUBLIC_URL_INVALID",
            request_id=request_id,
        )
    try:
        streamlit_token, csrf_nonce = _new_streamlit_auth(user_id)
    except RuntimeError as exc:
        request_id = _request_correlation_id(request)
        logger.error(
            "dashboard_session_error correlation_id=%s pod=%s pid=%s "
            "method=%s path=%s authenticated=true phase=streamlit_token "
            "exception=%s",
            request_id,
            _safe_runtime_label(os.environ.get("HOSTNAME", ""), "unknown"),
            os.getpid(),
            request.method,
            request.url.path,
            type(exc).__name__,
        )
        return _configuration_error_response(
            request,
            message="Não foi possível renovar a sessão do painel.",
            status_code=500,
            error_code="DASHBOARD_SESSION_INVALID",
            request_id=request_id,
        )
    response = templates.TemplateResponse(
        request, "dashboard.html",
        context={
            "user": user,
            "streamlit_url": streamlit_base_url,
            "streamlit_base_url": streamlit_base_url,
            "csrf_query_param": CSRF_QUERY_PARAM,
            "csrf_nonce": csrf_nonce,
        },
    )
    try:
        _write_streamlit_auth_cookie(response, request, streamlit_token)
        request.session["csrf_nonce"] = csrf_nonce
    except AppConfigurationError as exc:
        request_id = _log_configuration_failure(
            request,
            phase="streamlit_cookie",
            exc=exc,
            authenticated=True,
        )
        return _configuration_error_response(
            request,
            message="Não foi possível renovar a sessão do painel.",
            status_code=500,
            error_code="DASHBOARD_COOKIE_CONFIGURATION_INVALID",
            request_id=request_id,
        )
    return response


@app.get("/logout")
async def logout(request: Request):
    """Logout — call BB end_session and clear local session."""
    access_token = _pop_access_token(request.session.get("access_token_key", ""))
    if access_token:
        try:
            end_session_url = _oauth_endpoint("end_session")
            async with httpx.AsyncClient(timeout=5, verify=SSL_VERIFY) as client:
                await client.get(
                    end_session_url,
                    headers={"Authorization": f"Bearer {access_token}"},
                )
        except Exception as exc:
            logger.warning(
                "Falha ao encerrar sessão OAuth remota (%s).",
                type(exc).__name__,
            )

    request.session.clear()
    response = RedirectResponse(url="/")
    _clear_streamlit_auth_cookie(response)
    return response


# ── Backtest access guards ───────────────────────────────────
# Todas as paginas de backtest reutilizam a mesma allow-list de matriculas
# usada pelo /dashboard: a matricula da sessao precisa estar em
# ``ALLOWED_MATRICULA_DIGESTS``. Isso garante que, se a lista for atualizada
# apos o login (revogacao), a sessao perde acesso na proxima requisicao.
def _session_matricula(request: Request, user: dict) -> str:
    raw = request.session.get("matricula") or (user or {}).get("matricula", "")
    return str(raw or "").strip().upper()


def _revoke_unauthorized_session(request: Request, matricula: str, kind: str):
    logger.warning(
        "Acesso a backtest (%s) negado por sujeito fora da allow-list | ts=%s | sujeito=%s",
        kind,
        _log_timestamp(),
        _log_subject(matricula),
    )
    request.session.clear()


def _require_backtest_user(request: Request):
    """Guarda para rotas HTML de backtest.

    Retorna (user, None) quando autorizado; caso contrario (None, RedirectResponse).
    """
    user = request.session.get("user")
    if not user:
        return None, RedirectResponse(url="/")
    matricula = _session_matricula(request, user)
    if not matricula or not _is_matricula_authorized(matricula):
        _revoke_unauthorized_session(request, matricula, "html")
        response = RedirectResponse(url="/")
        _clear_streamlit_auth_cookie(response)
        return None, response
    return user, None


def _require_backtest_user_json(request: Request):
    """Guarda para rotas JSON de backtest.

    Retorna (user, None) quando autorizado; caso contrario (None, JSONResponse).
    """
    user = request.session.get("user")
    if not user:
        return None, JSONResponse({"error": "unauthenticated"}, status_code=401)
    matricula = _session_matricula(request, user)
    if not matricula or not _is_matricula_authorized(matricula):
        _revoke_unauthorized_session(request, matricula, "json")
        return None, JSONResponse({"error": "forbidden"}, status_code=403)
    return user, None


# ── Relatorio HTML do backtest VPN (Phase D) ─────────────────
# Serves the self-contained standalone HTML report generated by
# `backtest-vpn report-html` in the backtest_vpn_local project.
# The file is baked into the image at build time (COPY . /app).
# Read-only, session-authenticated, no DB2 access from this route.

_BACKTEST_VPN_DIR = _Path(__file__).parent / "acr_controle_acesso_dashboard" / "static" / "backtest_vpn"
_BACKTEST_VPN_LATEST = _BACKTEST_VPN_DIR / "latest.htm"


@app.get("/backtest/vpn", response_class=HTMLResponse)
async def backtest_vpn_report(request: Request):
    """Relatorio tecnico do backtest VPN — renderizado no layout unificado."""
    user, _redirect = _require_backtest_user(request)
    if _redirect is not None:
        return _redirect
    bundle_tuple = _load_bundle_or_none()
    ctx = {"user": user, "active_tab": "vpn", "page_title": "Relatório · Backtest VPN", "bundle": None}
    if bundle_tuple is None:
        return templates.TemplateResponse(request, "backtest_vpn.html", context=ctx)
    ctx.update(_build_backtest_vpn_context(bundle_tuple))
    return templates.TemplateResponse(request, "backtest_vpn.html", context=ctx)


@app.get("/backtest/vpn/raw", response_class=HTMLResponse)
async def backtest_vpn_report_raw(request: Request):
    """Relatorio HTML autocontido (fallback) gerado pelo backtest CLI."""
    user, _redirect = _require_backtest_user(request)
    if _redirect is not None:
        return _redirect
    if _load_bundle_or_none() is None:
        return PlainTextResponse(
            "Nenhum bundle v2 compatível foi gerado. Execute novamente o backtest.",
            status_code=503,
        )
    if not _BACKTEST_VPN_LATEST.is_file():
        return PlainTextResponse(
            "Relatorio de backtest VPN ainda nao gerado nesta implantacao.",
            status_code=503,
        )
    return FileResponse(
        _BACKTEST_VPN_LATEST,
        media_type="text/html; charset=utf-8",
        headers={"Cache-Control": "no-store"},
    )


@app.get("/backtest/vpn/fragment", response_class=HTMLResponse)
async def backtest_vpn_report_fragment(request: Request):
    """Fragmento embutivel (`<div class=\"vpnbt-root\">...</div>`) para inclusao server-side."""
    user, _redirect = _require_backtest_user(request)
    if _redirect is not None:
        return _redirect
    if _load_bundle_or_none() is None:
        return PlainTextResponse(
            "Nenhum bundle v2 compatível foi gerado. Execute novamente o backtest.",
            status_code=503,
        )
    fragment = _BACKTEST_VPN_DIR / "latest.fragment.htm"
    if not fragment.is_file():
        return PlainTextResponse(
            "Fragmento do relatorio VPN ainda nao gerado nesta implantacao.",
            status_code=503,
        )
    return FileResponse(
        fragment,
        media_type="text/html; charset=utf-8",
        headers={"Cache-Control": "no-store"},
    )


# ─────────────────────────────────────────────────────────────
# /backtest/sumario, /backtest/segmentacao, /backtest/executar*
# ─────────────────────────────────────────────────────────────
# Páginas negociais renderizadas server-side com Jinja2 + Plotly,
# consumindo o bundle mais recente publicado em ``static/backtest_vpn/``
# e um orquestrador de subprocess (``backtest_runner.py``) para disparar
# novas execuções sob demanda com feedback de progresso em tempo real.

from fastapi import Form, HTTPException  # noqa: E402
from fastapi.responses import JSONResponse, Response  # noqa: E402
import io as _io  # noqa: E402
import pandas as _pd  # noqa: E402

from backtest_bundle import (  # noqa: E402
    RULE_DESCRIPTIONS_PT,
    RULE_METRIC_LABELS,
    RULE_ORDER,
    RULE_TITLES_PT,
    affected_users_by_rule,
    all_flagged_users,
    build_rule_user_matrix,
    curio_coverage,
    group_counts,
    group_rule_by_dimension,
    load_latest_bundle,
    redundancy_count,
    rule_flagged_counts,
    rule_labels_from_matrix,
    should_use_org_fallback,
    top_reincident_users,
)
from org_enrichment import fetch_employee_profile, flatten_org, is_matricula  # noqa: E402

from acr_controle_acesso_dashboard.backtest_runner import (  # noqa: E402
    RUNNER as _BACKTEST_RUNNER,
    BacktestBusy,
    BacktestUnavailable,
)
from backtest_vpn.config import load_detection_config as _load_detection_config  # noqa: E402
from backtest_vpn.clock import FixedClock as _FixedClock  # noqa: E402
from backtest_vpn.period import (  # noqa: E402
    CUTOFF_CURRENT_DAY as _CUTOFF_CURRENT_DAY,
    build_period as _build_period,
    default_period as _default_period,
    inclusive_dates_to_window as _inclusive_to_window,
    parse_window_days as _parse_window_days,
)
from backtest_vpn.detection import APP_TIMEZONE as _BACKTEST_TIMEZONE  # noqa: E402
from backtest_vpn import runtime as _backtest_runtime  # noqa: E402
from backtest_vpn.progress import (  # noqa: E402
    PHASE_DONE as _PHASE_DONE,
    PHASE_FAILED as _PHASE_FAILED,
    PHASE_QUEUED as _PHASE_QUEUED,
    PHASE_VALIDATING_CONFIG as _PHASE_VALIDATING_CONFIG,
    friendly_progress as _friendly_progress,
)

# ── Runtime de backtesting compartilhado ─────────────────────────────────
# O estado autoritativo de jobs, agendamento e publicação vive em
# ``backtest_vpn.runtime``. A aplicação web **não** executa backtest no
# processo HTTP: ela apenas enfileira comandos e lê o estado durável
# compartilhado, o que mantém o status legível de qualquer pod.
_BACKTEST_RUNTIME = None
_BACKTEST_RUNTIME_ERROR = ""


def _backtest_runtime_instance():
    """Devolve (e memoriza) o runtime de backtesting, ou ``None`` se indisponível."""
    global _BACKTEST_RUNTIME, _BACKTEST_RUNTIME_ERROR
    if _BACKTEST_RUNTIME is not None:
        return _BACKTEST_RUNTIME
    try:
        _BACKTEST_RUNTIME = _backtest_runtime.build_runtime(
            application_version=_APP_VERSION,
            base_dir=_Path(__file__).parent,
            logger=logger,
            reports_dir=_BACKTEST_RUNNER.reports_dir(),
        )
        _BACKTEST_RUNTIME_ERROR = ""
    except Exception as exc:  # noqa: BLE001 - degradação explícita e visível
        _BACKTEST_RUNTIME_ERROR = "Runtime de backtesting indisponível."
        logger.error(
            "Runtime de backtesting indisponível (%s).", type(exc).__name__
        )
        return None
    return _BACKTEST_RUNTIME


def _rule_description(
    code: str,
    *,
    distinct_limit=2,
    daily_login_limit=2,
    mta_delta_minutes=15,
    start="?",
    end="?",
    rule_parameters=None,
) -> str:
    configured = dict(rule_parameters or {})
    return RULE_DESCRIPTIONS_PT[code].format(
        distinct_limit=distinct_limit,
        daily_login_limit=daily_login_limit,
        mta_delta_minutes=mta_delta_minutes,
        start=start,
        end=end,
        r1_min_distinct_ips=configured.get("r1_min_distinct_ips", 2),
        r4_high_severity_above=configured.get("r4_high_severity_above", 10),
        r4_high_start=configured.get("r4_high_severity_above", 10) + 1,
        r4_critical_severity_above=configured.get(
            "r4_critical_severity_above", 20
        ),
        device_windows_days=", ".join(
            str(value) for value in configured.get("device_windows_days", [1, 7, 30])
        ),
        multi_device_min_devices=configured.get("multi_device_min_devices", 2),
        multi_device_window_minutes=configured.get("multi_device_window_minutes", 60),
        rapid_ip_min_distinct=configured.get("rapid_ip_min_distinct", 3),
        rapid_ip_window_minutes=configured.get("rapid_ip_window_minutes", 120),
    )


def _configured_rule_parameters() -> dict:
    """Parâmetros não sensíveis usados para manter a tela igual à execução."""
    raw_path = os.environ.get("BACKTEST_RULES_CONFIG", "").strip()
    path = None
    if raw_path:
        candidate = _Path(raw_path)
        path = candidate if candidate.is_absolute() else (_Path(__file__).parent / candidate)
    try:
        configured = _load_detection_config(path)
    except ValueError as exc:
        logger.warning(
            "Configuração de regras inválida ao montar a interface (%s).",
            type(exc).__name__,
        )
        configured = _load_detection_config()
    return {
        "r1_min_distinct_ips": configured.r1_min_distinct_ips,
        "r4_vpn_login_limit": configured.r4_vpn_login_limit,
        "r4_high_severity_above": configured.r4_high_severity_above,
        "r4_critical_severity_above": configured.r4_critical_severity_above,
        "device_windows_days": list(configured.device_windows_days),
        "multi_device_min_devices": configured.multi_device_min_devices,
        "multi_device_window_minutes": configured.multi_device_window_minutes,
        "rapid_ip_min_distinct": configured.rapid_ip_min_distinct,
        "rapid_ip_window_minutes": configured.rapid_ip_window_minutes,
    }


def _load_bundle_or_none():
    return load_latest_bundle(str(_BACKTEST_VPN_DIR))


def _sumario_enrich(user_key: str) -> dict:
    if is_matricula(user_key):
        return flatten_org(fetch_employee_profile(user_key))
    return flatten_org(None)


def _fmt_num(v, kind="int"):
    if v is None:
        return "—"
    if kind == "pct":
        try:
            return "{0:.2%}".format(float(v))
        except Exception:
            return str(v)
    if kind == "float":
        try:
            return "{0:.4g}".format(float(v))
        except Exception:
            return str(v)
    try:
        return "{0:,}".format(int(v)).replace(",", ".")
    except Exception:
        return str(v)


def _build_backtest_vpn_context(bundle_tuple):
    bundle_path, bundle = bundle_tuple
    params = bundle.get("parameters") or {}
    rules = bundle.get("rules") or {}
    cross = bundle.get("cross_rule") or {}

    distinct_limit = params.get("distinct_limit", "?")
    daily_login_limit = params.get("daily_login_limit", "?")
    mta_cfg = params.get("mta_table_config") or {}
    mta_delta_minutes = params.get("mta_delta_minutes") or mta_cfg.get("delta_minutes", "?")
    win_start = params.get("start", "?")
    win_end = params.get("end", "?")
    rule_params = params.get("rule_parameters") or {}

    params_display = [
        ("Início técnico da janela (incluído)", win_start),
        ("Fim técnico da janela (excluído)", win_end),
        ("R1 — mínimo de IPs distintos no mesmo campo e dia", "≥ {0}".format(rule_params.get("r1_min_distinct_ips", 2))),
        ("R2/R3 — limite no período", "> {0} valores distintos".format(distinct_limit)),
        ("R4 — logins VPN deduplicados no dia", "> {0} (3 ou mais sinalizam)".format(rule_params.get("r4_vpn_login_limit", daily_login_limit))),
        (
            "R4 — faixas de severidade",
            "MÉDIA até {0}; ALTA de {1} a {2}; CRÍTICA acima de {2}".format(
                rule_params.get("r4_high_severity_above", 10),
                rule_params.get("r4_high_severity_above", 10) + 1,
                rule_params.get("r4_critical_severity_above", 20),
            ),
        ),
        ("R7 — janelas de associação do dispositivo", "{0} dias".format(", ".join(str(v) for v in rule_params.get("device_windows_days", [1, 7, 30])))),
        ("R8 — dispositivos / janela", "≥ {0} em {1} min".format(rule_params.get("multi_device_min_devices", 2), rule_params.get("multi_device_window_minutes", 60))),
        ("R9 — IPs de origem / janela", "≥ {0} em {1} min".format(rule_params.get("rapid_ip_min_distinct", 3), rule_params.get("rapid_ip_window_minutes", 120))),
        ("Janela de correlação VPN ↔ ``DB2PEP.MTA_AUT_CLI_TRAN`` (R5/R6)", "± {0} minutos".format(mta_delta_minutes)),
        ("Faixas privadas aceitas em ``DB2PEP.MTA_AUT_CLI_TRAN`` (R5/R6)", ", ".join(mta_cfg.get("physical_ip_cidrs") or []) or "—"),
        ("Máx. usuários por execução (R5/R6)", mta_cfg.get("max_users_per_run", "?")),
        ("Chunk temporal de leitura de ``DB2PEP.MTA_AUT_CLI_TRAN``", "{0}h".format(params.get("mta_chunk_hours") or mta_cfg.get("chunk_hours", "?"))),
        ("Amostra máxima por caso", params.get("sample_limit", "?")),
        ("Fonte de dados", "DB2 (endereço omitido no relatório)"),
    ]

    rules_summary = []
    rules_detail = []
    for code in RULE_ORDER:
        payload = rules.get(code) or {}
        description = _rule_description(
            code,
            distinct_limit=distinct_limit,
            daily_login_limit=daily_login_limit,
            mta_delta_minutes=mta_delta_minutes,
            start=win_start,
            end=win_end,
            rule_parameters=rule_params,
        )
        temporal = payload.get("temporal_stability") or {}
        negative = payload.get("negative_control") or {}
        sweep = payload.get("threshold_sweep") or []
        sweep_rows = [
            {
                "threshold": row.get("threshold"),
                "flagged": _fmt_num(row.get("flagged")),
                "rate": _fmt_num(row.get("rate"), "pct"),
            }
            for row in sweep
        ]
        rules_summary.append({
            "code": code,
            "title": RULE_TITLES_PT[code],
            "status": payload.get("status") or "—",
            "flagged": _fmt_num(payload.get("flagged")),
            "flagged_users": _fmt_num(payload.get("flagged_users")),
            "alert_rate": _fmt_num(payload.get("alert_rate"), "pct"),
        })
        rules_detail.append({
            "code": code,
            "title": RULE_TITLES_PT[code],
            "description": description,
            "note": payload.get("note") or "",
            "flagged": _fmt_num(payload.get("flagged")),
            "flagged_users": _fmt_num(payload.get("flagged_users")),
            "alert_rate": _fmt_num(payload.get("alert_rate"), "pct"),
            "temporal_cv": _fmt_num(temporal.get("cv"), "float"),
            "negative_upper": _fmt_num(negative.get("fpr_bound_wilson95_upper"), "float"),
            "suggested_threshold": payload.get("suggested_threshold") if payload.get("suggested_threshold") is not None else "—",
            "sweep_rows": sweep_rows,
        })

    return {
        "bundle": bundle,
        "bundle_name": os.path.basename(bundle_path),
        "generated_at": bundle.get("generated_at", "?"),
        "methodology": bundle.get("methodology_version", "?"),
        "git_commit": (bundle.get("git_commit") or "?")[:12],
        "params_display": params_display,
        "rules_summary": rules_summary,
        "rules_detail": rules_detail,
        "cross_matrix": cross.get("overlap_matrix") or [],
        "convergent_users": [
            {**u, "uor": (_sumario_enrich(u.get("user")) or {}).get("Unidade Organizacional") or "—"}
            for u in (cross.get("convergent_users") or [])[:50]
        ],
        "convergent_total": cross.get("convergent_total", 0),
        "rule_codes": list(RULE_ORDER),
        "limitations": bundle.get("limitations") or [],
    }


def _build_sumario_context(bundle_tuple):
    if bundle_tuple is None:
        return {"bundle": None}
    bundle_path, bundle = bundle_tuple
    params = bundle.get("parameters") or {}
    metrics = (bundle.get("summary") or {}).get("metrics") or {}
    counts = rule_flagged_counts(bundle)
    per_rule = affected_users_by_rule(bundle)
    matrix = build_rule_user_matrix(bundle)
    for row in matrix:
        row["labels"] = rule_labels_from_matrix(row)
    reincidentes = [r for r in matrix if r["total_regras"] > 1]

    distinct_limit = params.get("distinct_limit", "?")
    daily_login_limit = params.get("daily_login_limit", "?")
    mta_cfg = params.get("mta_table_config") or {}
    mta_delta_minutes = params.get("mta_delta_minutes") or mta_cfg.get("delta_minutes", "?")
    win_start = params.get("start", "?")
    win_end = params.get("end", "?")

    def _format_desc(code: str) -> str:
        return _rule_description(
            code,
            distinct_limit=distinct_limit,
            daily_login_limit=daily_login_limit,
            mta_delta_minutes=mta_delta_minutes,
            start=win_start,
            end=win_end,
            rule_parameters=params.get("rule_parameters") or {},
        )

    rules_ctx = []
    for rule in RULE_ORDER:
        rows = []
        for entry in per_rule.get(rule, []):
            org = _sumario_enrich(entry["USER_KEY"])
            rows.append({
                "Matrícula": entry["USER_KEY"],
                "Regra": rule,
                "Ocorrências": entry["occurrences"],
                "Última ocorrência": entry.get("last_seen") or "—",
                "Métrica": entry.get("metric") or "—",
                "Explicação": entry.get("explanation") or "Consulte a ocorrência e suas evidências no dossiê.",
                "Nome": org.get("Nome") or "—",
                "Local de Trabalho": org.get("Local de Trabalho") or "—",
                "Cargo": org.get("Cargo") or "—",
                "Prefixo Dependência": org.get("Prefixo Dependência") or "—",
                "Unidade Organizacional": org.get("Unidade Organizacional") or "—",
                "Tipo Usuário": org.get("Tipo Usuário") or "—",
                "Comissão": org.get("Comissão") or "—",
            })
        rules_ctx.append({
            "code": rule,
            "title": RULE_TITLES_PT[rule],
            "description": _format_desc(rule),
            "metric_label": RULE_METRIC_LABELS.get(rule, "Métrica"),
            "users": counts[rule]["users"],
            "events": counts[rule]["events"],
            "rows": rows,
        })

    return {
        "bundle": bundle,
        "bundle_name": os.path.basename(bundle_path),
        "generated_at": bundle.get("generated_at", "?"),
        "window_start": params.get("start", "?"),
        "window_end": params.get("end", "?"),
        "total_events": int(metrics.get("total_events_analyzed") or 0),
        "total_users": int(metrics.get("total_users_analyzed") or 0),
        "unique_flagged": len(all_flagged_users(bundle)),
        "actions_sum": sum(c["users"] for c in counts.values()),
        "redundancy": redundancy_count(bundle),
        "rules": rules_ctx,
        "matrix": matrix,
        "reincidentes": reincidentes,
        "rule_codes": list(RULE_ORDER),
    }


@app.get("/backtest/sumario", response_class=HTMLResponse)
async def backtest_sumario(request: Request):
    user, _redirect = _require_backtest_user(request)
    if _redirect is not None:
        return _redirect
    ctx = _build_sumario_context(_load_bundle_or_none())
    ctx.update({"user": user, "active_tab": "sumario", "page_title": "Sumário Negocial · Backtest VPN"})
    return templates.TemplateResponse(request, "backtest_sumario.html", context=ctx)


def _sumario_csv_bytes(bundle_tuple, name: str) -> bytes | None:
    if bundle_tuple is None:
        return None
    _, bundle = bundle_tuple
    matrix = build_rule_user_matrix(bundle)
    for row in matrix:
        row["labels"] = rule_labels_from_matrix(row)

    if name.startswith("impacto_") and name.endswith("_afetados.csv"):
        rule_code = name[len("impacto_"):-len("_afetados.csv")].upper()
        if rule_code not in RULE_ORDER:
            return None
        rows = []
        metric_label = RULE_METRIC_LABELS.get(rule_code, "Métrica")
        for entry in affected_users_by_rule(bundle).get(rule_code, []):
            org = _sumario_enrich(entry["USER_KEY"])
            rows.append({
                "Matrícula": entry["USER_KEY"],
                "Regra": rule_code,
                "Ocorrências": entry["occurrences"],
                metric_label: entry.get("metric") or "",
                "Última ocorrência": entry.get("last_seen") or "",
                "Nome": org.get("Nome") or "",
                "Local de Trabalho": org.get("Local de Trabalho") or "",
                "Cargo": org.get("Cargo") or "",
                "Prefixo Dependência": org.get("Prefixo Dependência") or "",
                "Unidade Organizacional": org.get("Unidade Organizacional") or "",
                "Tipo Usuário": org.get("Tipo Usuário") or "",
                "Comissão": org.get("Comissão") or "",
            })
        df = _pd.DataFrame(rows)
    elif name == "todos_afetados_unicos.csv":
        df = _pd.DataFrame({"USER_KEY": all_flagged_users(bundle)})
    elif name == "matriz_regras_x_usuarios.csv":
        df = _pd.DataFrame(matrix)
    elif name == "top_reincidentes.csv":
        df = _pd.DataFrame(top_reincident_users(bundle))
    else:
        return None
    return df.to_csv(index=False).encode("utf-8")


@app.get("/backtest/sumario/csv/{name}")
async def backtest_sumario_csv(request: Request, name: str):
    user, _redirect = _require_backtest_user(request)
    if _redirect is not None:
        return _redirect
    if not re.fullmatch(r"[A-Za-z0-9_\-]+\.csv", name):
        raise HTTPException(status_code=400, detail="Nome de arquivo inválido.")
    payload = _sumario_csv_bytes(_load_bundle_or_none(), name)
    if payload is None:
        raise HTTPException(status_code=404, detail="CSV indisponível.")
    return Response(
        content=payload,
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{name}"'},
    )


def _build_segmentacao_rows(bundle):
    matrix = build_rule_user_matrix(bundle)
    out = []
    for entry in matrix:
        user_key = entry["USER_KEY"]
        org = flatten_org(fetch_employee_profile(user_key)) if is_matricula(user_key) else flatten_org(None)
        row = {
            "USER_KEY": user_key,
            "Matrícula": org.get("Matrícula") or (user_key if is_matricula(user_key) else "—"),
            "Nome": org.get("Nome"),
            "Local de Trabalho": org.get("Local de Trabalho"),
            "Cargo": org.get("Cargo"),
            "Prefixo Dependência": org.get("Prefixo Dependência"),
            "Unidade Organizacional": org.get("Unidade Organizacional"),
            "Instituição Organizacional": org.get("Instituição Organizacional"),
            "Tipo Usuário": org.get("Tipo Usuário"),
            "Comissão": org.get("Comissão"),
            "Referência Perfil": org.get("Referência Perfil"),
            "Regras Sinalizadas": rule_labels_from_matrix(entry),
            "Total de Regras": entry["total_regras"],
        }
        for rule in RULE_ORDER:
            row[rule] = int(entry.get(rule) or 0)
        out.append(row)
    return out


def _render_chart(fig) -> str:
    fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="#161b22",
        plot_bgcolor="#161b22",
        font=dict(color="#e0e0e0"),
        margin=dict(l=40, r=20, t=40, b=40),
    )
    return fig.to_html(include_plotlyjs="cdn", full_html=False, div_id=None)


@app.get("/backtest/segmentacao", response_class=HTMLResponse)
async def backtest_segmentacao(request: Request):
    user, _redirect = _require_backtest_user(request)
    if _redirect is not None:
        return _redirect
    bundle_tuple = _load_bundle_or_none()
    ctx = {"user": user, "active_tab": "segmentacao", "page_title": "Segmentação · Backtest VPN", "bundle": None}
    if bundle_tuple is None:
        return templates.TemplateResponse(request, "backtest_segmentacao.html", context=ctx)

    import plotly.express as _px

    bundle_path, bundle = bundle_tuple
    params = bundle.get("parameters") or {}
    rows = _build_segmentacao_rows(bundle)
    coverage = curio_coverage(rows, "Prefixo Dependência")
    fallback = should_use_org_fallback(rows, "Prefixo Dependência")

    ctx.update({
        "bundle": bundle,
        "bundle_name": os.path.basename(bundle_path),
        "window_start": params.get("start", "?"),
        "window_end": params.get("end", "?"),
        "rows": rows,
        "coverage": coverage,
        "fallback": fallback,
        "total_rows": len(rows),
        "distinct_prefixos": len({r["Prefixo Dependência"] for r in rows if r.get("Prefixo Dependência")}),
        "distinct_tipos": len({r["Tipo Usuário"] for r in rows if r.get("Tipo Usuário")}),
    })

    if fallback:
        counts = {rule: sum(int(r.get(rule) or 0) for r in rows) for rule in RULE_ORDER}
        df = _pd.DataFrame({"Regra": list(counts.keys()), "Funcionários": list(counts.values())})
        ctx["chart_fallback"] = _render_chart(_px.bar(df, x="Regra", y="Funcionários", title="Funcionários sinalizados por regra"))
    else:
        top_prefixos = group_counts(rows, "Prefixo Dependência")[:20]
        df_top = _pd.DataFrame(top_prefixos, columns=["Prefixo Dependência", "Funcionários"]) if top_prefixos else _pd.DataFrame(columns=["Prefixo Dependência", "Funcionários"])
        ctx["chart_prefixos"] = _render_chart(_px.bar(df_top, x="Prefixo Dependência", y="Funcionários", title="Top 20 prefixos com mais funcionários sinalizados"))

        tipos = group_counts(rows, "Tipo Usuário")
        df_tipos = _pd.DataFrame(tipos, columns=["Tipo Usuário", "Funcionários"]) if tipos else _pd.DataFrame(columns=["Tipo Usuário", "Funcionários"])
        ctx["chart_tipos"] = _render_chart(_px.bar(df_tipos, x="Tipo Usuário", y="Funcionários", title="Distribuição por tipo de usuário"))

        stacked = group_rule_by_dimension(rows, "Prefixo Dependência")[:20]
        df_stack = _pd.DataFrame(stacked) if stacked else _pd.DataFrame(columns=["Prefixo Dependência", *RULE_ORDER, "total"])
        if not df_stack.empty:
            df_long = df_stack.melt(id_vars=["Prefixo Dependência", "total"], value_vars=list(RULE_ORDER), var_name="Regra", value_name="Ocorrências")
            ctx["chart_stacked"] = _render_chart(_px.bar(df_long, x="Prefixo Dependência", y="Ocorrências", color="Regra", title="Prefixo Dependência × Regra (empilhado)"))
            heat_df = df_stack.set_index("Prefixo Dependência")[list(RULE_ORDER)]
            ctx["chart_heatmap"] = _render_chart(_px.imshow(heat_df, aspect="auto", color_continuous_scale="Reds", title="Heatmap Prefixo × Regra", labels=dict(x="Regra", y="Prefixo Dependência", color="Ocorrências")))
        else:
            ctx["chart_stacked"] = ""
            ctx["chart_heatmap"] = ""

    return templates.TemplateResponse(request, "backtest_segmentacao.html", context=ctx)


@app.get("/backtest/segmentacao/csv/{name}")
async def backtest_segmentacao_csv(request: Request, name: str):
    user, _redirect = _require_backtest_user(request)
    if _redirect is not None:
        return _redirect
    if name != "segmentacao_suspeitos.csv":
        raise HTTPException(status_code=404, detail="CSV indisponível.")
    bundle_tuple = _load_bundle_or_none()
    if bundle_tuple is None:
        raise HTTPException(status_code=404, detail="Nenhum bundle disponível.")
    _, bundle = bundle_tuple
    rows = _build_segmentacao_rows(bundle)
    payload = _pd.DataFrame(rows).to_csv(index=False).encode("utf-8")
    return Response(
        content=payload,
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{name}"'},
    )


def _executar_defaults(now: datetime | None = None):
    """Período padrão: os dias de calendário local configurados.

    A semântica é única em toda a aplicação e vem de
    :mod:`backtest_vpn.period`. ``BACKTEST_WINDOW_DAYS`` aceita de 1 a 400 e
    preserva 33 dias quando não é informado.
    """
    reference = now or datetime.now(APP_TZ)
    if reference.tzinfo is None:
        reference = reference.replace(tzinfo=APP_TZ)
    else:
        reference = reference.astimezone(APP_TZ)
    period = _default_period(
        _FixedClock(reference, _BACKTEST_TIMEZONE),
        window_days=_backtest_window_days(),
        cutoff_mode=_CUTOFF_CURRENT_DAY,
    )
    return period.start_text, period.end_inclusive_text


def _backtest_window_days() -> int:
    """Janela padrão compartilhada pela UI, runtime e agendador."""
    return _parse_window_days(os.environ.get("BACKTEST_WINDOW_DAYS"))


def _inclusive_dates_to_window(start_date: str, end_date: str) -> tuple[str, str]:
    """Converte datas inclusivas da interface para intervalo técnico semiaberto."""
    return _inclusive_to_window(start_date, end_date, timezone_name=_BACKTEST_TIMEZONE)


def _availability_reason() -> str:
    if not _BACKTEST_RUNNER.bin_path():
        return "Wrapper ``backtest-vpn`` não encontrado nos caminhos suportados da aplicação."
    if not _BACKTEST_RUNNER.credentials_ok():
        return (
            "Credenciais DB2 não configuradas. Provisione os secrets "
            "``DB2_USERNAME`` e ``DB2_PASSWORD`` (recomendado no k8s) ou "
            "aponte ``DB2_CREDENTIALS_FILE`` para um JSON válido."
        )
    return ""


@app.get("/backtest/executar", response_class=HTMLResponse)
async def backtest_executar_form(request: Request, error: str | None = None):
    user, _redirect = _require_backtest_user(request)
    if _redirect is not None:
        return _redirect
    default_start, default_end = _executar_defaults()
    rule_parameters = _configured_rule_parameters()
    available = _BACKTEST_RUNNER.is_available() and _BACKTEST_RUNNER.credentials_ok()
    return templates.TemplateResponse(
        request,
        "backtest_executar.html",
        context={
            "user": user,
            "active_tab": "executar",
            "page_title": "Executar · Backtest VPN",
            "available": available,
            "availability_reason": _availability_reason(),
            "default_start": default_start,
            "default_end": default_end,
            "rule_choices": [
                (
                    code,
                    RULE_TITLES_PT[code],
                    _rule_description(
                        code,
                        distinct_limit=2,
                        daily_login_limit=2,
                        mta_delta_minutes=15,
                        start=default_start,
                        end=default_end,
                        rule_parameters=rule_parameters,
                    ),
                )
                for code in RULE_ORDER
            ],
            "active_job": _BACKTEST_RUNNER.active_job_id(),
            "recent_jobs": _BACKTEST_RUNNER.list_jobs(),
            "shared_jobs": _shared_recent_jobs(),
            "dataset": _backtest_dashboard_state(),
            "window_days": _backtest_window_days(),
            "error": error,
            "csrf_token": _backtest_form_csrf_token(request),
        },
    )


def _shared_recent_jobs(limit: int = 10) -> list[dict]:
    """Execuções recentes lidas do estado durável, de qualquer pod."""
    runtime = _backtest_runtime_instance()
    if runtime is None:
        return []
    try:
        return [
            _ensure_shared_progress(item)
            for item in runtime.recent(limit)
            if item is not None
        ]
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "Falha ao listar execuções recentes (%s).", type(exc).__name__
        )
        return []


@app.post("/backtest/executar")
async def backtest_executar_submit(
    request: Request,
    csrf_token: str = Form(...),
    start_date: str = Form(...),
    end_date: str = Form(...),
    mta_delta_minutes: int = Form(15),
    mta_max_users: int = Form(400),
    mta_users_per_batch: int = Form(8),
    mta_chunk_hours: int = Form(4),
    active_window_hours: int = Form(8),
    distinct_limit: int = Form(2),
    daily_login_limit: int = Form(2),
    enabled_rules: list[str] = Form(default=[]),
):
    user, _redirect = _require_backtest_user(request)
    if _redirect is not None:
        return _redirect
    if not _valid_backtest_form_csrf(request, csrf_token):
        raise HTTPException(status_code=403, detail="Solicitação não autorizada.")
    try:
        start, end = _inclusive_dates_to_window(start_date, end_date)
        durable_job_id = _enqueue_manual_backtest_job(
            start_date, end_date, enabled_rules, requested_by=_session_matricula(request, user)
        )
        job = _BACKTEST_RUNNER.submit(
            start_window=start,
            end_window=end,
            mta_delta_minutes=mta_delta_minutes,
            mta_max_users=mta_max_users,
            mta_users_per_batch=mta_users_per_batch,
            mta_chunk_hours=mta_chunk_hours,
            active_window_hours=active_window_hours,
            distinct_limit=distinct_limit,
            daily_login_limit=daily_login_limit,
            enabled_rules=",".join(enabled_rules),
            job_id=durable_job_id,
        )
    except (BacktestUnavailable, BacktestBusy, ValueError) as exc:
        logger.warning(
            "Solicitação manual de backtest rejeitada (%s).",
            type(exc).__name__,
        )
        return RedirectResponse(
            url="/backtest/executar?error="
            + urllib.parse.quote(
                "Não foi possível iniciar a execução. Revise os parâmetros "
                "e a disponibilidade do serviço."
            ),
            status_code=303,
        )
    logger.info(
        "Backtest disparado | ts=%s | sujeito=%s | job=%s | janela=%s→%s | regras=%s",
        _log_timestamp(),
        _log_subject(_session_matricula(request, user)),
        job.job_id, start, end, ",".join(enabled_rules) or "todas",
    )
    return RedirectResponse(url=f"/backtest/executar/{job.job_id}", status_code=303)


def _enqueue_manual_backtest_job(
    start_date: str, end_date: str, enabled_rules: list[str], *, requested_by: str
) -> str | None:
    """Enfileira o comando manual no estado compartilhado antes de executar.

    Devolve o ``job_id`` durável, que passa a ser o identificador exibido pela
    interface. Quando o runtime está usando apenas memória do processo, devolve
    ``None`` e o fluxo de processo único (subcomando ``full``) é preservado.
    Um runtime que nem sequer pôde ser construído é tratado como indisponível,
    pois o subprocesso encontraria a mesma configuração inválida.

    Essa verificação precisa ocorrer *antes* do ``enqueue``: o wrapper
    ``scripts/backtest-vpn`` abre outro interpretador Python, portanto um
    ``InMemoryJobStore`` criado pelo processo HTTP nunca pode ser consultado
    pelo subprocesso. Passar seu ``job_id`` para ``run-job`` faria o CLI
    terminar imediatamente com "Job não encontrado no estado compartilhado".
    """
    runtime = _backtest_runtime_instance()
    if runtime is None:
        raise BacktestUnavailable(
            "O runtime de backtesting não pôde acessar o estado configurado."
        )
    if not runtime.store.cluster_safe:
        logger.warning(
            "Backend de jobs não compartilhado (%s); execução manual usará "
            "o fluxo de processo único.",
            runtime.store.backend_name,
        )
        return None
    period = _build_period(
        start_date, end_date,
        timezone_name=_BACKTEST_TIMEZONE,
        cutoff_mode=_CUTOFF_CURRENT_DAY,
    )
    record = runtime.enqueue_manual(
        period,
        rules=enabled_rules or None,
        requested_by=requested_by or "usuário autorizado",
    )
    return record.job_id


_REPORT_MEDIA_TYPES = {
    ".tex": "application/x-tex",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".json": "application/json",
    ".csv": "text/csv; charset=utf-8",
}
_REPORT_FLAT_FILES = {
    "backtesting_dossier.tex",
    "backtesting_dossier.xlsx",
    "backtesting_report_model.json",
}
# Aceita apenas nomes emitidos pelos geradores: raiz do pacote ou um nível
# dentro de ``detalhamento_csv/``. Não há travessia possível.
_REPORT_NAME_RE = re.compile(
    r"^(?:detalhamento_csv/)?[A-Za-z0-9][A-Za-z0-9._-]{0,95}\.(?:tex|xlsx|json|csv)$"
)


@app.get("/backtest/reports")
async def backtest_report_index(request: Request):
    """Índice autenticado do pacote publicado, sem revelar caminhos absolutos."""
    user, _redirect = _require_backtest_user_json(request)
    if _redirect is not None:
        return _redirect
    from backtest_vpn import publication as _publication

    pointer = _publication.read_pointer(_BACKTEST_RUNNER.reports_dir())
    files = [name for name in (pointer.get("files") or []) if _REPORT_NAME_RE.match(name)]
    flat = [
        name for name in sorted(_REPORT_FLAT_FILES)
        if (_Path(_BACKTEST_RUNNER.reports_dir()) / name).is_file()
    ]
    return JSONResponse({
        "published": {
            "job_id": pointer.get("job_id"),
            "report_id": pointer.get("report_id"),
            "published_at": pointer.get("published_at"),
            "period": pointer.get("period"),
            "occurrences": pointer.get("occurrences"),
            "files": files,
        },
        "current_working_files": flat,
        "download_prefix": "/backtest/reports/",
    })


@app.get("/backtest/reports/{filename:path}")
async def backtest_report_download(request: Request, filename: str):
    """Download autenticado dos artefatos; nunca serve caminhos arbitrários.

    A resolução prioriza o **resultado publicado atomicamente** (allowlist
    derivada do ponteiro de publicação). Só depois recorre aos arquivos de
    trabalho na raiz de ``reports/``, com allowlist fixa de nomes.
    """
    user, _redirect = _require_backtest_user(request)
    if _redirect is not None:
        return _redirect
    from backtest_vpn import publication as _publication

    name = str(filename or "")
    if not _REPORT_NAME_RE.match(name):
        raise HTTPException(status_code=404, detail="Relatório indisponível.")
    media_type = _REPORT_MEDIA_TYPES.get(_Path(name).suffix.lower())
    if media_type is None:
        raise HTTPException(status_code=404, detail="Relatório indisponível.")
    reports_dir = _BACKTEST_RUNNER.reports_dir()
    report_path = _publication.resolve_published_file(reports_dir, name)
    if report_path is None and name in _REPORT_FLAT_FILES:
        base = _Path(reports_dir).resolve()
        candidate = (base / name).resolve()
        if candidate.parent == base and candidate.is_file() and not candidate.is_symlink():
            report_path = candidate
    if report_path is None:
        raise HTTPException(status_code=404, detail="Relatório ainda não foi gerado.")
    return FileResponse(
        report_path,
        media_type=media_type,
        filename=_Path(name).name,
        headers={"Cache-Control": "no-store"},
    )


_JOB_ID_PATTERN = re.compile(r"^(?:bt-[0-9a-f]{40}|[0-9a-f]{32})$")


def _validated_job_id(job_id: str) -> str:
    if not _JOB_ID_PATTERN.match(str(job_id or "")):
        raise HTTPException(status_code=400, detail="job_id inválido.")
    return str(job_id)


def _shared_job_view(job_id: str) -> dict | None:
    """Estado durável do job, legível de qualquer pod."""
    runtime = _backtest_runtime_instance()
    if runtime is None:
        return None
    try:
        view = runtime.status(job_id)
        return _ensure_shared_progress(view)
    except Exception as exc:  # noqa: BLE001 - status nunca derruba a página
        logger.warning(
            "Falha ao ler o estado compartilhado do job (%s).",
            type(exc).__name__,
        )
        return None


def _backtest_dashboard_state() -> dict:
    runtime = _backtest_runtime_instance()
    if runtime is None:
        return {
            "available": False,
            "reason": _BACKTEST_RUNTIME_ERROR
            or "Estado compartilhado de jobs indisponível nesta implantação.",
        }
    try:
        state = runtime.dashboard_state()
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "Falha ao montar estado do backtesting (%s).", type(exc).__name__
        )
        return {
            "available": False,
            "reason": "Estado compartilhado de jobs temporariamente indisponível.",
        }
    state["available"] = True
    state["active_jobs"] = [
        _ensure_shared_progress(item) for item in state.get("active_jobs") or []
    ]
    state["dataset_message"] = _backtest_runtime.summarize_active(runtime)
    return state


@app.get("/backtest/executar/{job_id}", response_class=HTMLResponse)
async def backtest_executar_status_page(request: Request, job_id: str):
    user, _redirect = _require_backtest_user(request)
    if _redirect is not None:
        return _redirect
    job_id = _validated_job_id(job_id)
    job = _BACKTEST_RUNNER.get_job(job_id)
    shared = _shared_job_view(job_id)
    if job is None and shared is None:
        raise HTTPException(status_code=404, detail="Job não encontrado.")
    progress = (
        dict(shared.get("progress") or {})
        if shared is not None
        else _local_backtest_progress(job.public_view())
    )
    return templates.TemplateResponse(
        request,
        "backtest_executar_status.html",
        context={
            "user": user,
            "active_tab": "executar",
            "page_title": "Execução · Backtest VPN",
            "job": job,
            "job_id": job_id,
            "shared": shared,
            "progress": progress,
            "dataset": _backtest_dashboard_state(),
            "local_log_available": job is not None,
        },
    )


@app.get("/backtest/executar/{job_id}/status")
async def backtest_executar_status_json(request: Request, job_id: str, since: int = 0):
    """Status autenticado do job, montado a partir do estado compartilhado.

    Funciona quando a requisição chega em um pod diferente do que executa o
    job: o progresso, as fases, o ETA e o *heartbeat* vêm do armazenamento
    durável. O *tail* de log local só é incluído quando existe neste pod.
    """
    user, _redirect = _require_backtest_user_json(request)
    if _redirect is not None:
        return _redirect
    job_id = _validated_job_id(job_id)
    job = _BACKTEST_RUNNER.get_job(job_id)
    shared = _shared_job_view(job_id)
    if job is None and shared is None:
        # A página de status pode permanecer aberta durante um restart local,
        # quando o job em memória deixa de existir. Responder 404 faria o
        # JavaScript antigo tentar novamente para sempre e inundar o log
        # técnico. Uma resposta terminal também encerra páginas já abertas.
        return JSONResponse({
            "job_id": job_id,
            "status": "cancelled",
            "state": "CANCELLED",
            "state_label": "Execução não está mais disponível",
            "phase_label": "Encerrada",
            "new_lines": [],
            "log_size": max(0, int(since)),
            "local_pod_log": False,
            "error_summary": (
                "Esta execução não existe mais, provavelmente porque a "
                "aplicação local foi reiniciada. Solicite um novo backtest."
            ),
            "dataset": _backtest_dashboard_state(),
        })
    since = max(0, int(since))
    if job is not None:
        view = job.public_view()
        view["new_lines"] = job.log_lines[since:]
        view["local_pod_log"] = True
    else:
        view = {
            "job_id": job_id,
            "status": _LOCAL_STATUS_BY_STATE.get(str((shared or {}).get("state")), "running"),
            "new_lines": [],
            "log_size": since,
            "local_pod_log": False,
        }
    if shared is not None:
        view["shared"] = shared
        progress = shared.get("progress") or {}
        for key in (
            "phase", "phase_label", "overall_percent", "indeterminate",
            "completed_units", "total_units", "elapsed_seconds",
            "eta_seconds_remaining", "eta_is_estimate", "eta_suppressed_reason",
            "current_rule", "friendly_summary", "friendly_detail",
            "elapsed_label", "eta_label", "progress_bar_value",
            "progress_bar_indeterminate",
        ):
            view[key] = progress.get(key)
        view["heartbeat_at"] = shared.get("heartbeat_at")
        view["state"] = shared.get("state")
        view["state_label"] = shared.get("state_label")
        view["attempt"] = shared.get("attempt")
        view["max_attempts"] = shared.get("max_attempts")
        view["error_summary"] = shared.get("error_summary")
        view["period"] = shared.get("period")
        view["data_cutoff"] = shared.get("data_cutoff")
    else:
        view.update(_local_backtest_progress(view))
    view["dataset"] = _backtest_dashboard_state()
    return JSONResponse(view)


#: Mapa dos estados duráveis para o vocabulário curto usado pelo painel.
_LOCAL_STATUS_BY_STATE = {
    "QUEUED": "pending",
    "RUNNING": "running",
    "SUCCEEDED": "success",
    "FAILED_RETRYABLE": "running",
    "FAILED_TERMINAL": "failed",
    "CANCELLED": "cancelled",
}


def _local_backtest_progress(view: dict) -> dict:
    """Indicador honesto para o modo legado sem progresso compartilhado."""
    status = str((view or {}).get("status") or "pending")
    phase = {
        "pending": _PHASE_QUEUED,
        "running": _PHASE_VALIDATING_CONFIG,
        "success": _PHASE_DONE,
        "failed": _PHASE_FAILED,
        "cancelled": "CANCELADO",
    }.get(status, _PHASE_QUEUED)
    indeterminate = status in {"pending", "running"}
    payload = {
        "trigger": "manual",
        "phase": phase,
        "phase_label": {
            "pending": "Na fila, aguardando início",
            "running": "Análise em andamento",
            "success": "Concluído",
            "failed": "Falhou",
            "cancelled": "Cancelado",
        }.get(status, "Aguardando"),
        "overall_percent": 100.0 if status == "success" else 0.0,
        "indeterminate": indeterminate,
        "completed_units": 0,
        "total_units": None if indeterminate else 1,
        "elapsed_seconds": 0,
        "eta_seconds_remaining": None,
        "eta_suppressed_reason": (
            "este modo de execução não informa unidades intermediárias"
            if indeterminate else None
        ),
        "current_rule": None,
    }
    payload.update(_friendly_progress(payload))
    if status == "running":
        payload["friendly_summary"] = "Sua análise está em andamento"
        payload["friendly_detail"] = (
            "Os registros estão sendo processados. Esta implantação ainda não "
            "informa o percentual intermediário, por isso a barra permanece animada."
        )
    return payload


def _ensure_shared_progress(view: dict | None) -> dict | None:
    """Completa snapshots antigos sem reescrever o registro compartilhado."""
    if view is None:
        return None
    normalized = dict(view)
    progress = dict(normalized.get("progress") or {})
    if not progress:
        status = _LOCAL_STATUS_BY_STATE.get(str(normalized.get("state")), "running")
        progress = _local_backtest_progress({"status": status})
        progress["trigger"] = normalized.get("trigger") or "manual"
        progress.update(_friendly_progress(progress))
    else:
        progress.update(_friendly_progress(progress))
    normalized["progress"] = progress
    return normalized


@app.get("/backtest/status")
async def backtest_status_overview(request: Request):
    """Visão autenticada do ciclo de backtesting, legível de qualquer pod."""
    user, _redirect = _require_backtest_user_json(request)
    if _redirect is not None:
        return _redirect
    runtime = _backtest_runtime_instance()
    payload = {"dataset": _backtest_dashboard_state()}
    if runtime is not None:
        try:
            payload["recent_jobs"] = runtime.recent(10)
            payload["schedule_decision"] = runtime.evaluate_schedule().as_payload()
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "Falha ao montar a visão de status do backtesting (%s).",
                type(exc).__name__,
            )
    return JSONResponse(payload)


@app.post("/api/audit/search")
async def audit_search(request: Request):
    """Record a search action to MongoDB audit log."""
    user = request.session.get("user")
    matricula = request.session.get("matricula", "")
    if not user:
        return JSONResponse(
            {"ok": False, "reason": "unauthenticated"}, status_code=401
        )
    try:
        content_length = int(request.headers.get("content-length", "0") or 0)
    except ValueError:
        content_length = 0
    if content_length > 8192:
        raise HTTPException(status_code=413, detail="Corpo da requisição muito grande.")
    try:
        body = await request.json()
    except Exception as exc:
        raise HTTPException(status_code=400, detail="JSON inválido.") from exc
    if not isinstance(body, dict):
        raise HTTPException(status_code=400, detail="JSON deve ser um objeto.")
    query = str(body.get("query", ""))[:512]
    page = str(body.get("page", ""))[:128]
    client_ip = request.headers.get("x-forwarded-for", request.client.host if request.client else "")
    record_search(
        matricula=matricula,
        userinfo=user,
        search_query=query,
        page=page,
        ip=client_ip,
    )
    logger.info(
        "Busca registrada | ts=%s | sujeito=%s | pagina=%s",
        _log_timestamp(),
        _log_subject(matricula),
        page,
    )
    return {"ok": True}


@app.get("/healthz")
@app.get("/health")
@app.get("/health/live")
async def healthz():
    """Liveness: o processo web está vivo.

    Deliberadamente **não** depende do backtest: uma execução longa, uma falha
    de DB2 ou um resultado ainda ausente nunca devem reiniciar o pod.
    """
    return {"status": "ok"}


@app.get("/health/ready")
async def health_ready():
    """Readiness: a aplicação web pode atender requisições.

    Também deliberadamente independente do backtest. O primeiro conjunto de
    dados pode continuar sendo preparado depois do pod ficar pronto; a
    interface e os logs dizem isso com clareza, e o resultado anterior válido
    (quando existe) continua sendo servido com o horário da última atualização
    bem-sucedida. Bloquear a prontidão aqui atrasaria a implantação sem
    benefício.
    """
    payload = {"status": "ok", "web": "ready"}
    runtime = _backtest_runtime_instance()
    if runtime is None:
        payload["backtest_dataset"] = "estado compartilhado de jobs indisponível"
        return payload
    try:
        state = runtime.dashboard_state()
    except Exception as exc:  # noqa: BLE001 - readiness não falha por isso
        payload["backtest_dataset"] = "estado indisponível: {0}".format(exc)
        return payload
    payload["backtest_dataset"] = (
        "execução em andamento"
        if state["initial_dataset_pending"]
        else ("disponível" if state["last_successful"] else "sem resultado publicado")
    )
    payload["last_successful_at"] = state["last_successful_at"]
    payload["store_cluster_safe"] = state["store_cluster_safe"]
    return payload
