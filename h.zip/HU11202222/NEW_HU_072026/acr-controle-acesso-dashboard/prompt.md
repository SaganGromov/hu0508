implement a new functionality wherein all logins are recorded to mongodb. the connection string you need to use is mongodb://user_telemetria:DfIJKUPe@dxl1bdhmg007.dispositivos.bb.com.br:27017/telemetria?replicaSet=rs_silo7, this will be set in an enviroment variable. the database in that mongodb uri you will record in is "TELEMETRIA", and in there you will record toa new collection with the name "AUDIT_LOGINS_DASHBOARD_VPN" (you shall in the code create such a collection in case it does not already exist)

all searches must be recorded to mongo as well. all userinfo, as in the one that gets captured at line 230 of #file:app.py, must be recorded as well. 

only intentional user action (such as looking up some matricula in the search, or any human action in the page) or catastrophic errors should show up in the logs. none of this stuff should be in the logs:

INFO:     10.149.64.2:50638 - "GET /health/live HTTP/1.1" 200 OK
INFO:     10.149.100.2:55752 - "GET /health/ready HTTP/1.1" 200 OK
INFO:     10.149.100.2:55756 - "GET /health/live HTTP/1.1" 200 OK
INFO:     127.0.0.1:59656 - "GET /health HTTP/1.1" 200 OK
INFO:     127.0.0.1:51608 - "GET /health HTTP/1.1" 200 OK
INFO:     127.0.0.1:39382 - "GET /health HTTP/1.1" 200 OK
INFO:     127.0.0.1:60048 - "GET /health HTTP/1.1" 200 OK
INFO:     10.149.86.2:33434 - "GET /health/live HTTP/1.1" 200 OK
INFO:     10.149.86.2:33436 - "GET /health/ready HTTP/1.1" 200 OK
INFO:     127.0.0.1:59932 - "GET /health HTTP/1.1" 200 OK
INFO:     127.0.0.1:56750 - "GET /health HTTP/1.1" 200 OK
INFO:     127.0.0.1:52270 - "GET /health HTTP/1.1" 200 OK
INFO:     10.149.91.2:45834 - "GET /health/live HTTP/1.1" 200 OK
INFO:     10.149.91.2:45846 - "GET /health/ready HTTP/1.1" 200 OK
INFO:     127.0.0.1:39398 - "GET /health HTTP/1.1" 200 OK
INFO:     127.0.0.1:55198 - "GET /health HTTP/1.1" 200 OK
INFO:     127.0.0.1:59938 - "GET /health HTTP/1.1" 200 OK
INFO:     10.149.69.2:48894 - "GET /health/live HTTP/1.1" 200 OK
INFO:     10.149.69.2:48908 - "GET /health/ready HTTP/1.1" 200 OK
INFO:     10.149.64.2:60860 - "GET /health/live HTTP/1.1" 200 OK
INFO:     10.149.64.2:60870 - "GET /health/ready HTTP/1.1" 200 OK
INFO:     10.149.100.2:38428 - "GET /health/live HTTP/1.1" 200 OK
INFO:     10.149.100.2:38442 - "GET /health/ready HTTP/1.1" 200 OK
INFO:     127.0.0.1:56764 - "GET /health HTTP/1.1" 200 OK
INFO:     127.0.0.1:52286 - "GET /health HTTP/1.1" 200 OK
INFO:     127.0.0.1:51720 - "GET /health HTTP/1.1" 200 OK
INFO:     127.0.0.1:55212 - "GET /health HTTP/1.1" 200 OK
INFO:     10.149.86.2:58456 - "GET /health/ready HTTP/1.1" 200 OK
INFO:     10.149.86.2:58444 - "GET /health/live HTTP/1.1" 200 OK
INFO:     127.0.0.1:35350 - "GET /health HTTP/1.1" 200 OK
INFO:     127.0.0.1:46774 - "GET /health HTTP/1.1" 200 OK
INFO:     127.0.0.1:56714 - "GET /health HTTP/1.1" 200 OK
INFO:     10.149.91.2:60688 - "GET /health/live HTTP/1.1" 200 OK
INFO:     10.149.91.2:60702 - "GET /health/ready HTTP/1.1" 200 OK
INFO:     127.0.0.1:51724 - "GET /health HTTP/1.1" 200 OK
INFO:     127.0.0.1:54406 - "GET /health HTTP/1.1" 200 OK
INFO:     10.149.69.2:60182 - "GET /health/live HTTP/1.1" 200 OK
INFO:     10.149.69.2:60188 - "GET /health/ready HTTP/1.1" 200 OK
INFO:     127.0.0.1:35352 - "GET /health HTTP/1.1" 200 OK
INFO:     10.149.64.2:33244 - "GET /health/live HTTP/1.1" 200 OK
INFO:     10.149.64.2:33248 - "GET /health/ready HTTP/1.1" 200 OK
INFO:     10.149.100.2:33770 - "GET /health/live HTTP/1.1" 200 OK
INFO:     10.149.100.2:33766 - "GET /health/ready HTTP/1.1" 200 OK
INFO:     127.0.0.1:46788 - "GET /health HTTP/1.1" 200 OK
INFO:     127.0.0.1:56730 - "GET /health HTTP/1.1" 200 OK
INFO:     127.0.0.1:44006 - "GET /health HTTP/1.1" 200 OK

the logs should show timestamps in Brasilia time as well. 


you should also take a look at test_curio_op2076328.py and implement a new "suspect logins" page (with a navigable button) which looks for logins where employees were on vacation and flags them as suspicious. for now, you should only do this for the matriculas F0734273, F8456159, F0744898, F3514379, F6333868, F6002110, F8711439, F9813878, but you should implement the code so that it is easy to remove this restriction later. you should also update the version in init.py by bumping it up to 2.0.8, and you should also update the deploy repo deploy-acr-controle-acesso-dashboard accordingly (I think only the values.yaml file will need updating).

also, make all the code modular, avoiding any duplication, deleting unncessary stuff, restructuring stuff that needs to be restructed, keeping it modular, SOLID, clean code, all that beautiful stuff.

after all this, you should of course update the README.md accordingly.