#!/bin/bash
set -e

echo "Starting ACR Alert Context..."

export PYTHONPATH="${PYTHONPATH:-/app}"
export PATH="/app/.venv/bin:${PATH}"

exec /bin/bash /app/run.sh
