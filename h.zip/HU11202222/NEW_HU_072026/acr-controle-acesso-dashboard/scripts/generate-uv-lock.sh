#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

export UV_CACHE_DIR="${UV_CACHE_DIR:-/tmp/uv-cache}"
export SSL_CERT_FILE="${SSL_CERT_FILE:-$ROOT_DIR/bb.bundle.crt}"
export REQUESTS_CA_BUNDLE="${REQUESTS_CA_BUNDLE:-$SSL_CERT_FILE}"
export UV_INDEX_URL="${UV_INDEX_URL:-https://binarios.intranet.bb.com.br/artifactory/api/pypi/pypi/simple}"
export UV_PYTHON_DOWNLOADS="${UV_PYTHON_DOWNLOADS:-never}"

cd "$ROOT_DIR"

echo "Generating uv.lock..."
uv lock
