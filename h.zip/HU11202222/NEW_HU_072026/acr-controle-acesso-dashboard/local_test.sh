#!/usr/bin/env bash
# =============================================================================
#  local_test.sh — Self-contained local test for acr-controle-acesso-dashboard
# =============================================================================
#  Sincroniza dependencias com UV e sobe FastAPI + Streamlit localmente.
#  Ctrl+C to stop everything cleanly.
#
#  Usage:
#      chmod +x local_test.sh
#      ./local_test.sh
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

STREAMLIT_PORT=8501
FASTAPI_PORT=8000

# ── Colors ────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

log()  { echo -e "${CYAN}[local_test]${NC} $*"; }
warn() { echo -e "${YELLOW}[local_test]${NC} $*"; }
ok()   { echo -e "${GREEN}[local_test]${NC} $*"; }

# ── Cleanup on exit ──────────────────────────────────────────
PIDS=()
CURIO_CONTAINER="curio-sidecar-local"
cleanup() {
    log "Shutting down..."
    for pid in "${PIDS[@]}"; do
        kill "$pid" 2>/dev/null && wait "$pid" 2>/dev/null || true
    done
    docker rm -f "$CURIO_CONTAINER" 2>/dev/null || true
    ok "All processes stopped."
}
trap cleanup EXIT INT TERM

if ! command -v uv >/dev/null 2>&1; then
    echo "Erro: uv nao encontrado no PATH."
    echo "Instale o uv antes de continuar: https://docs.astral.sh/uv/getting-started/installation/"
    exit 1
fi

export UV_CACHE_DIR="${UV_CACHE_DIR:-/tmp/uv-cache}"
if [ -f "$SCRIPT_DIR/bb.bundle.crt" ]; then
    export SSL_CERT_FILE="${SSL_CERT_FILE:-$SCRIPT_DIR/bb.bundle.crt}"
    export REQUESTS_CA_BUNDLE="${REQUESTS_CA_BUNDLE:-$SSL_CERT_FILE}"
    export KAFKA_SSL_CA_LOCATION="${KAFKA_SSL_CA_LOCATION:-$SCRIPT_DIR/bb.bundle.crt}"
fi

# ── 1. Virtual environment / dependencies ───────────────────
if [ -f "$SCRIPT_DIR/uv.lock" ]; then
    log "Synchronizing dependencies with uv.lock ..."
    uv sync --frozen
else
    warn "uv.lock not found. Running unlocked dependency sync ..."
    uv sync
fi
log "Using Python: $(uv run --no-sync python --version 2>&1)"

# ── 3. .env file ─────────────────────────────────────────────
if [ ! -f .env ]; then
    if [ -f .env.example ]; then
        warn ".env not found — creating from .env.example"
        cp .env.example .env
    else
        warn ".env not found — creating minimal defaults"
        cat > .env <<'ENVEOF'
AMBIENTE=desenv
RODANDO_LOCALMENTE=YES
PROMETHEUS_MONITORING_ENABLED=false
REDIS_MONITORING_ENABLED=false
METRICS_NOTIFICATIONS_ENABLED=false
ENVEOF
    fi
fi

# ── 4. Secrets (local dev defaults) ─────────────────────────
SECRETS_DIR="$SCRIPT_DIR/secrets"
mkdir -p "$SECRETS_DIR"

if [ ! -s "$SECRETS_DIR/matricula_hmac_key" ]; then
    warn "Generating local dev HMAC key in secrets/matricula_hmac_key"
    uv run --no-sync python -c "import secrets; print(secrets.token_hex(32))" > "$SECRETS_DIR/matricula_hmac_key"
fi

if [ ! -s "$SECRETS_DIR/allowed_matricula_digests" ]; then
    warn "No allowed digests found. Generating a test digest for F0000000..."
    HMAC_KEY=$(cat "$SECRETS_DIR/matricula_hmac_key")
    DIGEST=$(uv run --no-sync python -c "
import hmac, hashlib
key = '$HMAC_KEY'.encode()
digest = hmac.new(key, b'F0000000', hashlib.sha256).hexdigest()
print(digest)
")
    echo "$DIGEST" > "$SECRETS_DIR/allowed_matricula_digests"
    ok "Test matricula F0000000 added to allowed digests"
fi

# ── 5. Export env vars for local run ─────────────────────────
export MATRICULA_HMAC_KEY_FILE="$SECRETS_DIR/matricula_hmac_key"
export ALLOWED_MATRICULA_DIGESTS_FILE="$SECRETS_DIR/allowed_matricula_digests"
export STREAMLIT_BASE_URL_PATH="${STREAMLIT_BASE_URL_PATH:-/streamlit}"
export STREAMLIT_SERVER_ENABLE_CORS="false"
export STREAMLIT_SERVER_ENABLE_XSRF_PROTECTION="true"
export OAUTH2_AMBIENTE="${OAUTH2_AMBIENTE:-intranet}"
export OAUTH2_CLIENT_ID="${OAUTH2_CLIENT_ID:-acr-controle-acesso-dashboard}"
export OAUTH2_ISSUER_BASE_URL="${OAUTH2_ISSUER_BASE_URL:-}"
export OAUTH2_REDIRECT_URI="${OAUTH2_REDIRECT_URI:-http://localhost:$FASTAPI_PORT/auth/callback}"
export SESSION_COOKIE_SECURE="${SESSION_COOKIE_SECURE:-false}"
export SSL_CA_BUNDLE="${SSL_CA_BUNDLE:-}"
export CURIO_BASE_URL="http://localhost:8081"
export CURIO_IMAGE="${CURIO_IMAGE:-docker.binarios.intranet.bb.com.br/bb/iib/iib-curio:0.9.10}"
export KAFKA_REALTIME_LOOKBACK_MINUTES="${KAFKA_REALTIME_LOOKBACK_MINUTES:-60}"

# Source .env after defaults so local files can override them.
set -a
# shellcheck disable=SC1091
source .env
set +a

# ── 5b. Start curio sidecar (Docker) ─────────────────────────
if [ ! -f "$SCRIPT_DIR/.env_curio" ] && [ -f "$SCRIPT_DIR/.env_curio.example" ]; then
    warn ".env_curio not found — creating it from .env_curio.example"
    cp "$SCRIPT_DIR/.env_curio.example" "$SCRIPT_DIR/.env_curio"
fi
CURIO_LOTACAO_OPERATION="br.com.bb.arh.operacao:Op5360402-v1:3.0.1"
if [ -f "$SCRIPT_DIR/.env_curio" ]; then
    current_ops="$(grep '^CURIO_OP_CONSUMIDOR=' "$SCRIPT_DIR/.env_curio" | tail -n 1 | cut -d= -f2-)"
    case "|$current_ops|" in
        *"|$CURIO_LOTACAO_OPERATION|"*) ;;
        *)
            merged_ops="${current_ops:+${current_ops}|}${CURIO_LOTACAO_OPERATION}"
            tmp_env="$SCRIPT_DIR/.env_curio.tmp.$$"
            awk -v merged="$merged_ops" '
                BEGIN { written = 0 }
                /^CURIO_OP_CONSUMIDOR=/ {
                    if (!written) {
                        print "CURIO_OP_CONSUMIDOR=" merged
                        written = 1
                    }
                    next
                }
                { print }
                END {
                    if (!written) print "CURIO_OP_CONSUMIDOR=" merged
                }
            ' "$SCRIPT_DIR/.env_curio" > "$tmp_env"
            mv "$tmp_env" "$SCRIPT_DIR/.env_curio"
            warn ".env_curio updated with required operation Op5360402-v1:3.0.1."
            ;;
    esac
fi
if command -v docker &>/dev/null && [ -f "$SCRIPT_DIR/.env_curio" ] && [ -n "${CURIO_IMAGE:-}" ]; then
    docker rm -f "$CURIO_CONTAINER" 2>/dev/null || true
    log "Starting curio sidecar on localhost:8081 ..."
    if docker run -d --name "$CURIO_CONTAINER" \
        --env-file "$SCRIPT_DIR/.env_curio" \
        -p 8081:8081 \
        "$CURIO_IMAGE" >/dev/null; then
        sleep 3
    else
        warn "Unable to start curio sidecar. Continuing without local curio."
    fi
elif [ ! -f "$SCRIPT_DIR/.env_curio" ]; then
    warn ".env_curio not found — curio sidecar will not be available locally"
elif [ -z "${CURIO_IMAGE:-}" ]; then
    warn "CURIO_IMAGE not configured — curio sidecar will not be started"
else
    warn "Docker not found — curio sidecar will not be available locally"
fi

# ── 6. Start Streamlit (background) ─────────────────────────
log "Starting Streamlit on 0.0.0.0:$STREAMLIT_PORT ..."
uv run --no-sync streamlit run \
    acr_controle_acesso_dashboard/streamlit_app/real_time_dashboard.py \
    --server.port="$STREAMLIT_PORT" \
    --server.address=0.0.0.0 \
    --server.headless=true \
    --server.enableCORS=false \
    --server.baseUrlPath="$STREAMLIT_BASE_URL_PATH" \
    --server.enableXsrfProtection=true \
    &
PIDS+=($!)

# Wait a moment for Streamlit to bind
sleep 2

# ── 7. Start FastAPI (foreground) ────────────────────────────
log "Starting FastAPI on 0.0.0.0:$FASTAPI_PORT ..."
ok "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ok "  Open: http://localhost:$FASTAPI_PORT"
ok "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

uv run --no-sync uvicorn app:app --host 0.0.0.0 --port "$FASTAPI_PORT" --reload &
PIDS+=($!)

# Wait for any child to exit
wait -n "${PIDS[@]}" 2>/dev/null || true
