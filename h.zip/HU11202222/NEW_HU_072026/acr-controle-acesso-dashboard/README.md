# ACR Alert Context

Dashboard de controle de acesso com FastAPI em `:8000` e Streamlit em `:8501`.

## Funcionalidades Principais

- **Dashboard VPN em tempo real** — consumo de eventos Kafka com visualizacao de logins, alertas e KPIs
- **Busca por matricula** — pesquisa retroativa de logins por matricula nos ultimos 7 dias
- **Relatorio historico** — consumo completo do topico Kafka com analise de multiplos hostnames
- **Multiplos IPs + Hostnames** — deteccao de usuarios logando de multiplas origens
- **Logins suspeitos** — cruzamento de logins VPN com periodos de ferias/ausencia (curio op2076328v2)
- **Auditoria MongoDB** — todos os logins e buscas sao registrados em `TELEMETRIA.AUDIT_LOGINS_DASHBOARD_VPN`
- **Logs filtrados** — health checks suprimidos dos logs; apenas acoes de usuario e erros criticos aparecem; timestamps em horario de Brasilia
- **Backtesting explicável R1–R9** — ocorrências deduplicadas, período padrão
  rolante de **33 dias de calendário local inclusivos**, regras configuráveis e
  evidências por usuário/dia/dispositivo
- **IP ausente tratado de forma única** — `0.0.0.0`, `::` e grafias
  equivalentes nunca contam como IP nem entram em evidência
- **R4 com severidade graduada** — 3–10 logins qualificáveis no dia: média;
  11–20: alta; 21 ou mais: crítica
- **Backtesting contínuo** — execução padrão enfileirada de forma idempotente na
  implantação e atualização automática a cada 24 h, coordenadas entre vários
  pods por estado durável compartilhado com reserva atômica, lease, heartbeat e
  *fencing* (ver [docs/internal_handoff.md](docs/internal_handoff.md))
- **Progresso amigável e ETA** — todo pedido recebe uma barra desde a fila,
  inclusive a primeira análise após a implantação; fases sem total conhecido
  ficam animadas sem inventar percentual, e os detalhes técnicos permanecem
  disponíveis sob demanda em `/backtest/status`
- **Dossiês unificados e de leitura rápida** — HTML, LaTeX, XLSX, JSON e
  pacote CSV apresentam até 10 ocorrências prioritárias de cada regra, enquanto
  os totais executivos e o bundle-fonte preservam a visão completa

O projeto agora segue um fluxo `uv`-first:

- dependências declaradas em [pyproject.toml](pyproject.toml)
- build Docker sem `pip`
- `uv sync` para ambiente local
- `uv lock` para congelar versões quando executado na rede corporativa

## Pré-requisitos

- Python `3.11+`
- `uv` instalado no host
- Docker opcional para testes locais com container e sidecar Curio
- acesso à rede corporativa BB para gerar `uv.lock` e resolver dependências pelo índice interno

Instalação do `uv`:

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
uv --version
```

## Arquivos importantes

- [pyproject.toml](pyproject.toml): metadados e dependências
- [run.sh](run.sh): sobe Streamlit e FastAPI
- [setup_env.sh](setup_env.sh): sincroniza o ambiente local com `uv`
- [local_test.sh](local_test.sh): sobe a aplicação localmente com sidecar Curio opcional
- [test_local.sh](test_local.sh): executa testes e smoke checks antes de subir a
  aplicação; inicia o sidecar Curio quando `.env_curio` está disponível
- [scripts/generate-uv-lock.sh](scripts/generate-uv-lock.sh): gera `uv.lock`
- [docs/backtesting_rule_audit.md](docs/backtesting_rule_audit.md): condição
  auditada de cada regra, limitações e deduplicação
- [docs/internal_handoff.md](docs/internal_handoff.md): preparação da máquina interna
- [docs/application_architecture.md](docs/application_architecture.md):
  componentes, fluxos, dados, segurança e extensão
- [docs/security_static_analysis.md](docs/security_static_analysis.md):
  controles e validação Checkmarx/Sonar exigida
- [generate_reports.sh](generate_reports.sh): geração offline de `.tex`, `.xlsx` e `.pdf`
- [generate_matricula_secrets.local.sh](generate_matricula_secrets.local.sh): gera segredos locais
- [create_oc_secrets.sh](create_oc_secrets.sh): publica segredos no OpenShift

## Fluxo local com UV

### 1. Preparar variáveis de ambiente

O repositório já possui [.env.example](.env.example).

```bash
cp .env.example .env
```

Preencha ao menos o que for necessário para o seu ambiente local. Para a autenticação FastAPI/SSO, normalmente os valores mais relevantes são:

- `OAUTH2_CLIENT_ID`
- `OAUTH2_CLIENT_SECRET`
- `OAUTH2_ISSUER_BASE_URL` — URL HTTPS do emissor SSO, sem caminho de endpoint
- `OAUTH2_REDIRECT_URI`
- `SESSION_SECRET` — obrigatória em deploy; usada para assinar a sessao FastAPI, os headers autenticados do proxy e qualquer fallback local por token
- `SESSION_COOKIE_SECURE` — `true` em implantação HTTPS (padrão); use `false`
  apenas no teste HTTP local
- `STREAMLIT_BASE_URL_PATH` — caminho configurado no processo Streamlit quando ele estiver servido atras do proxy FastAPI (em deploy, use `/streamlit`)
- `PUBLIC_BASE_URL` — origem HTTPS confiável usada para callbacks e links
  absolutos. É necessária fora de localhost quando `OAUTH2_REDIRECT_URI` não
  está definida; o iframe same-origin usa sempre `STREAMLIT_BASE_URL_PATH` e
  não depende dela. Cabeçalhos `Host`/`X-Forwarded-*` não definem a origem pública
- `SSL_CA_BUNDLE`
- `MONGODB_AUDIT_URI` — connection string para auditoria (MongoDB)
- `SUSPECT_MATRICULAS_RESTRICT` — `true` para restringir analise de logins suspeitos (default: `true`)
- `SUSPECT_MATRICULAS` — lista externa que, quando informada, substitui a
  allowlist incorporada usada pela página restrita

`SSL_CA_BUNDLE` aceita somente uma CA confiável. Não há modo suportado para
desabilitar a validação TLS.

Para usar o Curio local, os scripts criam `.env_curio` a partir do modelo
[`.env_curio.example`](.env_curio.example). O modelo habilita as três operações
consumidas pelo dashboard: dados organizacionais (`op292018v3`), ausências
(`op2076328v2`) e lotação/função do funcionário (`op5360402v1`). O arquivo local
é ignorado pelo Git e pode ser ajustado sem
publicar configuração específica da estação. O `test_local.sh` inicia o
sidecar e aguarda o health check antes de liberar as chamadas.

### 2. Gerar segredos locais de matrícula

```bash
./generate_matricula_secrets.local.sh
```

Isso gera:

- `secrets/matricula_hmac_key`
- `secrets/allowed_matricula_digests`

### 3. Gerar `uv.lock` na rede corporativa

Recomendado antes de build e deploy:

```bash
./scripts/generate-uv-lock.sh
```

Se o arquivo `uv.lock` existir, os comandos locais e os Dockerfiles passam a usar modo congelado. Se ele ainda não existir, o projeto continua funcional, mas a resolução será não congelada.

### 4. Sincronizar o ambiente local

```bash
./setup_env.sh
```

Esse script:

- exige `uv`
- usa `bb.bundle.crt` quando disponível
- executa `uv sync --frozen` se `uv.lock` existir
- caso contrário, executa `uv sync`

### 5. Rodar localmente

Opção recomendada:

```bash
./local_test.sh
```

Esse script:

- sincroniza dependências com `uv`
- gera segredos locais se necessário
- sobe o sidecar Curio se Docker e `.env_curio` estiverem disponíveis
- usa `bb.bundle.crt` também como CA do Kafka (`KAFKA_SSL_CA_LOCATION`) quando o arquivo existir
- inicia o consumer em tempo real a partir dos últimos 60 minutos de mensagens Kafka (`KAFKA_REALTIME_LOOKBACK_MINUTES=60`), para que uma execução local nova não fique vazia apenas por ter entrado no fim do tópico
- sobe Streamlit em `http://localhost:8501`
- sobe FastAPI em `http://localhost:8000`

Para reproduzir exatamente o comportamento de produção, onde o consumer em tempo real entra em `latest` e só recebe eventos novos após iniciar, rode:

```bash
KAFKA_REALTIME_LOOKBACK_MINUTES=0 ./local_test.sh
```

Se mesmo com o lookback o dashboard exibir "Aguardando mensagens do Kafka", confirme se há mensagens retidas ou eventos novos no tópico configurado em `KAFKA_TOPIC`.

Na página **Busca por Matrícula**, um resultado antigo pode permanecer na sessão do Streamlit até uma nova busca ser executada. Se o deploy HML parecer retornar dados mas o teste local e o diagnóstico do pod mostrarem `0` mensagens no tópico, force uma nova busca ou abra a página em janela privada para descartar estado antigo da sessão.

Opção manual, após `./setup_env.sh`:

```bash
./run.sh
```

## Build local com Docker

### Build local simples

```bash
docker build -f Dockerfile.local -t acr-controle-acesso-dashboard:local .
```

Executar:

```bash
docker run --rm \
  -p 8000:8000 \
  -p 8501:8501 \
  --env-file .env \
  -v "$(pwd)/secrets/matricula_hmac_key:/run/secrets/matricula_hmac_key:ro" \
  -v "$(pwd)/secrets/allowed_matricula_digests:/run/secrets/allowed_matricula_digests:ro" \
  acr-controle-acesso-dashboard:local
```

### Docker Compose local

```bash
docker compose -f docker-compose.local.yml up --build
```

Observações:

- o compose local usa [Dockerfile.local](Dockerfile.local)
- ele espera `OAUTH2_CLIENT_SECRET` no ambiente ou no `.env`
- os segredos locais precisam existir no diretório `secrets/`

## Build da imagem de produção

Build padrão:

```bash
docker build -t acr-controle-acesso-dashboard:latest .
```

Os Dockerfiles agora:

- não usam `pip`
- copiam o binário `uv` de uma imagem dedicada
- executam `uv sync --frozen --no-dev --no-install-project` quando `uv.lock` existe
- fazem fallback para `uv sync --no-dev --no-install-project` quando o lock ainda não existe

Se a sua esteira precisar usar uma imagem `uv` espelhada internamente, sobrescreva o build arg:

```bash
docker build \
  --build-arg UV_IMAGE=<imagem-uv-espelhada> \
  -t acr-controle-acesso-dashboard:latest .
```

## Auditoria MongoDB

Todos os logins e buscas realizadas no dashboard sao registrados automaticamente no MongoDB.

- **Connection string**: variavel de ambiente `MONGODB_AUDIT_URI`
- **Database**: `TELEMETRIA`
- **Collection**: `AUDIT_LOGINS_DASHBOARD_VPN` (criada automaticamente se nao existir)

Cada registro contem:

- `tipo`: `"LOGIN"` ou `"SEARCH"`
- `matricula`: matricula do funcionario
- `userinfo`: dados completos do usuario retornados pelo OAuth
- `timestamp`: horario de Brasilia
- Para buscas: `busca` (termo pesquisado) e `pagina` (pagina de origem)
- `ip`: IP do cliente

Se `MONGODB_AUDIT_URI` nao estiver configurada, a auditoria e desabilitada silenciosamente (sem afetar o funcionamento do dashboard).

## Logins Suspeitos

A pagina "Logins Suspeitos" cruza dados de login VPN (Kafka) com periodos de ferias/ausencia obtidos via curio (operacao 2076328v2).

Configuracao:

- `SUSPECT_MATRICULAS_RESTRICT` (default: `true`) — quando `true`, a analise e restrita a um conjunto pre-definido de matriculas. Para remover a restricao, defina como `false`.

## Logs

Os logs do uvicorn sao filtrados para exibir apenas:

- Acoes intencionais de usuario (login, busca, acesso ao dashboard)
- Erros criticos

Health checks (`/health`, `/health/live`, `/health/ready`, `/healthz`) sao automaticamente suprimidos. Todos os timestamps nos logs usam o horario de Brasilia (America/Sao_Paulo).

## Contrato de health check

O container principal expõe os seguintes aliases de health check no FastAPI:

- `/healthz`
- `/health`
- `/health/live`
- `/health/ready`

Todos retornam `200 {"status": "ok"}` e existem para compatibilidade com:

- o probe HTTP do Kubernetes/OpenShift
- o watchdog do sidecar Curio
- smoke tests locais

Para execução local com Curio:

- o FastAPI responde em `http://localhost:8000`
- o sidecar Curio responde em `http://localhost:8081`
- o arquivo [.env_curio](.env_curio) deve manter `CURIO_APLICACAO_HOST=http://localhost:8000`

Para deploy:

- o app deve apontar `CURIO_BASE_URL` para `http://localhost:8081`
- o sidecar Curio deve apontar `CURIO_APLICACAO_HOST` para `http://localhost:8000`
- o acesso web ao Streamlit deve passar pelo FastAPI em `/streamlit`; nao publique `:8501` diretamente no ingress
- configure `STREAMLIT_BASE_URL_PATH=/streamlit` para que o processo Streamlit gere assets e rotas compativeis com o proxy
- prefira `PUBLIC_BASE_URL=https://<rota-publica-do-fastapi>` fora de
  localhost; ela é obrigatória quando `OAUTH2_REDIRECT_URI` não está definida.
  O iframe usa o path same-origin e não falha se essa variável ainda estiver
  ausente; `Host` e `X-Forwarded-*` não são fontes confiáveis para callback ou
  política de cookie
- configure `OAUTH2_REDIRECT_URI` com a mesma origem HTTPS e registre esse
  callback exato no provedor OAuth2
- o fragmento local
  `deploy/values-dashboard-auth.patch.yaml` documenta as entradas de ambiente,
  o redirect HTTP→HTTPS e o Secret TLS esperados para homologação
- `SESSION_SECRET` deve existir no mesmo container para FastAPI e Streamlit; sem ela o iframe e o proxy do dashboard falham de forma explicita
- todas as exportacoes CSV passam a receber nome unico e ser auditadas no MongoDB

Teste rápido local:

```bash
curl -s http://localhost:8000/health/live
curl -s http://localhost:8000/health/ready
curl -s http://localhost:8000/healthz
```

## Deploy em OpenShift

### 1. Login no cluster

```bash
oc login --token='<SEU_TOKEN>' --server='<SEU_CLUSTER>'
oc project <seu-namespace>
```

### 2. Publicar segredos

Depois de gerar os arquivos em `secrets/`, publique-os com:

```bash
./create_oc_secrets.sh -n <namespace>
```

O script cria ou atualiza:

- `kafka-credentials`
- `acr-dashboard-auth-secrets`

O secret `acr-dashboard-auth-secrets` precisa conter ao menos:

- `oauth2_client_secret`
- `session_secret`
- `matricula_hmac_key`
- `allowed_matricula_digests`

Opcionalmente, ele tambem pode conter `mongodb_audit_uri`.

### 3. Build e publicação da imagem

Normalmente isso deve ocorrer pela esteira CI/CD. Se você precisar reproduzir localmente:

```bash
docker build -t <registro>/<namespace>/acr-controle-acesso-dashboard:<tag> .
docker push <registro>/<namespace>/acr-controle-acesso-dashboard:<tag>
```

### 4. Aplicar rollout

```bash
oc -n <namespace> rollout restart deploy/acr-controle-acesso-dashboard
oc -n <namespace> rollout status deploy/acr-controle-acesso-dashboard
```

### 5. Validar

```bash
oc -n <namespace> get pods
oc -n <namespace> logs deploy/acr-controle-acesso-dashboard --tail=200
```

Health checks recomendados após o rollout:

```bash
oc -n <namespace> exec deploy/acr-controle-acesso-dashboard -- curl -s http://localhost:8000/health/live
oc -n <namespace> exec deploy/acr-controle-acesso-dashboard -- curl -s http://localhost:8000/health/ready
oc -n <namespace> exec deploy/acr-controle-acesso-dashboard -c curio-sidecar -- curl -s http://localhost:8081/health/live
oc -n <namespace> exec deploy/acr-controle-acesso-dashboard -c curio-sidecar -- curl -s http://localhost:8081/health/ready
```

## Observações sobre certificados e índice de pacotes

- [Dockerfile](Dockerfile) usa `bb.bundle.crt` e define `SSL_CERT_FILE`, `REQUESTS_CA_BUNDLE` e `CURL_CA_BUNDLE`
- os scripts locais também tentam reutilizar `bb.bundle.crt`
- o índice corporativo é preservado no `pyproject.toml` e nos scripts de build

## Comandos úteis

Sincronizar ambiente:

```bash
./setup_env.sh
```

Gerar lock:

```bash
./scripts/generate-uv-lock.sh
```

Rodar local:

```bash
./local_test.sh
```

Rodar manualmente:

```bash
./run.sh
```

Publicar segredos no OpenShift:

```bash
./create_oc_secrets.sh -n <namespace>
```
