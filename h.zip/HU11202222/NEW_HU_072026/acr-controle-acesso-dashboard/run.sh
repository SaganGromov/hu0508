#!/bin/bash
# Start both services: Streamlit (background) + FastAPI (foreground)
set -e

BASE_URL_PATH="${STREAMLIT_BASE_URL_PATH:-/streamlit}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ -x /app/.venv/bin/python ]; then
    PYTHON_BIN=/app/.venv/bin/python
elif [ -x /app/venv/bin/python ]; then
    PYTHON_BIN=/app/venv/bin/python
elif [ -x "$SCRIPT_DIR/.venv/bin/python" ]; then
    PYTHON_BIN="$SCRIPT_DIR/.venv/bin/python"
elif command -v python3 >/dev/null 2>&1; then
    PYTHON_BIN=$(command -v python3)
elif command -v python >/dev/null 2>&1; then
    PYTHON_BIN=$(command -v python)
else
    echo "Python interpreter not found."
    exit 1
fi

echo "Starting Streamlit dashboard on 0.0.0.0:8501 ..."
CMD=("$PYTHON_BIN" -m streamlit run
    acr_controle_acesso_dashboard/streamlit_app/real_time_dashboard.py
    --server.port=8501 --server.address=0.0.0.0 --server.headless=true
    --server.enableCORS=false --server.enableXsrfProtection=true)

if [ -n "$BASE_URL_PATH" ]; then
    CMD+=(--server.baseUrlPath="$BASE_URL_PATH")
fi

"${CMD[@]}" &
STREAMLIT_PID=$!

# Cleanup on exit
trap "kill $STREAMLIT_PID 2>/dev/null" EXIT

echo "Starting FastAPI server on 0.0.0.0:8000 ..."
echo "Acesse: http://localhost:8000"
"$PYTHON_BIN" -m uvicorn app:app --host 0.0.0.0 --port 8000
