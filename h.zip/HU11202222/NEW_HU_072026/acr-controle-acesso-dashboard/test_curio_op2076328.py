"""
Script para testar a operação 2076328 no sidecar curio.

- Requisição baseada em CONTRATO_2076328v2.txt
- Usa integracao_curio do projeto

Uso:
    python test_curio_op2076328.py
"""

import os
import sys
from pathlib import Path

# Permite rodar o script de qualquer lugar
sys.path.insert(0, str(Path(__file__).parent / "acr_controle_acesso_dashboard" / "streamlit_app"))
os.environ["CURIO_BASE_URL"] = "http://localhost:8081"

from curio_models import PAYLOAD_OP292018V3
from curio_service import integracao_curio

# Payload de teste (ajuste os valores conforme necessário)
payload = {
    "codigoMatriculaFuncionarioPesquisa": "0734273",  # Matrícula numérica
    "dataInicioPerPesquisa": "01.01.2026",
    "dataFimPerPesquisa": "30.12.2026",
    "codigoChaveUsuario": ""  # Chave do usuário
}

print("Enviando requisição para operação 2076328...")

print("\nPayload enviado:")
resposta = integracao_curio("op2076328v2", payload)
print(payload)

# Listar todas as ausências reais
if resposta and "listaAusencia" in resposta:
    print("\nAusências encontradas:")
    ausencias = [a for a in resposta["listaAusencia"] if a.get("dataInicioAusencia")]
    if not ausencias:
        print("Nenhuma ausência encontrada.")
    else:
        for i, a in enumerate(ausencias, 1):
            print(f"{i}. {a['nomeAusencia']} | {a['dataInicioAusencia']} a {a['dataFimAusencia']} | Dias: {a['quantidadeDiaAusencia']} | Código: {a['codigoAusencia']} | Despacho: {a['indicadorDespachoEfetivado']}")
