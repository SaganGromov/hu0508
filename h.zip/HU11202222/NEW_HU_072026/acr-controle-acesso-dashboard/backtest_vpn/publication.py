"""Publicação atômica e versionada dos resultados e relatórios.

Modelo de publicação
--------------------
Todo artefato de uma execução é escrito primeiro em um diretório de
*staging* exclusivo do par ``job_id`` + ``fence``::

    <reports>/.staging/<job_id>-<fence>/

Depois da validação (arquivos obrigatórios presentes e não vazios) o
diretório é renomeado para o destino versionado::

    <reports>/published/<job_id>/

e somente então o ponteiro ``<reports>/published/latest.json`` é substituído
por ``os.replace``, que é atômico no mesmo sistema de arquivos. O ponteiro é
o **ponto de commit**: leitores enxergam o resultado anterior íntegro até a
troca e o novo resultado íntegro depois dela.

Consequências desejadas:

* uma execução parcial ou falha nunca sobrescreve um resultado válido;
* um worker antigo (``fence`` menor) não sobrescreve um resultado mais novo,
  porque o ponteiro guarda o ``fence`` publicado e a publicação é recusada
  quando o ``fence`` do chamador é menor;
* nomes de arquivo são derivados de identificadores validados, jamais de
  entrada livre — não há travessia de caminho nem colisão entre jobs.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path

POINTER_NAME = "latest.json"
PUBLISHED_DIRNAME = "published"
STAGING_DIRNAME = ".staging"

_SAFE_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")


class PublicationError(RuntimeError):
    """Falha de validação ou de troca atômica na publicação."""


def safe_identifier(value, label: str) -> str:
    """Aceita apenas identificadores seguros para compor caminhos."""
    text = str(value or "").strip()
    if not _SAFE_ID_RE.match(text) or ".." in text:
        raise PublicationError(
            "{0} inválido para compor caminho de publicação.".format(label)
        )
    return text


@dataclass(frozen=True)
class PublicationTarget:
    """Diretórios calculados de uma publicação."""

    reports_dir: Path
    staging_dir: Path
    published_dir: Path
    pointer_path: Path
    job_id: str
    fence: int


def prepare(reports_dir, job_id: str, fence: int) -> PublicationTarget:
    """Cria o diretório de staging exclusivo do par job+fence."""
    job = safe_identifier(job_id, "job_id")
    try:
        fence_value = int(fence)
    except (TypeError, ValueError):
        raise PublicationError("fence inválido para publicação.")
    if fence_value < 0:
        raise PublicationError("fence inválido para publicação.")
    base = Path(reports_dir).resolve()
    staging_root = base / STAGING_DIRNAME
    published_root = base / PUBLISHED_DIRNAME
    staging = staging_root / "{0}-{1}".format(job, fence_value)
    if staging.exists():
        shutil.rmtree(staging)
    staging.mkdir(parents=True, exist_ok=True)
    published_root.mkdir(parents=True, exist_ok=True)
    return PublicationTarget(
        reports_dir=base,
        staging_dir=staging,
        published_dir=published_root / job,
        pointer_path=published_root / POINTER_NAME,
        job_id=job,
        fence=fence_value,
    )


def read_pointer(reports_dir) -> dict:
    """Lê o ponteiro do último resultado publicado, se existir e for válido."""
    pointer = Path(reports_dir).resolve() / PUBLISHED_DIRNAME / POINTER_NAME
    if not pointer.is_file():
        return {}
    try:
        payload = json.loads(pointer.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return payload if isinstance(payload, dict) else {}


def validate_staging(target: PublicationTarget, required_files: list[str]) -> None:
    """Recusa publicar saída incompleta ou vazia."""
    missing = []
    for name in required_files:
        candidate = target.staging_dir / name
        if not candidate.is_file() or candidate.stat().st_size == 0:
            missing.append(name)
    if missing:
        raise PublicationError(
            "Publicação recusada: arquivos ausentes ou vazios em staging: {0}".format(
                ", ".join(sorted(missing))
            )
        )


def publish(
    target: PublicationTarget,
    *,
    required_files: list[str],
    metadata: dict,
) -> dict:
    """Valida, promove o diretório versionado e troca o ponteiro atomicamente."""
    validate_staging(target, required_files)
    previous = read_pointer(target.reports_dir)
    previous_fence = int(previous.get("fence") or -1)
    if previous.get("job_id") == target.job_id and previous_fence > target.fence:
        raise PublicationError(
            "Publicação recusada: já existe um resultado mais novo deste job "
            "(fence {0} > {1}).".format(previous_fence, target.fence)
        )

    if target.published_dir.exists():
        retired = target.published_dir.with_name(
            "{0}.superseded-{1}".format(target.published_dir.name, target.fence)
        )
        if retired.exists():
            shutil.rmtree(retired)
        os.replace(target.published_dir, retired)
        shutil.rmtree(retired, ignore_errors=True)
    os.replace(target.staging_dir, target.published_dir)

    pointer_payload = {
        **metadata,
        "job_id": target.job_id,
        "fence": target.fence,
        "directory": target.published_dir.name,
        "files": _relative_files(target.published_dir),
    }
    _atomic_write_json(target.pointer_path, pointer_payload)
    _cleanup_staging(target)
    return pointer_payload


def discard(target: PublicationTarget) -> None:
    """Remove o staging de uma execução que falhou, preservando o publicado."""
    shutil.rmtree(target.staging_dir, ignore_errors=True)


def resolve_published_file(reports_dir, filename: str) -> Path | None:
    """Resolve um arquivo do último resultado publicado, sem travessia.

    Retorna ``None`` quando o nome não está no ponteiro publicado, o que
    impede referência direta insegura a objetos e leitura de caminhos
    arbitrários.
    """
    base = Path(reports_dir).resolve()
    pointer = read_pointer(base)
    if not pointer:
        return None
    allowed = set(pointer.get("files") or [])
    name = str(filename or "")
    # Allowlist estrita: só nomes que o próprio ponteiro publicou. Isso barra
    # travessia de caminho e referência direta insegura a objetos, mesmo que o
    # nome venha de uma requisição HTTP.
    if name not in allowed:
        return None
    directory = str(pointer.get("directory") or "")
    try:
        safe_directory = safe_identifier(directory, "diretório publicado")
    except PublicationError:
        return None
    published_root = (base / PUBLISHED_DIRNAME).resolve()
    job_root = (published_root / safe_directory).resolve()
    candidate = (job_root / name).resolve()
    if not str(candidate).startswith(str(job_root) + os.sep):
        return None
    if candidate.is_symlink() or not candidate.is_file():
        return None
    return candidate


def _relative_files(directory: Path) -> list[str]:
    """Nomes relativos (POSIX) de todos os arquivos publicados, ordenados."""
    names = []
    for candidate in directory.rglob("*"):
        if candidate.is_symlink() or not candidate.is_file():
            continue
        names.append(candidate.relative_to(directory).as_posix())
    return sorted(names)


def _atomic_write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    handle, temporary = tempfile.mkstemp(dir=str(path.parent), prefix=".pointer-", suffix=".tmp")
    try:
        with os.fdopen(handle, "w", encoding="utf-8") as stream:
            json.dump(payload, stream, ensure_ascii=False, indent=2, sort_keys=True, default=str)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise


def _cleanup_staging(target: PublicationTarget) -> None:
    staging_root = target.reports_dir / STAGING_DIRNAME
    if not staging_root.is_dir():
        return
    prefix = "{0}-".format(target.job_id)
    for entry in staging_root.iterdir():
        if entry.name.startswith(prefix):
            shutil.rmtree(entry, ignore_errors=True)


def apply_retention(reports_dir, keep: int) -> list[str]:
    """Remove diretórios publicados antigos conforme política configurada.

    ``keep <= 0`` desativa a limpeza: nada é removido silenciosamente. O
    diretório referenciado pelo ponteiro nunca é removido.
    """
    if keep is None or int(keep) <= 0:
        return []
    base = Path(reports_dir).resolve()
    published_root = base / PUBLISHED_DIRNAME
    if not published_root.is_dir():
        return []
    pointer = read_pointer(base)
    protected = str(pointer.get("directory") or "")
    entries = [
        entry for entry in published_root.iterdir()
        if entry.is_dir() and entry.name != protected
    ]
    entries.sort(key=lambda item: item.stat().st_mtime, reverse=True)
    removed = []
    for entry in entries[max(0, int(keep) - 1):]:
        shutil.rmtree(entry, ignore_errors=True)
        removed.append(entry.name)
    return removed


__all__ = [
    "POINTER_NAME",
    "PUBLISHED_DIRNAME",
    "PublicationError",
    "PublicationTarget",
    "STAGING_DIRNAME",
    "apply_retention",
    "discard",
    "prepare",
    "publish",
    "read_pointer",
    "resolve_published_file",
    "safe_identifier",
    "validate_staging",
]
