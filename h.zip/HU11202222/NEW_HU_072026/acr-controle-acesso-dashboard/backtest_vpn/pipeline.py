"""Adaptadores do pipeline de dados usados pelos handlers de comando.

Dois adaptadores implementam a porta :class:`backtest_vpn.commands.BacktestPipeline`:

* :class:`Db2BacktestPipeline` — reutiliza exatamente as funções já existentes
  (``db2.connect``, ``rules.run_backtest_cases``, ``labelfree``, ``proxies``,
  ``bundle``) e apenas instrumenta fases e contadores de progresso. Nenhuma
  semântica de regra é alterada aqui.
* :class:`FixtureBacktestPipeline` — dados sintéticos, sem qualquer acesso a
  rede ou banco, para validar o fluxo completo offline. A saída é marcada com
  ``safe_fixture: true`` e nunca deve ser apresentada como relatório interno.
"""

from __future__ import annotations

import logging

from .commands import BacktestPipeline, PipelineRequest, PipelineResult
from .progress import (
    PHASE_CONNECTING,
    PHASE_CONSOLIDATING,
    PHASE_CORRELATING,
    PHASE_EVALUATING_RULES,
    PHASE_NORMALIZING,
    PHASE_QUERYING,
    PHASE_VALIDATING_SCHEMA,
)


class Db2BacktestPipeline(BacktestPipeline):
    """Executa o backtest real contra o DB2, em modo somente leitura.

    A construção da configuração continua sendo responsabilidade do CLI: este
    adaptador recebe uma fábrica que devolve ``(cfg, params)`` já validados
    para o período do job, de modo que o domínio não conhece variáveis de
    ambiente nem argumentos de linha de comando.
    """

    def __init__(
        self,
        *,
        config_factory,
        bundle_builder,
        logger: logging.Logger | None = None,
    ) -> None:
        self._config_factory = config_factory
        self._bundle_builder = bundle_builder
        self._logger = logger or logging.getLogger("backtest_vpn.pipeline")

    def execute(self, request: PipelineRequest) -> PipelineResult:
        from . import db2, rules as rules_mod

        progress = request.progress
        progress.start_phase(
            PHASE_CONNECTING, total_units=1,
            message="Abrindo conexão somente leitura com a fonte configurada.",
        )
        cfg, params = self._config_factory(request)
        connection = db2.connect(cfg.db2)
        progress.advance(1)
        try:
            progress.start_phase(
                PHASE_VALIDATING_SCHEMA, total_units=1,
                message="Conferindo as colunas exigidas nas tabelas configuradas.",
            )
            rules_mod.validate_configured_tables(connection, cfg)
            progress.advance(1)
            request.cancellation.raise_if_cancelled()

            metrics, cases = rules_mod.run_backtest_cases(
                connection, cfg, progress=progress, cancellation=request.cancellation,
                worker_limits=request.worker_limits,
            )
            progress.start_phase(
                PHASE_CONSOLIDATING,
                total_units=len(cases),
                message="Consolidando ocorrências das {0} regra(s) executada(s).".format(len(cases)),
            )
            for case in cases:
                progress.record_occurrences(
                    case.rule_id or case.name,
                    [item.get("severity") for item in (case.occurrences or [])],
                )
                progress.advance(1, rule_id=case.rule_id or None)
            bundle = self._bundle_builder(request, cfg, params, metrics, cases, connection)
        finally:
            db2.close(connection)
        return PipelineResult(
            bundle=bundle,
            metrics=dict(metrics),
            counters=progress.counters(),
        )


class FixtureBacktestPipeline(BacktestPipeline):
    """Pipeline sintético determinístico, sem rede e sem banco de dados."""

    def __init__(self, *, rows: list[dict] | None = None, logger: logging.Logger | None = None) -> None:
        self._rows = rows
        self._logger = logger or logging.getLogger("backtest_vpn.pipeline.fixture")

    def execute(self, request: PipelineRequest) -> PipelineResult:
        from .detection import DetectionConfig, run_event_rules
        from .report_model import safe_fixture_bundle

        progress = request.progress
        rows = list(self._rows if self._rows is not None else synthetic_rows(request))
        progress.start_phase(
            PHASE_QUERYING, total_units=None,
            message="Lendo a fixture sintética (nenhum acesso a banco é feito).",
        )
        progress.set_total(len(rows))
        for index in range(len(rows)):
            progress.advance(1, partition=str(index))
        progress.set_counter("database_rows_read", len(rows))

        progress.start_phase(
            PHASE_NORMALIZING, total_units=max(1, len(rows)),
            message="Normalizando e deduplicando a fixture.",
        )
        detection = DetectionConfig(enabled_rules=tuple(request.rules))
        detected, quality = run_event_rules(rows, detection)
        progress.set_position(max(1, len(rows)))
        progress.merge_counters(quality)

        progress.start_phase(
            PHASE_EVALUATING_RULES, total_units=max(1, len(request.rules)),
            message="Avaliando {0} regra(s) sobre a fixture.".format(len(request.rules)),
        )
        for rule_id in request.rules:
            occurrences = detected.get(rule_id) or []
            progress.record_occurrences(rule_id, [item.get("severity") for item in occurrences])
            progress.advance(1, rule_id=rule_id)

        progress.start_phase(
            PHASE_CORRELATING, total_units=1,
            message="Correlação OpenAM não se aplica à fixture sintética.",
        )
        progress.advance(1)
        progress.start_phase(PHASE_CONSOLIDATING, total_units=1)
        progress.advance(1)

        bundle = safe_fixture_bundle()
        params = dict(bundle.get("parameters") or {})
        params.update({
            "start": request.period.start_timestamp,
            "end": request.period.end_exclusive_timestamp,
            "timezone": request.period.timezone_name,
            "enabled_rules": list(request.rules),
        })
        bundle["parameters"] = params
        bundle["safe_fixture"] = True
        return PipelineResult(bundle=bundle, metrics={}, counters=progress.counters())


def synthetic_rows(request: PipelineRequest) -> list[dict]:
    """Linhas sintéticas determinísticas, sem qualquer dado de pessoa real."""
    start = request.period.start_datetime
    day = start.date().isoformat()
    return [
        {
            "USER_KEY": "T0000001", "EVENT_TS": "{0} 09:00:00".format(day),
            "SOURCE_IP": "192.0.2.10", "CORPORATE_IP": "10.0.0.9",
            "HOSTNAME": "EST-FIXTURE-1", "DEVICE_ID": "DEV-FIXTURE-A",
        },
        {
            "USER_KEY": "T0000001", "EVENT_TS": "{0} 10:00:00".format(day),
            "SOURCE_IP": "198.51.100.20", "CORPORATE_IP": "10.0.0.9",
            "HOSTNAME": "EST-FIXTURE-1", "DEVICE_ID": "DEV-FIXTURE-A",
        },
        {
            "USER_KEY": "T0000001", "EVENT_TS": "{0} 11:00:00".format(day),
            "SOURCE_IP": "203.0.113.30", "CORPORATE_IP": "10.0.0.9",
            "HOSTNAME": "EST-FIXTURE-1", "DEVICE_ID": "DEV-FIXTURE-B",
        },
        {
            "USER_KEY": "T0000002", "EVENT_TS": "{0} 12:00:00".format(day),
            "SOURCE_IP": "192.0.2.11", "CORPORATE_IP": "10.0.0.10",
            "HOSTNAME": "EST-FIXTURE-2", "DEVICE_ID": "DEV-FIXTURE-B",
        },
    ]


def build_period_config_factory(base_args, base_dir, build_config):
    """Fábrica que reconstrói a configuração do CLI para o período do job."""

    def factory(request: PipelineRequest):
        args = replace_period(base_args, request)
        cfg, jdbc_url, credentials_path = build_config(args, base_dir)
        from .cli import _parameters_payload

        params = _parameters_payload(cfg)
        params["period"] = request.period.as_payload()
        params["configuration_hash"] = request.job.config_hash
        return cfg, params

    return factory


def replace_period(args, request: PipelineRequest):
    """Copia os argumentos ajustando somente o período e as regras do job."""
    import copy

    clone = copy.copy(args)
    clone.start = request.period.start_timestamp
    clone.end = request.period.end_exclusive_timestamp
    clone.rules = ",".join(request.rules)
    return clone


__all__ = [
    "Db2BacktestPipeline",
    "FixtureBacktestPipeline",
    "build_period_config_factory",
    "replace_period",
    "synthetic_rows",
]
