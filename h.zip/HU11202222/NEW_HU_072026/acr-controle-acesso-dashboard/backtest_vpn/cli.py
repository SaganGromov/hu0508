"""CLI do backtest local de VPN sobre DB2."""

import argparse
import os
import sys
from dataclasses import asdict, replace
from datetime import datetime
from pathlib import Path

from . import bundle as bundle_mod
from . import config as cfg_mod
from . import db2, htmlreport, labelfree, mta as mta_mod, pseudonym, report, rules
from .commands import CommandValidationError

KNOWN_SUBCOMMANDS = {
    "run", "labelfree", "full", "report-html", "generate-reports",
    "run-initial", "run-scheduled", "run-job", "worker", "job-status", "schedule-status",
    "extract", "parity", "inject", "adjudicate", "bundle",
}


def _parse_int_list(text):
    if isinstance(text, list):
        return text
    return [int(part.strip()) for part in str(text).split(",") if part.strip()]


def _add_common_flags(parser, require_period=True):
    parser.add_argument("--start", required=require_period, help="Inicio do periodo (YYYY-MM-DD ou 'YYYY-MM-DD HH:MM:SS')")
    parser.add_argument("--end", required=require_period, help="Fim exclusivo do periodo (YYYY-MM-DD ou 'YYYY-MM-DD HH:MM:SS')")
    parser.add_argument("--jdbc-url", help="URL JDBC do DB2 (env DB2_JDBC_URL)")
    parser.add_argument("--credentials-file", help="Arquivo JSON de credenciais (env DB2_CREDENTIALS_FILE)")
    parser.add_argument("--schema", help="Schema da tabela VPN (env DB2_SCHEMA)")
    parser.add_argument("--table", help="Tabela VPN (env DB2_TABLE)")
    parser.add_argument("--user-column", help="Coluna da chave do usuario (env VPN_USER_COLUMN)")
    parser.add_argument("--timestamp-column", help="Coluna de timestamp (env VPN_TIMESTAMP_COLUMN)")
    parser.add_argument("--source-ip-column", help="Coluna de IP de origem (env VPN_SOURCE_IP_COLUMN)")
    parser.add_argument("--corporate-ip-column", help="Coluna de IP corporativo (env VPN_CORPORATE_IP_COLUMN)")
    parser.add_argument("--hostname-column", help="Coluna de hostname (env VPN_HOSTNAME_COLUMN)")
    parser.add_argument("--device-column", help="Coluna de ID de dispositivo (env VPN_DEVICE_COLUMN)")
    parser.add_argument("--physical-schema", help="Schema da tabela de login fisico (env PHYSICAL_SCHEMA)")
    parser.add_argument("--physical-table", help="Tabela de login fisico (env PHYSICAL_TABLE); sem ela R5 e pulado")
    parser.add_argument("--physical-user-column", help="Coluna de usuario na tabela fisica (env PHYSICAL_USER_COLUMN)")
    parser.add_argument("--physical-timestamp-column", help="Coluna de timestamp na tabela fisica (env PHYSICAL_TIMESTAMP_COLUMN)")
    parser.add_argument("--physical-network-column", help="Coluna de rede na tabela fisica (env PHYSICAL_NETWORK_COLUMN)")
    parser.add_argument("--physical-network-value", help="Valor esperado da coluna de rede (env PHYSICAL_NETWORK_VALUE)")
    parser.add_argument("--no-mta-physical", action="store_true", help="Desliga a deteccao 'VPN + rede fisica' via MTA_AUT_CLI_TRAN")
    parser.add_argument("--mta-schema", help="Schema da tabela MTA (env MTA_SCHEMA, padrao DB2PEP)")
    parser.add_argument("--mta-table", help="Tabela MTA (env MTA_TABLE, padrao MTA_AUT_CLI_TRAN)")
    parser.add_argument("--mta-decision-nodes", help="Lista CSV de NM_ETP considerados 'login efetivo' (env MTA_DECISION_NODES)")
    parser.add_argument("--physical-ip-cidrs", help="Faixas privadas consideradas 'rede fisica' (env PHYSICAL_IP_CIDRS)")
    parser.add_argument("--mta-delta-minutes", type=int, help="Δ em minutos ao redor de cada evento VPN (env MTA_DELTA_MINUTES, padrao 15)")
    parser.add_argument("--mta-max-users", type=int, help="Maximo de usuarios distintos verificados por rodada (env MTA_MAX_USERS, padrao 300)")
    parser.add_argument("--mta-users-per-batch", type=int, help="Usuarios agrupados por statement em MTA (env MTA_USERS_PER_BATCH, padrao 12)")
    parser.add_argument("--mta-fetch-first-rows", type=int, help="Limite completo por consulta MTA; excedê-lo falha sem publicar parcial (env MTA_FETCH_FIRST_ROWS, padrão 400)")
    parser.add_argument("--mta-chunk-hours", type=int, help="Tamanho em horas dos chunks temporais para respeitar ASUTIME (env MTA_CHUNK_HOURS, padrao 24)")
    parser.add_argument("--active-window-hours", type=int, default=8, help="Janela de sessao ativa em horas (1..168, padrao 8)")
    parser.add_argument("--distinct-limit", type=int, help="Sobrescreve os limites de valores distintos de R2 e R3 (padrão configurado: 2)")
    parser.add_argument("--daily-login-limit", type=int, help="Limite de R4; somente 2 é aceito (padrão configurado: 2)")
    parser.add_argument("--rules-config", help="JSON local com parâmetros e allowlists das regras (env BACKTEST_RULES_CONFIG)")
    parser.add_argument("--rules", help="Regras habilitadas, separadas por vírgula, por exemplo R1,R4,R7 (env BACKTEST_ENABLED_RULES)")
    parser.add_argument("--sample-limit", type=int, default=50, help="Tamanho maximo das amostras (padrao 50)")
    parser.add_argument("--output-dir", default="reports", help="Diretorio de saida dos relatorios (padrao: reports)")
    parser.add_argument("--sweep-distinct-limits", default="1,2,3,5,8,13,21")
    parser.add_argument("--sweep-daily-limits", default="5,10,20,50,100")
    parser.add_argument("--sweep-window-hours", default="1,2,4,8,12,24")
    parser.add_argument("--stability-granularity", default="week")
    parser.add_argument("--velocity-minutes", type=int, default=5)
    parser.add_argument("--dormancy-days", type=int, default=60)
    parser.add_argument("--seed", type=int, default=20260719)
    parser.add_argument("--clean-cohort-min-events", type=int, default=20)
    parser.add_argument("--pseudonym-key", default=".pseudonym_key")
    parser.add_argument(
        "--no-pseudonymize",
        action="store_true",
        help="Desativa a pseudonimizacao HMAC (mostra as matriculas explicitamente no bundle).",
    )


def build_parser():
    parser = argparse.ArgumentParser(prog="backtest-vpn", description="Backtest local (somente leitura) das regras de deteccao de VPN sobre dados historicos em DB2.")
    sub = parser.add_subparsers(dest="command")
    run_p = sub.add_parser("run", help="Relatorio legado")
    _add_common_flags(run_p)
    lab_p = sub.add_parser("labelfree", help="Fase A: metricas label-free e proxies")
    _add_common_flags(lab_p)
    full_p = sub.add_parser("full", help="Executa run legado + labelfree + bundle")
    _add_common_flags(full_p)
    html_p = sub.add_parser("report-html", help="Gera HTML standalone e fragmento a partir do bundle")
    html_p.add_argument("--bundle", required=True)
    html_p.add_argument("--out-dir", default="reports/html")
    group = html_p.add_mutually_exclusive_group()
    group.add_argument("--standalone-only", action="store_true")
    group.add_argument("--fragment-only", action="store_true")
    html_p.add_argument("--lang", default="pt-BR")
    html_p.add_argument("--title", default="Relatorio Backtest VPN")
    dossier_p = sub.add_parser("generate-reports", help="Gera o dossiê LaTeX e o workbook XLSX a partir de um bundle")
    dossier_p.add_argument("--bundle", help="Bundle JSON; se omitido, usa o mais recente de reports/")
    dossier_p.add_argument("--output-dir", default="reports")
    dossier_p.add_argument("--employee-data", help="JSON opcional, autorizado, indexado por usuário")
    dossier_p.add_argument("--safe-fixture", action="store_true", help="Gera somente com fixture sintética")
    dossier_p.add_argument("--no-csv-package", action="store_true", help="Não gera o pacote de detalhamento em CSV")
    dossier_p.add_argument("--csv-bom", action="store_true", help="Escreve os CSV com BOM UTF-8 (compatibilidade com Excel pt-BR)")
    dossier_p.add_argument(
        "--formats",
        help=(
            "Formatos gerados, separados por vírgula (tex,xlsx,csv). O padrão gera "
            "os três; o modelo normalizado é sempre gravado."
        ),
    )

    initial_p = sub.add_parser(
        "run-initial",
        help="Enfileira (e por padrão executa) o backtest padrão de 33 dias após a implantação",
    )
    _add_common_flags(initial_p, require_period=False)
    initial_p.add_argument("--enqueue-only", action="store_true", help="Apenas enfileira; a execução fica para o worker")
    initial_p.add_argument("--fixture", action="store_true", help="Usa o pipeline sintético, sem acesso a banco")

    scheduled_p = sub.add_parser(
        "run-scheduled",
        help="Avalia a política de 24 horas e executa a janela devida, se houver",
    )
    _add_common_flags(scheduled_p, require_period=False)
    scheduled_p.add_argument("--enqueue-only", action="store_true", help="Apenas enfileira a janela devida")
    scheduled_p.add_argument("--force", action="store_true", help="Ignora a marca d'água e executa a janela devida agora")
    scheduled_p.add_argument("--fixture", action="store_true", help="Usa o pipeline sintético, sem acesso a banco")

    runjob_p = sub.add_parser(
        "run-job",
        help="Reserva e executa um job já enfileirado no estado compartilhado",
    )
    _add_common_flags(runjob_p, require_period=False)
    runjob_p.add_argument("--job-id", required=True, help="Identificador do job a reservar e executar")
    runjob_p.add_argument("--fixture", action="store_true", help="Usa o pipeline sintético, sem acesso a banco")

    worker_p = sub.add_parser("worker", help="Reserva e executa jobs pendentes do estado compartilhado")
    _add_common_flags(worker_p, require_period=False)
    worker_p.add_argument("--once", action="store_true", help="Processa no máximo um job e encerra")
    worker_p.add_argument("--max-jobs", type=int, help="Número máximo de jobs processados antes de encerrar")
    worker_p.add_argument("--poll-seconds", type=float, default=15.0, help="Intervalo entre consultas à fila (padrão 15s)")
    worker_p.add_argument("--drain", action="store_true", help="Encerra quando a fila ficar vazia")
    worker_p.add_argument("--fixture", action="store_true", help="Usa o pipeline sintético, sem acesso a banco")

    status_p = sub.add_parser("job-status", help="Mostra o estado de um job lido do estado compartilhado")
    status_p.add_argument("--job-id", help="Identificador do job; se omitido, lista as execuções recentes")
    status_p.add_argument("--limit", type=int, default=10, help="Quantidade de execuções recentes listadas")

    sched_status_p = sub.add_parser("schedule-status", help="Mostra a decisão do agendador e a marca d'água publicada")

    for name in ("extract", "parity", "inject", "bundle"):
        p = sub.add_parser(name, help="Stub nao implementado nesta rodada")
        p.add_argument("args", nargs="*")
    adj = sub.add_parser("adjudicate", help="Stub nao implementado nesta rodada")
    adj.add_argument("args", nargs="*")
    return parser


def _opt(cli_value, env_name, default=None):
    if cli_value is not None and str(cli_value).strip() != "":
        return cli_value
    env_value = os.environ.get(env_name)
    if env_value is not None and env_value.strip() != "":
        return env_value
    return default


def _build_config(args, base_dir):
    jdbc_url = _opt(args.jdbc_url, "DB2_JDBC_URL", cfg_mod.DEFAULT_JDBC_URL)
    credentials_file = _opt(args.credentials_file, "DB2_CREDENTIALS_FILE", cfg_mod.DEFAULT_CREDENTIALS_FILE)
    if not jdbc_url:
        raise ValueError(
            "DB2_JDBC_URL deve ser configurada explicitamente; não há destino "
            "DB2 incorporado ao código."
        )

    schema = cfg_mod.normalize_identifier(_opt(args.schema, "DB2_SCHEMA", "DB2PEP"), "--schema")
    table = cfg_mod.normalize_identifier(_opt(args.table, "DB2_TABLE", "AUT_CPTV"), "--table")
    user_column = cfg_mod.normalize_identifier(_opt(args.user_column, "VPN_USER_COLUMN", "CD_USU_AUT"), "--user-column")
    timestamp_column = cfg_mod.normalize_identifier(_opt(args.timestamp_column, "VPN_TIMESTAMP_COLUMN", "TS_TRAN"), "--timestamp-column")
    source_ip_column = cfg_mod.normalize_identifier(_opt(args.source_ip_column, "VPN_SOURCE_IP_COLUMN", "CD_END_LGC_OGM"), "--source-ip-column")
    corporate_ip_column = cfg_mod.normalize_identifier(_opt(args.corporate_ip_column, "VPN_CORPORATE_IP_COLUMN", "CD_END_LGC_CPTV"), "--corporate-ip-column")
    hostname_column = cfg_mod.normalize_identifier(_opt(args.hostname_column, "VPN_HOSTNAME_COLUMN", "NM_DSVO"), "--hostname-column")
    device_column = cfg_mod.normalize_identifier(_opt(args.device_column, "VPN_DEVICE_COLUMN", "CD_IDFC_DSVO"), "--device-column")

    start = cfg_mod.parse_datetime(args.start)
    end = cfg_mod.parse_datetime(args.end)
    if end <= start:
        raise ValueError("--end deve ser maior que --start.")
    if not 1 <= args.active_window_hours <= 168:
        raise ValueError("--active-window-hours deve estar entre 1 e 168.")
    for label, value in (("--distinct-limit", args.distinct_limit), ("--daily-login-limit", args.daily_login_limit), ("--sample-limit", args.sample_limit), ("--velocity-minutes", args.velocity_minutes), ("--dormancy-days", args.dormancy_days), ("--clean-cohort-min-events", args.clean_cohort_min_events)):
        if value is not None and value <= 0:
            raise ValueError("{0} deve ser um inteiro positivo.".format(label))
    if args.daily_login_limit is not None and args.daily_login_limit != 2:
        raise ValueError(
            "--daily-login-limit deve ser 2: R4 sinaliza exatamente três ou mais logins VPN no dia."
        )

    physical = None
    physical_table_raw = _opt(args.physical_table, "PHYSICAL_TABLE")
    if physical_table_raw:
        physical_schema = cfg_mod.normalize_identifier(_opt(args.physical_schema, "PHYSICAL_SCHEMA", schema), "--physical-schema")
        physical_table = cfg_mod.normalize_identifier(physical_table_raw, "--physical-table")
        physical_user_column = cfg_mod.normalize_identifier(_opt(args.physical_user_column, "PHYSICAL_USER_COLUMN", user_column), "--physical-user-column")
        physical_timestamp_column = cfg_mod.normalize_identifier(_opt(args.physical_timestamp_column, "PHYSICAL_TIMESTAMP_COLUMN", timestamp_column), "--physical-timestamp-column")
        network_column_raw = _opt(args.physical_network_column, "PHYSICAL_NETWORK_COLUMN")
        network_value = _opt(args.physical_network_value, "PHYSICAL_NETWORK_VALUE")
        if bool(network_column_raw) != bool(network_value):
            raise ValueError("--physical-network-column e --physical-network-value devem ser informados juntos.")
        network_column = cfg_mod.normalize_identifier(network_column_raw, "--physical-network-column") if network_column_raw else None
        physical = cfg_mod.PhysicalLoginTableConfig(physical_schema, physical_table, physical_user_column, physical_timestamp_column, network_column, network_value)

    host, port, database = cfg_mod.parse_jdbc_url(jdbc_url)
    credentials_path = (
        cfg_mod.resolve_path(credentials_file, base_dir)
        if credentials_file
        else None
    )
    env_username = os.environ.get("DB2_USERNAME") or os.environ.get("DB2_USER")
    env_password = os.environ.get("DB2_PASSWORD") or os.environ.get("DB2_PASS")
    if env_username and env_password:
        username, password = str(env_username), str(env_password)
    elif credentials_path is not None:
        username, password = cfg_mod.load_credentials(credentials_path)
    else:
        raise ValueError(
            "Configure DB2_USERNAME e DB2_PASSWORD ou DB2_CREDENTIALS_FILE."
        )

    rules_config_path = _opt(getattr(args, "rules_config", None), "BACKTEST_RULES_CONFIG")
    detection_cfg = cfg_mod.load_detection_config(
        cfg_mod.resolve_path(rules_config_path, base_dir) if rules_config_path else None
    )
    enabled_raw = _opt(getattr(args, "rules", None), "BACKTEST_ENABLED_RULES")
    if enabled_raw:
        enabled = tuple(part.strip().upper() for part in str(enabled_raw).split(",") if part.strip())
        allowed = {"R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8", "R9"}
        unknown = sorted(set(enabled) - allowed)
        if unknown:
            raise ValueError("Regras desconhecidas em --rules: {0}".format(", ".join(unknown)))
        detection_cfg = replace(detection_cfg, enabled_rules=enabled)
    if args.distinct_limit is not None:
        detection_cfg = replace(
            detection_cfg,
            r2_distinct_hostname_limit=args.distinct_limit,
            r3_distinct_device_limit=args.distinct_limit,
        )
    if args.daily_login_limit is not None:
        detection_cfg = replace(
            detection_cfg,
            r4_vpn_login_limit=args.daily_login_limit,
        )

    mta_cfg = None
    if not getattr(args, "no_mta_physical", False):
        env_overrides = {}
        for arg_name, env_name in (
            ("mta_schema", "MTA_SCHEMA"),
            ("mta_table", "MTA_TABLE"),
            ("mta_decision_nodes", "MTA_DECISION_NODES"),
            ("physical_ip_cidrs", "PHYSICAL_IP_CIDRS"),
            ("mta_delta_minutes", "MTA_DELTA_MINUTES"),
            ("mta_max_users", "MTA_MAX_USERS"),
            ("mta_users_per_batch", "MTA_USERS_PER_BATCH"),
            ("mta_fetch_first_rows", "MTA_FETCH_FIRST_ROWS"),
            ("mta_chunk_hours", "MTA_CHUNK_HOURS"),
        ):
            value = getattr(args, arg_name, None)
            if value is not None and str(value) != "":
                env_overrides[env_name] = str(value)
        merged_env = dict(os.environ)
        merged_env.update(env_overrides)
        mta_cfg = mta_mod.load_mta_config_from_env(env=merged_env)

    cfg = cfg_mod.BacktestConfig(
        db2=cfg_mod.Db2ConnectionConfig(hostname=host, port=port, database=database, username=username, password=password),
        vpn_table=cfg_mod.VpnTableConfig(schema=schema, table=table, user_column=user_column, timestamp_column=timestamp_column, source_ip_column=source_ip_column, corporate_ip_column=corporate_ip_column, hostname_column=hostname_column, device_column=device_column),
        physical_table=physical,
        start=start,
        end=end,
        active_window_hours=args.active_window_hours,
        distinct_limit=max(
            detection_cfg.r2_distinct_hostname_limit,
            detection_cfg.r3_distinct_device_limit,
        ),
        daily_login_limit=detection_cfg.r4_vpn_login_limit,
        sample_limit=args.sample_limit,
        output_dir=cfg_mod.resolve_path(args.output_dir, base_dir),
        sweep_distinct_limits=_parse_int_list(args.sweep_distinct_limits),
        sweep_daily_limits=_parse_int_list(args.sweep_daily_limits),
        sweep_window_hours=_parse_int_list(args.sweep_window_hours),
        stability_granularity=args.stability_granularity,
        velocity_minutes=args.velocity_minutes,
        dormancy_days=args.dormancy_days,
        seed=args.seed,
        clean_cohort_min_events=args.clean_cohort_min_events,
        mta_table=mta_cfg,
        detection=detection_cfg,
    )
    return cfg, jdbc_url, credentials_path


def _parameters_payload(cfg):
    physical = None
    if cfg.physical_table is not None:
        physical = {
            "schema": cfg.physical_table.schema, "table": cfg.physical_table.table,
            "user_column": cfg.physical_table.user_column, "timestamp_column": cfg.physical_table.timestamp_column,
            "network_column": cfg.physical_table.network_column, "network_value": cfg.physical_table.network_value,
        }
    mta = None
    if cfg.mta_table is not None:
        mta = {
            "schema": cfg.mta_table.schema,
            "table": cfg.mta_table.table,
            "decision_nodes": list(cfg.mta_table.decision_nodes),
            "delta_minutes": cfg.mta_table.delta_minutes,
            "max_users_per_run": cfg.mta_table.max_users_per_run,
            "users_per_batch": cfg.mta_table.users_per_batch,
            "fetch_first_rows": cfg.mta_table.fetch_first_rows,
            "physical_ip_cidrs": [str(n) for n in cfg.mta_table.ip_networks],
        }
    return {
        "start": cfg.start.strftime("%Y-%m-%d %H:%M:%S"), "end": cfg.end.strftime("%Y-%m-%d %H:%M:%S"),
        "data_source": "DB2 configurado externamente; endereço e credenciais omitidos",
        "vpn_schema": cfg.vpn_table.schema, "vpn_table": cfg.vpn_table.table,
        "user_column": cfg.vpn_table.user_column, "timestamp_column": cfg.vpn_table.timestamp_column,
        "source_ip_column": cfg.vpn_table.source_ip_column, "corporate_ip_column": cfg.vpn_table.corporate_ip_column,
        "hostname_column": cfg.vpn_table.hostname_column, "device_column": cfg.vpn_table.device_column,
        "physical_table_config": physical, "active_window_hours": cfg.active_window_hours,
        "mta_table_config": mta,
        "distinct_limit": cfg.distinct_limit, "daily_login_limit": cfg.daily_login_limit,
        "sample_limit": cfg.sample_limit, "output_dir": str(cfg.output_dir),
        "sweep_distinct_limits": cfg.sweep_distinct_limits, "sweep_daily_limits": cfg.sweep_daily_limits,
        "sweep_window_hours": cfg.sweep_window_hours, "stability_granularity": cfg.stability_granularity,
        "velocity_minutes": cfg.velocity_minutes, "dormancy_days": cfg.dormancy_days,
        "seed": cfg.seed, "clean_cohort_min_events": cfg.clean_cohort_min_events,
        "timezone": cfg.detection.timezone,
        "enabled_rules": list(cfg.detection.enabled_rules),
        "rule_parameters": {
            "r1_min_distinct_ips": cfg.detection.r1_min_distinct_ips,
            "r2_distinct_hostname_limit": cfg.detection.r2_distinct_hostname_limit,
            "r3_distinct_device_limit": cfg.detection.r3_distinct_device_limit,
            "r4_vpn_login_limit": cfg.detection.r4_vpn_login_limit,
            "r4_high_severity_above": cfg.detection.r4_high_severity_above,
            "r4_critical_severity_above": cfg.detection.r4_critical_severity_above,
            "device_windows_days": list(cfg.detection.device_windows_days),
            "multi_device_window_minutes": cfg.detection.multi_device_window_minutes,
            "multi_device_min_devices": cfg.detection.multi_device_min_devices,
            "rapid_ip_window_minutes": cfg.detection.rapid_ip_window_minutes,
            "rapid_ip_min_distinct": cfg.detection.rapid_ip_min_distinct,
        },
        "allowlist_effects": {
            "shared_device_entries": len(cfg.detection.shared_device_allowlist),
            "excluded_user_entries": len(cfg.detection.excluded_user_allowlist),
            "corporate_ip_network_entries": len(cfg.detection.corporate_ip_networks),
            "vpn_ip_network_entries": len(cfg.detection.vpn_ip_networks),
        },
    }


def _connect_and_run_cases(cfg):
    conn = db2.connect(cfg.db2)
    try:
        metrics, cases = rules.run_backtest_cases(conn, cfg)
    finally:
        db2.close(conn)
    return metrics, cases


def _write_legacy_reports(cfg, params, metrics, cases, stamp, generated_at):
    payload = {"generated_at": generated_at, "parameters": params, "metrics": metrics, "cases": [asdict(case) for case in cases]}
    cfg.output_dir.mkdir(parents=True, exist_ok=True)
    json_path = cfg.output_dir / "backtest_vpn_{0}.json".format(stamp)
    md_path = cfg.output_dir / "backtest_vpn_{0}.md".format(stamp)
    report.write_json(json_path, payload)
    report.write_markdown(md_path, payload)
    print("Relatorios gerados: {0} {1}".format(json_path, md_path))
    return json_path, md_path


def _bundle_builder_factory(args, base_dir):
    """Constrói o bundle reaproveitando labelfree/proxies na mesma conexão."""

    def builder(request, cfg, params, metrics, cases, conn):
        from . import proxies as proxies_mod

        progress = request.progress
        progress.set_subphase("métricas label-free e proxies")
        if args.no_pseudonymize:
            pz = pseudonym.IdentityPseudonymizer()
        else:
            key = pseudonym.load_or_create_key(base_dir / ".pseudonym_key", repo_dir=base_dir)
            pz = pseudonym.Pseudonymizer(key)
        lf = labelfree.run_labelfree(
            conn, cfg, legacy_metrics=metrics, legacy_cases=cases, pseudonymizer=pz
        )
        try:
            proxy_payload, agreement = proxies_mod.run_proxies(
                conn, cfg, lf["base_stats"], lf["flag_sets"], pseudonymizer=pz
            )
        except Exception as exc:
            message = str(exc)
            if "CLI0106E" in message or "Connection is closed" in message:
                # Reabre a conexão apenas em falha transitória documentada.
                conn.reconnect()
                proxy_payload, agreement = proxies_mod.run_proxies(
                    conn, cfg, lf["base_stats"], lf["flag_sets"], pseudonymizer=pz
                )
            else:
                raise
        lf_public = {
            key: value for key, value in lf.items()
            if key not in ("base_stats", "daily_rows", "flag_sets", "r4_user_days")
        }
        generated_at = request.job.created_at or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        payload = bundle_mod.build_results_bundle(
            cfg, params, metrics, cases, lf_public, proxy_payload, agreement, pz,
            base_dir.parent, generated_at=generated_at,
        )
        stamp = _stamp_from_job(request)
        _write_legacy_reports(cfg, params, metrics, cases, stamp, generated_at)
        path = bundle_mod.write_results_bundle(cfg.output_dir, stamp, payload)
        # A linha abaixo é consumida pelo orquestrador da aplicação web.
        print("Bundle gerado: {0}".format(path))
        return payload

    return builder


def _stamp_from_job(request):
    """Stamp determinístico por execução, estável entre tentativas do job."""
    created = str(request.job.created_at or "")
    digits = "".join(char for char in created if char.isdigit())
    if len(digits) >= 14:
        return "{0}_{1}".format(digits[:8], digits[8:14])
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def _build_runtime(args, base_dir, *, fixture=False):
    """Monta o runtime com o pipeline adequado ao ponto de entrada."""
    from acr_controle_acesso_dashboard import __version__ as application_version
    from . import pipeline as pipeline_mod
    from . import runtime as runtime_mod

    if fixture:
        pipeline = pipeline_mod.FixtureBacktestPipeline()
    else:
        pipeline = pipeline_mod.Db2BacktestPipeline(
            config_factory=pipeline_mod.build_period_config_factory(args, base_dir, _build_config),
            bundle_builder=_bundle_builder_factory(args, base_dir),
        )
    reports_dir = getattr(args, "output_dir", None)
    return runtime_mod.build_runtime(
        application_version=application_version,
        base_dir=base_dir,
        pipeline=pipeline,
        reports_dir=cfg_mod.resolve_path(reports_dir, base_dir) if reports_dir else None,
    )


def _print_json(payload):
    import json as _json

    print(_json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True, default=str))


def _command_run_initial(args, base_dir):
    from . import runtime as runtime_mod

    runtime = _build_runtime(args, base_dir, fixture=bool(getattr(args, "fixture", False)))
    rules = _selected_rules(args)
    job = runtime_mod.ensure_initial_job(runtime, rules=rules)
    if job is None:
        print(
            "Backtest inicial não é necessário: já existe resultado publicado ou "
            "a execução inicial está desabilitada."
        )
        return 0
    print("Job inicial: {0} (período {1} a {2}, {3} dias)".format(
        job.job_id,
        job.period.get("start_date"),
        job.period.get("end_date_inclusive"),
        job.period.get("total_calendar_days"),
    ))
    if args.enqueue_only:
        print("Execução delegada ao worker; nada é executado por este processo.")
        return 0
    return _claim_and_report(runtime, job.job_id)


def _command_run_scheduled(args, base_dir):
    from . import runtime as runtime_mod

    runtime = _build_runtime(args, base_dir, fixture=bool(getattr(args, "fixture", False)))
    rules = _selected_rules(args)
    if getattr(args, "force", False):
        period = runtime.default_period_for("scheduled")
        job = runtime.enqueue_scheduled(period, rules=rules)
        print("Janela forçada: {0} a {1}".format(period.start_text, period.end_inclusive_text))
        if args.enqueue_only:
            return 0
        return _claim_and_report(runtime, job.job_id)
    payload = runtime_mod.run_scheduled_if_due(
        runtime, rules=rules, execute=not args.enqueue_only
    )
    _print_json(payload)
    return 0


def _claim_and_report(runtime, job_id):
    from .commands import JobNotClaimable

    try:
        final = runtime.claim_and_run(job_id)
    except JobNotClaimable as exc:
        print("Job não reservado por este processo: {0}".format(exc))
        return 0
    except Exception as exc:  # noqa: BLE001 - estado já registrado no store
        print("Execução falhou: {0}".format(exc), file=sys.stderr)
        return 1
    print("Estado final do job {0}: {1}".format(final.job_id, final.state))
    return 0


def _command_run_job(args, base_dir):
    """Executa um job já enfileirado; usado pela rota HTTP autenticada.

    A rota web enfileira o comando manual e delega a execução a este
    subcomando, de modo que HTTP, CLI, worker e agendador percorrem o mesmo
    handler e o status permanece legível de qualquer pod.
    """
    runtime = _build_runtime(args, base_dir, fixture=bool(getattr(args, "fixture", False)))
    record = runtime.store.get(args.job_id)
    if record is None:
        print("Job não encontrado no estado compartilhado.", file=sys.stderr)
        return 2
    print("Executando job {0} ({1} a {2}, {3} dias)".format(
        record.job_id,
        (record.period or {}).get("start_date"),
        (record.period or {}).get("end_date_inclusive"),
        (record.period or {}).get("total_calendar_days"),
    ))
    return _claim_and_report(runtime, record.job_id)


def _command_worker(args, base_dir):
    from . import runtime as runtime_mod

    runtime = _build_runtime(args, base_dir, fixture=bool(getattr(args, "fixture", False)))
    loop = runtime_mod.WorkerLoop(runtime)
    max_jobs = 1 if args.once else args.max_jobs
    processed = loop.run(
        max_jobs=max_jobs,
        poll_seconds=args.poll_seconds,
        idle_limit=1 if (args.once or args.drain) else None,
    )
    print("Jobs processados nesta execução do worker: {0}".format(processed))
    return 0


def _command_job_status(args, base_dir):
    runtime = _build_runtime(args, base_dir, fixture=True)
    if args.job_id:
        payload = runtime.status(args.job_id)
        if payload is None:
            print("Job não encontrado no estado compartilhado.", file=sys.stderr)
            return 1
        _print_json(payload)
        return 0
    _print_json({
        "store_backend": runtime.store.backend_name,
        "cluster_safe": runtime.store.cluster_safe,
        "recent": runtime.recent(args.limit),
    })
    return 0


def _command_schedule_status(args, base_dir):
    runtime = _build_runtime(args, base_dir, fixture=True)
    decision = runtime.evaluate_schedule()
    _print_json({
        "decision": decision.as_payload(),
        "watermark": runtime.watermark(),
        "dashboard": runtime.dashboard_state(),
    })
    return 0


def _selected_rules(args):
    raw = _opt(getattr(args, "rules", None), "BACKTEST_ENABLED_RULES")
    return raw if raw else None


def _command_run(args, base_dir):
    cfg, jdbc_url, credentials_path = _build_config(args, base_dir)
    metrics, cases = _connect_and_run_cases(cfg)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    _write_legacy_reports(cfg, _parameters_payload(cfg), metrics, cases, stamp, generated_at)
    return 0


def _command_labelfree(args, base_dir, write_legacy=False):
    """Execução parametrizada; passa pelos mesmos comandos do agendador.

    ``full`` e ``labelfree`` compartilham o handler de execução usado pelo
    worker, pelo agendamento de 24 h e pela rota HTTP, para que o
    comportamento não possa divergir entre pontos de entrada.
    """
    from . import period as period_mod

    runtime = _build_runtime(args, base_dir)
    period = period_mod.window_to_period(
        args.start, args.end, timezone_name=runtime.clock.timezone_name
    )
    job = runtime.enqueue_manual(
        period,
        rules=_selected_rules(args),
        requested_by="cli",
    )
    print("Job manual: {0} (período {1} a {2}, {3} dias)".format(
        job.job_id, period.start_text, period.end_inclusive_text, period.total_calendar_days,
    ))
    return _claim_and_report(runtime, job.job_id)


def _command_report_html(args):
    standalone = not args.fragment_only
    fragment = not args.standalone_only
    paths = htmlreport.write_html_report(args.bundle, out_dir=args.out_dir, standalone=standalone, fragment=fragment, title=args.title)
    print("HTML gerado: {0}".format(" ".join(str(p) for p in paths.values())))
    return 0


def _command_generate_reports(args, base_dir):
    import glob
    import json

    from acr_controle_acesso_dashboard import __version__ as application_version
    from .dossier import write_reports
    from .report_model import build_report_model, safe_fixture_bundle

    if args.safe_fixture:
        bundle = safe_fixture_bundle()
    else:
        bundle_path = args.bundle
        if not bundle_path:
            candidates = sorted(glob.glob(str(base_dir / "reports" / "results_bundle_*.json")))
            if not candidates:
                raise ValueError("Nenhum bundle informado ou localizado em reports/.")
            bundle_path = candidates[-1]
        resolved_bundle = cfg_mod.resolve_path(bundle_path, base_dir)
        if not resolved_bundle.is_file():
            raise ValueError("Bundle não encontrado: {0}".format(resolved_bundle))
        try:
            bundle = json.loads(resolved_bundle.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError("Bundle JSON inválido (linha {0}).".format(exc.lineno))
    employee_data = None
    if args.employee_data:
        employee_path = cfg_mod.resolve_path(args.employee_data, base_dir)
        if not employee_path.is_file():
            raise ValueError("Arquivo de dados funcionais não encontrado: {0}".format(employee_path))
        try:
            employee_data = json.loads(employee_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError("Dados funcionais JSON inválidos (linha {0}).".format(exc.lineno))
        if not isinstance(employee_data, dict):
            raise ValueError("Dados funcionais devem ser um objeto indexado por usuário.")
    if employee_data is None:
        try:
            from .org_lookup import fetch_employee_details

            employee_data = fetch_employee_details(bundle) or None
        except Exception:
            employee_data = None
    model = build_report_model(bundle, application_version, employee_details=employee_data)
    output_dir = cfg_mod.resolve_path(args.output_dir, base_dir)
    paths = write_reports(
        model,
        output_dir,
        formats=getattr(args, "formats", None),
        csv_package=not bool(getattr(args, "no_csv_package", False)),
        csv_use_bom=bool(getattr(args, "csv_bom", False)),
    )
    generated = " ".join(
        str(paths[key]) for key in ("tex", "xlsx") if key in paths
    )
    print("Relatórios gerados: {0}".format(generated or "nenhum formato de dossiê selecionado"))
    print("Modelo normalizado: {0}".format(paths["model"]))
    if "csv_manifest" in paths:
        from . import csvpackage as csv_mod

        problems = csv_mod.verify_package(output_dir)
        if problems:
            raise ValueError("Pacote CSV inválido: {0}".format("; ".join(problems[:5])))
        print("Pacote CSV: {0}".format(paths["csv_package"]))
        print("Manifesto CSV: {0}".format(paths["csv_manifest"]))
    return 0


def main(argv=None):
    base_dir = Path.cwd()
    cfg_mod.load_dotenv_file(base_dir / ".env")
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] not in KNOWN_SUBCOMMANDS and "--start" in argv:
        argv.insert(0, "run")
    args = build_parser().parse_args(argv)
    if not args.command:
        build_parser().print_help()
        return 2
    if args.command in ("extract", "parity", "inject", "adjudicate", "bundle"):
        print("skipped: not implemented in this handoff run")
        return 0
    try:
        if args.command == "run":
            return _command_run(args, base_dir)
        if args.command == "labelfree":
            return _command_labelfree(args, base_dir, write_legacy=False)
        if args.command == "full":
            return _command_labelfree(args, base_dir, write_legacy=True)
        if args.command == "report-html":
            return _command_report_html(args)
        if args.command == "generate-reports":
            return _command_generate_reports(args, base_dir)
        if args.command == "run-initial":
            return _command_run_initial(args, base_dir)
        if args.command == "run-scheduled":
            return _command_run_scheduled(args, base_dir)
        if args.command == "run-job":
            return _command_run_job(args, base_dir)
        if args.command == "worker":
            return _command_worker(args, base_dir)
        if args.command == "job-status":
            return _command_job_status(args, base_dir)
        if args.command == "schedule-status":
            return _command_schedule_status(args, base_dir)
    except (CommandValidationError, ValueError) as exc:
        print("Erro de configuracao: {0}".format(exc), file=sys.stderr)
        return 2
    return 2


if __name__ == "__main__":
    sys.exit(main())
