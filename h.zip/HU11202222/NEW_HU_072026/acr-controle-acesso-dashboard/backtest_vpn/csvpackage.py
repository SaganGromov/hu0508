"""Pacote de detalhamento em CSV, portátil e verificável.

O que vai para CSV
------------------
Apenas evidência **detalhada e repetitiva** que tornaria o PDF ou o XLSX
difíceis de ler: registros de evidência por ocorrência, sequência de IPs de
R1, horários de login de R4, uso por usuário nos dispositivos de R7 e o
cronograma completo. Os fatos executivos e de nível de ocorrência permanecem
no dossiê e na planilha.

Garantias
---------
* nomes de arquivo determinísticos e seguros;
* colunas estáveis e documentadas no dicionário de dados;
* UTF-8 sem BOM por padrão (``\\n`` como fim de linha, delimitador ``,``),
  com BOM opcional apenas quando o destino exige compatibilidade com o Excel
  em português;
* mesma política antifórmula do XLSX (``=``, ``+``, ``-``, ``@`` viram texto);
* divisão determinística em partes quando o limite de linhas é excedido;
* manifesto com finalidade, contagem de linhas, esquema, versão, IDs de
  relatório/job e SHA-256 de cada arquivo;
* links relativos, portáteis quando o pacote inteiro é movido de máquina.
"""

from __future__ import annotations

import csv
import hashlib
import io
import json
import re
from dataclasses import dataclass
from pathlib import Path

from .report_model import display_value

#: Nome do diretório relativo do pacote, dentro da pasta do relatório.
PACKAGE_DIRNAME = "detalhamento_csv"
MANIFEST_NAME = "manifest.json"
DICTIONARY_NAME = "dicionario_de_dados.csv"

#: Limite conservador de linhas de dados por arquivo, abaixo do limite do Excel.
MAX_ROWS_PER_FILE = 500_000
#: Limite de caracteres por célula, alinhado ao limite do Excel.
MAX_CELL_LENGTH = 32_767

ENCODING = "utf-8"
DELIMITER = ","
LINE_TERMINATOR = "\n"
MISSING_VALUE = "Não informado"

_FORMULA_PREFIXES = ("=", "+", "-", "@")
_CONTROL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
_SAFE_NAME_RE = re.compile(r"[^A-Za-z0-9._-]+")


def safe_csv_value(value) -> str:
    """Neutraliza fórmulas e caracteres de controle, preservando o texto."""
    if value is None or value == "" or value == [] or value == {}:
        return MISSING_VALUE
    if isinstance(value, bool):
        return "Sim" if value else "Não"
    if isinstance(value, (int, float)):
        return str(value)
    text = display_value(value)
    text = _CONTROL_RE.sub("", text.replace("\r\n", " ").replace("\r", " ").replace("\n", " "))
    if text.startswith(_FORMULA_PREFIXES):
        text = "'" + text
    return text[:MAX_CELL_LENGTH]


def safe_file_name(value: str) -> str:
    cleaned = _SAFE_NAME_RE.sub("-", str(value or "")).strip("-.")
    return cleaned[:96] or "arquivo"


@dataclass(frozen=True)
class CsvFile:
    """Descrição de um arquivo CSV emitido."""

    name: str
    purpose: str
    headers: tuple[str, ...]
    row_count: int
    sha256: str
    byte_size: int
    part: int
    total_parts: int

    def as_payload(self) -> dict:
        return {
            "file": self.name,
            "purpose": self.purpose,
            "schema": list(self.headers),
            "schema_version": 1,
            "row_count": self.row_count,
            "sha256": self.sha256,
            "byte_size": self.byte_size,
            "part": self.part,
            "total_parts": self.total_parts,
            "relative_link": "{0}/{1}".format(PACKAGE_DIRNAME, self.name),
        }


def _write_csv(path: Path, headers: list[str], rows: list[list], *, use_bom: bool) -> CsvFile:
    buffer = io.StringIO(newline="")
    writer = csv.writer(buffer, delimiter=DELIMITER, lineterminator=LINE_TERMINATOR, quoting=csv.QUOTE_MINIMAL)
    writer.writerow([safe_csv_value(header) for header in headers])
    for row in rows:
        writer.writerow([safe_csv_value(cell) for cell in row])
    payload = buffer.getvalue().encode(ENCODING)
    if use_bom:
        payload = b"\xef\xbb\xbf" + payload
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(payload)
    return CsvFile(
        name=path.name,
        purpose="",
        headers=tuple(str(header) for header in headers),
        row_count=len(rows),
        sha256=hashlib.sha256(payload).hexdigest(),
        byte_size=len(payload),
        part=1,
        total_parts=1,
    )


def _emit_dataset(
    directory: Path,
    base_name: str,
    purpose: str,
    headers: list[str],
    rows: list[list],
    *,
    use_bom: bool,
) -> list[CsvFile]:
    """Emite um dataset, dividindo em partes determinísticas quando necessário."""
    safe_base = safe_file_name(base_name)
    chunks = [rows[index:index + MAX_ROWS_PER_FILE] for index in range(0, len(rows), MAX_ROWS_PER_FILE)] or [[]]
    total_parts = len(chunks)
    emitted: list[CsvFile] = []
    for index, chunk in enumerate(chunks, start=1):
        suffix = "" if total_parts == 1 else "_parte{0:03d}".format(index)
        path = directory / "{0}{1}.csv".format(safe_base, suffix)
        entry = _write_csv(path, headers, chunk, use_bom=use_bom)
        emitted.append(
            CsvFile(
                name=entry.name,
                purpose=purpose,
                headers=entry.headers,
                row_count=entry.row_count,
                sha256=entry.sha256,
                byte_size=entry.byte_size,
                part=index,
                total_parts=total_parts,
            )
        )
    return emitted


def _evidence_rows(model: dict) -> list[list]:
    rows = []
    for occurrence in model["occurrences"]:
        for evidence in occurrence.get("evidence_records") or []:
            user = evidence.get("user_id") or evidence.get("USER_KEY") or occurrence.get("user_id")
            rows.append([
                occurrence["occurrence_id"],
                occurrence["rule_id"],
                occurrence.get("rule_version"),
                occurrence.get("severity"),
                user,
                evidence.get("device_id") or evidence.get("DEVICE_ID") or occurrence.get("device_id"),
                evidence.get("timestamp") or evidence.get("EVENT_TS") or evidence.get("VPN_TS"),
                evidence.get("local_date") or occurrence.get("local_date"),
                evidence.get("event_id") or evidence.get("EVENT_ID"),
                evidence.get("session_id") or evidence.get("SESSION_ID"),
                evidence.get("authentication_id") or evidence.get("AUTHENTICATION_ID"),
                evidence.get("source_ip") or evidence.get("SOURCE_IP"),
                evidence.get("source_ip_classification"),
                evidence.get("corporate_ip") or evidence.get("CORPORATE_IP") or evidence.get("VPN_CPTV_IP"),
                evidence.get("corporate_ip_classification"),
                evidence.get("hostname") or evidence.get("HOSTNAME"),
                occurrence.get("deduplication_method"),
                _occurrence_alert_label(occurrence, user),
            ])
    rows.sort(key=lambda row: (str(row[6] or ""), str(row[0]), str(row[8] or "")))
    return rows


def _occurrence_alert_label(occurrence: dict, user_id) -> str:
    normalized = str(user_id) if user_id not in (None, "") else None
    for alert in occurrence.get("uor_alerts") or []:
        if normalized is not None and str(alert.get("user_id")) == normalized:
            return str(alert.get("uor_alert_label") or "")
    return str(occurrence.get("uor_alert_label") or "")


def _ip_sequence_rows(model: dict) -> list[list]:
    rows = []
    for occurrence in model["occurrences"]:
        if occurrence["rule_id"] != "R1":
            continue
        details = occurrence.get("details") or {}
        for position, step in enumerate(details.get("ip_sequence") or [], start=1):
            rows.append([
                occurrence["occurrence_id"],
                occurrence.get("user_id"),
                occurrence.get("local_date"),
                position,
                step.get("timestamp"),
                step.get("source_ip"),
                step.get("source_classification"),
                step.get("corporate_ip"),
                step.get("corporate_classification"),
                step.get("event_id"),
            ])
    rows.sort(key=lambda row: (str(row[0]), int(row[3])))
    return rows


def _login_rows(model: dict) -> list[list]:
    rows = []
    for occurrence in model["occurrences"]:
        if occurrence["rule_id"] != "R4":
            continue
        details = occurrence.get("details") or {}
        timestamps = details.get("login_timestamps") or []
        for position, timestamp in enumerate(timestamps, start=1):
            rows.append([
                occurrence["occurrence_id"],
                occurrence.get("user_id"),
                occurrence.get("local_date"),
                occurrence.get("triggering_value"),
                position,
                timestamp,
            ])
    rows.sort(key=lambda row: (str(row[0]), int(row[4])))
    return rows


def _device_usage_rows(model: dict) -> list[list]:
    rows = []
    for device in model["devices"]:
        for user, usage in sorted((device.get("per_user_usage") or {}).items()):
            rows.append([
                device["device_id"],
                user,
                usage.get("first_use"),
                usage.get("last_use"),
                usage.get("event_count"),
                usage.get("source_ips"),
                usage.get("corporate_tunnel_ips"),
                device.get("same_day_association"),
                device.get("seven_day_association"),
                device.get("thirty_day_association"),
                device.get("concurrent_or_overlapping"),
            ])
    rows.sort(key=lambda row: (str(row[0]), str(row[1])))
    return rows


def _timeline_rows(model: dict) -> list[list]:
    rows = []
    for entry in model.get("timeline") or []:
        rows.append([
            entry.get("timestamp"),
            entry.get("local_date"),
            entry.get("rule_id"),
            entry.get("occurrence_id"),
            entry.get("user_id"),
            entry.get("device_id"),
            entry.get("event_id"),
            entry.get("source_ip"),
            entry.get("corporate_ip"),
            entry.get("uor_alert_label"),
        ])
    return rows


DATASETS = (
    (
        "evidencias_por_ocorrencia",
        "Registro de evidência de cada ocorrência, com identificadores de evento, sessão e IPs.",
        [
            "Ocorrência", "Regra", "Versão da regra", "Severidade", "Usuário",
            "Dispositivo", "Timestamp local", "Data local", "Evento", "Sessão",
            "Identificador de autenticação", "IP de origem",
            "Classificação do IP de origem", "IP corporativo/túnel",
            "Classificação do IP corporativo/túnel", "Nome do computador",
            "Método de deduplicação", "Alerta UOR",
        ],
        _evidence_rows,
    ),
    (
        "r1_sequencia_de_ips",
        "Sequência temporal de IPs por usuário e dia local que acionou R1.",
        [
            "Ocorrência", "Usuário", "Data local", "Posição", "Timestamp local",
            "IP de origem", "Classificação do IP de origem", "IP corporativo/túnel",
            "Classificação do IP corporativo/túnel", "Evento",
        ],
        _ip_sequence_rows,
    ),
    (
        "r4_logins_vpn_por_dia",
        "Horários de cada login VPN deduplicado que compôs a contagem diária de R4.",
        [
            "Ocorrência", "Usuário", "Data local", "Total de logins no dia",
            "Posição", "Timestamp local do login",
        ],
        _login_rows,
    ),
    (
        "r7_uso_de_dispositivo_por_usuario",
        "Uso de cada dispositivo por usuário: primeiro/último uso, volume e IPs.",
        [
            "Dispositivo", "Usuário", "Primeiro uso", "Último uso",
            "Total de eventos", "IPs de origem", "IPs corporativos/túnel",
            "Associação no mesmo dia", "Associação em 7 dias",
            "Associação em 30 dias", "Concorrência",
        ],
        _device_usage_rows,
    ),
    (
        "cronologia_consolidada",
        "Cronologia consolidada de todas as evidências, ordenada por horário local.",
        [
            "Timestamp local", "Data local", "Regra", "Ocorrência", "Usuário",
            "Dispositivo", "Evento", "IP de origem", "IP corporativo/túnel",
            "Alerta UOR",
        ],
        _timeline_rows,
    ),
)

DICTIONARY_ROWS = (
    ("Ocorrência", "Identificador estável de um achado consolidado de regra."),
    ("Regra", "Identificador da regra de detecção (R1 a R9)."),
    ("Severidade", "Severidade da anomalia atribuída pela regra; não é classificação organizacional."),
    ("Alerta UOR", "Classificação organizacional visual da UOR; independente da severidade."),
    ("Usuário", "Chave do usuário autenticado (CD_USU_AUT) normalizada."),
    ("Dispositivo", "Identificador de dispositivo (CD_IDFC_DSVO) normalizado."),
    ("Evento", "Identificador estável de uma linha deduplicada de AUT_CPTV."),
    ("Sessão", "Identificador de sessão apenas quando a fonte o fornece; nunca inferido."),
    ("IP de origem", "CD_END_LGC_OGM normalizado como IPv4/IPv6."),
    ("IP corporativo/túnel", "CD_END_LGC_CPTV normalizado; mantido separado do IP de origem."),
    ("Timestamp local", "Horário do evento interpretado no fuso do relatório."),
    ("Data local", "Data civil local usada para agregação diária de R1 e R4."),
    (MISSING_VALUE, "Valor ausente, vazio, malformado ou não determinado com confiabilidade."),
)


def describe_datasets(model: dict) -> list[dict]:
    """Descreve o pacote a partir **do próprio modelo**, sem escrever arquivos.

    O dossiê e a planilha usam esta descrição para imprimir nomes de arquivo e
    contagens idênticas às do manifesto, sem depender da ordem de geração dos
    formatos. Assim os três formatos derivam do mesmo modelo normalizado.
    """
    described = []
    for base_name, purpose, headers, extractor in DATASETS:
        rows = extractor(model)
        total_parts = max(1, -(-len(rows) // MAX_ROWS_PER_FILE)) if rows else 1
        safe_base = safe_file_name(base_name)
        for part in range(1, total_parts + 1):
            suffix = "" if total_parts == 1 else "_parte{0:03d}".format(part)
            name = "{0}{1}.csv".format(safe_base, suffix)
            chunk = (
                rows[(part - 1) * MAX_ROWS_PER_FILE: part * MAX_ROWS_PER_FILE]
                if rows else []
            )
            described.append({
                "file": name,
                "purpose": purpose,
                "schema": list(headers),
                "row_count": len(chunk),
                "part": part,
                "total_parts": total_parts,
                "relative_link": "{0}/{1}".format(PACKAGE_DIRNAME, name),
            })
    described.append({
        "file": DICTIONARY_NAME,
        "purpose": "Dicionário de dados das colunas usadas nos arquivos deste pacote.",
        "schema": ["Termo", "Definição"],
        "row_count": len(DICTIONARY_ROWS),
        "part": 1,
        "total_parts": 1,
        "relative_link": "{0}/{1}".format(PACKAGE_DIRNAME, DICTIONARY_NAME),
    })
    return described


def write_package(
    model: dict,
    output_dir,
    *,
    use_bom: bool = False,
) -> dict:
    """Escreve o pacote CSV e devolve o manifesto já persistido."""
    package_dir = Path(output_dir) / PACKAGE_DIRNAME
    package_dir.mkdir(parents=True, exist_ok=True)
    for stale in package_dir.glob("*.csv"):
        stale.unlink()
    files: list[CsvFile] = []
    for base_name, purpose, headers, extractor in DATASETS:
        rows = extractor(model)
        files.extend(
            _emit_dataset(package_dir, base_name, purpose, list(headers), rows, use_bom=use_bom)
        )
    dictionary = _write_csv(
        package_dir / DICTIONARY_NAME,
        ["Termo", "Definição"],
        [list(row) for row in DICTIONARY_ROWS],
        use_bom=use_bom,
    )
    files.append(
        CsvFile(
            name=dictionary.name,
            purpose="Dicionário de dados das colunas usadas nos arquivos deste pacote.",
            headers=dictionary.headers,
            row_count=dictionary.row_count,
            sha256=dictionary.sha256,
            byte_size=dictionary.byte_size,
            part=1,
            total_parts=1,
        )
    )
    report = model["report"]
    manifest = {
        "manifest_version": 1,
        "package_directory": PACKAGE_DIRNAME,
        "report_id": report.get("report_id"),
        "job_id": report.get("job_id"),
        "execution_trigger": report.get("trigger_type"),
        "application_version": report.get("application_version"),
        "generated_at": report.get("generation_timestamp"),
        "period_start": report.get("period_start"),
        "period_end_inclusive": report.get("period_end_inclusive"),
        "data_cutoff": report.get("data_cutoff"),
        "timezone": report.get("timezone"),
        "encoding": "UTF-8 com BOM" if use_bom else "UTF-8 sem BOM",
        "delimiter": DELIMITER,
        "line_terminator": "\\n",
        "missing_value": MISSING_VALUE,
        "formula_injection_policy": (
            "valores iniciados por =, +, - ou @ são prefixados com apóstrofo e "
            "permanecem texto"
        ),
        "max_rows_per_file": MAX_ROWS_PER_FILE,
        "files": [entry.as_payload() for entry in files],
        "total_files": len(files),
        "total_rows": sum(entry.row_count for entry in files),
    }
    manifest_path = package_dir / MANIFEST_NAME
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding=ENCODING,
    )
    return manifest


def verify_package(output_dir) -> list[str]:
    """Revalida o manifesto: presença, contagem de linhas e SHA-256.

    Retorna a lista de problemas encontrados; lista vazia significa pacote
    íntegro. Serve tanto para o script de geração quanto para conferir o
    pacote depois de movê-lo para outra máquina.
    """
    package_dir = Path(output_dir) / PACKAGE_DIRNAME
    manifest_path = package_dir / MANIFEST_NAME
    if not manifest_path.is_file():
        return ["Manifesto {0} não encontrado.".format(manifest_path.name)]
    try:
        manifest = json.loads(manifest_path.read_text(encoding=ENCODING))
    except ValueError as exc:
        return ["Manifesto inválido: {0}".format(exc)]
    problems: list[str] = []
    for entry in manifest.get("files") or []:
        name = str(entry.get("file") or "")
        candidate = package_dir / name
        if not candidate.is_file():
            problems.append("Arquivo ausente: {0}".format(name))
            continue
        payload = candidate.read_bytes()
        if hashlib.sha256(payload).hexdigest() != entry.get("sha256"):
            problems.append("SHA-256 divergente: {0}".format(name))
        text = payload.decode(ENCODING).lstrip("﻿")
        data_rows = max(0, len(text.splitlines()) - 1)
        if data_rows != int(entry.get("row_count") or 0):
            problems.append(
                "Contagem de linhas divergente em {0}: {1} no arquivo, {2} no manifesto.".format(
                    name, data_rows, entry.get("row_count")
                )
            )
        if str(entry.get("relative_link") or "") != "{0}/{1}".format(PACKAGE_DIRNAME, name):
            problems.append("Link relativo inconsistente em {0}.".format(name))
    return problems


__all__ = [
    "DATASETS",
    "DELIMITER",
    "DICTIONARY_NAME",
    "ENCODING",
    "MANIFEST_NAME",
    "MAX_ROWS_PER_FILE",
    "MISSING_VALUE",
    "PACKAGE_DIRNAME",
    "CsvFile",
    "describe_datasets",
    "safe_csv_value",
    "safe_file_name",
    "verify_package",
    "write_package",
]
