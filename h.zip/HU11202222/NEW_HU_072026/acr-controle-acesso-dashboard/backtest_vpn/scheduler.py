"""Política de agendamento contínuo do backtesting (24 horas).

Responsabilidades
-----------------
* decidir **se** uma nova execução automática é devida, com base na marca
  d'água (*watermark*) publicada e no horário de corte local configurado;
* tratar execuções perdidas (pod desligado, DB2 indisponível, atraso) sem
  pular dias: a política recupera o atraso executando a janela devida mais
  recente, e a marca d'água só avança **após publicação bem-sucedida**;
* nunca permitir duas execuções automáticas simultâneas para a mesma janela
  lógica — isso é garantido pela chave de idempotência e pela reserva atômica
  em :mod:`backtest_vpn.jobstore`.

O módulo é puro: recebe relógio e marca d'água, devolve uma decisão.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta

from .clock import Clock, resolve_timezone
from .detection import APP_TIMEZONE
from .period import (
    CUTOFF_COMPLETED_DAY,
    CUTOFF_MODES,
    DEFAULT_WINDOW_DAYS,
    BacktestPeriod,
    parse_local_date,
    parse_window_days,
)

DEFAULT_INTERVAL_HOURS = 24
DEFAULT_CUTOFF_TIME = "01:30"
DEFAULT_LEASE_SECONDS = 1800
DEFAULT_MAX_ATTEMPTS = 3
DEFAULT_RETRY_BASE_SECONDS = 300
DEFAULT_RETRY_MAX_SECONDS = 3600


@dataclass(frozen=True)
class ScheduleConfig:
    """Parâmetros configuráveis do ciclo automático."""

    # Explicit constructors retain the scheduler test/CLI semantics; deployed
    # defaults are disabled by ``from_env`` below.
    enabled: bool = True
    interval_hours: int = DEFAULT_INTERVAL_HOURS
    cutoff_time: str = DEFAULT_CUTOFF_TIME
    cutoff_mode: str = CUTOFF_COMPLETED_DAY
    window_days: int = DEFAULT_WINDOW_DAYS
    timezone_name: str = APP_TIMEZONE
    lease_seconds: int = DEFAULT_LEASE_SECONDS
    max_attempts: int = DEFAULT_MAX_ATTEMPTS
    retry_base_seconds: int = DEFAULT_RETRY_BASE_SECONDS
    retry_max_seconds: int = DEFAULT_RETRY_MAX_SECONDS
    run_initial_on_startup: bool = True
    catch_up: bool = True

    @classmethod
    def from_env(cls, env: dict | None = None) -> "ScheduleConfig":
        source = dict(os.environ if env is None else env)

        def _flag(name: str, default: bool) -> bool:
            raw = str(source.get(name, "")).strip().lower()
            if not raw:
                return default
            if raw in ("1", "true", "yes", "on"):
                return True
            if raw in ("0", "false", "no", "off"):
                return False
            raise ValueError("{0} deve ser um booleano (true/false).".format(name))

        def _int(name: str, default: int, low: int, high: int) -> int:
            raw = str(source.get(name, "")).strip()
            if not raw:
                return default
            try:
                value = int(raw)
            except ValueError:
                raise ValueError("{0} deve ser um inteiro entre {1} e {2}.".format(name, low, high))
            if not low <= value <= high:
                raise ValueError("{0} deve estar entre {1} e {2}.".format(name, low, high))
            return value

        cutoff_mode = str(source.get("BACKTEST_SCHEDULE_CUTOFF_MODE", CUTOFF_COMPLETED_DAY)).strip()
        if cutoff_mode not in CUTOFF_MODES:
            raise ValueError(
                "BACKTEST_SCHEDULE_CUTOFF_MODE deve ser {0}.".format(" ou ".join(CUTOFF_MODES))
            )
        cutoff_time = str(source.get("BACKTEST_SCHEDULE_CUTOFF_TIME", DEFAULT_CUTOFF_TIME)).strip()
        parse_cutoff_time(cutoff_time)
        return cls(
            enabled=_flag("BACKTEST_SCHEDULE_ENABLED", False),
            interval_hours=_int("BACKTEST_SCHEDULE_INTERVAL_HOURS", DEFAULT_INTERVAL_HOURS, 1, 168),
            cutoff_time=cutoff_time,
            cutoff_mode=cutoff_mode,
            window_days=parse_window_days(source.get("BACKTEST_WINDOW_DAYS")),
            timezone_name=str(source.get("BACKTEST_TIMEZONE", APP_TIMEZONE)).strip() or APP_TIMEZONE,
            lease_seconds=_int("BACKTEST_LEASE_SECONDS", DEFAULT_LEASE_SECONDS, 60, 86400),
            max_attempts=_int("BACKTEST_MAX_ATTEMPTS", DEFAULT_MAX_ATTEMPTS, 1, 10),
            retry_base_seconds=_int("BACKTEST_RETRY_BASE_SECONDS", DEFAULT_RETRY_BASE_SECONDS, 1, 86400),
            retry_max_seconds=_int("BACKTEST_RETRY_MAX_SECONDS", DEFAULT_RETRY_MAX_SECONDS, 1, 86400),
            run_initial_on_startup=_flag("BACKTEST_RUN_INITIAL_ON_STARTUP", False),
            catch_up=_flag("BACKTEST_SCHEDULE_CATCH_UP", True),
        )

    def as_payload(self) -> dict:
        return {
            "schedule_enabled": self.enabled,
            "interval_hours": self.interval_hours,
            "cutoff_time_local": self.cutoff_time,
            "cutoff_mode": self.cutoff_mode,
            "window_days": self.window_days,
            "timezone": self.timezone_name,
            "lease_seconds": self.lease_seconds,
            "max_attempts": self.max_attempts,
            "retry_base_seconds": self.retry_base_seconds,
            "retry_max_seconds": self.retry_max_seconds,
            "run_initial_on_startup": self.run_initial_on_startup,
            "catch_up": self.catch_up,
        }

    def retry_delay_seconds(self, attempt: int) -> int:
        """Backoff exponencial limitado, determinístico e sem jitter."""
        exponent = max(0, int(attempt) - 1)
        delay = self.retry_base_seconds * (2 ** min(exponent, 16))
        return int(min(delay, self.retry_max_seconds))


_CUTOFF_TIME_RE = re.compile(r"^([01]\d|2[0-3]):([0-5]\d)$")


def parse_cutoff_time(value: str) -> time:
    """Valida ``HH:MM`` local (dois dígitos em cada campo, 24 horas)."""
    match = _CUTOFF_TIME_RE.match(str(value or "").strip())
    if not match:
        raise ValueError(
            "Horário de corte inválido: use HH:MM em 24 horas com dois dígitos "
            "em cada campo, por exemplo 01:30."
        )
    return time(hour=int(match.group(1)), minute=int(match.group(2)))


@dataclass(frozen=True)
class ScheduleDecision:
    """Resultado da avaliação do agendador."""

    should_run: bool
    reason: str
    period: BacktestPeriod | None = None
    next_due_at: str | None = None
    missed_runs: int = 0

    def as_payload(self) -> dict:
        return {
            "should_run": self.should_run,
            "reason": self.reason,
            "next_due_at": self.next_due_at,
            "missed_runs": self.missed_runs,
            "period": self.period.as_payload() if self.period else None,
        }


def scheduled_period(config: ScheduleConfig, reference_date: date) -> BacktestPeriod:
    """Janela automática que termina conforme o corte configurado."""
    end = (
        reference_date - timedelta(days=1)
        if config.cutoff_mode == CUTOFF_COMPLETED_DAY
        else reference_date
    )
    start = end - timedelta(days=config.window_days - 1)
    return BacktestPeriod(
        start_date=start,
        end_date_inclusive=end,
        timezone_name=config.timezone_name,
        cutoff_mode=config.cutoff_mode,
        reference_date=reference_date,
    )


def _cutoff_moment(config: ScheduleConfig, day: date) -> datetime:
    tz = resolve_timezone(config.timezone_name)
    return datetime.combine(day, parse_cutoff_time(config.cutoff_time), tzinfo=tz)


def evaluate(config: ScheduleConfig, clock: Clock, watermark: dict | None) -> ScheduleDecision:
    """Decide se uma execução automática é devida agora.

    ``watermark`` é o estado publicado com sucesso: contém
    ``last_published_end_date`` (data local final inclusiva do último
    resultado publicado) e ``last_success_at``. A decisão nunca depende de
    estado em memória do processo.
    """
    if not config.enabled:
        return ScheduleDecision(False, "Agendamento automático desabilitado por configuração.")
    now = clock.now()
    today = now.date()
    target = scheduled_period(config, today)
    cutoff_today = _cutoff_moment(config, today)

    payload = dict(watermark or {})
    last_end_text = payload.get("last_published_end_date")
    last_end = None
    if last_end_text:
        try:
            last_end = parse_local_date(last_end_text, "a marca d'água")
        except ValueError:
            last_end = None

    if last_end is None:
        return ScheduleDecision(
            True,
            "Nenhum resultado publicado ainda: executa a janela padrão de {0} dias.".format(
                config.window_days
            ),
            period=target,
            next_due_at=cutoff_today.isoformat(timespec="seconds"),
        )

    if last_end >= target.end_date_inclusive:
        next_day = today + timedelta(days=1)
        return ScheduleDecision(
            False,
            "A janela devida já está publicada até {0}.".format(last_end.isoformat()),
            next_due_at=_cutoff_moment(config, next_day).isoformat(timespec="seconds"),
        )

    if now < cutoff_today:
        # Antes do horário de corte, a janela do dia ainda não é devida.
        return ScheduleDecision(
            False,
            "Aguardando o horário de corte local {0}.".format(config.cutoff_time),
            next_due_at=cutoff_today.isoformat(timespec="seconds"),
        )

    missed = max(0, (target.end_date_inclusive - last_end).days - 1)
    if missed and not config.catch_up:
        reason = (
            "Execuções perdidas detectadas ({0}); recuperação desabilitada, executa "
            "somente a janela mais recente.".format(missed)
        )
    elif missed:
        reason = (
            "Recuperando {0} execução(ões) perdida(s) com uma única janela rolante "
            "que reprocessa todo o período de {1} dias.".format(missed, config.window_days)
        )
    else:
        reason = "Nova execução automática devida após o corte local {0}.".format(config.cutoff_time)
    return ScheduleDecision(
        True,
        reason,
        period=target,
        next_due_at=_cutoff_moment(config, today + timedelta(days=1)).isoformat(timespec="seconds"),
        missed_runs=missed,
    )


def watermark_after_success(
    period: BacktestPeriod, job_id: str, clock: Clock, *, report_id: str | None = None
) -> dict:
    """Marca d'água gravada **somente** após publicação validada."""
    return {
        "last_published_end_date": period.end_inclusive_text,
        "last_published_start_date": period.start_text,
        "last_published_window_days": period.total_calendar_days,
        "last_published_cutoff_mode": period.cutoff_mode,
        "last_published_data_cutoff": period.end_exclusive_timestamp,
        "last_success_at": clock.now().isoformat(timespec="seconds"),
        "last_success_job_id": job_id,
        "last_success_report_id": report_id,
        "timezone": period.timezone_name,
    }


__all__ = [
    "DEFAULT_CUTOFF_TIME",
    "DEFAULT_INTERVAL_HOURS",
    "DEFAULT_LEASE_SECONDS",
    "DEFAULT_MAX_ATTEMPTS",
    "ScheduleConfig",
    "ScheduleDecision",
    "evaluate",
    "parse_cutoff_time",
    "scheduled_period",
    "watermark_after_success",
]
