"""Casos do backtest de VPN executados contra o DB2 (somente leitura).

Todos os identificadores SQL (schema, tabela, coluna) usados aqui ja passaram
pela regex de identificadores em config.normalize_identifier antes de serem
interpolados. Valores literais (datas, limites de HAVING, valor de rede) sao
sempre enviados via binding `?`.
"""

import hashlib
import json
from dataclasses import dataclass, field
from typing import List

from .db2 import fetch_all
from . import mta as mta_mod
from .detection import (
    RULE_CATALOG,
    normalize_identifier,
    normalize_ip,
    occurrence_to_legacy_sample,
    run_event_rules,
)

RATE_NOT_AVAILABLE = "not_available_without_validated_labels"

_TS_FORMAT = "%Y-%m-%d %H:%M:%S"

# Nomes de fase resolvidos preguiçosamente para não acoplar este módulo, que é
# de acesso a dados, ao módulo de progresso quando ele não é usado.
_PHASES = {
    "querying": "CONSULTANDO_EVENTOS",
    "normalizing": "NORMALIZANDO_EVENTOS",
    "evaluating": "AVALIANDO_REGRAS",
    "correlating": "CORRELACIONANDO_OPENAM",
}


class _NullProgress:
    """Reporter neutro usado quando o chamador não acompanha progresso."""

    def start_phase(self, *args, **kwargs) -> None:
        return

    def set_total(self, *args, **kwargs) -> None:
        return

    def set_position(self, *args, **kwargs) -> None:
        return

    def set_subphase(self, *args, **kwargs) -> None:
        return

    def advance(self, *args, **kwargs) -> None:
        return

    def add_counter(self, *args, **kwargs) -> None:
        return

    def set_counter(self, *args, **kwargs) -> None:
        return

    def merge_counters(self, *args, **kwargs) -> None:
        return

    def record_occurrences(self, *args, **kwargs) -> None:
        return


@dataclass
class BacktestCaseResult:
    name: str
    status: str
    count: int
    sample: List[dict]
    note: str = ""
    occurrences: List[dict] = field(default_factory=list)
    rule_id: str = ""
    rule_title: str = ""
    rule_version: str = ""
    severity: str = ""
    quality: dict = field(default_factory=dict)


def qualified(schema, table):
    """Retorna o nome qualificado 'schema.table'."""
    return "{0}.{1}".format(schema, table)


def ts_params(start, end):
    """Retorna (start, end) como strings 'YYYY-MM-DD HH:MM:SS' para binding."""
    return (start.strftime(_TS_FORMAT), end.strftime(_TS_FORMAT))


def get_table_columns(conn, schema, table):
    """Lista as colunas da tabela em ordem de COLNO.

    Tenta SYSCAT.COLUMNS (DB2 LUW) primeiro; em caso de falha, usa
    SYSIBM.SYSCOLUMNS (DB2 z/OS).
    """
    syscat_sql = (
        "SELECT COLNAME FROM SYSCAT.COLUMNS "
        "WHERE TABSCHEMA = ? AND TABNAME = ? "
        "ORDER BY COLNO"
    )
    sysibm_sql = (
        "SELECT NAME AS COLNAME FROM SYSIBM.SYSCOLUMNS "
        "WHERE TBCREATOR = ? AND TBNAME = ? "
        "ORDER BY COLNO"
    )
    try:
        rows = fetch_all(conn, syscat_sql, (schema, table))
    except Exception:
        rows = fetch_all(conn, sysibm_sql, (schema, table))
    return [str(row["COLNAME"]).strip().upper() for row in rows]


def validate_columns(conn, schema, table, required_columns):
    """Garante que todas as colunas exigidas existem na tabela.

    Levanta ValueError nomeando as colunas ausentes e listando as
    disponiveis, em vez de deixar um SQL0206N opaco estourar depois.
    """
    available = get_table_columns(conn, schema, table)
    if not available:
        raise ValueError(
            "Tabela {0} nao encontrada no catalogo"
            " (SYSCAT.COLUMNS / SYSIBM.SYSCOLUMNS).".format(qualified(schema, table))
        )
    missing = [col for col in required_columns if col not in available]
    if missing:
        raise ValueError(
            "Colunas ausentes em {0}: {1}. Colunas disponiveis: {2}".format(
                qualified(schema, table), ", ".join(missing), ", ".join(available)
            )
        )


def validate_configured_tables(conn, cfg):
    """Valida as colunas da tabela VPN e, se configurada, da tabela fisica."""
    vpn = cfg.vpn_table
    validate_columns(
        conn,
        vpn.schema,
        vpn.table,
        [
            vpn.user_column,
            vpn.timestamp_column,
            vpn.source_ip_column,
            vpn.corporate_ip_column,
            vpn.hostname_column,
            vpn.device_column,
        ],
    )
    physical = cfg.physical_table
    if physical is not None:
        required = [physical.user_column, physical.timestamp_column]
        if physical.network_column:
            required.append(physical.network_column)
        validate_columns(conn, physical.schema, physical.table, required)


def run_summary(conn, cfg):
    """Resumo do periodo: total de eventos e de usuarios distintos."""
    vpn = cfg.vpn_table
    sql = (
        "SELECT COUNT(1) AS TOTAL_EVENTS, "  # nosec B608 -- identificadores passam pela allowlist de config; valores usam binding
        "COUNT(DISTINCT TRIM({user})) AS TOTAL_USERS "
        "FROM {table} "
        "WHERE {ts} >= ? AND {ts} < ?"
    ).format(
        user=vpn.user_column,
        table=qualified(vpn.schema, vpn.table),
        ts=vpn.timestamp_column,
    )
    row = fetch_all(conn, sql, ts_params(cfg.start, cfg.end))[0]
    total_events = int(row["TOTAL_EVENTS"])
    # Toda linha da tabela de autenticacao analisada e um evento de VPN,
    # portanto os casos classificados como VPN equivalem ao total de eventos.
    return {
        "total_events_analyzed": total_events,
        "total_users_analyzed": int(row["TOTAL_USERS"]),
        "vpn_classified_cases": total_events,
        "false_positive_rate": RATE_NOT_AVAILABLE,
        "false_negative_rate": RATE_NOT_AVAILABLE,
    }


def _distinct_expr(column):
    return "COUNT(DISTINCT NULLIF(TRIM({0}), ''))".format(column)


def _count_wrapping(conn, base_sql, params, alias):
    count_sql = "SELECT COUNT(1) AS {0} FROM ({1}) AS Q".format(alias, base_sql)  # nosec B608 -- alias e base_sql são construções internas fixas
    return int(fetch_all(conn, count_sql, params)[0][alias])


def run_distinct_limit_case(conn, cfg, name, columns, note):
    """Usuários com mais de cfg.distinct_limit valores distintos nas colunas."""
    vpn = cfg.vpn_table
    metrics = ", ".join(
        "{expr} AS DISTINCT_{col}".format(expr=_distinct_expr(col), col=col)
        for col in columns
    )
    having = " OR ".join(
        "{expr} > ?".format(expr=_distinct_expr(col)) for col in columns
    )
    base_sql = (
        "SELECT TRIM({user}) AS USER_KEY, COUNT(1) AS EVENTS, {metrics}, "  # nosec B608 -- identificadores validados; limiares usam binding
        "MAX({ts}) AS LAST_SEEN "
        "FROM {table} "
        "WHERE {ts} >= ? AND {ts} < ? "
        "GROUP BY TRIM({user}) "
        "HAVING {having}"
    ).format(
        user=vpn.user_column,
        metrics=metrics,
        table=qualified(vpn.schema, vpn.table),
        ts=vpn.timestamp_column,
        having=having,
    )
    start_s, end_s = ts_params(cfg.start, cfg.end)
    params = (start_s, end_s) + tuple(cfg.distinct_limit for _ in columns)
    qualifying_users = _count_wrapping(conn, base_sql, params, "QUALIFYING_USERS")
    sample_sql = base_sql + (
        " ORDER BY EVENTS DESC FETCH FIRST {0} ROWS ONLY".format(cfg.sample_limit)
    )
    sample = fetch_all(conn, sample_sql, params)
    return BacktestCaseResult(
        name=name, status="ok", count=qualifying_users, sample=sample, note=note
    )


def run_daily_volume_case(conn, cfg):
    """Usuários com mais de cfg.daily_login_limit logins no mesmo dia."""
    vpn = cfg.vpn_table
    base_sql = (
        "SELECT TRIM({user}) AS USER_KEY, DATE({ts}) AS LOGIN_DATE, "  # nosec B608 -- identificadores validados; datas/limite usam binding
        "COUNT(1) AS LOGIN_COUNT "
        "FROM {table} "
        "WHERE {ts} >= ? AND {ts} < ? "
        "GROUP BY TRIM({user}), DATE({ts}) "
        "HAVING COUNT(1) > ?"
    ).format(
        user=vpn.user_column,
        table=qualified(vpn.schema, vpn.table),
        ts=vpn.timestamp_column,
    )
    start_s, end_s = ts_params(cfg.start, cfg.end)
    params = (start_s, end_s, cfg.daily_login_limit)
    qualifying = _count_wrapping(conn, base_sql, params, "QUALIFYING_USER_DAYS")
    sample_sql = base_sql + (
        " ORDER BY LOGIN_COUNT DESC FETCH FIRST {0} ROWS ONLY".format(cfg.sample_limit)
    )
    sample = fetch_all(conn, sample_sql, params)
    return BacktestCaseResult(
        name="logins_diarios_acima_do_limite",
        status="ok",
        count=qualifying,
        sample=sample,
        note=(
            "Pares usuario+dia com mais de {0} logins no mesmo dia.".format(
                cfg.daily_login_limit
            )
        ),
    )


def run_active_vpn_plus_physical_login_case(conn, cfg):
    """Politica da HU: sessao VPN ativa + login em rede fisica do BB.

    Apenas simula a elegibilidade da regra sobre dados historicos; nenhuma
    acao e executada no LDAP. A "sessao ativa" e aproximada por uma janela
    parametrizada (--active-window-hours) apos o evento de VPN.
    """
    case_name = "vpn_ativa_com_login_em_rede_fisica"
    physical = cfg.physical_table
    if physical is None:
        return BacktestCaseResult(
            name=case_name,
            status="skipped",
            count=0,
            sample=[],
            note=(
                "Tabela de login em rede física não configurada"
                " (--physical-table / PHYSICAL_TABLE); caso não executado."
                " Os demais casos foram executados normalmente."
            ),
        )
    vpn = cfg.vpn_table
    network_filter = ""
    start_s, end_s = ts_params(cfg.start, cfg.end)
    params = [start_s, end_s]
    if physical.network_column and physical.network_value:
        network_filter = " AND TRIM(P.{0}) = ?".format(physical.network_column)
        params.append(physical.network_value)
    base_sql = (
        "SELECT TRIM(V.{vuser}) AS USER_KEY, "  # nosec B608 -- identificadores e horas são normalizados/faixa; valores usam binding
        "V.{vts} AS VPN_TS, P.{pts} AS PHYSICAL_TS "
        "FROM {vtable} V "
        "JOIN {ptable} P "
        "ON TRIM(V.{vuser}) = TRIM(P.{puser}) "
        "AND P.{pts} >= V.{vts} "
        "AND P.{pts} < V.{vts} + {hours} HOURS "
        "WHERE P.{pts} >= ? AND P.{pts} < ?{network_filter}"
    ).format(
        vuser=vpn.user_column,
        vts=vpn.timestamp_column,
        vtable=qualified(vpn.schema, vpn.table),
        ptable=qualified(physical.schema, physical.table),
        puser=physical.user_column,
        pts=physical.timestamp_column,
        hours=cfg.active_window_hours,
        network_filter=network_filter,
    )
    eligible = _count_wrapping(conn, base_sql, params, "ELIGIBLE_MATCHES")
    sample_sql = base_sql + (
        " ORDER BY VPN_TS DESC FETCH FIRST {0} ROWS ONLY".format(cfg.sample_limit)
    )
    sample = fetch_all(conn, sample_sql, params)
    return BacktestCaseResult(
        name=case_name,
        status="ok",
        count=eligible,
        sample=sample,
        note=(
            "Eventos de VPN com login em rede fisica do BB para a mesma chave"
            " em ate {0} hora(s); simulacao de elegibilidade apenas,"
            " sem acao no LDAP.".format(cfg.active_window_hours)
        ),
    )


def _r5_occurrence(row, cfg):
    """Normaliza uma correlação R5 no modelo comum de ocorrência."""
    event_parts = (
        row.get("USER_KEY"), row.get("VPN_TS"), row.get("VPN_CPTV_IP"),
        row.get("MTA_TS"), row.get("MTA_IP_CLIENTE"),
        row.get("MTA_CD_UNCO_TRAN"), row.get("MTA_CD_IDFR_MTA"),
    )
    digest = hashlib.sha256(
        json.dumps(event_parts, default=str, ensure_ascii=False).encode("utf-8")
    ).hexdigest()[:20]
    vpn_ts = row.get("VPN_TS")
    mta_ts = row.get("MTA_TS")
    event_ids = [
        "AUT-{0}".format(hashlib.sha256(
            json.dumps((row.get("USER_KEY"), vpn_ts, row.get("VPN_CPTV_IP")), default=str).encode("utf-8")
        ).hexdigest()[:20])
    ]
    if row.get("MTA_CD_UNCO_TRAN"):
        event_ids.append("MTA-FLOW-{0}".format(row["MTA_CD_UNCO_TRAN"]))
    elif row.get("MTA_CD_IDFR_MTA") is not None:
        event_ids.append("MTA-ROW-{0}".format(row["MTA_CD_IDFR_MTA"]))
    first = min(vpn_ts, mta_ts) if vpn_ts is not None and mta_ts is not None else (vpn_ts or mta_ts)
    last = max(vpn_ts, mta_ts) if vpn_ts is not None and mta_ts is not None else (vpn_ts or mta_ts)
    return {
        "occurrence_id": "R5-{0}".format(digest),
        "rule_id": "R5",
        "rule_title": "Correlação temporal entre evento VPN e autenticação OpenAM em IP diferente",
        "rule_version": "2.1.0",
        "severity": "ALTA",
        "user_id": row.get("USER_KEY"),
        "device_id": None,
        "local_date": vpn_ts.date().isoformat() if hasattr(vpn_ts, "date") else str(vpn_ts or "")[:10] or None,
        "window_start": first.isoformat() if hasattr(first, "isoformat") else str(first or "") or None,
        "window_end": last.isoformat() if hasattr(last, "isoformat") else str(last or "") or None,
        "triggering_value": {
            "vpn_corporate_ip": row.get("VPN_CPTV_IP"),
            "openam_client_ip": row.get("MTA_IP_CLIENTE"),
        },
        "configured_threshold": {"correlation_minutes": cfg.mta_table.delta_minutes},
        "explanation": (
            "O mesmo usuário teve um evento VPN e uma autenticação OpenAM bem-sucedida "
            "em IP privado diferente dentro de ±{0} minutos. A fonte não fornece "
            "início/fim de sessão suficiente para comprovar simultaneidade."
        ).format(cfg.mta_table.delta_minutes),
        "supporting_event_identifiers": sorted(event_ids),
        "evidence_records": [{
            key: (value.isoformat() if hasattr(value, "isoformat") else value)
            for key, value in row.items()
        }],
        "relevant_ips": sorted({str(value) for value in (row.get("VPN_CPTV_IP"), row.get("MTA_IP_CLIENTE")) if value}),
        "relevant_devices": [],
        "relevant_sessions": [],
        "deduplication_key": "|".join(str(value or "") for value in event_parts),
        "deduplication_method": "OpenAM deduplicado por CD_UNCO_TRAN; correlação VPN+fluxo",
        "first_event_timestamp": first.isoformat() if hasattr(first, "isoformat") else str(first or "") or None,
        "last_event_timestamp": last.isoformat() if hasattr(last, "isoformat") else str(last or "") or None,
        "applicable_exclusions": ["IPs curingas/ausentes", "IP OpenAM fora das faixas privadas configuradas"],
        "details": {
            "mta_cd_unco_tran": row.get("MTA_CD_UNCO_TRAN"),
            "mta_cd_idfr_mta": row.get("MTA_CD_IDFR_MTA"),
            "mta_cd_cli_tran": row.get("MTA_CD_CLI_TRAN"),
            "mta_decision_node": row.get("MTA_NM_ETP"),
        },
    }


def run_vpn_plus_mta_physical_case(conn, cfg):
    """Correlação de evento VPN e autenticação OpenAM próxima em outro IP.

    Para cada evento VPN em `AUT_CPTV` no periodo, procura em
    `MTA_AUT_CLI_TRAN` um fluxo de autenticacao bem-sucedido (dedup por
    `CD_UNCO_TRAN`) para o mesmo usuário, dentro de uma janela +/- Delta
    minutos e cujo `ipCliente` extraido de `JS_INF_CLI`:

      * pertenca a uma faixa privada configurada (default 10/8, 172.16/12,
        192.168/16); e
      * seja DIFERENTE do IP corporativo tunelado pela VPN
        (`CD_END_LGC_CPTV`).

    A correlação não prova simultaneidade porque as fontes consultadas não
    fornecem início e fim confiáveis de sessão. Nada é alterado no LDAP.
    """
    case_name = "vpn_ativa_com_login_em_rede_fisica_mta"
    mta_cfg = getattr(cfg, "mta_table", None)
    if mta_cfg is None:
        return BacktestCaseResult(
            name=case_name,
            status="skipped",
            count=0,
            sample=[],
            note=(
                "Deteccao via DB2PEP.MTA_AUT_CLI_TRAN desligada"
                " (--no-mta-physical); caso não executado."
            ),
        )
    vpn = cfg.vpn_table
    start_s, end_s = ts_params(cfg.start, cfg.end)
    # R5: linhas com IP corporativo "wildcard" (0.0.0.0 / ::) representam
    # ausencia de IP tunelado — descartamos como se nao existissem.
    ignored_ips = tuple(sorted(mta_mod.IGNORED_IPS))
    ignored_ip_marks = ", ".join("?" for _ in ignored_ips)
    events_sql = (
        "SELECT TRIM({user}) AS USER_KEY, {ts} AS VPN_TS, "  # nosec B608 -- identificadores validados e IN contém apenas placeholders
        "TRIM({corp}) AS CPTV_IP "
        "FROM {tbl} WHERE {ts} >= ? AND {ts} < ? "
        "AND {user} IS NOT NULL AND TRIM({user}) <> '' "
        "AND {corp} IS NOT NULL AND TRIM({corp}) <> '' "
        "AND TRIM({corp}) NOT IN ({ignored}) "
        "ORDER BY {ts} ASC"
    ).format(
        user=vpn.user_column,
        ts=vpn.timestamp_column,
        corp=vpn.corporate_ip_column,
        tbl=qualified(vpn.schema, vpn.table),
        ignored=ignored_ip_marks,
    )
    rows = fetch_all(conn, events_sql, (start_s, end_s) + ignored_ips)
    vpn_events = {}
    seen_vpn_events = set()
    for row in rows:
        user = normalize_identifier(row.get("USER_KEY"))
        ts = row.get("VPN_TS")
        if not user or ts is None:
            continue
        if user in cfg.detection.excluded_user_allowlist:
            continue
        cptv_ip = normalize_ip(row.get("CPTV_IP"))
        if mta_mod.is_ignored_ip(cptv_ip):
            # Defesa em profundidade: descarta se o TRIM do DB2 nao normalizou.
            continue
        natural_key = (user, str(ts), cptv_ip)
        if natural_key in seen_vpn_events:
            continue
        seen_vpn_events.add(natural_key)
        vpn_events.setdefault(str(user), []).append({
            "ts": ts,
            "cptv_ip": cptv_ip,
        })
    if not vpn_events:
        return BacktestCaseResult(
            name=case_name,
            status="ok",
            count=0,
            sample=[],
            note=(
                "Nenhum evento VPN no período; nada a correlacionar em DB2PEP.MTA_AUT_CLI_TRAN."
            ),
        )
    from datetime import timedelta as _td
    chunk_hours = int(getattr(mta_cfg, "chunk_hours", 24) or 24)
    chunk_delta = _td(hours=chunk_hours)
    total_users = len(vpn_events)
    matches_by_user = {}
    chunks = {}
    chunk_seconds = chunk_delta.total_seconds()
    for user, user_events in vpn_events.items():
        for event in user_events:
            chunk_index = int((event["ts"] - cfg.start).total_seconds() // chunk_seconds)
            chunks.setdefault(chunk_index, {}).setdefault(user, []).append(event)
    for chunk_index in sorted(chunks):
        chunk_events = chunks[chunk_index]
        if chunk_events:
            chunk_hits = mta_mod.match_vpn_events(conn, mta_cfg, chunk_events)
            for u, hits in chunk_hits.items():
                if hits:
                    matches_by_user.setdefault(u, []).extend(hits)
    flat_by_key = {}
    users_hit = set()
    for user, hits in matches_by_user.items():
        for h in hits:
            finding = {
                "USER_KEY": user,
                "VPN_TS": h["ts_vpn"],
                "VPN_CPTV_IP": h["cptv_ip"],
                "MTA_TS": h["ts_mta"],
                "MTA_IP_CLIENTE": h["ip_cliente"],
                "MTA_CD_IDFR_MTA": h.get("cd_idfr_mta"),
                "MTA_CD_UNCO_TRAN": h["cd_unco_tran"],
                "MTA_CD_CLI_TRAN": h.get("cd_cli_tran"),
                "MTA_NM_ETP": h["nm_etp"],
            }
            natural_key = (
                finding["USER_KEY"], str(finding["VPN_TS"]),
                finding["VPN_CPTV_IP"], str(finding["MTA_TS"]),
                finding["MTA_IP_CLIENTE"], finding["MTA_CD_UNCO_TRAN"],
                finding["MTA_CD_IDFR_MTA"],
            )
            flat_by_key[natural_key] = finding
            users_hit.add(user)
    flat = list(flat_by_key.values())
    flat.sort(key=lambda x: x["VPN_TS"], reverse=True)
    sample = flat[: cfg.sample_limit]
    occurrences = [_r5_occurrence(row, cfg) for row in flat]
    return BacktestCaseResult(
        name=case_name,
        status="ok",
        count=len(flat),
        sample=sample,
        occurrences=occurrences,
        rule_id="R5",
        rule_title="Correlação temporal entre evento VPN e autenticação OpenAM em IP diferente",
        rule_version="2.1.0",
        severity="ALTA",
        note=(
            "Fluxos bem-sucedidos em DB2PEP.MTA_AUT_CLI_TRAN (nodes {node_names}) para o mesmo usuário da"
            " VPN, dentro de +/-{d} min, com ipCliente em {cidrs} e distinto"
            " do IP tunelado; dedup por CD_UNCO_TRAN. Usuários distintos"
            " sinalizados: {u}. O universo de {total} usuários foi processado "
            "integralmente em rodadas de no máximo {round_size} usuários."
        ).format(
            node_names=", ".join(mta_cfg.decision_nodes),
            d=mta_cfg.delta_minutes,
            cidrs=", ".join(str(n) for n in mta_cfg.ip_networks),
            u=len(users_hit),
            total=total_users,
            round_size=mta_cfg.max_users_per_run,
        ),
    )


def run_backtest_cases(conn, cfg, progress=None, cancellation=None, worker_limits=None):
    """Valida as tabelas e executa as regras sobre eventos deduplicados.

    ``progress``, ``cancellation`` e ``worker_limits`` são opcionais para
    preservar a compatibilidade dos chamadores existentes; quando informados,
    o progresso detalhado é publicado e o cancelamento é respeitado nas
    fronteiras de fase.
    """
    progress = progress or _NullProgress()
    validate_configured_tables(conn, cfg)
    progress.start_phase(_PHASES["querying"], total_units=None, message="Contando eventos do período.")
    metrics = run_summary(conn, cfg)
    expected_rows = int(metrics.get("total_events_analyzed") or 0)
    progress.set_total(expected_rows or None)
    progress.set_counter("expected_database_rows", expected_rows)
    if cancellation is not None:
        cancellation.raise_if_cancelled()
    vpn = cfg.vpn_table
    sql = (
        "SELECT TRIM({user}) AS USER_KEY, {ts} AS EVENT_TS, "  # nosec B608 -- identificadores passam pela allowlist; datas usam binding
        "TRIM({src}) AS SOURCE_IP, TRIM({corp}) AS CORPORATE_IP, "
        "TRIM({host}) AS HOSTNAME, TRIM({dev}) AS DEVICE_ID "
        "FROM {table} WHERE {ts} >= ? AND {ts} < ? "
        "ORDER BY {ts}, TRIM({user})"
    ).format(
        user=vpn.user_column, ts=vpn.timestamp_column,
        src=vpn.source_ip_column, corp=vpn.corporate_ip_column,
        host=vpn.hostname_column, dev=vpn.device_column,
        table=qualified(vpn.schema, vpn.table),
    )
    rows = fetch_all(conn, sql, ts_params(cfg.start, cfg.end))
    progress.set_total(len(rows))
    progress.set_position(len(rows), message="{0} linha(s) lidas da fonte.".format(len(rows)))
    progress.set_counter("database_rows_read", len(rows))
    if cancellation is not None:
        cancellation.raise_if_cancelled()
    progress.start_phase(
        _PHASES["normalizing"], total_units=max(1, len(rows)),
        message="Normalizando e deduplicando as linhas lidas.",
    )
    enabled_event_rules = [
        rule for rule in ("R1", "R2", "R3", "R4", "R7", "R8", "R9")
        if rule in cfg.detection.enabled_rules
    ]
    progress.start_phase(
        _PHASES["evaluating"], total_units=max(1, len(enabled_event_rules)),
        message="Avaliando {0} regra(s) de evento.".format(len(enabled_event_rules)),
    )
    detected, quality = run_event_rules(
        rows,
        cfg.detection,
        max_workers=int(getattr(worker_limits, "rule_workers", 1) or 1),
        on_rule_done=lambda rule_id, occurrences: progress.advance(
            1, rule_id=rule_id,
            message="{0}: {1} ocorrência(s).".format(rule_id, len(occurrences)),
        ),
    )
    progress.merge_counters(quality)
    metrics.update({
        "database_rows_analyzed": quality["input_rows"],
        "deduplicated_events_analyzed": quality["deduplicated_events"],
        "total_users_analyzed": quality["distinct_valid_users"],
        "total_devices_analyzed": quality["distinct_valid_devices"],
        "duplicate_database_rows_ignored": quality["duplicate_rows"],
        "data_quality": quality,
    })
    names = {
        "R1": "ips_distintos_acima_do_limite",
        "R2": "hostnames_distintos_acima_do_limite",
        "R3": "dispositivos_distintos_acima_do_limite",
        "R4": "logins_diarios_acima_do_limite",
        "R7": "dispositivo_multiplos_usuarios",
        "R8": "usuario_multiplos_dispositivos_intervalo_curto",
        "R9": "troca_rapida_ips",
    }
    notes = {
        "R1": "Usuário+dia com pelo menos {0} IPs válidos distintos no campo de origem ou no campo corporativo/túnel; os campos não são misturados.".format(cfg.detection.r1_min_distinct_ips),
        "R2": "Usuário com mais de {0} nomes de computador distintos no período.".format(cfg.detection.r2_distinct_hostname_limit),
        "R3": "Usuário com mais de {0} dispositivos válidos distintos no período.".format(cfg.detection.r3_distinct_device_limit),
        "R4": (
            "Usuário+dia com mais de {0} eventos de login VPN deduplicados. "
            "Severidade média até {1}, alta de {2} a {3} e crítica acima "
            "de {3}."
        ).format(
            cfg.detection.r4_vpn_login_limit,
            cfg.detection.r4_high_severity_above,
            cfg.detection.r4_high_severity_above + 1,
            cfg.detection.r4_critical_severity_above,
        ),
        "R7": "Dispositivo com dois ou mais usuários distintos; janelas configuradas de {0} dias consolidadas.".format(", ".join(str(value) for value in cfg.detection.device_windows_days)),
        "R8": "Usuário em pelo menos {0} dispositivos em até {1} minutos.".format(cfg.detection.multi_device_min_devices, cfg.detection.multi_device_window_minutes),
        "R9": "Usuário com pelo menos {0} IPs de origem em até {1} minutos.".format(cfg.detection.rapid_ip_min_distinct, cfg.detection.rapid_ip_window_minutes),
    }
    cases = []
    for rule_id in ("R1", "R2", "R3", "R4"):
        occurrences = detected.get(rule_id, [])
        meta = RULE_CATALOG[rule_id]
        cases.append(BacktestCaseResult(
            name=names[rule_id],
            status="ok" if rule_id in cfg.detection.enabled_rules else "disabled",
            count=len(occurrences),
            sample=[occurrence_to_legacy_sample(item) for item in occurrences[:cfg.sample_limit]],
            note=notes[rule_id], occurrences=occurrences, rule_id=rule_id,
            rule_title=meta["title"], rule_version=meta["version"],
            severity=meta["severity"], quality=quality,
        ))
    cases.append(run_active_vpn_plus_physical_login_case(conn, cfg))
    if cancellation is not None:
        cancellation.raise_if_cancelled()
    progress.start_phase(
        _PHASES["correlating"], total_units=2,
        message="Correlacionando eventos VPN com autenticações OpenAM (R5/R6).",
    )
    if "R5" in cfg.detection.enabled_rules:
        r5_case = run_vpn_plus_mta_physical_case(conn, cfg)
        progress.advance(1, rule_id="R5", message="R5: {0} correlação(ões).".format(r5_case.count))
    else:
        r5_case = BacktestCaseResult(
            name="vpn_ativa_com_login_em_rede_fisica_mta", status="disabled",
            count=0, sample=[], note="R5 desabilitada na configuração.", rule_id="R5",
        )
        progress.advance(1, rule_id="R5")
    cases.append(r5_case)
    if "R6" in cfg.detection.enabled_rules:
        r6_case = _synthesize_r6_case(conn, cfg, r5_case)
        cases.append(r6_case)
        progress.advance(1, rule_id="R6", message="R6: {0} ocorrência(s).".format(r6_case.count))
    else:
        cases.append(BacktestCaseResult(
            name="vpn_ativa_com_login_em_rede_fisica_mta_multiplos_dispositivos",
            status="disabled", count=0, sample=[], note="R6 desabilitada na configuração.", rule_id="R6",
        ))
        progress.advance(1, rule_id="R6")
    for rule_id in ("R7", "R8", "R9"):
        occurrences = detected.get(rule_id, [])
        meta = RULE_CATALOG[rule_id]
        status = "ok" if rule_id in cfg.detection.enabled_rules else "disabled"
        cases.append(BacktestCaseResult(
            name=names[rule_id], status=status, count=len(occurrences),
            sample=[occurrence_to_legacy_sample(item) for item in occurrences[:cfg.sample_limit]],
            note=notes[rule_id], occurrences=occurrences, rule_id=rule_id,
            rule_title=meta["title"], rule_version=meta["version"],
            severity=meta["severity"], quality=quality,
        ))
    return metrics, cases


def _synthesize_r6_case(conn, cfg, r5_case):
    """R6: R5 + múltiplos hostnames/dispositivos no período.

    Toma o conjunto completo de usuários sinalizados por R5 e
    consulta a tabela VPN para descobrir quantos hostnames e dispositivos
    distintos cada usuario apresenta no periodo. Sao mantidos apenas os
    usuários que excedem `cfg.distinct_limit` em pelo menos uma das métricas.
    A diversidade no período não é tratada como simultaneidade.
    """
    case_name = "vpn_ativa_com_login_em_rede_fisica_mta_multiplos_dispositivos"
    r5_users = []
    seen = set()
    r5_rows = []
    if r5_case.occurrences:
        for occurrence in r5_case.occurrences:
            evidence = occurrence.get("evidence_records") or []
            if evidence:
                r5_rows.append(evidence[0])
    else:
        r5_rows = list(r5_case.sample or [])
    for row in r5_rows:
        uk = row.get("USER_KEY")
        if not uk:
            continue
        uk = str(uk).strip()
        if uk and uk not in seen:
            seen.add(uk)
            r5_users.append(uk)
    if r5_case.status != "ok" or not r5_users:
        return BacktestCaseResult(
            name=case_name,
            status="skipped",
            count=0,
            sample=[],
            note=(
                "R6 depende de R5 estar disponivel e ter usuarios sinalizados"
                " (universo vazio; caso nao executado)."
            ),
        )
    vpn = cfg.vpn_table
    host_limit = int(getattr(
        cfg.detection, "r2_distinct_hostname_limit", cfg.distinct_limit
    ))
    device_limit = int(getattr(
        cfg.detection, "r3_distinct_device_limit", cfg.distinct_limit
    ))
    start_s, end_s = ts_params(cfg.start, cfg.end)
    rows = []
    # Mantém a quantidade de marcadores abaixo dos limites usuais do driver e
    # do DB2. Todos os usuários são processados; o lote não é uma amostra.
    for batch_start in range(0, len(r5_users), 200):
        user_batch = r5_users[batch_start:batch_start + 200]
        placeholders = ",".join(["?"] * len(user_batch))
        host_expr = _distinct_expr(vpn.hostname_column)
        device_expr = _distinct_expr(vpn.device_column)
        sql = (
            "SELECT TRIM({user}) AS USER_KEY, "  # nosec B608 -- identificadores validados e lote usa placeholders
            "{host_expr} AS DISTINCT_HOSTNAMES, "
            "{device_expr} AS DISTINCT_DEVICES, "
            "COUNT(1) AS EVENTS "
            "FROM {tbl} "
            "WHERE {ts} >= ? AND {ts} < ? "
            "AND TRIM({user}) IN ({ph}) "
            "GROUP BY TRIM({user}) "
            "HAVING {host_expr} > ? OR {device_expr} > ?"
        ).format(
            user=vpn.user_column,
            host_expr=host_expr,
            device_expr=device_expr,
            tbl=qualified(vpn.schema, vpn.table),
            ts=vpn.timestamp_column,
            ph=placeholders,
        )
        params = (
            (start_s, end_s)
            + tuple(user_batch)
            + (host_limit, device_limit)
        )
        try:
            rows.extend(fetch_all(conn, sql, params))
        except Exception as exc:
            raise RuntimeError(
                "R6 não pôde consultar a diversidade de equipamentos; "
                "nenhum resultado parcial deve ser publicado."
            ) from exc
    per_user = {}
    for row in rows:
        uk = row.get("USER_KEY")
        if uk is None:
            continue
        per_user[str(uk).strip()] = row
    sample = []
    occurrences = []
    for r5_row in r5_rows:
        uk = str(r5_row.get("USER_KEY") or "").strip()
        counts = per_user.get(uk)
        if not counts:
            continue
        enriched = dict(r5_row)
        enriched["DISTINCT_HOSTNAMES"] = counts.get("DISTINCT_HOSTNAMES")
        enriched["DISTINCT_DEVICES"] = counts.get("DISTINCT_DEVICES")
        enriched["TOTAL_EVENTS_VPN"] = counts.get("EVENTS")
        sample.append(enriched)
        r5_occurrence = _r5_occurrence(r5_row, cfg)
        r5_occurrence.update({
            "occurrence_id": "R6-{0}".format(r5_occurrence["occurrence_id"].split("-", 1)[1]),
            "rule_id": "R6",
            "rule_title": "Correlação R5 com múltiplos equipamentos no período",
            "rule_version": "2.1.0",
            "explanation": (
                "Ocorrência R5 para usuário que também apresentou {0} hostname(s) "
                "e {1} dispositivo(s) distintos no período; pelo menos uma contagem "
                "é maior que seu limite configurado (hostname > {2}; "
                "dispositivo > {3})."
            ).format(
                counts.get("DISTINCT_HOSTNAMES"),
                counts.get("DISTINCT_DEVICES"),
                host_limit,
                device_limit,
            ),
            "triggering_value": {
                "distinct_hostnames": counts.get("DISTINCT_HOSTNAMES"),
                "distinct_devices": counts.get("DISTINCT_DEVICES"),
            },
            "configured_threshold": {
                "operator": ">",
                "hostname_value": host_limit,
                "device_value": device_limit,
            },
        })
        occurrences.append(r5_occurrence)
    sample = sample[: cfg.sample_limit]
    return BacktestCaseResult(
        name=case_name,
        status="ok",
        count=len(occurrences),
        sample=sample,
        occurrences=occurrences,
        rule_id="R6",
        rule_title="Correlação R5 com múltiplos equipamentos no período",
        rule_version="2.1.0",
        severity="ALTA",
        note=(
            "R5 restrito a usuários com mais de {host_lim} hostnames OU mais "
            "de {device_lim} dispositivos distintos no período. A diversidade não"
            " comprova uso simultâneo. Usuários distintos: {u}."
        ).format(
            host_lim=host_limit,
            device_lim=device_limit,
            u=len(per_user),
        ),
    )
