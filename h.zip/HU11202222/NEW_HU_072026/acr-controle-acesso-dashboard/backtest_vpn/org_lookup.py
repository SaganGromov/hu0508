"""Enriquecimento organizacional dos dossiês de backtesting via Curio.

O modelo normalizado (``report_model``) aceita diretamente os registros brutos
das duas operações do Curio:

* ``op292018v3`` (ATC) — códigos organizacionais: ``nomeUsuario``,
  ``numeroMatriculaUsuario``, ``codigoUnidadeOrganizacionalDependenciaUsuario``,
  ``codigoPrefixoDependenciaAtual``, ``codigoComissaoUsuario`` e
  ``codigoTipoUsuario``;
* ``op5360402v1`` (ARH) — nomes legíveis: ``nomeFuncionario``,
  ``nomeDependenciaLotacao`` (local de trabalho) e ``nomeFuncaoLotacao``
  (cargo), de onde também saem departamento, unidade e hierarquia.

Faltava apenas alguém consultar o Curio e entregar esses registros como
``employee_details``; sem isso todo dossiê saía com "Não informado".

O cliente é exatamente o mesmo usado pelas páginas Streamlit
(``streamlit_app/org_enrichment.fetch_employee_profile``), o que preserva os
payloads corretos, as duas tentativas em falha transitória, o disjuntor de
conexão e a variável ``CURIO_ENABLED``. Este módulo apenas o localiza, porque
``streamlit_app`` é um diretório de scripts, não um pacote importável.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Callable, Iterable, Optional

logger = logging.getLogger("backtest_vpn.org_lookup")

_MATRICULA_RE = re.compile(r"^[A-Za-z]\d{7}$")


def is_matricula(value) -> bool:
    """``True`` somente para matrículas reais (``F1234567``).

    Chaves pseudonimizadas (``U-<hash>``) nunca são enviadas ao Curio.
    """
    if not value:
        return False
    return bool(_MATRICULA_RE.match(str(value).strip()))


def _streamlit_app_dir() -> Optional[Path]:
    try:
        import acr_controle_acesso_dashboard as package
    except Exception:  # pragma: no cover - pacote sempre presente em produção
        return None
    candidate = Path(package.__file__).resolve().parent / "streamlit_app"
    return candidate if candidate.is_dir() else None


def load_org_fetcher() -> Optional[Callable]:
    """Devolve o coletor em lote de perfis ou ``None`` se indisponível."""
    directory = _streamlit_app_dir()
    if directory is None:
        logger.warning("Cliente Curio não localizado; enriquecimento organizacional desativado.")
        return None
    import sys

    path = str(directory)
    if path not in sys.path:
        sys.path.insert(0, path)
    try:
        from org_enrichment import fetch_employee_profiles  # type: ignore[import-not-found]
    except Exception:
        logger.warning("Cliente Curio não pôde ser carregado; enriquecimento organizacional desativado.")
        return None
    return fetch_employee_profiles


def collect_user_ids(bundle: dict) -> list[str]:
    """Extrai os usuários do bundle na mesma convenção do modelo normalizado."""
    if not isinstance(bundle, dict):
        return []
    users: set[str] = set()

    def _add(value) -> None:
        if value in (None, ""):
            return
        users.add(str(value).strip())

    for case in (bundle.get("summary") or {}).get("cases") or []:
        if not isinstance(case, dict):
            continue
        occurrences = case.get("occurrences")
        if isinstance(occurrences, list):
            for occurrence in occurrences:
                if not isinstance(occurrence, dict):
                    continue
                _add(occurrence.get("user_id"))
                details = occurrence.get("details")
                if isinstance(details, dict):
                    for item in details.get("users") or []:
                        _add(item)
        for sample in case.get("sample") or []:
            if isinstance(sample, dict):
                _add(sample.get("USER_KEY") or sample.get("user_id"))
    return sorted(users)


def fetch_employee_details(
    bundle: dict,
    *,
    curio_client: Optional[Callable[[str], Optional[dict]]] = None,
    user_ids: Optional[Iterable[str]] = None,
) -> dict:
    """Consulta o Curio para cada matrícula do bundle.

    Devolve ``{matrícula: registro}``. Usuários pseudonimizados e falhas
    individuais são simplesmente omitidos: o dossiê exibe "Não informado" para
    eles, sem inventar dado nem interromper a geração do relatório.
    """
    candidates = [
        user for user in (user_ids if user_ids is not None else collect_user_ids(bundle))
        if is_matricula(user)
    ]
    if not candidates:
        return {}
    client = curio_client if curio_client is not None else load_org_fetcher()
    if client is None:
        return {}

    details: dict[str, dict] = {}
    unique = sorted({str(user).strip().upper() for user in candidates})
    if curio_client is None:
        try:
            records = client(unique)
        except Exception:
            records = {}
        if isinstance(records, dict):
            details.update({
                str(key).strip().upper(): value
                for key, value in records.items()
                if isinstance(value, dict) and value
            })
    else:
        # Injeção simples preservada para testes e consumidores customizados.
        for matricula in unique:
            try:
                record = client(matricula)
            except Exception:
                record = None
            if isinstance(record, dict) and record:
                details[matricula] = record

    resolved = len(details)
    total = len(set(candidates))
    if resolved < total:
        logger.warning(
            "Enriquecimento organizacional parcial: %s de %s matrículas resolvidas pelo Curio.",
            resolved,
            total,
        )
    else:
        logger.info("Enriquecimento organizacional concluído para %s matrícula(s).", resolved)
    return details


__all__ = [
    "collect_user_ids",
    "fetch_employee_details",
    "is_matricula",
    "load_org_fetcher",
]
