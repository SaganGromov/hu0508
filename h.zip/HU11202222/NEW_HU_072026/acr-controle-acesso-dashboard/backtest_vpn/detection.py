"""Detecção determinística e explicável sobre eventos de ``AUT_CPTV``.

O módulo não acessa banco de dados. Ele recebe as seis colunas cuja semântica
já é usada pelo projeto, normaliza os valores, remove apenas duplicatas exatas
e produz ocorrências estáveis. Timestamps sem offset são tratados como horário
local de ``America/Sao_Paulo``, que é a convenção da aplicação.
"""

from __future__ import annotations

import hashlib
import ipaddress
import json
import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Iterable
from zoneinfo import ZoneInfo


APP_TIMEZONE = "America/Sao_Paulo"

RULE_CATALOG = {
    "R1": {
        "title": "Alteração de endereço IP no mesmo dia",
        "version": "2.1.0",
        "severity": "MÉDIA",
    },
    "R2": {
        "title": "Múltiplos nomes de computador no período",
        "version": "2.0.0",
        "severity": "BAIXA",
    },
    "R3": {
        "title": "Múltiplos dispositivos no período",
        "version": "2.0.0",
        "severity": "BAIXA",
    },
    "R4": {
        "title": "Mais de dois logins VPN no mesmo dia",
        "version": "2.2.0",
        "severity": "VARIÁVEL",
    },
    "R7": {
        "title": "Dispositivo associado a múltiplos usuários",
        "version": "1.1.0",
        "severity": "VARIÁVEL",
    },
    "R8": {
        "title": "Usuário em múltiplos dispositivos em curto intervalo",
        "version": "1.1.0",
        "severity": "MÉDIA",
    },
    "R9": {
        "title": "Troca rápida de endereços IP",
        "version": "1.1.0",
        "severity": "MÉDIA",
    },
}

_PLACEHOLDERS = {
    "-", "--", "0", "00", "00000000", "DESCONHECIDO", "INDEFINIDO",
    "N/A", "NA", "NONE", "NULL", "SEM DADO", "SEM_DADO", "UNKNOWN",
}
_CONTROL_RE = re.compile(r"[\x00-\x1f\x7f]")


@dataclass(frozen=True)
class DetectionConfig:
    """Parâmetros centralizados das regras baseadas em ``AUT_CPTV``."""

    timezone: str = APP_TIMEZONE
    r1_min_distinct_ips: int = 2
    r2_distinct_hostname_limit: int = 2
    r3_distinct_device_limit: int = 2
    r4_vpn_login_limit: int = 2
    r4_high_severity_above: int = 10
    r4_critical_severity_above: int = 20
    device_windows_days: tuple[int, ...] = (1, 7, 30)
    multi_device_window_minutes: int = 60
    multi_device_min_devices: int = 2
    rapid_ip_window_minutes: int = 120
    rapid_ip_min_distinct: int = 3
    enabled_rules: tuple[str, ...] = ("R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8", "R9")
    shared_device_allowlist: frozenset[str] = field(default_factory=frozenset)
    excluded_user_allowlist: frozenset[str] = field(default_factory=frozenset)
    corporate_ip_networks: tuple[ipaddress._BaseNetwork, ...] = ()
    vpn_ip_networks: tuple[ipaddress._BaseNetwork, ...] = ()

    @classmethod
    def from_mapping(cls, value: dict | None) -> "DetectionConfig":
        raw = dict(value or {})

        def _positive(name: str, default: int) -> int:
            try:
                result = int(raw.get(name, default))
            except (TypeError, ValueError):
                raise ValueError("{0} deve ser um inteiro positivo.".format(name))
            if result <= 0:
                raise ValueError("{0} deve ser um inteiro positivo.".format(name))
            return result

        def _values(name: str) -> frozenset[str]:
            supplied = raw.get(name) or []
            if not isinstance(supplied, list):
                raise ValueError("{0} deve ser uma lista.".format(name))
            return frozenset(
                normalized for item in supplied
                if (normalized := normalize_identifier(item)) is not None
            )

        def _networks(name: str) -> tuple[ipaddress._BaseNetwork, ...]:
            supplied = raw.get(name) or []
            if not isinstance(supplied, list):
                raise ValueError("{0} deve ser uma lista de CIDRs.".format(name))
            try:
                return tuple(ipaddress.ip_network(str(item).strip(), strict=False) for item in supplied)
            except ValueError as exc:
                raise ValueError("CIDR inválido em {0}: {1}".format(name, exc))

        enabled = raw.get(
            "enabled_rules",
            ["R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8", "R9"],
        )
        if not isinstance(enabled, list):
            raise ValueError("enabled_rules deve ser uma lista.")
        if not enabled:
            raise ValueError("enabled_rules deve conter pelo menos uma regra.")
        normalized_enabled = [str(item).strip().upper() for item in enabled]
        enabled_set = set(normalized_enabled)
        unknown = sorted(enabled_set - set(RULE_CATALOG) - {"R5", "R6"})
        if unknown:
            raise ValueError("Regras desconhecidas em enabled_rules: {0}".format(", ".join(unknown)))
        supplied_windows = raw.get("device_windows_days", [1, 7, 30])
        if not isinstance(supplied_windows, list):
            raise ValueError("device_windows_days deve ser uma lista.")
        try:
            windows = tuple(sorted({int(value) for value in supplied_windows}))
        except (TypeError, ValueError):
            raise ValueError("device_windows_days deve conter somente inteiros.")
        if any(value <= 0 for value in windows):
            raise ValueError("device_windows_days deve conter somente inteiros positivos.")
        if 1 not in windows or len(windows) < 2:
            raise ValueError(
                "device_windows_days deve conter 1 e ao menos uma janela maior."
            )
        r4_limit = _positive("r4_vpn_login_limit", 2)
        if r4_limit != 2:
            raise ValueError(
                "r4_vpn_login_limit deve ser 2: R4 sinaliza exatamente três "
                "ou mais logins VPN no dia local."
            )
        r4_high = _positive("r4_high_severity_above", 10)
        r4_critical = _positive("r4_critical_severity_above", 20)
        if r4_high <= r4_limit:
            raise ValueError(
                "r4_high_severity_above deve ser maior que r4_vpn_login_limit."
            )
        if r4_critical <= r4_high:
            raise ValueError(
                "r4_critical_severity_above deve ser maior que "
                "r4_high_severity_above."
            )
        return cls(
            timezone=str(raw.get("timezone") or APP_TIMEZONE),
            r1_min_distinct_ips=_positive("r1_min_distinct_ips", 2),
            r2_distinct_hostname_limit=_positive("r2_distinct_hostname_limit", 2),
            r3_distinct_device_limit=_positive("r3_distinct_device_limit", 2),
            r4_vpn_login_limit=r4_limit,
            r4_high_severity_above=r4_high,
            r4_critical_severity_above=r4_critical,
            device_windows_days=windows,
            multi_device_window_minutes=_positive("multi_device_window_minutes", 60),
            multi_device_min_devices=_positive("multi_device_min_devices", 2),
            rapid_ip_window_minutes=_positive("rapid_ip_window_minutes", 120),
            rapid_ip_min_distinct=_positive("rapid_ip_min_distinct", 3),
            enabled_rules=tuple(
                rule for rule in ("R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8", "R9")
                if rule in enabled_set
            ),
            shared_device_allowlist=_values("shared_device_allowlist"),
            excluded_user_allowlist=_values("excluded_user_allowlist"),
            corporate_ip_networks=_networks("corporate_ip_networks"),
            vpn_ip_networks=_networks("vpn_ip_networks"),
        )


def normalize_identifier(value) -> str | None:
    """Normaliza usuário, hostname ou dispositivo sem inferir sua semântica."""
    if value is None:
        return None
    text = " ".join(str(value).strip().split()).upper()
    if not text or text in _PLACEHOLDERS or len(text) > 256 or _CONTROL_RE.search(text):
        return None
    return text


def _normalize_ip_with_status(value) -> tuple[str | None, str]:
    """Normaliza um IP e informa por que um valor não pôde ser usado."""
    if value is None:
        return None, "missing"
    text = str(value).strip()
    if not text:
        return None, "missing"
    try:
        address = ipaddress.ip_address(text)
    except ValueError:
        return None, "invalid"
    if address.is_unspecified:
        return None, "unspecified"
    return address.compressed.lower(), "valid"


def normalize_ip(value) -> str | None:
    """Retorna IPv4/IPv6 canônico e ignora inválidos ou não especificados.

    ``ipaddress`` reconhece todas as representações equivalentes do endereço
    não especificado. Assim, ``0.0.0.0``, ``::``, ``::0`` e a forma IPv6
    expandida são sempre tratados como dado ausente, sem uma lista textual
    incompleta de casos especiais.
    """
    return _normalize_ip_with_status(value)[0]


def normalize_timestamp(value, timezone_name: str = APP_TIMEZONE) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        parsed = value
    else:
        text = str(value).strip()
        parsed = None
        for candidate in (text, text.replace("T", " "), text[:26]):
            try:
                parsed = datetime.fromisoformat(candidate)
                break
            except ValueError:
                continue
        if parsed is None:
            return None
    try:
        tz = ZoneInfo(timezone_name)
    except Exception:
        if timezone_name != APP_TIMEZONE:
            raise ValueError("Fuso horário indisponível: {0}".format(timezone_name))
        # America/Sao_Paulo não observa horário de verão desde 2019. Este
        # fallback mantém execuções recentes possíveis em imagens mínimas;
        # instalações normais devem fornecer tzdata para datas históricas.
        tz = timezone(timedelta(hours=-3), name="-03")
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=tz)
    return parsed.astimezone(tz)


def _stable_hash(*parts: object) -> str:
    payload = json.dumps(parts, ensure_ascii=False, separators=(",", ":"), default=str)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _network_classification(ip_text: str | None, cfg: DetectionConfig) -> str:
    if not ip_text:
        return "não determinada"
    address = ipaddress.ip_address(ip_text)
    for network in cfg.vpn_ip_networks:
        if address.version == network.version and address in network:
            return "VPN configurada"
    for network in cfg.corporate_ip_networks:
        if address.version == network.version and address in network:
            return "rede corporativa configurada"
    if cfg.vpn_ip_networks or cfg.corporate_ip_networks:
        return "externa às faixas configuradas"
    return "não determinada (faixas não configuradas)"


def normalize_events(rows: Iterable[dict], cfg: DetectionConfig) -> tuple[list[dict], dict]:
    """Normaliza e deduplica linhas exatas, preservando a chave natural."""
    events: dict[tuple, dict] = {}
    stats = {
        "input_rows": 0,
        "duplicate_rows": 0,
        "invalid_timestamp_rows": 0,
        "invalid_user_rows": 0,
        "invalid_source_ip_rows": 0,
        "invalid_corporate_ip_rows": 0,
        "unspecified_source_ip_rows": 0,
        "unspecified_corporate_ip_rows": 0,
        "invalid_device_rows": 0,
    }
    for row in rows:
        stats["input_rows"] += 1
        user = normalize_identifier(row.get("USER_KEY") or row.get("CD_USU_AUT"))
        ts = normalize_timestamp(row.get("EVENT_TS") or row.get("TS_TRAN"), cfg.timezone)
        source_ip, source_ip_status = _normalize_ip_with_status(
            row.get("SOURCE_IP") or row.get("CD_END_LGC_OGM")
        )
        corporate_ip, corporate_ip_status = _normalize_ip_with_status(
            row.get("CORPORATE_IP") or row.get("CD_END_LGC_CPTV")
        )
        hostname = normalize_identifier(row.get("HOSTNAME") or row.get("NM_DSVO"))
        device = normalize_identifier(row.get("DEVICE_ID") or row.get("CD_IDFC_DSVO"))
        if not user:
            stats["invalid_user_rows"] += 1
        if not ts:
            stats["invalid_timestamp_rows"] += 1
        if not source_ip:
            stats["invalid_source_ip_rows"] += 1
            if source_ip_status == "unspecified":
                stats["unspecified_source_ip_rows"] += 1
        if not corporate_ip:
            stats["invalid_corporate_ip_rows"] += 1
            if corporate_ip_status == "unspecified":
                stats["unspecified_corporate_ip_rows"] += 1
        if not device:
            stats["invalid_device_rows"] += 1
        if not user or not ts:
            continue
        natural_key = (
            user, ts.isoformat(), source_ip or "", corporate_ip or "",
            hostname or "", device or "",
        )
        event_id = str(row.get("EVENT_ID") or "").strip() or "AUT-" + _stable_hash(*natural_key)[:20]
        if natural_key in events:
            stats["duplicate_rows"] += 1
            continue
        events[natural_key] = {
            "event_id": event_id,
            "natural_key": "|".join(natural_key),
            "user_id": user,
            "timestamp": ts,
            "local_date": ts.date().isoformat(),
            "source_ip": source_ip,
            "source_ip_classification": _network_classification(source_ip, cfg),
            "corporate_ip": corporate_ip,
            "corporate_ip_classification": _network_classification(corporate_ip, cfg),
            "hostname": hostname,
            "device_id": device,
            "session_id": row.get("SESSION_ID"),
            "authentication_id": row.get("AUTHENTICATION_ID"),
        }
    ordered = sorted(events.values(), key=lambda event: (event["timestamp"], event["user_id"], event["event_id"]))
    stats["deduplicated_events"] = len(ordered)
    stats["distinct_valid_users"] = len({event["user_id"] for event in ordered})
    stats["distinct_valid_devices"] = len({
        event["device_id"] for event in ordered if event["device_id"]
    })
    return ordered, stats


def _public_event(event: dict) -> dict:
    return {
        key: (value.isoformat() if isinstance(value, datetime) else value)
        for key, value in event.items() if key != "natural_key"
    }


def _occurrence(
    rule_id: str,
    evidence: list[dict],
    *,
    user_id: str | None = None,
    device_id: str | None = None,
    local_date: str | None = None,
    triggering_value=None,
    threshold=None,
    explanation: str,
    severity: str | None = None,
    window_start: datetime | str | None = None,
    window_end: datetime | str | None = None,
    relevant_ips: Iterable[str] = (),
    relevant_devices: Iterable[str] = (),
    relevant_sessions: Iterable[str] = (),
    exclusions: Iterable[str] = (),
    details: dict | None = None,
) -> dict:
    meta = RULE_CATALOG[rule_id]
    event_ids = sorted({str(item["event_id"]) for item in evidence if item.get("event_id")})
    first = min((item["timestamp"] for item in evidence), default=None)
    last = max((item["timestamp"] for item in evidence), default=None)
    dedup_key = "|".join([
        rule_id, user_id or "", device_id or "", local_date or "",
        ",".join(event_ids),
    ])
    return {
        "occurrence_id": "{0}-{1}".format(rule_id, _stable_hash(dedup_key)[:20]),
        "rule_id": rule_id,
        "rule_title": meta["title"],
        "rule_version": meta["version"],
        "severity": severity or meta["severity"],
        "user_id": user_id,
        "device_id": device_id,
        "local_date": local_date,
        "window_start": (
            window_start.isoformat() if isinstance(window_start, datetime) else window_start
        ) or (first.isoformat() if first else None),
        "window_end": (
            window_end.isoformat() if isinstance(window_end, datetime) else window_end
        ) or (last.isoformat() if last else None),
        "triggering_value": triggering_value,
        "configured_threshold": threshold,
        "explanation": explanation,
        "supporting_event_identifiers": event_ids,
        "evidence_records": [_public_event(item) for item in evidence],
        "relevant_ips": sorted({value for value in relevant_ips if value}),
        "relevant_devices": sorted({value for value in relevant_devices if value}),
        "relevant_sessions": sorted({str(value) for value in relevant_sessions if value}),
        "deduplication_key": dedup_key,
        "deduplication_method": "tupla exata usuário+timestamp+IPs+hostname+dispositivo",
        "first_event_timestamp": first.isoformat() if first else None,
        "last_event_timestamp": last.isoformat() if last else None,
        "applicable_exclusions": sorted(set(exclusions)),
        "details": details or {},
    }


def detect_r1(events: list[dict], cfg: DetectionConfig) -> list[dict]:
    grouped = defaultdict(list)
    for event in events:
        grouped[(event["user_id"], event["local_date"])].append(event)
    out = []
    for (user, local_day), group in sorted(grouped.items()):
        src = sorted({event["source_ip"] for event in group if event["source_ip"]})
        corp = sorted({event["corporate_ip"] for event in group if event["corporate_ip"]})
        qualifying = []
        if len(src) >= cfg.r1_min_distinct_ips:
            qualifying.append("IP de origem")
        if len(corp) >= cfg.r1_min_distinct_ips:
            qualifying.append("IP corporativo/túnel")
        if not qualifying:
            continue
        sequence = [
            {
                "timestamp": event["timestamp"].isoformat(),
                "source_ip": event["source_ip"],
                "corporate_ip": event["corporate_ip"],
                "source_classification": event["source_ip_classification"],
                "corporate_classification": event["corporate_ip_classification"],
                "event_id": event["event_id"],
            }
            for event in group
        ]
        out.append(_occurrence(
            "R1", group, user_id=user, local_date=local_day,
            triggering_value={"source_ip_count": len(src), "corporate_ip_count": len(corp)},
            threshold={"minimum_distinct_per_ip_field": cfg.r1_min_distinct_ips},
            explanation=(
                "Usuário sinalizado em {0}: foram observados {1} IP(s) de origem "
                "e {2} IP(s) corporativo(s)/de túnel distintos no mesmo dia local; "
                "o limiar foi atingido em {3}. Os dois campos não foram misturados."
            ).format(local_day, len(src), len(corp), " e ".join(qualifying)),
            relevant_ips=src + corp,
            relevant_devices=[event["device_id"] for event in group],
            relevant_sessions=[event["session_id"] for event in group],
            details={"ip_sequence": sequence, "distinct_source_ips": src, "distinct_corporate_ips": corp},
        ))
    return out


def _period_distinct_rule(events: list[dict], cfg: DetectionConfig, rule_id: str) -> list[dict]:
    field_name, limit, label = (
        ("hostname", cfg.r2_distinct_hostname_limit, "nomes de computador")
        if rule_id == "R2"
        else ("device_id", cfg.r3_distinct_device_limit, "identificadores de dispositivo")
    )
    grouped = defaultdict(list)
    for event in events:
        grouped[event["user_id"]].append(event)
    out = []
    for user, group in sorted(grouped.items()):
        values = sorted({event[field_name] for event in group if event[field_name]})
        if len(values) <= limit:
            continue
        out.append(_occurrence(
            rule_id, group, user_id=user, triggering_value=len(values),
            threshold={"operator": ">", "value": limit},
            explanation="Usuário sinalizado por apresentar {0} {1} distintos no período; o limite configurado é mais de {2}.".format(len(values), label, limit),
            relevant_ips=[ip for event in group for ip in (event["source_ip"], event["corporate_ip"])],
            relevant_devices=[event["device_id"] for event in group],
            details={"distinct_values": values},
        ))
    return out


def detect_r4(events: list[dict], cfg: DetectionConfig) -> list[dict]:
    grouped = defaultdict(list)
    for event in events:
        grouped[(event["user_id"], event["local_date"])].append(event)
    out = []
    for (user, local_day), group in sorted(grouped.items()):
        count = len(group)
        if count <= cfg.r4_vpn_login_limit:
            continue
        if count > cfg.r4_critical_severity_above:
            severity = "CRÍTICA"
            severity_reason = (
                "contagem superior ao limiar crítico de {0}"
            ).format(cfg.r4_critical_severity_above)
        elif count > cfg.r4_high_severity_above:
            severity = "ALTA"
            severity_reason = (
                "contagem superior ao limiar alto de {0}"
            ).format(cfg.r4_high_severity_above)
        else:
            severity = "MÉDIA"
            severity_reason = (
                "contagem acima do limiar de detecção e até {0}"
            ).format(cfg.r4_high_severity_above)
        out.append(_occurrence(
            "R4", group, user_id=user, local_date=local_day,
            triggering_value=count,
            threshold={
                "operator": ">",
                "value": cfg.r4_vpn_login_limit,
                "high_severity_above": cfg.r4_high_severity_above,
                "critical_severity_above": cfg.r4_critical_severity_above,
            },
            severity=severity,
            explanation=(
                "Usuário sinalizado por {0} logins VPN distintos em {1}; a "
                "regra exige três ou mais no mesmo dia local. Severidade "
                "{2}: {3}."
            ).format(count, local_day, severity.lower(), severity_reason),
            relevant_ips=[ip for event in group for ip in (event["source_ip"], event["corporate_ip"])],
            relevant_devices=[event["device_id"] for event in group],
            relevant_sessions=[event["session_id"] for event in group],
            details={
                "login_timestamps": [
                    event["timestamp"].isoformat() for event in group
                ],
                "severity_reason": severity_reason,
            },
        ))
    return out


def _different_user_min_delta(group: list[dict]) -> timedelta | None:
    """Menor distância entre usuários distintos em uma sequência ordenada.

    O par de menor distância necessariamente aparece em posições adjacentes
    depois da ordenação temporal. A varredura linear substitui a comparação
    quadrática de todos os pares sem alterar o resultado.
    """
    best = None
    previous = None
    for event in group:
        if previous is not None and previous["user_id"] != event["user_id"]:
            delta = event["timestamp"] - previous["timestamp"]
            if best is None or delta < best:
                best = delta
        previous = event
    return best


def _rolling_device_candidates(
    device_events: list[dict], maximum_window_days: int
) -> list[dict]:
    """Consolida janelas móveis qualificadas em tempo linear amortizado.

    Cada evento entra e sai uma única vez do contador da janela. Janelas
    sobrepostas com o mesmo conjunto de usuários são representadas por um
    intervalo consolidado, evitando copiar listas de evidência para cada
    posição inicial.
    """
    right = 0
    user_counts: Counter[str] = Counter()
    buckets: list[dict] = []
    latest_by_users: dict[frozenset[str], dict] = {}
    maximum_delta = timedelta(days=maximum_window_days)

    for left, first in enumerate(device_events):
        if right < left:
            right = left
        window_end = first["timestamp"] + maximum_delta
        while right < len(device_events) and device_events[right]["timestamp"] <= window_end:
            user_counts[device_events[right]["user_id"]] += 1
            right += 1

        if len(user_counts) >= 2:
            users = frozenset(user_counts)
            candidate_end = right - 1
            bucket = latest_by_users.get(users)
            if bucket is not None and left <= bucket["end"]:
                bucket["end"] = max(bucket["end"], candidate_end)
                bucket["qualifying_window_count"] += 1
            else:
                bucket = {
                    "start": left,
                    "end": candidate_end,
                    "users": users,
                    "qualifying_window_count": 1,
                }
                buckets.append(bucket)
                latest_by_users[users] = bucket

        departing_user = device_events[left]["user_id"]
        user_counts[departing_user] -= 1
        if user_counts[departing_user] <= 0:
            del user_counts[departing_user]

    return buckets


def detect_r7(events: list[dict], cfg: DetectionConfig) -> list[dict]:
    by_device = defaultdict(list)
    for event in events:
        device = event["device_id"]
        if not device or event["user_id"] in cfg.excluded_user_allowlist:
            continue
        by_device[device].append(event)
    findings = []
    for device, device_events in sorted(by_device.items()):
        if device in cfg.shared_device_allowlist:
            continue
        maximum_window_days = max(cfg.device_windows_days)
        consolidated = _rolling_device_candidates(device_events, maximum_window_days)
        for bucket in consolidated:
            group = device_events[bucket["start"]:bucket["end"] + 1]
            users = sorted(bucket["users"])
            min_delta = _different_user_min_delta(group)
            users_by_day = defaultdict(set)
            for event in group:
                users_by_day[event["local_date"]].add(event["user_id"])
            same_days = sorted(
                day for day, day_users in users_by_day.items() if len(day_users) >= 2
            )
            same_day = bool(same_days)
            if same_day:
                horizon, severity = "MESMO_DIA", "ALTA"
                pattern = "mesmo dia; ordem temporal observada, mas sobreposição de sessões não determinável"
            else:
                eligible_windows = [
                    days for days in cfg.device_windows_days
                    if days > 1 and min_delta is not None
                    and min_delta <= timedelta(days=days)
                ]
                selected_days = min(eligible_windows)
                horizon = "{0}_DIAS".format(selected_days)
                severity = "MÉDIA" if selected_days <= 7 else "BAIXA"
                pattern = (
                    "uso sequencial por usuários diferentes dentro da janela "
                    "configurada de {0} dias"
                ).format(selected_days)
            events_by_user = defaultdict(list)
            for event in group:
                events_by_user[event["user_id"]].append(event)
            per_user = {}
            for user in users:
                user_events = events_by_user[user]
                per_user[user] = {
                    "first_use": user_events[0]["timestamp"].isoformat(),
                    "last_use": user_events[-1]["timestamp"].isoformat(),
                    "event_count": len(user_events),
                    "source_ips": sorted({
                        event["source_ip"] for event in user_events if event["source_ip"]
                    }),
                    "corporate_tunnel_ips": sorted({
                        event["corporate_ip"] for event in user_events if event["corporate_ip"]
                    }),
                }
            findings.append(_occurrence(
                "R7", group, device_id=device,
                local_date=same_days[0] if len(same_days) == 1 else None,
                triggering_value={"distinct_users": len(users), "horizon": horizon},
                threshold={"minimum_distinct_users": 2, "windows_days": list(cfg.device_windows_days)},
                explanation="Dispositivo {0} associado a {1} usuários autenticados distintos; classificação temporal: {2}.".format(device, len(users), pattern),
                severity=severity,
                relevant_ips=[ip for event in group for ip in (event["source_ip"], event["corporate_ip"])],
                relevant_devices=[device],
                relevant_sessions=[event["session_id"] for event in group],
                details={
                    "users": users,
                    "per_user": per_user,
                    "qualifying_window_count": bucket["qualifying_window_count"],
                    "consolidation_method": (
                        "janelas móveis sobrepostas com o mesmo conjunto de "
                        "usuários, consolidadas por intervalo"
                    ),
                    "same_day_dates": same_days,
                    "association_horizon": horizon,
                    "usage_pattern": pattern,
                    "minimum_cross_user_interval_seconds": min_delta.total_seconds() if min_delta else None,
                    "same_day_association": same_day,
                    "seven_day_association": bool(min_delta is not None and min_delta <= timedelta(days=7)),
                    "thirty_day_association": bool(
                        min_delta is not None and min_delta <= timedelta(days=30)
                    ) or same_day,
                    "configured_window_associations": {
                        str(days): bool(
                            same_day if days == 1 else (
                                min_delta is not None and min_delta <= timedelta(days=days)
                            )
                        )
                        for days in cfg.device_windows_days
                    },
                    "ip_context_changed": any(
                        len(payload["source_ips"]) > 1
                        or len(payload["corporate_tunnel_ips"]) > 1
                        for payload in per_user.values()
                    ),
                    "organizational_context_changes": (
                        "Não determinável: AUT_CPTV não contém snapshots "
                        "históricos de UOR, função ou departamento."
                    ),
                },
            ))
    return sorted(findings, key=lambda item: (item["device_id"] or "", item["window_start"] or "", item["occurrence_id"]))


def _short_window_findings(
    events: list[dict],
    *,
    rule_id: str,
    group_key: str,
    value_key: str,
    window_minutes: int,
    minimum_distinct: int,
    cfg: DetectionConfig,
) -> list[dict]:
    grouped = defaultdict(list)
    for event in events:
        if event[group_key] and event[value_key]:
            grouped[event[group_key]].append(event)
    out = []
    for entity, group in sorted(grouped.items()):
        right = 0
        value_counts: Counter[str] = Counter()
        episodes: list[dict] = []
        window_delta = timedelta(minutes=window_minutes)
        for left, first in enumerate(group):
            if right < left:
                right = left
            window_end = first["timestamp"] + window_delta
            while right < len(group) and group[right]["timestamp"] <= window_end:
                value_counts[group[right][value_key]] += 1
                right += 1
            if len(value_counts) >= minimum_distinct:
                candidate_end = right - 1
                if episodes and left <= episodes[-1]["end"]:
                    episodes[-1]["end"] = max(episodes[-1]["end"], candidate_end)
                    episodes[-1]["qualifying_window_count"] += 1
                    episodes[-1]["maximum_distinct_in_window"] = max(
                        episodes[-1]["maximum_distinct_in_window"],
                        len(value_counts),
                    )
                else:
                    episodes.append({
                        "start": left,
                        "end": candidate_end,
                        "qualifying_window_count": 1,
                        "maximum_distinct_in_window": len(value_counts),
                    })
            departing_value = group[left][value_key]
            value_counts[departing_value] -= 1
            if value_counts[departing_value] <= 0:
                del value_counts[departing_value]

        for episode in episodes:
            evidence = group[episode["start"]:episode["end"] + 1]
            values = sorted({event[value_key] for event in evidence if event[value_key]})
            if rule_id == "R8":
                explanation = (
                    "Usuário sinalizado por usar pelo menos {0} dispositivos "
                    "distintos em uma ou mais janelas de até {1} minutos; "
                    "janelas qualificadas sobrepostas foram consolidadas."
                ).format(minimum_distinct, window_minutes)
                relevant_ips = [ip for event in evidence for ip in (event["source_ip"], event["corporate_ip"])]
                relevant_devices = values
            else:
                explanation = (
                    "Usuário sinalizado por apresentar pelo menos {0} IPs de "
                    "origem distintos em uma ou mais janelas de até {1} "
                    "minutos; janelas qualificadas sobrepostas foram "
                    "consolidadas e os campos de origem e túnel não foram "
                    "misturados."
                ).format(minimum_distinct, window_minutes)
                relevant_ips = values
                relevant_devices = [event["device_id"] for event in evidence]
            out.append(_occurrence(
                rule_id, evidence, user_id=entity,
                local_date=evidence[0]["local_date"],
                triggering_value=episode["maximum_distinct_in_window"],
                threshold={"minimum_distinct": minimum_distinct, "window_minutes": window_minutes},
                explanation=explanation,
                relevant_ips=relevant_ips,
                relevant_devices=relevant_devices,
                relevant_sessions=[event["session_id"] for event in evidence],
                details={
                    "distinct_values": values,
                    "qualifying_window_count": episode["qualifying_window_count"],
                    "maximum_distinct_in_qualifying_window": (
                        episode["maximum_distinct_in_window"]
                    ),
                    "consolidation_method": (
                        "janelas qualificadas com evidência temporal "
                        "sobreposta, consolidadas em um episódio"
                    ),
                },
            ))
    return sorted(out, key=lambda item: (item["user_id"] or "", item["window_start"] or "", item["occurrence_id"]))


#: Regras baseadas exclusivamente em ``AUT_CPTV``, na ordem canônica.
EVENT_RULE_IDS: tuple[str, ...] = ("R1", "R2", "R3", "R4", "R7", "R8", "R9")


def _rule_task(rule_id: str, events: list[dict], cfg: DetectionConfig):
    """Devolve o avaliador de uma regra sobre uma lista imutável de eventos.

    Cada avaliador recebe a mesma lista somente para leitura e devolve uma
    lista nova. Não há acumulador mutável compartilhado, por isso o resultado
    é idêntico com execução sequencial ou com o executor limitado.
    """
    if rule_id == "R1":
        return lambda: detect_r1(events, cfg)
    if rule_id in ("R2", "R3"):
        return lambda: _period_distinct_rule(events, cfg, rule_id)
    if rule_id == "R4":
        return lambda: detect_r4(events, cfg)
    if rule_id == "R7":
        return lambda: detect_r7(events, cfg)
    if rule_id == "R8":
        return lambda: _short_window_findings(
            events, rule_id="R8", group_key="user_id", value_key="device_id",
            window_minutes=cfg.multi_device_window_minutes,
            minimum_distinct=cfg.multi_device_min_devices, cfg=cfg,
        )
    if rule_id == "R9":
        return lambda: _short_window_findings(
            events, rule_id="R9", group_key="user_id", value_key="source_ip",
            window_minutes=cfg.rapid_ip_window_minutes,
            minimum_distinct=cfg.rapid_ip_min_distinct, cfg=cfg,
        )
    raise ValueError("Regra de evento desconhecida: {0}".format(rule_id))


def run_event_rules(
    rows: Iterable[dict],
    cfg: DetectionConfig | None = None,
    *,
    max_workers: int = 1,
    on_rule_done=None,
) -> tuple[dict[str, list[dict]], dict]:
    """Executa R1–R4 e R7–R9 sobre as linhas fornecidas.

    ``max_workers`` habilita o executor limitado de
    :mod:`backtest_vpn.concurrency`. O padrão 1 mantém a execução sequencial;
    valores maiores produzem exatamente o mesmo resultado, porque a ordem do
    dicionário devolvido segue a ordem canônica das regras.
    """
    cfg = cfg or DetectionConfig()
    events, quality = normalize_events(rows, cfg)
    excluded_events = [
        event for event in events if event["user_id"] in cfg.excluded_user_allowlist
    ]
    events = [
        event for event in events if event["user_id"] not in cfg.excluded_user_allowlist
    ]
    quality["excluded_user_events"] = len(excluded_events)
    selected = [rule for rule in EVENT_RULE_IDS if rule in cfg.enabled_rules]
    if max_workers > 1 and len(selected) > 1:
        from .concurrency import run_bounded

        outcomes = run_bounded(
            [_rule_task(rule_id, events, cfg) for rule_id in selected],
            max_workers=max_workers,
        )
    else:
        outcomes = []
        for rule_id in selected:
            outcomes.append(_rule_task(rule_id, events, cfg)())
            if on_rule_done is not None:
                on_rule_done(rule_id, outcomes[-1])
    rules = {rule_id: outcome for rule_id, outcome in zip(selected, outcomes)}
    if max_workers > 1 and on_rule_done is not None:
        for rule_id in selected:
            on_rule_done(rule_id, rules[rule_id])
    for rule_id, occurrences in rules.items():
        for occurrence in occurrences:
            if cfg.excluded_user_allowlist:
                occurrence["applicable_exclusions"].append(
                    "allowlist de contas de serviço/teste aplicada; usuários da ocorrência não constavam nela"
                )
            if rule_id == "R7" and cfg.shared_device_allowlist:
                occurrence["applicable_exclusions"].append(
                    "allowlist de dispositivos compartilhados aplicada; dispositivo da ocorrência não constava nela"
                )
    return rules, quality


def occurrence_to_legacy_sample(occurrence: dict) -> dict:
    """Adapta uma ocorrência ao formato consumido pelas páginas antigas."""
    rule_id = occurrence["rule_id"]
    value = occurrence.get("triggering_value")
    row = {
        "USER_KEY": occurrence.get("user_id"),
        "DEVICE_ID": occurrence.get("device_id"),
        "LOCAL_DATE": occurrence.get("local_date"),
        "FIRST_SEEN": occurrence.get("first_event_timestamp"),
        "LAST_SEEN": occurrence.get("last_event_timestamp"),
        "OCCURRENCE_ID": occurrence.get("occurrence_id"),
        "EXPLANATION": occurrence.get("explanation"),
    }
    if rule_id == "R1":
        row.update({
            "LOGIN_DATE": occurrence.get("local_date"),
            "DISTINCT_CD_END_LGC_OGM": (value or {}).get("source_ip_count"),
            "DISTINCT_CD_END_LGC_CPTV": (value or {}).get("corporate_ip_count"),
        })
    elif rule_id == "R2":
        row["DISTINCT_NM_DSVO"] = value
    elif rule_id == "R3":
        row["DISTINCT_CD_IDFC_DSVO"] = value
    elif rule_id == "R4":
        row.update({"LOGIN_DATE": occurrence.get("local_date"), "LOGIN_COUNT": value})
    elif rule_id == "R7":
        row.update({
            "USER_KEY": ", ".join((occurrence.get("details") or {}).get("users") or []),
            "DISTINCT_USERS": (value or {}).get("distinct_users"),
            "HORIZON": (value or {}).get("horizon"),
        })
    elif rule_id == "R8":
        row["DISTINCT_DEVICES_SHORT_WINDOW"] = value
    elif rule_id == "R9":
        row["DISTINCT_SOURCE_IPS_SHORT_WINDOW"] = value
    return row
