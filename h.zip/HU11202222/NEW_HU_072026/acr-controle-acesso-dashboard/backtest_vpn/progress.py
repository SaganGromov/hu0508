"""Fases, progresso monotônico, ETA explicável e log estruturado.

O módulo é puramente de aplicação: não conhece HTTP, CLI, Kubernetes nem
banco de dados. Ele recebe um :class:`~backtest_vpn.clock.Clock` e um
publicador de snapshots (``sink``) e produz:

* fases nomeadas, com subfase opcional e unidades **monotônicas**;
* fases explicitamente **indeterminadas** quando o total ainda não é
  conhecível — nunca um percentual enganoso;
* ETA por média exponencial de vazão dentro da fase corrente, com número
  mínimo de amostras, marcação explícita de estimativa e reinício a cada
  troca de fase;
* logs estruturados com campos fixos, sem conteúdo sensível de linhas,
  limitados por *throttling* de tempo/percentual, preservando sempre as
  fronteiras de fase e os marcos materiais.
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from typing import Callable, Iterable

from .clock import Clock, SystemClock

# ── Fases ────────────────────────────────────────────────────────────────
PHASE_QUEUED = "ENFILEIRADO"
PHASE_CLAIMED = "RESERVADO"
PHASE_VALIDATING_CONFIG = "VALIDANDO_CONFIGURACAO"
PHASE_CONNECTING = "CONECTANDO_FONTE"
PHASE_VALIDATING_SCHEMA = "VALIDANDO_ESQUEMA"
PHASE_QUERYING = "CONSULTANDO_EVENTOS"
PHASE_NORMALIZING = "NORMALIZANDO_EVENTOS"
PHASE_EVALUATING_RULES = "AVALIANDO_REGRAS"
PHASE_CORRELATING = "CORRELACIONANDO_OPENAM"
PHASE_CONSOLIDATING = "CONSOLIDANDO_OCORRENCIAS"
PHASE_BUILDING_MODEL = "MONTANDO_MODELO_RELATORIO"
PHASE_GENERATING_LATEX = "GERANDO_LATEX"
PHASE_GENERATING_XLSX = "GERANDO_XLSX"
PHASE_GENERATING_CSV = "GERANDO_CSV"
PHASE_VALIDATING_OUTPUT = "VALIDANDO_SAIDA"
PHASE_PUBLISHING = "PUBLICANDO_RESULTADO"
PHASE_DONE = "CONCLUIDO"
PHASE_FAILED = "FALHOU"
PHASE_CANCELLED = "CANCELADO"

#: Ordem canônica das fases. Usada para garantir monotonicidade.
PHASE_ORDER: tuple[str, ...] = (
    PHASE_QUEUED,
    PHASE_CLAIMED,
    PHASE_VALIDATING_CONFIG,
    PHASE_CONNECTING,
    PHASE_VALIDATING_SCHEMA,
    PHASE_QUERYING,
    PHASE_NORMALIZING,
    PHASE_EVALUATING_RULES,
    PHASE_CORRELATING,
    PHASE_CONSOLIDATING,
    PHASE_BUILDING_MODEL,
    PHASE_GENERATING_LATEX,
    PHASE_GENERATING_XLSX,
    PHASE_GENERATING_CSV,
    PHASE_VALIDATING_OUTPUT,
    PHASE_PUBLISHING,
    PHASE_DONE,
)

TERMINAL_PHASES = frozenset({PHASE_DONE, PHASE_FAILED, PHASE_CANCELLED})

#: Peso relativo de cada fase no percentual global. A soma é 100.
PHASE_WEIGHTS: dict[str, int] = {
    PHASE_QUEUED: 0,
    PHASE_CLAIMED: 1,
    PHASE_VALIDATING_CONFIG: 1,
    PHASE_CONNECTING: 1,
    PHASE_VALIDATING_SCHEMA: 2,
    PHASE_QUERYING: 25,
    PHASE_NORMALIZING: 10,
    PHASE_EVALUATING_RULES: 25,
    PHASE_CORRELATING: 10,
    PHASE_CONSOLIDATING: 5,
    PHASE_BUILDING_MODEL: 5,
    PHASE_GENERATING_LATEX: 4,
    PHASE_GENERATING_XLSX: 4,
    PHASE_GENERATING_CSV: 2,
    PHASE_VALIDATING_OUTPUT: 2,
    PHASE_PUBLISHING: 3,
    PHASE_DONE: 0,
}

PHASE_LABELS_PT: dict[str, str] = {
    PHASE_QUEUED: "Na fila, aguardando um processador disponível",
    PHASE_CLAIMED: "Reservado por um processador",
    PHASE_VALIDATING_CONFIG: "Validando período, regras e parâmetros",
    PHASE_CONNECTING: "Conectando à fonte de dados",
    PHASE_VALIDATING_SCHEMA: "Conferindo as colunas exigidas na fonte",
    PHASE_QUERYING: "Lendo os registros de autenticação do período",
    PHASE_NORMALIZING: "Normalizando e deduplicando os registros lidos",
    PHASE_EVALUATING_RULES: "Avaliando as regras selecionadas",
    PHASE_CORRELATING: "Correlacionando eventos VPN com autenticações OpenAM",
    PHASE_CONSOLIDATING: "Consolidando ocorrências e evidências",
    PHASE_BUILDING_MODEL: "Montando o modelo normalizado do relatório",
    PHASE_GENERATING_LATEX: "Gerando o dossiê LaTeX",
    PHASE_GENERATING_XLSX: "Gerando a planilha XLSX",
    PHASE_GENERATING_CSV: "Gerando os detalhamentos em CSV",
    PHASE_VALIDATING_OUTPUT: "Validando os arquivos produzidos",
    PHASE_PUBLISHING: "Publicando o resultado de forma atômica",
    PHASE_DONE: "Concluído",
    PHASE_FAILED: "Falhou",
    PHASE_CANCELLED: "Cancelado",
}

#: Explicação curta, sem jargão de infraestrutura, para a interface humana.
PHASE_EXPLANATIONS_PT: dict[str, str] = {
    PHASE_QUEUED: "Seu pedido foi recebido. Ele começará assim que houver capacidade disponível.",
    PHASE_CLAIMED: "Um processador assumiu o pedido e está preparando a análise.",
    PHASE_VALIDATING_CONFIG: "Estamos conferindo se o período e as regras podem ser processados com segurança.",
    PHASE_CONNECTING: "Estamos abrindo uma conexão protegida com a fonte dos registros.",
    PHASE_VALIDATING_SCHEMA: "Estamos conferindo se os dados necessários estão disponíveis.",
    PHASE_QUERYING: "Estamos reunindo os registros do período solicitado. Esta costuma ser a etapa mais demorada.",
    PHASE_NORMALIZING: "Estamos organizando os registros e removendo duplicidades exatas.",
    PHASE_EVALUATING_RULES: "Estamos verificando os registros com as regras selecionadas.",
    PHASE_CORRELATING: "Estamos comparando eventos relacionados para encontrar sinais que merecem revisão.",
    PHASE_CONSOLIDATING: "Estamos agrupando sinais repetidos em ocorrências mais fáceis de analisar.",
    PHASE_BUILDING_MODEL: "A análise terminou; estamos organizando os resultados para os relatórios.",
    PHASE_GENERATING_LATEX: "Estamos preparando o dossiê LaTeX para download.",
    PHASE_GENERATING_XLSX: "Estamos preparando a planilha para consulta rápida.",
    PHASE_GENERATING_CSV: "Estamos preparando os arquivos de detalhamento.",
    PHASE_VALIDATING_OUTPUT: "Estamos conferindo se todos os arquivos foram gerados corretamente.",
    PHASE_PUBLISHING: "Estamos disponibilizando o novo resultado sem interromper o resultado anterior.",
    PHASE_DONE: "Tudo pronto. O resultado e os relatórios já podem ser consultados.",
    PHASE_FAILED: "Não foi possível concluir esta análise. O último resultado válido continua disponível.",
    PHASE_CANCELLED: "Esta análise foi cancelada antes da publicação.",
}

#: Nome exibido quando o total de unidades ainda não é conhecível.
INDETERMINATE_LABEL = "em andamento, total ainda não conhecido"

_MIN_ETA_SAMPLES = 3
_MIN_ETA_FRACTION = 0.05
_MAX_ETA_SECONDS = 30 * 24 * 3600
_EWMA_ALPHA = 0.3
_CONTROL_CHARS_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
_MAX_LOG_STRING = 512


def format_duration_pt(seconds) -> str:
    """Formata duração aproximada para pessoas, sem falsa precisão."""
    if seconds is None:
        return "ainda não disponível"
    try:
        value = max(0, int(round(float(seconds))))
    except (TypeError, ValueError):
        return "ainda não disponível"
    if value < 60:
        return "menos de 1 minuto"
    minutes = int(round(value / 60))
    if minutes < 60:
        return "cerca de {0} minuto{1}".format(minutes, "" if minutes == 1 else "s")
    hours, remaining = divmod(minutes, 60)
    if remaining:
        return "cerca de {0} h {1} min".format(hours, remaining)
    return "cerca de {0} hora{1}".format(hours, "" if hours == 1 else "s")


def friendly_progress(payload: dict) -> dict:
    """Deriva textos e valores de apresentação a partir do snapshot técnico."""
    phase = str(payload.get("phase") or PHASE_QUEUED)
    trigger = str(payload.get("trigger") or "")
    percent = float(payload.get("overall_percent") or 0)
    indeterminate = bool(payload.get("indeterminate"))
    summary = PHASE_LABELS_PT.get(phase, phase)
    if phase == PHASE_QUEUED and trigger == "initial":
        summary = "Primeira análise após a implantação: pedido recebido"
    elif phase == PHASE_QUEUED and trigger == "scheduled":
        summary = "Atualização automática recebida"
    elif phase == PHASE_QUEUED and trigger == "manual":
        summary = "Sua análise foi recebida"
    detail = PHASE_EXPLANATIONS_PT.get(phase, "A análise está em andamento.")
    current_rule = payload.get("current_rule")
    if current_rule and phase == PHASE_EVALUATING_RULES:
        detail += " Regra em avaliação: {0}.".format(current_rule)
    eta_seconds = payload.get("eta_seconds_remaining")
    return {
        "friendly_summary": summary,
        "friendly_detail": detail,
        "elapsed_label": format_duration_pt(payload.get("elapsed_seconds")),
        "eta_label": (
            format_duration_pt(eta_seconds)
            if eta_seconds is not None
            else "calculando após obter dados suficientes"
        ),
        "progress_bar_value": None if indeterminate else round(percent, 1),
        "progress_bar_indeterminate": indeterminate,
    }


def queued_progress_payload(*, job_id: str, trigger: str, updated_at: str) -> dict:
    """Cria progresso visível já no instante em que qualquer job entra na fila."""
    payload = {
        "job_id": str(job_id),
        "attempt": 0,
        "trigger": str(trigger),
        "phase": PHASE_QUEUED,
        "phase_label": PHASE_LABELS_PT[PHASE_QUEUED],
        "subphase": None,
        "indeterminate": True,
        "indeterminate_label": INDETERMINATE_LABEL,
        "completed_units": 0,
        "total_units": None,
        "phase_percent": None,
        "overall_percent": 0.0,
        "elapsed_seconds": 0,
        "started_at": None,
        "updated_at": str(updated_at),
        "current_rule": None,
        "current_partition": None,
        "counters": {},
        "occurrences_by_rule": {},
        "occurrences_by_severity": {},
        "message": "Pedido recebido e aguardando processamento.",
        "eta_seconds_remaining": None,
        "eta_is_estimate": True,
        "eta_suppressed_reason": "o processamento ainda não começou",
    }
    payload.update(friendly_progress(payload))
    return payload


def sanitize_log_value(value):
    """Remove caracteres de controle e limita o tamanho de texto de log.

    Impede injeção de linha/terminal em logs estruturados sem alterar a
    semântica dos identificadores usados pela operação.
    """
    if isinstance(value, str):
        return _CONTROL_CHARS_RE.sub("", value.replace("\n", " ").replace("\r", " "))[:_MAX_LOG_STRING]
    if isinstance(value, (list, tuple)):
        return [sanitize_log_value(item) for item in value]
    if isinstance(value, dict):
        return {
            sanitize_log_value(str(key)): sanitize_log_value(item)
            for key, item in value.items()
        }
    return value


@dataclass(frozen=True)
class EtaEstimate:
    """Resultado explicável de uma estimativa de tempo restante."""

    seconds_remaining: float | None
    method: str
    is_estimate: bool = True
    samples: int = 0
    throughput_per_second: float | None = None
    suppressed_reason: str | None = None

    def as_payload(self) -> dict:
        return {
            "eta_seconds_remaining": (
                None if self.seconds_remaining is None else int(round(self.seconds_remaining))
            ),
            "eta_method": self.method,
            "eta_is_estimate": self.is_estimate,
            "eta_samples": self.samples,
            "eta_throughput_per_second": (
                None if self.throughput_per_second is None
                else round(self.throughput_per_second, 4)
            ),
            "eta_suppressed_reason": self.suppressed_reason,
        }


class EtaEstimator:
    """Vazão suavizada (EWMA) sobre trabalho comparável já concluído.

    A estimativa só é publicada depois de ``_MIN_ETA_SAMPLES`` amostras e de
    pelo menos ``_MIN_ETA_FRACTION`` do trabalho da fase. Ela é descartada
    quando a fase muda, quando o total é desconhecido ou quando o total é
    zero. Valores negativos, infinitos ou absurdamente grandes nunca são
    publicados.
    """

    def __init__(self, clock: Clock | None = None) -> None:
        self._clock = clock or SystemClock()
        self._phase: str | None = None
        self._samples = 0
        self._throughput: float | None = None
        self._last_monotonic: float | None = None
        self._last_completed: int = 0

    def reset(self, phase: str | None = None) -> None:
        self._phase = phase
        self._samples = 0
        self._throughput = None
        self._last_monotonic = self._clock.monotonic()
        self._last_completed = 0

    def observe(self, phase: str, completed_units: int, total_units: int | None) -> EtaEstimate:
        if phase != self._phase:
            self.reset(phase)
        now = self._clock.monotonic()
        if self._last_monotonic is None:
            self._last_monotonic = now
        elapsed = now - self._last_monotonic
        delta_units = max(0, int(completed_units) - self._last_completed)
        if delta_units > 0 and elapsed > 0:
            instant = delta_units / elapsed
            self._throughput = (
                instant if self._throughput is None
                else (_EWMA_ALPHA * instant) + ((1 - _EWMA_ALPHA) * self._throughput)
            )
            self._samples += 1
            self._last_monotonic = now
            self._last_completed = int(completed_units)
        elif delta_units > 0:
            # Trabalho concluído sem tempo mensurável: registra a unidade sem
            # produzir uma vazão infinita.
            self._last_completed = int(completed_units)

        if total_units is None:
            return EtaEstimate(
                None, "vazão suavizada (EWMA) da fase", samples=self._samples,
                throughput_per_second=self._throughput,
                suppressed_reason="fase indeterminada: total de unidades desconhecido",
            )
        if total_units <= 0:
            return EtaEstimate(
                0.0, "fase sem trabalho a executar", samples=self._samples,
                throughput_per_second=self._throughput,
                suppressed_reason=None,
            )
        if self._samples < _MIN_ETA_SAMPLES:
            return EtaEstimate(
                None, "vazão suavizada (EWMA) da fase", samples=self._samples,
                throughput_per_second=self._throughput,
                suppressed_reason="amostras insuficientes para uma estimativa confiável",
            )
        fraction = min(1.0, max(0.0, completed_units / total_units))
        if fraction < _MIN_ETA_FRACTION:
            return EtaEstimate(
                None, "vazão suavizada (EWMA) da fase", samples=self._samples,
                throughput_per_second=self._throughput,
                suppressed_reason="progresso insuficiente para uma estimativa confiável",
            )
        remaining_units = max(0, int(total_units) - int(completed_units))
        if not self._throughput or self._throughput <= 0:
            return EtaEstimate(
                None, "vazão suavizada (EWMA) da fase", samples=self._samples,
                throughput_per_second=self._throughput,
                suppressed_reason="vazão medida ainda não é positiva",
            )
        seconds = remaining_units / self._throughput
        if seconds != seconds or seconds in (float("inf"), float("-inf")):  # NaN/inf
            return EtaEstimate(
                None, "vazão suavizada (EWMA) da fase", samples=self._samples,
                throughput_per_second=self._throughput,
                suppressed_reason="estimativa numericamente inválida",
            )
        seconds = max(0.0, min(float(seconds), float(_MAX_ETA_SECONDS)))
        return EtaEstimate(
            seconds, "vazão suavizada (EWMA) da fase", samples=self._samples,
            throughput_per_second=self._throughput,
        )


@dataclass(frozen=True)
class ProgressSnapshot:
    """Estado publicável do progresso; sempre serializável e sem dado sensível."""

    job_id: str
    attempt: int
    trigger: str
    phase: str
    phase_label: str
    subphase: str | None
    indeterminate: bool
    completed_units: int
    total_units: int | None
    phase_percent: float | None
    overall_percent: float
    elapsed_seconds: float
    started_at: str | None
    updated_at: str
    current_rule: str | None
    current_partition: str | None
    counters: dict = field(default_factory=dict)
    occurrences_by_rule: dict = field(default_factory=dict)
    occurrences_by_severity: dict = field(default_factory=dict)
    eta: dict = field(default_factory=dict)
    message: str | None = None

    def as_payload(self) -> dict:
        payload = {
            "job_id": self.job_id,
            "attempt": self.attempt,
            "trigger": self.trigger,
            "phase": self.phase,
            "phase_label": self.phase_label,
            "subphase": self.subphase,
            "indeterminate": self.indeterminate,
            "indeterminate_label": INDETERMINATE_LABEL if self.indeterminate else None,
            "completed_units": self.completed_units,
            "total_units": self.total_units,
            "phase_percent": self.phase_percent,
            "overall_percent": self.overall_percent,
            "elapsed_seconds": int(round(self.elapsed_seconds)),
            "started_at": self.started_at,
            "updated_at": self.updated_at,
            "current_rule": self.current_rule,
            "current_partition": self.current_partition,
            "counters": dict(self.counters),
            "occurrences_by_rule": dict(self.occurrences_by_rule),
            "occurrences_by_severity": dict(self.occurrences_by_severity),
            "message": self.message,
        }
        payload.update(self.eta)
        payload.update(friendly_progress(payload))
        return payload


class ProgressReporter:
    """Publica fases, unidades e ETA de forma monotônica e auditável.

    ``sink`` recebe cada :class:`ProgressSnapshot` (por exemplo, para gravar
    em estado durável compartilhado). ``logger`` recebe uma linha estruturada
    por evento material, respeitando o *throttling* configurado.
    """

    def __init__(
        self,
        *,
        job_id: str,
        trigger: str,
        attempt: int = 1,
        clock: Clock | None = None,
        sink: Callable[[ProgressSnapshot], None] | None = None,
        logger: logging.Logger | None = None,
        log_interval_seconds: float = 15.0,
        log_percent_step: float = 5.0,
        static_fields: dict | None = None,
    ) -> None:
        self._clock = clock or SystemClock()
        self._job_id = str(job_id)
        self._trigger = str(trigger)
        self._attempt = int(attempt)
        self._sink = sink
        self._logger = logger or logging.getLogger("backtest_vpn.progress")
        self._log_interval = max(0.0, float(log_interval_seconds))
        self._log_percent_step = max(0.0, float(log_percent_step))
        self._static_fields = sanitize_log_value(dict(static_fields or {}))
        self._eta = EtaEstimator(self._clock)
        self._started_monotonic = self._clock.monotonic()
        self._started_at = self._clock.now().isoformat(timespec="seconds")
        self._phase = PHASE_QUEUED
        self._phase_index = 0
        self._subphase: str | None = None
        self._completed = 0
        self._total: int | None = 0
        self._current_rule: str | None = None
        self._current_partition: str | None = None
        self._counters: dict[str, int] = {}
        self._occurrences_by_rule: dict[str, int] = {}
        self._occurrences_by_severity: dict[str, int] = {}
        self._overall_percent = 0.0
        self._last_log_monotonic = -1e9
        self._last_log_percent = -1e9
        self._last_snapshot: ProgressSnapshot | None = None

    # ── leitura ──────────────────────────────────────────────────────
    @property
    def snapshot(self) -> ProgressSnapshot:
        return self._last_snapshot or self._build_snapshot()

    def counters(self) -> dict:
        return dict(self._counters)

    # ── fases ────────────────────────────────────────────────────────
    def start_phase(
        self,
        phase: str,
        *,
        total_units: int | None = 0,
        subphase: str | None = None,
        message: str | None = None,
    ) -> None:
        """Entra em uma fase. ``total_units=None`` declara fase indeterminada."""
        if phase in TERMINAL_PHASES:
            index = len(PHASE_ORDER) - 1
        else:
            try:
                index = PHASE_ORDER.index(phase)
            except ValueError:
                raise ValueError("Fase de progresso desconhecida: {0}".format(phase))
        if index < self._phase_index:
            # Progresso é monotônico: nunca retrocede de fase.
            return
        self._phase = phase
        self._phase_index = index
        self._subphase = subphase
        self._completed = 0
        self._total = None if total_units is None else max(0, int(total_units))
        self._eta.reset(phase)
        self._overall_percent = max(self._overall_percent, self._completed_weight())
        self._emit(message=message, force_log=True)

    def set_total(self, total_units: int | None) -> None:
        """Define o total quando ele passa a ser conhecível dentro da fase."""
        self._total = None if total_units is None else max(0, int(total_units))
        self._emit(force_log=True)

    def set_subphase(self, subphase: str | None, *, message: str | None = None) -> None:
        self._subphase = subphase
        self._emit(message=message, force_log=True)

    def advance(
        self,
        units: int = 1,
        *,
        rule_id: str | None = None,
        partition: str | None = None,
        message: str | None = None,
        force_log: bool = False,
    ) -> None:
        """Avança unidades concluídas da fase corrente, sem retroceder."""
        if units < 0:
            raise ValueError("O progresso não pode retroceder.")
        self._completed += int(units)
        if self._total is not None:
            self._completed = min(self._completed, self._total)
        if rule_id is not None:
            self._current_rule = rule_id
        if partition is not None:
            self._current_partition = partition
        self._emit(message=message, force_log=force_log)

    def set_position(self, completed_units: int, *, message: str | None = None) -> None:
        """Define a posição absoluta; valores menores que o atual são ignorados."""
        self._completed = max(self._completed, int(completed_units))
        if self._total is not None:
            self._completed = min(self._completed, self._total)
        self._emit(message=message)

    # ── contadores ───────────────────────────────────────────────────
    def add_counter(self, name: str, value: int = 1) -> None:
        self._counters[name] = self._counters.get(name, 0) + int(value)

    def set_counter(self, name: str, value: int) -> None:
        self._counters[name] = int(value)

    def merge_counters(self, values: dict) -> None:
        for name, value in (values or {}).items():
            if isinstance(value, bool) or not isinstance(value, int):
                continue
            self._counters[str(name)] = int(value)

    def record_occurrences(self, rule_id: str, severities: Iterable[str]) -> None:
        severities = list(severities)
        self._occurrences_by_rule[str(rule_id)] = (
            self._occurrences_by_rule.get(str(rule_id), 0) + len(severities)
        )
        for severity in severities:
            key = str(severity or "Não informado")
            self._occurrences_by_severity[key] = self._occurrences_by_severity.get(key, 0) + 1

    # ── término ──────────────────────────────────────────────────────
    def finish(self, *, message: str | None = None) -> None:
        """Marca 100% somente depois de publicar resultado e relatórios."""
        self._phase = PHASE_DONE
        self._phase_index = len(PHASE_ORDER) - 1
        self._subphase = None
        self._total = self._total if self._total else 1
        self._completed = self._total
        self._overall_percent = 100.0
        self._emit(message=message or "Execução concluída e publicada.", force_log=True)

    def fail(self, *, message: str) -> None:
        self._phase = PHASE_FAILED
        self._subphase = None
        self._emit(message=message, force_log=True, level=logging.ERROR)

    def cancel(self, *, message: str = "Execução cancelada.") -> None:
        self._phase = PHASE_CANCELLED
        self._subphase = None
        self._emit(message=message, force_log=True, level=logging.WARNING)

    # ── internos ─────────────────────────────────────────────────────
    def _completed_weight(self) -> float:
        done = sum(
            PHASE_WEIGHTS.get(name, 0)
            for name in PHASE_ORDER[: self._phase_index]
        )
        return min(100.0, float(done))

    def _build_snapshot(self, message: str | None = None) -> ProgressSnapshot:
        indeterminate = self._total is None
        phase_percent = None
        if not indeterminate and self._total:
            phase_percent = round(100.0 * self._completed / self._total, 2)
        elif not indeterminate:
            phase_percent = 100.0
        base = self._completed_weight()
        weight = PHASE_WEIGHTS.get(self._phase, 0)
        if self._phase in TERMINAL_PHASES:
            overall = 100.0 if self._phase == PHASE_DONE else self._overall_percent
        elif indeterminate:
            overall = base
        else:
            overall = base + (weight * ((phase_percent or 0.0) / 100.0))
        # Nunca declara 100% antes da publicação concluir.
        if self._phase != PHASE_DONE:
            overall = min(overall, 99.0)
        self._overall_percent = max(self._overall_percent, round(overall, 2))
        eta = self._eta.observe(self._phase, self._completed, self._total)
        elapsed = max(0.0, self._clock.monotonic() - self._started_monotonic)
        return ProgressSnapshot(
            job_id=self._job_id,
            attempt=self._attempt,
            trigger=self._trigger,
            phase=self._phase,
            phase_label=PHASE_LABELS_PT.get(self._phase, self._phase),
            subphase=self._subphase,
            indeterminate=indeterminate,
            completed_units=self._completed,
            total_units=self._total,
            phase_percent=phase_percent,
            overall_percent=self._overall_percent,
            elapsed_seconds=elapsed,
            started_at=self._started_at,
            updated_at=self._clock.now().isoformat(timespec="seconds"),
            current_rule=self._current_rule,
            current_partition=self._current_partition,
            counters=dict(self._counters),
            occurrences_by_rule=dict(self._occurrences_by_rule),
            occurrences_by_severity=dict(self._occurrences_by_severity),
            eta=eta.as_payload(),
            message=sanitize_log_value(message) if message else None,
        )

    def _emit(
        self,
        *,
        message: str | None = None,
        force_log: bool = False,
        level: int = logging.INFO,
    ) -> None:
        snapshot = self._build_snapshot(message)
        self._last_snapshot = snapshot
        if self._sink is not None:
            self._sink(snapshot)
        if self._should_log(force_log):
            self._log(snapshot, level)

    def _should_log(self, force_log: bool) -> bool:
        if force_log:
            return True
        now = self._clock.monotonic()
        if now - self._last_log_monotonic >= self._log_interval:
            return True
        return self._overall_percent - self._last_log_percent >= self._log_percent_step

    def _log(self, snapshot: ProgressSnapshot, level: int) -> None:
        self._last_log_monotonic = self._clock.monotonic()
        self._last_log_percent = self._overall_percent
        record = dict(self._static_fields)
        record.update(sanitize_log_value(snapshot.as_payload()))
        record["timezone"] = self._clock.timezone_name
        self._logger.log(
            level,
            "backtest_progress %s",
            json.dumps(record, ensure_ascii=False, sort_keys=True, default=str),
        )


class NullProgressReporter(ProgressReporter):
    """Reporter silencioso para caminhos em que progresso não é observado."""

    def __init__(self, *, clock: Clock | None = None) -> None:
        super().__init__(
            job_id="-", trigger="none", clock=clock,
            logger=logging.getLogger("backtest_vpn.progress.null"),
            log_interval_seconds=float("inf"), log_percent_step=float("inf"),
        )

    def _log(self, snapshot: ProgressSnapshot, level: int) -> None:  # pragma: no cover
        return


def rebuild_snapshot(payload: dict) -> ProgressSnapshot:
    """Reconstrói um snapshot lido do estado durável compartilhado."""
    data = dict(payload or {})
    eta_keys = [key for key in data if key.startswith("eta_")]
    eta = {key: data.pop(key) for key in eta_keys}
    known = {
        "job_id", "attempt", "trigger", "phase", "phase_label", "subphase",
        "indeterminate", "completed_units", "total_units", "phase_percent",
        "overall_percent", "elapsed_seconds", "started_at", "updated_at",
        "current_rule", "current_partition", "counters", "occurrences_by_rule",
        "occurrences_by_severity", "message",
    }
    filtered = {key: value for key, value in data.items() if key in known}
    filtered.setdefault("job_id", "-")
    filtered.setdefault("attempt", 1)
    filtered.setdefault("trigger", "none")
    filtered.setdefault("phase", PHASE_QUEUED)
    filtered.setdefault("phase_label", PHASE_LABELS_PT[PHASE_QUEUED])
    filtered.setdefault("subphase", None)
    filtered.setdefault("indeterminate", False)
    filtered.setdefault("completed_units", 0)
    filtered.setdefault("total_units", 0)
    filtered.setdefault("phase_percent", 0.0)
    filtered.setdefault("overall_percent", 0.0)
    filtered.setdefault("elapsed_seconds", 0)
    filtered.setdefault("started_at", None)
    filtered.setdefault("updated_at", "")
    filtered.setdefault("current_rule", None)
    filtered.setdefault("current_partition", None)
    filtered.setdefault("counters", {})
    filtered.setdefault("occurrences_by_rule", {})
    filtered.setdefault("occurrences_by_severity", {})
    filtered.setdefault("message", None)
    return ProgressSnapshot(eta=eta, **filtered)


__all__ = [
    "EtaEstimate",
    "EtaEstimator",
    "INDETERMINATE_LABEL",
    "NullProgressReporter",
    "PHASE_BUILDING_MODEL",
    "PHASE_CANCELLED",
    "PHASE_CLAIMED",
    "PHASE_CONNECTING",
    "PHASE_CONSOLIDATING",
    "PHASE_CORRELATING",
    "PHASE_DONE",
    "PHASE_EVALUATING_RULES",
    "PHASE_FAILED",
    "PHASE_GENERATING_CSV",
    "PHASE_GENERATING_LATEX",
    "PHASE_GENERATING_XLSX",
    "PHASE_LABELS_PT",
    "PHASE_NORMALIZING",
    "PHASE_ORDER",
    "PHASE_PUBLISHING",
    "PHASE_QUERYING",
    "PHASE_QUEUED",
    "PHASE_VALIDATING_CONFIG",
    "PHASE_VALIDATING_OUTPUT",
    "PHASE_VALIDATING_SCHEMA",
    "PHASE_WEIGHTS",
    "ProgressReporter",
    "ProgressSnapshot",
    "TERMINAL_PHASES",
    "rebuild_snapshot",
    "sanitize_log_value",
]
