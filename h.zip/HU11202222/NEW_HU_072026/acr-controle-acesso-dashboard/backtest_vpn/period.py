"""Semântica única de período do backtesting.

Regras adotadas em toda a aplicação (interface, API, CLI, agendador,
persistência, relatórios e testes):

* o usuário informa **duas datas locais inclusivas** (``AAAA-MM-DD``);
* o processamento usa a janela técnica **semiaberta** ``[início, fim)``,
  em que ``fim`` é a meia-noite local do dia seguinte à data final
  inclusiva — por isso o último dia nunca é perdido;
* o período padrão contém uma quantidade configurável de dias de calendário
  local (33 quando ``BACKTEST_WINDOW_DAYS`` não é informado);
* execuções automáticas usam um **corte de dados configurável**
  (:data:`CUTOFF_COMPLETED_DAY` por padrão) para não apresentar um dia local
  parcial como se estivesse completo.

Todas as conversões passam por este módulo; nada recalcula datas por conta
própria.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta

from .clock import Clock, resolve_timezone
from .detection import APP_TIMEZONE

#: Quantidade de datas locais inclusivas do período padrão.
DEFAULT_WINDOW_DAYS = 33
MAX_WINDOW_DAYS = 400

#: O período automático termina no último dia local **completo** (ontem).
CUTOFF_COMPLETED_DAY = "completed_day"
#: O período automático termina no dia local **corrente**, ainda parcial.
CUTOFF_CURRENT_DAY = "current_day"

CUTOFF_MODES = (CUTOFF_COMPLETED_DAY, CUTOFF_CURRENT_DAY)

CUTOFF_LABELS_PT = {
    CUTOFF_COMPLETED_DAY: (
        "último dia local completo (o dia corrente, ainda parcial, é excluído)"
    ),
    CUTOFF_CURRENT_DAY: (
        "dia local corrente, que pode estar parcial no momento da execução"
    ),
}

_DATE_FORMAT = "%Y-%m-%d"
_TS_FORMAT = "%Y-%m-%d %H:%M:%S"


def parse_window_days(value=None) -> int:
    """Valida a quantidade configurada para a janela padrão.

    ``None`` e texto vazio preservam o padrão histórico de 33 dias. A mesma
    função é usada pela interface web e pelo agendador para que ambos aceitem
    exatamente o mesmo intervalo.
    """
    raw = str(value or "").strip()
    if not raw:
        return DEFAULT_WINDOW_DAYS
    try:
        days = int(raw)
    except ValueError:
        raise ValueError(
            "BACKTEST_WINDOW_DAYS deve ser um inteiro entre 1 e {0}.".format(
                MAX_WINDOW_DAYS
            )
        )
    if not 1 <= days <= MAX_WINDOW_DAYS:
        raise ValueError(
            "BACKTEST_WINDOW_DAYS deve estar entre 1 e {0}.".format(
                MAX_WINDOW_DAYS
            )
        )
    return days


@dataclass(frozen=True)
class BacktestPeriod:
    """Período resolvido, com as duas representações e o corte aplicado."""

    start_date: date
    end_date_inclusive: date
    timezone_name: str = APP_TIMEZONE
    cutoff_mode: str = CUTOFF_CURRENT_DAY
    reference_date: date | None = None

    @property
    def total_calendar_days(self) -> int:
        return (self.end_date_inclusive - self.start_date).days + 1

    @property
    def start_text(self) -> str:
        return self.start_date.strftime(_DATE_FORMAT)

    @property
    def end_inclusive_text(self) -> str:
        return self.end_date_inclusive.strftime(_DATE_FORMAT)

    @property
    def start_timestamp(self) -> str:
        return "{0} 00:00:00".format(self.start_text)

    @property
    def end_exclusive_timestamp(self) -> str:
        return "{0} 00:00:00".format(
            (self.end_date_inclusive + timedelta(days=1)).strftime(_DATE_FORMAT)
        )

    @property
    def start_datetime(self) -> datetime:
        tz = resolve_timezone(self.timezone_name)
        return datetime.combine(self.start_date, datetime.min.time(), tzinfo=tz)

    @property
    def end_exclusive_datetime(self) -> datetime:
        tz = resolve_timezone(self.timezone_name)
        return datetime.combine(
            self.end_date_inclusive + timedelta(days=1), datetime.min.time(), tzinfo=tz
        )

    @property
    def data_cutoff_description(self) -> str:
        return CUTOFF_LABELS_PT.get(self.cutoff_mode, self.cutoff_mode)

    def local_dates(self) -> list[str]:
        """Lista estável de todas as datas locais cobertas pelo período."""
        return [
            (self.start_date + timedelta(days=offset)).strftime(_DATE_FORMAT)
            for offset in range(self.total_calendar_days)
        ]

    def as_payload(self) -> dict:
        """Representação serializável reutilizada por job, bundle e relatório."""
        return {
            "start_date": self.start_text,
            "end_date_inclusive": self.end_inclusive_text,
            "start": self.start_timestamp,
            "end_exclusive": self.end_exclusive_timestamp,
            "timezone": self.timezone_name,
            "total_calendar_days": self.total_calendar_days,
            "boundary_semantics": (
                "datas inclusivas na interface; janela técnica [início, fim) no "
                "processamento"
            ),
            "cutoff_mode": self.cutoff_mode,
            "data_cutoff": self.end_exclusive_timestamp,
            "data_cutoff_description": self.data_cutoff_description,
        }


def parse_local_date(value, label: str) -> date:
    """Converte ``AAAA-MM-DD`` em :class:`datetime.date` validando o calendário."""
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    text = str(value or "").strip()
    try:
        return datetime.strptime(text, _DATE_FORMAT).date()
    except ValueError:
        raise ValueError(
            "Período inválido: informe {0} como data real no formato AAAA-MM-DD.".format(label)
        )


def build_period(
    start_date,
    end_date_inclusive,
    *,
    timezone_name: str = APP_TIMEZONE,
    cutoff_mode: str = CUTOFF_CURRENT_DAY,
    max_calendar_days: int | None = 400,
    reference_date: date | None = None,
) -> BacktestPeriod:
    """Valida um período parametrizado informado por pessoa ou automação."""
    if cutoff_mode not in CUTOFF_MODES:
        raise ValueError(
            "Corte de dados inválido: use {0}.".format(" ou ".join(CUTOFF_MODES))
        )
    start = parse_local_date(start_date, "a data inicial")
    end = parse_local_date(end_date_inclusive, "a data final")
    if start > end:
        raise ValueError(
            "Período inválido: a data inicial deve ser anterior ou igual à data final."
        )
    total = (end - start).days + 1
    if max_calendar_days is not None and total > max_calendar_days:
        raise ValueError(
            "Período inválido: {0} dias solicitados excedem o limite de {1} dias "
            "por execução.".format(total, max_calendar_days)
        )
    return BacktestPeriod(
        start_date=start,
        end_date_inclusive=end,
        timezone_name=timezone_name,
        cutoff_mode=cutoff_mode,
        reference_date=reference_date,
    )


def default_period(
    clock: Clock,
    *,
    window_days: int = DEFAULT_WINDOW_DAYS,
    cutoff_mode: str = CUTOFF_CURRENT_DAY,
) -> BacktestPeriod:
    """Período rolante padrão de ``window_days`` datas locais inclusivas.

    Com ``cutoff_mode=CUTOFF_CURRENT_DAY`` (padrão da interface) o período
    termina na data local corrente. Com :data:`CUTOFF_COMPLETED_DAY` (padrão
    das execuções automáticas) termina no último dia local completo.
    """
    if window_days <= 0:
        raise ValueError("A janela padrão deve conter pelo menos um dia.")
    if cutoff_mode not in CUTOFF_MODES:
        raise ValueError(
            "Corte de dados inválido: use {0}.".format(" ou ".join(CUTOFF_MODES))
        )
    reference = clock.today()
    end = reference if cutoff_mode == CUTOFF_CURRENT_DAY else reference - timedelta(days=1)
    start = end - timedelta(days=window_days - 1)
    return BacktestPeriod(
        start_date=start,
        end_date_inclusive=end,
        timezone_name=clock.timezone_name,
        cutoff_mode=cutoff_mode,
        reference_date=reference,
    )


def inclusive_dates_to_window(start_date, end_date, *, timezone_name: str = APP_TIMEZONE):
    """Converte datas inclusivas em ``(início, fim_exclusivo)`` textuais."""
    period = build_period(start_date, end_date, timezone_name=timezone_name)
    return period.start_timestamp, period.end_exclusive_timestamp


def window_to_period(start_timestamp, end_exclusive_timestamp, *, timezone_name: str = APP_TIMEZONE):
    """Reconstrói o período inclusivo a partir da janela técnica semiaberta."""
    start = _parse_timestamp(start_timestamp, "início")
    end = _parse_timestamp(end_exclusive_timestamp, "fim")
    if end <= start:
        raise ValueError("Janela inválida: o fim exclusivo deve ser posterior ao início.")
    return BacktestPeriod(
        start_date=start.date(),
        end_date_inclusive=(end - timedelta(seconds=1)).date(),
        timezone_name=timezone_name,
    )


def _parse_timestamp(value, label: str) -> datetime:
    if isinstance(value, datetime):
        return value
    text = str(value or "").strip()
    for fmt in (_TS_FORMAT, _DATE_FORMAT):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            continue
    raise ValueError(
        "Janela inválida: {0} deve usar 'AAAA-MM-DD HH:MM:SS' ou 'AAAA-MM-DD'.".format(label)
    )


__all__ = [
    "BacktestPeriod",
    "CUTOFF_COMPLETED_DAY",
    "CUTOFF_CURRENT_DAY",
    "CUTOFF_LABELS_PT",
    "CUTOFF_MODES",
    "DEFAULT_WINDOW_DAYS",
    "MAX_WINDOW_DAYS",
    "build_period",
    "default_period",
    "inclusive_dates_to_window",
    "parse_local_date",
    "parse_window_days",
    "window_to_period",
]
