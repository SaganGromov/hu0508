"""Relógio injetável usado por agendamento, progresso e ETA.

Nenhum componente de aplicação chama ``datetime.now`` diretamente: todos
recebem um :class:`Clock`. Isso mantém os testes determinísticos e permite
avançar o tempo sem depender do relógio de parede.
"""

from __future__ import annotations

import time
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from .detection import APP_TIMEZONE


def resolve_timezone(timezone_name: str = APP_TIMEZONE):
    """Resolve o fuso configurado, com fallback explícito para -03.

    ``America/Sao_Paulo`` não observa horário de verão desde 2019. O fallback
    permite operar em imagens mínimas sem ``tzdata``; instalações normais
    devem fornecer a base IANA para interpretar datas históricas.
    """
    try:
        return ZoneInfo(timezone_name)
    except Exception:
        if timezone_name != APP_TIMEZONE:
            raise ValueError("Fuso horário indisponível: {0}".format(timezone_name))
        return timezone(timedelta(hours=-3), name="-03")


class Clock:
    """Interface mínima de relógio."""

    timezone_name: str = APP_TIMEZONE

    def now(self) -> datetime:  # pragma: no cover - interface
        raise NotImplementedError

    def monotonic(self) -> float:  # pragma: no cover - interface
        raise NotImplementedError

    def today(self) -> date:
        return self.now().date()

    def tzinfo(self):
        return resolve_timezone(self.timezone_name)


class SystemClock(Clock):
    """Relógio real, sempre no fuso configurado da aplicação."""

    def __init__(self, timezone_name: str = APP_TIMEZONE) -> None:
        self.timezone_name = timezone_name
        self._tz = resolve_timezone(timezone_name)

    def now(self) -> datetime:
        return datetime.now(self._tz)

    def monotonic(self) -> float:
        return time.monotonic()


class FixedClock(Clock):
    """Relógio controlável para testes de ETA, lease e agendamento."""

    def __init__(self, moment: datetime, timezone_name: str = APP_TIMEZONE) -> None:
        self.timezone_name = timezone_name
        self._tz = resolve_timezone(timezone_name)
        self._now = moment if moment.tzinfo else moment.replace(tzinfo=self._tz)
        self._monotonic = 0.0

    def now(self) -> datetime:
        return self._now.astimezone(self._tz)

    def monotonic(self) -> float:
        return self._monotonic

    def advance(self, seconds: float) -> None:
        if seconds < 0:
            raise ValueError("FixedClock.advance não aceita valores negativos.")
        self._now = self._now + timedelta(seconds=seconds)
        self._monotonic += seconds

    def set(self, moment: datetime) -> None:
        """Reposiciona o relógio civil sem retroceder o monotônico."""
        self._now = moment if moment.tzinfo else moment.replace(tzinfo=self._tz)


__all__ = ["Clock", "FixedClock", "SystemClock", "resolve_timezone"]
