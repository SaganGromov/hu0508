"""Geradores LaTeX e XLSX baseados no mesmo modelo normalizado.

Estrutura do dossiê (divulgação progressiva)
--------------------------------------------
1. capa com classificação, metadados de execução e aviso obrigatório;
2. “Como ler este relatório”, com legendas de severidade, alerta UOR, dado
   ausente, exclusões e termos de evidência;
3. resumo executivo com os totais que orientam a priorização;
4. catálogo de regras: pergunta de negócio, condição exata, agrupamento,
   causas legítimas e limitações;
5. achados consolidados entre regras;
6. ocorrências por regra — resumo da regra e, em seguida, cada ocorrência com
   condição, valor, limiar, janela e evidência;
7. perfis de usuários e de dispositivos;
8. amostra cronológica no dossiê, com a cronologia completa no pacote CSV;
9. metodologia, qualidade dos dados, limitações e revisão humana;
10. índice do pacote de detalhamento em CSV, com nomes de arquivo visíveis.

Volume de dados é tratado por divulgação progressiva e pelo pacote CSV, nunca
por tabelas gigantes e ilegíveis no corpo do documento.
"""

from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

try:
    from openpyxl import Workbook, load_workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.worksheet.table import Table, TableStyleInfo
    from openpyxl.worksheet.page import PageMargins
    from openpyxl.worksheet.properties import PageSetupProperties
except ImportError:  # pragma: no cover - mensagem clara no handoff mínimo
    Workbook = load_workbook = Alignment = Font = PatternFill = None
    Border = Side = None
    Table = TableStyleInfo = PageMargins = PageSetupProperties = None

from . import csvpackage
from .report_model import UOR_ALERTS, _missing, display_value


NOTICE = (
    "Este documento contém informações internas de acesso restrito. Os alertas "
    "apresentados resultam de regras automatizadas de detecção e exigem análise "
    "humana. Um alerta, isoladamente, não comprova irregularidade, fraude ou má conduta."
)

#: Quantidade máxima de linhas da amostra cronológica impressa no dossiê.
#: A cronologia completa fica no pacote CSV, referenciada por nome de arquivo.
TIMELINE_SAMPLE_LIMIT = 200

UOR_FILLS = {}
SEVERITY_FILLS = {}
HEADER_FILL = TITLE_FILL = None
THIN_BORDER = None
if PatternFill is not None:
    UOR_FILLS = {
        "YELLOW_UOR_20259": PatternFill("solid", fgColor="FFF2CC"),
        "RED_OTHER_UOR": PatternFill("solid", fgColor="F4CCCC"),
        "GRAY_UNKNOWN_UOR": PatternFill("solid", fgColor="D9D9D9"),
        # Uma ocorrência R7 pode envolver pessoas de classes diferentes.
        # O texto lista cada classe; o fundo neutro evita escolher uma delas.
        "MULTIPLE": PatternFill("solid", fgColor="D9D9D9"),
    }
    HEADER_FILL = PatternFill("solid", fgColor="1F4E78")
    TITLE_FILL = PatternFill("solid", fgColor="D9EAF7")
    SEVERITY_FILLS = {
        "CRÍTICA": PatternFill("solid", fgColor="C00000"),
        "ALTA": PatternFill("solid", fgColor="F4CCCC"),
        "MÉDIA": PatternFill("solid", fgColor="FFF2CC"),
        "BAIXA": PatternFill("solid", fgColor="D9EAD3"),
        "VARIÁVEL": PatternFill("solid", fgColor="EAD1DC"),
    }
if Side is not None:
    THIN_BORDER = Border(
        left=Side(style="thin", color="BFBFBF"),
        right=Side(style="thin", color="BFBFBF"),
        top=Side(style="thin", color="BFBFBF"),
        bottom=Side(style="thin", color="BFBFBF"),
    )
INVALID_SHEET_CHARS = re.compile(r"[\[\]:*?/\\]")
EXCEL_MAX_ROWS = 1_048_576
EXCEL_MAX_COLUMNS = 16_384

#: Limite conservador de linhas de dados por planilha, com margem para o
#: título e o cabeçalho. Acima dele o dado detalhado vai apenas para o CSV.
SHEET_ROW_LIMIT = 200_000

_LATEX_CONTROL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def latex_escape(value) -> str:
    """Escapa todo valor externo antes de inseri-lo no LaTeX.

    Nenhum texto derivado de dados pode introduzir comando LaTeX: a barra
    invertida é neutralizada primeiro, e chaves, cifrão, porcentagem,
    cerquilha, sublinhado, e comercial, til e circunflexo são escapados.
    Caracteres de controle são removidos.
    """
    text = _LATEX_CONTROL_RE.sub("", display_value(value))
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
        "<": r"\textless{}",
        ">": r"\textgreater{}",
        "|": r"\textbar{}",
        "≥": r"\ensuremath{\geq}",
        "≤": r"\ensuremath{\leq}",
        "↔": r"\ensuremath{\leftrightarrow}",
        "→": r"\ensuremath{\rightarrow}",
        "±": r"\ensuremath{\pm}",
        "—": "---",
        "–": "--",
        "“": "``",
        "”": "''",
    }
    return "".join(replacements.get(char, char) for char in text)


#: Caracteres depois dos quais é seguro permitir quebra de linha em LaTeX.
_BREAK_AFTER = frozenset(",:;/|}])>_-.=&\"'")
#: Comprimento máximo de um trecho sem oportunidade de quebra.
_MAX_UNBROKEN_RUN = 12
#: Separadores que o escape LaTeX transforma em comando e que continuam sendo
#: pontos de quebra válidos.
_ESCAPED_BREAK_TOKENS = frozenset({r"\_", r"\&", r"\%", r"\#", r"\{", r"\}", r"\$"})


def latex_escape_breakable(value) -> str:
    """Escapa e insere oportunidades de quebra em valores longos.

    Listas de IPs, identificadores de evento e detalhes estruturados formam
    sequências sem espaço que o LaTeX não consegue quebrar, causando texto
    fora da margem. Esta função adiciona ``\\allowbreak{}`` depois de
    separadores naturais e, em trechos muito longos, a cada
    ``_MAX_UNBROKEN_RUN`` caracteres. Nenhum caractere é removido, então o
    valor permanece legível e conferível.
    """
    escaped = latex_escape(value)
    out = []
    run = 0
    index = 0
    length = len(escaped)
    while index < length:
        char = escaped[index]
        # Preserva comandos de escape (\_, \&, \textbackslash{} …) intactos.
        if char == "\\":
            end = index + 1
            while end < length and (escaped[end].isalpha() or end == index + 1):
                if escaped[end].isalpha():
                    end += 1
                    continue
                end += 1
                break
            if end < length and escaped[end] == "{":
                closing = escaped.find("}", end)
                end = length if closing == -1 else closing + 1
            token = escaped[index:end]
            out.append(token)
            run += len(token)
            index = end
            # Um separador escapado (\_ \& \% \# \{ \}) continua sendo um ponto
            # de quebra seguro, embora o caractere literal seja uma barra.
            if token in _ESCAPED_BREAK_TOKENS or run >= _MAX_UNBROKEN_RUN:
                out.append(r"\allowbreak{}")
                run = 0
            continue
        out.append(char)
        index += 1
        if char.isspace():
            run = 0
            continue
        run += 1
        if char in _BREAK_AFTER or run >= _MAX_UNBROKEN_RUN:
            out.append(r"\allowbreak{}")
            run = 0
    return "".join(out)


def safe_excel_value(value):
    """Impede interpretação de strings externas como fórmulas."""
    if value is None or value == "":
        return "Não informado"
    if isinstance(value, (int, float, bool)):
        return value
    if isinstance(value, (list, tuple, set, dict)):
        value = display_value(value)
    text = str(value)
    if text.startswith(("=", "+", "-", "@")):
        return "'" + text
    return text[:32767]


def _latex_uor_command(code: str) -> str:
    return {
        "YELLOW_UOR_20259": r"\UORYellowBadge",
        "RED_OTHER_UOR": r"\UORRedBadge",
        "GRAY_UNKNOWN_UOR": r"\UORGrayBadge",
    }.get(code, r"\UORGrayBadge")


def _latex_severity_badge(severity: str) -> str:
    """Mapeia severidade a comandos fixos; dados nunca viram comandos LaTeX."""
    return {
        "CRÍTICA": r"\SevCriticalBadge",
        "ALTA": r"\SevHighBadge",
        "MÉDIA": r"\SevMediumBadge",
        "BAIXA": r"\SevLowBadge",
        "VARIÁVEL": r"\SevVariableBadge",
    }.get(str(severity or "").strip().upper(), r"\SevVariableBadge")


def _latex_occurrence_uor(item: dict) -> str:
    alerts = item.get("uor_alerts") or []
    if not alerts:
        return r"\UORGrayBadge"
    # O identificador fica em uma linha e o selo na seguinte, para que o selo
    # ocupe a largura total da coluna e possa quebrar sem estourar a margem.
    return r"\newline ".join(
        latex_escape(alert.get("user_id")) + r":\newline "
        + _latex_uor_command(alert.get("uor_alert_code"))
        for alert in alerts
    )


def _latex_device_uor(item: dict) -> str:
    alerts = item.get("associated_uor_alerts") or []
    if not alerts:
        return r"\UORGrayBadge"
    return r"\newline ".join(
        latex_escape(alert.get("user_id")) + r":\newline "
        + _latex_uor_command(alert.get("uor_alert_code"))
        for alert in alerts
    )


def _longtable_head(columns: str, headers: list[str], *, continued: bool = True) -> list[str]:
    """Cabeçalho de longtable repetido em toda página, com aviso de continuação."""
    header_row = " & ".join(r"\textbf{" + latex_escape(item) + "}" for item in headers)
    span = len(headers)
    lines = [
        r"\begin{longtable}{" + columns + "}",
        r"\toprule " + header_row + r"\\\midrule",
        r"\endfirsthead",
        r"\multicolumn{" + str(span) + r"}{l}{\footnotesize\itshape Continuação da tabela anterior.}\\",
        r"\toprule " + header_row + r"\\\midrule",
        r"\endhead",
        r"\midrule\multicolumn{" + str(span) + r"}{r}{\footnotesize\itshape Continua na próxima página.}\\",
        r"\endfoot",
        r"\bottomrule",
        r"\endlastfoot",
    ]
    if not continued:
        lines = [
            r"\begin{longtable}{" + columns + "}",
            r"\toprule " + header_row + r"\\\midrule",
            r"\endhead",
            r"\bottomrule",
            r"\endlastfoot",
        ]
    return lines


def _empty_row(span: int, message: str) -> str:
    return r"\multicolumn{" + str(span) + r"}{l}{\itshape " + latex_escape(message) + r"}\\"


def _metadata_rows(report: dict) -> list[tuple[str, object]]:
    return [
        ("Identificador do relatório", report.get("report_id")),
        ("Identificador da execução", report.get("job_id")),
        ("Origem da execução", report.get("trigger_label") or report.get("trigger_type")),
        ("Tentativa da execução", report.get("execution_attempt")),
        ("Período (datas locais inclusivas)", "{0} a {1}".format(
            display_value(report.get("period_start_date")),
            display_value(report.get("period_end_inclusive")),
        )),
        ("Total de dias de calendário", report.get("total_calendar_days")),
        ("Janela técnica processada", "[{0}, {1})".format(
            display_value(report.get("period_start")),
            display_value(report.get("period_end_exclusive")),
        )),
        ("Semântica de limites", report.get("period_semantics")),
        ("Corte de dados", report.get("data_cutoff")),
        ("Critério do corte de dados", report.get("data_cutoff_description")),
        ("Fuso horário", report.get("timezone")),
        ("Data e hora de geração", report.get("generation_timestamp")),
        ("Versão da aplicação", report.get("application_version")),
        ("Hash da configuração", report.get("configuration_hash")),
        ("Versões das regras", report.get("rule_versions")),
        ("Dados sintéticos de teste", "Sim" if report.get("safe_fixture") else "Não"),
    ]


def render_latex(model: dict) -> str:
    report = model["report"]
    executive = model["executive"]
    csv_files = csvpackage.describe_datasets(model)
    lines = [
        r"\documentclass[11pt,a4paper]{article}",
        r"\usepackage[utf8]{inputenc}",
        r"\usepackage[T1]{fontenc}",
        r"\usepackage[brazil]{babel}",
        r"\usepackage{lmodern}",
        r"\usepackage[margin=1.8cm,includefoot]{geometry}",
        r"\usepackage[table]{xcolor}",
        r"\usepackage{booktabs,longtable,array,tabularx,pdflscape}",
        r"\usepackage{fancyhdr,enumitem}",
        r"\usepackage{hyperref}",
        r"\hypersetup{",
        r"  colorlinks=true,linkcolor=blue!45!black,urlcolor=blue!45!black,",
        r"  bookmarks=true,bookmarksnumbered=true,bookmarksopen=true,",
        r"  pdftitle={" + latex_escape(report["title"]) + "},",
        r"  pdfsubject={" + latex_escape(report["classification"]) + "},",
        r"  pdfkeywords={backtesting, VPN, revisão humana},",
        r"}",
        r"\definecolor{UORYellow}{HTML}{FFF2CC}",
        r"\definecolor{UORRed}{HTML}{F4CCCC}",
        r"\definecolor{UORGray}{HTML}{D9D9D9}",
        r"\definecolor{SevCritical}{HTML}{C00000}",
        r"\definecolor{SevHigh}{HTML}{F4CCCC}",
        r"\definecolor{SevMedium}{HTML}{FFF2CC}",
        r"\definecolor{SevLow}{HTML}{D9EAD3}",
        r"\definecolor{CorporateBlue}{HTML}{1F4E78}",
        # Os selos combinam cor e texto: em impressão em tons de cinza o rótulo
        # textual continua legível e distinguível pela borda. O rótulo fica em
        # um \parbox da largura da coluna, portanto quebra linha em vez de
        # invadir a margem, em qualquer largura de tabela.
        r"\setlength{\fboxsep}{2pt}",
        r"\newcommand{\UORBadge}[3]{%",
        r"  \fcolorbox{black!55}{#1}{\parbox[t]"
        r"{\dimexpr\linewidth-2\fboxsep-2\fboxrule\relax}"
        r"{\raggedright\footnotesize\textbf{#2}~\textsuperscript{\tiny #3}}}%",
        r"}",
        r"\newcommand{\UORYellowBadge}{\UORBadge{UORYellow}{ALERTA AMARELO --- UOR 20259}{A}}",
        r"\newcommand{\UORRedBadge}{\UORBadge{UORRed}{ALERTA VERMELHO --- UOR diferente de 20259}{V}}",
        r"\newcommand{\UORGrayBadge}{\UORBadge{UORGray}{UOR NÃO INFORMADA OU NÃO DETERMINADA}{N}}",
        r"\newcommand{\SevCriticalBadge}{\fcolorbox{black!55}{SevCritical}{\strut\color{white}\textbf{\footnotesize CRÍTICA}}}",
        r"\newcommand{\SevHighBadge}{\fcolorbox{black!55}{SevHigh}{\strut\textbf{\footnotesize ALTA}}}",
        r"\newcommand{\SevMediumBadge}{\fcolorbox{black!55}{SevMedium}{\strut\textbf{\footnotesize MÉDIA}}}",
        r"\newcommand{\SevLowBadge}{\fcolorbox{black!55}{SevLow}{\strut\textbf{\footnotesize BAIXA}}}",
        r"\newcommand{\SevVariableBadge}{\fcolorbox{black!55}{UORGray}{\strut\textbf{\footnotesize VARIÁVEL}}}",
        r"\newcommand{\NotInformed}{\textit{Não informado}}",
        r"\newcommand{\RefID}[1]{\texttt{\footnotesize #1}}",
        r"\pagestyle{fancy}\fancyhf{}",
        r"\lhead{\footnotesize Backtesting de acessos VPN}",
        r"\rhead{\footnotesize Informação interna --- acesso restrito}",
        r"\cfoot{\footnotesize Página \thepage}",
        r"\setlength{\parindent}{0pt}\setlength{\parskip}{5pt}",
        r"\setlength{\LTcapwidth}{\textwidth}",
        r"\renewcommand{\arraystretch}{1.15}",
        # Tolerância tipográfica: valores derivados de dados não têm hifenização
        # do idioma. Sem isso, uma sequência longa pode invadir a margem mesmo
        # com oportunidades de quebra inseridas pelo gerador.
        r"\tolerance=2000 \emergencystretch=3em \hbadness=10000",
        # Colunas de texto largo alinhadas à esquerda, para não gerar espaços
        # esticados nem estouro horizontal.
        r"\newcolumntype{W}[1]{>{\raggedright\arraybackslash}p{#1}}",
        r"\begin{document}",
        r"\begin{titlepage}\centering",
        r"{\color{CorporateBlue}\rule{\textwidth}{2pt}}\vspace{1.2cm}",
        r"{\Huge\bfseries " + latex_escape(report["title"]) + r"\par}\vspace{0.7cm}",
        r"{\Large " + latex_escape(report["classification"]) + r"\par}\vspace{0.9cm}",
        r"\begin{tabular}{@{}r@{\hspace{6pt}}p{0.62\textwidth}@{}}",
    ]
    for label, value in _metadata_rows(report):
        lines.append(
            r"\textbf{" + latex_escape(label) + ":} & " + latex_escape_breakable(value) + r"\\"
        )
    lines.extend([
        r"\end{tabular}\vfill",
        r"\fcolorbox{black!55}{UORGray}{\parbox{0.92\textwidth}{\textbf{Aviso:} "
        + latex_escape(NOTICE) + r"}}",
        r"\vfill{\color{CorporateBlue}\rule{\textwidth}{2pt}}\end{titlepage}",
        r"\tableofcontents\clearpage",
        # ── 1. Como ler ───────────────────────────────────────────────
        r"\section{Como ler este relatório}",
        r"\subsection{Ordem de leitura sugerida}",
        r"\begin{enumerate}[leftmargin=*,nosep]",
        *[r"\item " + latex_escape(item) for item in model["reading_guide"]],
        r"\end{enumerate}",
        r"\subsection{Como o documento é organizado}",
        r"\begin{itemize}[leftmargin=*,nosep]",
        r"\item \textbf{Resumo executivo} --- totais e prioridades.",
        r"\item \textbf{Catálogo de regras} --- o que cada regra pergunta e qual condição exata ela aplica.",
        r"\item \textbf{Achados consolidados} --- ocorrências de regras diferentes sobre a mesma evidência.",
        r"\item \textbf{Ocorrências por regra} --- resumo da regra e, em seguida, cada ocorrência detalhada.",
        r"\item \textbf{Perfis} --- visão por usuário e por dispositivo.",
        r"\item \textbf{Cronologia} --- amostra no dossiê; série completa no pacote CSV.",
        r"\item \textbf{Metodologia, qualidade e limitações} --- como interpretar e o que a fonte não permite afirmar.",
        r"\end{itemize}",
        r"\subsection{Legendas}",
        r"\textbf{Alerta UOR} (classificação organizacional, independente da severidade):\\",
        r"\UORYellowBadge\\[2pt]",
        r"\UORRedBadge\\[2pt]",
        r"\UORGrayBadge\\[4pt]",
        r"\textbf{Severidade da anomalia} (atribuída pela regra, não pela unidade organizacional):\\",
        r"\SevCriticalBadge\quad",
        r"\SevHighBadge\quad",
        r"\SevMediumBadge\quad",
        r"\SevLowBadge\\[4pt]",
        r"\textbf{Outros termos:}",
        r"\begin{itemize}[leftmargin=*,nosep]",
        r"\item \textit{Não informado}: dado ausente, vazio, malformado ou não determinado com confiabilidade. Nunca é um valor presumido.",
        r"\item \textbf{Ocorrência}: achado consolidado de uma regra, com identificador estável (por exemplo \RefID{R1-...}).",
        r"\item \textbf{Evento}: linha deduplicada da tabela de autenticação usada como evidência.",
        r"\item \textbf{Login VPN}: evento deduplicado; a fonte consultada não expõe início e fim de sessão.",
        r"\item \textbf{Sessão}: identificador apresentado somente quando a fonte o fornece; nunca é inferido.",
        r"\item \textbf{IP de origem} e \textbf{IP corporativo/túnel}: campos distintos e nunca combinados.",
        r"\item \textbf{Exclusões e allowlists}: contas e dispositivos formalmente autorizados que a configuração remove da avaliação.",
        r"\end{itemize}",
        r"\clearpage",
        # ── 2. Resumo executivo ───────────────────────────────────────
        r"\section{Resumo executivo}",
    ])
    lines.extend(_longtable_head(r"W{0.66\textwidth}r", ["Indicador", "Total"], continued=False))
    for label, value in [
        ("Linhas do banco analisadas", executive["total_database_rows"]),
        ("Eventos deduplicados analisados", executive["total_analyzed_events"]),
        ("Usuários únicos analisados", executive["total_analyzed_users"]),
        ("Dispositivos únicos analisados", executive["total_analyzed_devices"]),
        ("Usuários sinalizados", executive["flagged_users"]),
        ("Dispositivos sinalizados", executive["flagged_devices"]),
        ("Ocorrências consolidadas", executive["total_occurrences"]),
        ("Ocorrências apresentadas para leitura rápida", executive["presented_occurrences"]),
        ("Ocorrências omitidas do detalhamento", executive["omitted_occurrences"]),
        ("Usuários sinalizados por mais de uma regra", executive["multirule_users"]),
        ("Consolidações entre regras", executive.get("cross_rule_consolidations", 0)),
        ("Registros de evidência na cronologia", executive.get("timeline_entries", 0)),
    ]:
        lines.append("{0} & {1}\\\\".format(latex_escape(label), latex_escape(value)))
    lines.extend([
        r"\end{longtable}",
        r"\subsection{Classificação visual por UOR}",
        r"\UORYellowBadge\quad Total de usuários: "
        + str(executive["uor_alert_user_totals"].get("YELLOW_UOR_20259", 0)) + r"\\[3pt]",
        r"\UORRedBadge\quad Total de usuários: "
        + str(executive["uor_alert_user_totals"].get("RED_OTHER_UOR", 0)) + r"\\[3pt]",
        r"\UORGrayBadge\quad Total de usuários: "
        + str(executive["uor_alert_user_totals"].get("GRAY_UNKNOWN_UOR", 0)) + r"\\[3pt]",
        r"\textbf{Legenda:} a cor e o texto acima classificam apenas a UOR. "
        r"Não alteram a severidade da regra. Dado ausente ou inválido é sempre "
        r"cinza, nunca vermelho.",
        r"\subsection{Totais por regra e classificação de UOR}",
    ])
    lines.extend(_longtable_head(
        r"llrrrr",
        ["Regra", "Severidade", "Amarelo", "Vermelho", "UOR não informada", "Ocorrências"],
        continued=False,
    ))
    for rule in model["rule_catalog"]:
        uor = executive["findings_by_rule_and_uor"].get(rule["rule_id"], {})
        lines.append(
            "{0} & {1} & {2} & {3} & {4} & {5}\\\\".format(
                latex_escape(rule["rule_id"]),
                _latex_severity_badge(rule["severity"]),
                uor.get("YELLOW_UOR_20259", 0),
                uor.get("RED_OTHER_UOR", 0),
                uor.get("GRAY_UNKNOWN_UOR", 0),
                rule["finding_count"],
            )
        )
    if not model["rule_catalog"]:
        lines.append(_empty_row(6, "Nenhuma regra habilitada nesta execução."))
    lines.extend([r"\end{longtable}", r"\subsection{Totais por severidade da regra}"])
    lines.extend(_longtable_head(r"lr", ["Severidade", "Ocorrências"], continued=False))
    for severity, count in sorted(executive["findings_by_severity"].items()):
        lines.append("{0} & {1}\\\\".format(_latex_severity_badge(severity), count))
    if not executive["findings_by_severity"]:
        lines.append(_empty_row(2, "Nenhuma ocorrência sinalizada nesta execução."))
    lines.extend([r"\end{longtable}", r"\clearpage"])

    # ── 3. Catálogo de regras ────────────────────────────────────────
    lines.append(r"\section{Catálogo de regras}")
    if not model["rule_catalog"]:
        lines.append(r"Nenhuma regra habilitada nesta execução.")
    for rule in model["rule_catalog"]:
        lines.extend([
            r"\subsection{" + latex_escape("{0} — {1}".format(rule["rule_id"], rule["title"])) + "}",
            *_longtable_head(r"W{3.4cm}W{12.6cm}", ["Campo", "Descrição"], continued=False),
            "Pergunta de negócio & {0}\\\\".format(latex_escape(rule["question"])),
            "Condição implementada & {0}\\\\".format(latex_escape(rule["condition"])),
            "Agrupamento & {0}\\\\".format(latex_escape(rule["grouping"])),
            "Versão da regra & {0}\\\\".format(latex_escape(rule["version"])),
            "Severidade & {0}\\\\".format(_latex_severity_badge(rule["severity"])),
            "Limiares e janelas configurados & {0}\\\\".format(latex_escape_breakable(rule["parameters"])),
            "Ocorrências nesta execução & {0}\\\\".format(rule["finding_count"]),
            "Usuários sinalizados & {0}\\\\".format(rule["flagged_users"]),
            "Dispositivos sinalizados & {0}\\\\".format(rule["flagged_devices"]),
            "Causas legítimas comuns & {0}\\\\".format(latex_escape(rule["legitimate_causes"])),
            "Limitações & {0}\\\\".format(latex_escape(rule["limitation"])),
            r"\end{longtable}",
        ])
    lines.append(r"\clearpage")

    # ── 4. Consolidações entre regras ────────────────────────────────
    lines.extend([
        r"\section{Achados consolidados entre regras}",
        r"Cada consolidação agrupa ocorrências de regras diferentes que "
        r"compartilham os mesmos identificadores de evento e a mesma entidade. "
        r"Coincidência apenas de data não consolida nada.",
    ])
    lines.extend(_longtable_head(
        r"W{3.4cm}W{2.9cm}W{2.0cm}W{6.2cm}",
        ["Consolidação", "Entidades", "Regras", "Ocorrências"],
    ))
    for group in model["cross_rule_consolidations"]:
        lines.append("{0} & {1} & {2} & {3}\\\\".format(
            r"\RefID{" + latex_escape_breakable(group["consolidation_id"]) + "}",
            latex_escape_breakable(group["entities"]),
            latex_escape(group["rules"]),
            latex_escape_breakable(group["occurrence_ids"]),
        ))
    if not model["cross_rule_consolidations"]:
        lines.append(_empty_row(4, "Nenhuma ocorrência de regras diferentes compartilhou a mesma evidência."))
    lines.extend([r"\end{longtable}", r"\clearpage"])

    # ── 5. Ocorrências por regra ─────────────────────────────────────
    lines.append(r"\section{Ocorrências por regra}")
    lines.append(
        r"\fcolorbox{black!55}{UORGray}{\parbox{0.94\textwidth}{"
        r"\textbf{Escopo de leitura rápida:} este detalhamento apresenta no máximo "
        + str(model["presentation"]["occurrence_limit_per_rule"])
        + r" das ocorrências mais prioritárias de cada regra. Os totais "
        r"do Resumo Executivo consideram todos os achados; o bundle JSON "
        r"original preserva a relação completa.}}"
    )
    legitimate_by_rule = {
        rule["rule_id"]: rule["legitimate_causes"] for rule in model["rule_catalog"]
    }
    for rule in model["rule_catalog"]:
        matches = [item for item in model["occurrences"] if item["rule_id"] == rule["rule_id"]]
        lines.append(r"\subsection{" + latex_escape(rule["rule_id"] + " — " + rule["title"]) + "}")
        lines.extend([
            r"\textbf{Pergunta:} " + latex_escape(rule["question"]) + r"\\",
            r"\textbf{Condição:} " + latex_escape(rule["condition"]) + r"\\",
            r"\textbf{Limiares e janelas:} " + latex_escape_breakable(rule["parameters"]) + r"\\",
            r"\textbf{Severidade:} " + _latex_severity_badge(rule["severity"])
            + r" \quad \textbf{Total:} " + str(rule["finding_count"])
            + r" \quad \textbf{Apresentadas:} " + str(len(matches)),
        ])
        if not matches:
            lines.append(
                r"\par\textit{Nenhuma ocorrência sinalizada para esta regra no "
                r"período analisado. Ausência de alerta não comprova ausência do "
                r"comportamento.}"
            )
            continue
        lines.append(r"\subsubsection*{Visão consolidada}")
        lines.extend(_longtable_head(
            r"W{2.6cm}W{2.6cm}W{1.6cm}W{1.7cm}W{1.8cm}W{4.1cm}",
            ["Ocorrência", "Usuário ou dispositivo", "Data local", "Valor", "Severidade", "Alerta UOR"],
        ))
        for item in matches:
            identity = item.get("user_id") or item.get("device_id")
            lines.append("{0} & {1} & {2} & {3} & {4} & {5}\\\\".format(
                r"\RefID{" + latex_escape(item["occurrence_id"]) + "}",
                latex_escape(identity),
                latex_escape(item.get("local_date")),
                latex_escape_breakable(item.get("triggering_value")),
                _latex_severity_badge(item.get("severity")),
                _latex_occurrence_uor(item),
            ))
        lines.append(r"\end{longtable}")
        lines.append(r"\subsubsection*{Detalhe de cada ocorrência}")
        for item in matches:
            lines.extend([
                r"\paragraph{" + latex_escape(item["occurrence_id"]) + "}",
                *_longtable_head(r"W{4.1cm}W{11.9cm}", ["Campo", "Valor"], continued=False),
                "Condição acionada & {0}\\\\".format(latex_escape(item.get("explanation"))),
                "Valor observado & {0}\\\\".format(latex_escape_breakable(item.get("triggering_value"))),
                "Limiar/janela configurados & {0}\\\\".format(latex_escape_breakable(item.get("configured_threshold"))),
                "Severidade & {0}\\\\".format(_latex_severity_badge(item.get("severity"))),
                "Data local & {0}\\\\".format(latex_escape(item.get("local_date"))),
                "Início/fim da janela & {0} a {1}\\\\".format(
                    latex_escape(item.get("window_start")), latex_escape(item.get("window_end"))
                ),
                "Primeiro/último evento & {0} a {1}\\\\".format(
                    latex_escape(item.get("first_event_timestamp")),
                    latex_escape(item.get("last_event_timestamp")),
                ),
                "Usuário(s) & {0}\\\\".format(latex_escape_breakable(item.get("associated_users"))),
                "Dispositivo(s) & {0}\\\\".format(latex_escape_breakable(item.get("associated_devices"))),
                "IPs relevantes & {0}\\\\".format(latex_escape_breakable(item.get("relevant_ips"))),
                "Sessões informadas pela fonte & {0}\\\\".format(latex_escape_breakable(item.get("relevant_sessions"))),
                "Eventos de suporte & {0}\\\\".format(latex_escape_breakable(item.get("supporting_event_identifiers"))),
                "Detalhes estruturados & {0}\\\\".format(latex_escape_breakable(item.get("details"))),
                "Deduplicação & {0}\\\\".format(latex_escape(item.get("deduplication_method"))),
                "Chave de deduplicação & {0}\\\\".format(latex_escape_breakable(item.get("deduplication_key"))),
                "Exclusões consideradas & {0}\\\\".format(latex_escape_breakable(item.get("applicable_exclusions"))),
                "Alerta UOR & {0}\\\\".format(_latex_occurrence_uor(item)),
                "Causas legítimas comuns & {0}\\\\".format(
                    latex_escape(legitimate_by_rule.get(item["rule_id"], "Não informado"))
                ),
                "Revisão humana & Pendente de análise por pessoa autorizada\\\\",
                r"\end{longtable}",
            ])
        lines.append(r"\clearpage")

    # ── 6. Usuários multirregra ──────────────────────────────────────
    lines.append(r"\section{Usuários sinalizados por múltiplas regras}")
    lines.extend(_longtable_head(
        r"W{2.4cm}W{1.7cm}W{2.3cm}W{2.3cm}W{5.4cm}",
        ["Usuário", "UOR", "Regras", "Ocorrências", "Alerta UOR"],
    ))
    for user in model["multirule_users"]:
        lines.append("{0} & {1} & {2} & {3} & {4}\\\\".format(
            latex_escape(user["user_id"]), latex_escape(user["uor"]),
            latex_escape_breakable(user["rules_triggered"]), user["occurrence_count"],
            _latex_uor_command(user["uor_alert_code"]),
        ))
    if not model["multirule_users"]:
        lines.append(_empty_row(5, "Nenhum usuário foi sinalizado por mais de uma regra."))
    lines.append(r"\end{longtable}")

    # ── 7. Dispositivos com múltiplos usuários ───────────────────────
    lines.append(r"\section{Dispositivos associados a múltiplos usuários}")
    lines.extend(_longtable_head(
        r"W{2.8cm}W{1.9cm}W{3.9cm}W{6.4cm}",
        ["Dispositivo", "Usuários", "Identificadores", "Janelas de associação"],
    ))
    shared_devices = [item for item in model["devices"] if item["distinct_users"] >= 2]
    for device in shared_devices:
        windows = "mesmo dia: {0}; 7 dias: {1}; 30 dias: {2}".format(
            "sim" if device["same_day_association"] else "não",
            "sim" if device["seven_day_association"] else "não",
            "sim" if device["thirty_day_association"] else "não",
        )
        lines.append("{0} & {1} & {2} & {3}\\\\".format(
            latex_escape(device["device_id"]), device["distinct_users"],
            latex_escape_breakable(device["associated_users"]), latex_escape(windows),
        ))
    if not shared_devices:
        lines.append(_empty_row(4, "Nenhum dispositivo foi associado a dois ou mais usuários."))
    lines.extend([r"\end{longtable}", r"\clearpage"])

    # ── 8. Perfis de usuários ────────────────────────────────────────
    lines.append(r"\section{Perfis detalhados de usuários}")
    if not model["users"]:
        lines.append(r"Nenhum usuário sinalizado nesta execução.")
    for user in model["users"]:
        campos = [
            ("Nome completo", user["full_name"]), ("Matrícula/registro", user["registration"]),
            ("UOR", user["uor"]),
            ("Hierarquia organizacional", user["organizational_hierarchy"]),
            ("Departamento", user["department"]), ("Unidade", user["unit"]),
            ("Local de trabalho", user["workplace"]), ("Cargo", user["position"]),
            ("Função", user["function"]),
            ("Prefixo da dependência", user["prefix"]), ("Tipo de usuário", user["user_type"]),
            ("Regras acionadas", user["rules_triggered"]), ("Severidades", user["severities"]),
            ("Ocorrências", user["occurrence_count"]), ("Dispositivos", user["devices"]),
            ("IPs", user["ips"]), ("Primeiro evento", user["first_timestamp"]),
            ("Último evento", user["last_timestamp"]),
            ("Eventos de suporte", user["supporting_event_identifiers"]),
        ]
        # Campos sem valor são omitidos em vez de exibidos como "Não informado":
        # a tabela mostra apenas o que o Curio efetivamente devolveu.
        preenchidos = [(label, value) for label, value in campos if not _missing(value)]
        lines.extend([
            r"\subsection{" + latex_escape(user["user_id"]) + "}",
            _latex_uor_command(user["uor_alert_code"]) + r"\\[4pt]",
        ])
        if not preenchidos:
            lines.append(
                r"O Curio não devolveu dados organizacionais para esta matrícula."
            )
            continue
        lines.extend(_longtable_head(r"W{4.2cm}W{11.8cm}", ["Campo", "Valor"], continued=False))
        for label, value in preenchidos:
            lines.append("{0} & {1}\\\\".format(
                latex_escape(label), latex_escape_breakable(value)
            ))
        lines.append(r"\end{longtable}")
    lines.append(r"\clearpage")

    # ── 9. Perfis de dispositivos ────────────────────────────────────
    lines.append(r"\section{Perfis detalhados de dispositivos}")
    if not model["devices"]:
        lines.append(r"Nenhum dispositivo sinalizado nesta execução.")
    for device in model["devices"]:
        lines.extend([
            r"\subsection{" + latex_escape(device["device_id"]) + "}",
            *_longtable_head(r"W{4.4cm}W{11.6cm}", ["Campo", "Valor"], continued=False),
        ])
        for label, value in [
            ("Primeira observação", device["first_timestamp"]),
            ("Última observação", device["last_timestamp"]),
            ("Usuários distintos", device["distinct_users"]),
            ("Usuários associados", device["associated_users"]),
            ("Uso por usuário", device["per_user_usage"]),
            ("UORs associadas", device["associated_uors"]),
            ("Alertas UOR associados", None),
            ("Funções associadas", device["associated_functions"]),
            ("IPs relevantes", device["relevant_ips"]),
            ("Sessões relevantes", device["relevant_sessions"]),
            ("Uso concorrente/sobreposto", device["concurrent_or_overlapping"]),
            ("Allowlist", device["allowlist_classification"]),
            ("Regras acionadas", device["rules_triggered"]),
        ]:
            rendered = _latex_device_uor(device) if label == "Alertas UOR associados" else latex_escape_breakable(value)
            lines.append("{0} & {1}\\\\".format(latex_escape(label), rendered))
        lines.append(r"\end{longtable}")
    lines.append(r"\clearpage")

    # ── 10. Cronologia ───────────────────────────────────────────────
    timeline = model.get("timeline") or []
    sample = timeline[:TIMELINE_SAMPLE_LIMIT]
    lines.extend([
        r"\section{Cronologia das evidências}",
        r"A tabela abaixo apresenta as primeiras {0} de {1} linha(s) de "
        r"evidência, em ordem cronológica local. A série completa está no "
        r"pacote de detalhamento em CSV, arquivo "
        r"\RefID{{{2}}}.".format(
            len(sample), len(timeline),
            latex_escape("{0}/cronologia_consolidada.csv".format(csvpackage.PACKAGE_DIRNAME)),
        ),
        r"\begin{landscape}",
    ])
    lines.extend(_longtable_head(
        r"W{3.2cm}W{1.2cm}W{2.4cm}W{2.6cm}W{3.2cm}W{2.6cm}W{2.6cm}W{3.6cm}",
        ["Horário local", "Regra", "Usuário", "Dispositivo", "Evento",
         "IP de origem", "IP corp./túnel", "Ocorrência"],
    ))
    for entry in sample:
        lines.append("{0} & {1} & {2} & {3} & {4} & {5} & {6} & {7}\\\\".format(
            latex_escape(entry.get("timestamp")),
            latex_escape(entry.get("rule_id")),
            latex_escape(entry.get("user_id")),
            latex_escape(entry.get("device_id")),
            latex_escape(entry.get("event_id")),
            latex_escape(entry.get("source_ip")),
            latex_escape(entry.get("corporate_ip")),
            r"\RefID{" + latex_escape(entry.get("occurrence_id")) + "}",
        ))
    if not sample:
        lines.append(_empty_row(8, "Nenhum registro de evidência foi produzido nesta execução."))
    lines.extend([r"\end{longtable}", r"\end{landscape}", r"\clearpage"])

    # ── 11. Metodologia, qualidade e limitações ──────────────────────
    lines.extend([
        r"\section{Metodologia}",
        r"\begin{itemize}[leftmargin=*,nosep]",
        *[r"\item " + latex_escape(item) for item in model["methodology"]],
        r"\end{itemize}",
        r"\section{Qualidade dos dados}",
    ])
    lines.extend(_longtable_head(r"W{0.62\textwidth}W{0.3\textwidth}", ["Indicador", "Valor"], continued=False))
    for key, value in sorted(model["data_quality"].items()):
        lines.append("{0} & {1}\\\\".format(latex_escape_breakable(key), latex_escape_breakable(value)))
    for key, value in sorted(model["missing_data_indicators"].items()):
        lines.append("Dados ausentes: {0} & {1}\\\\".format(latex_escape_breakable(key), latex_escape_breakable(value)))
    if not model["data_quality"] and not model["missing_data_indicators"]:
        lines.append(_empty_row(2, "Nenhum indicador de qualidade foi informado pela execução."))
    lines.extend([
        r"\end{longtable}",
        r"\subsection{Efeito de allowlists e configuração}",
    ])
    lines.extend(_longtable_head(r"W{0.62\textwidth}W{0.3\textwidth}", ["Parâmetro", "Valor"], continued=False))
    for key, value in sorted(model["allowlist_effects"].items()):
        lines.append("{0} & {1}\\\\".format(latex_escape_breakable(key), latex_escape_breakable(value)))
    if not model["allowlist_effects"]:
        lines.append(_empty_row(2, "Nenhuma allowlist configurada foi aplicada nesta execução."))
    lines.extend([
        r"\end{longtable}",
        r"\section{Limitações e orientação de interpretação}",
        r"\begin{itemize}[leftmargin=*,nosep]",
        *[r"\item " + latex_escape(item) for item in model["limitations"]],
        r"\item " + latex_escape(NOTICE),
        r"\end{itemize}",
        r"\section{Pacote de detalhamento em CSV}",
        r"Os arquivos abaixo acompanham este dossiê no diretório relativo "
        r"\RefID{" + latex_escape(csvpackage.PACKAGE_DIRNAME) + r"}. "
        r"Alguns leitores de PDF bloqueiam links para arquivos locais; por isso "
        r"o nome de cada arquivo é impresso, e o manifesto "
        r"\RefID{" + latex_escape(
            "{0}/{1}".format(csvpackage.PACKAGE_DIRNAME, csvpackage.MANIFEST_NAME)
        ) + r"} traz o SHA-256 "
        r"e a contagem de linhas para conferência após mover o pacote.",
    ])
    lines.extend(_longtable_head(
        r"W{5.1cm}r W{8.9cm}", ["Arquivo (relativo)", "Linhas", "Finalidade"],
    ))
    for entry in csv_files:
        lines.append("{0} & {1} & {2}\\\\".format(
            r"\RefID{" + latex_escape_breakable(entry["relative_link"]) + "}",
            entry["row_count"],
            latex_escape(entry["purpose"]),
        ))
    lines.extend([
        r"\end{longtable}",
        r"\section{Revisão humana}",
        r"\begin{itemize}[leftmargin=*,nosep]",
        *[r"\item " + latex_escape(item) for item in model["human_review_guidance"]],
        r"\end{itemize}",
        r"\textbf{Status:} pendente de análise por pessoa autorizada. Este "
        r"relatório não registra conclusão disciplinar, de fraude ou de má conduta.",
        r"\end{document}",
        "",
    ])
    return "\n".join(lines)


def write_latex(model: dict, path) -> Path:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(render_latex(model), encoding="utf-8")
    return output


def _valid_sheet_name(name: str, used: set[str]) -> str:
    candidate = INVALID_SHEET_CHARS.sub("-", name).strip("'")[:31] or "Planilha"
    base = candidate
    index = 2
    while candidate.lower() in used:
        suffix = "-{0}".format(index)
        candidate = base[:31 - len(suffix)] + suffix
        index += 1
    used.add(candidate.lower())
    return candidate


def _write_table(
    ws, title: str, headers: list[str], rows: list[list], table_name: str,
    timezone_name: str,
):
    if len(headers) > EXCEL_MAX_COLUMNS:
        raise ValueError("XLSX excede o limite de {0} colunas.".format(EXCEL_MAX_COLUMNS))
    if len(rows) + 2 > EXCEL_MAX_ROWS:
        raise ValueError(
            "Planilha {0} excede o limite de {1} linhas do Excel.".format(
                ws.title, EXCEL_MAX_ROWS
            )
        )
    ws.append([title])
    ws["A1"].font = Font(bold=True, size=14, color="1F1F1F")
    ws["A1"].fill = TITLE_FILL
    ws.append(headers)
    for cell in ws[2]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        if THIN_BORDER is not None:
            cell.border = THIN_BORDER
    for row in rows:
        ws.append([safe_excel_value(value) for value in row])
    if rows:
        ref = "A2:{0}{1}".format(ws.cell(2, len(headers)).column_letter, len(rows) + 2)
        table = Table(displayName=table_name, ref=ref)
        table.tableStyleInfo = TableStyleInfo(
            name="TableStyleMedium2", showFirstColumn=False,
            showLastColumn=False, showRowStripes=True, showColumnStripes=False,
        )
        ws.add_table(table)
    ws.freeze_panes = "B3"
    ws.auto_filter.ref = "A2:{0}{1}".format(ws.cell(2, len(headers)).column_letter, max(2, len(rows) + 2))
    ws.sheet_view.showGridLines = False
    ws.page_setup.orientation = "landscape" if len(headers) > 7 else "portrait"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    if PageSetupProperties is not None:
        ws.sheet_properties.pageSetUpPr = PageSetupProperties(fitToPage=True)
    ws.print_title_rows = "1:2"
    ws.page_margins = PageMargins(left=0.25, right=0.25, top=0.5, bottom=0.5)
    for column in ws.columns:
        values = [len(str(cell.value or "")) for cell in column[:200]]
        ws.column_dimensions[column[0].column_letter].width = min(max(max(values, default=8) + 2, 12), 45)
        for cell in column:
            cell.alignment = Alignment(wrap_text=True, vertical="top")
    _format_datetime_columns(ws, timezone_name)


def _format_datetime_columns(ws, timezone_name: str, header_row=2):
    datetime_headers = {
        "Timestamp", "Timestamp local", "Início", "Fim", "Primeiro evento",
        "Último evento", "Primeira observação", "Última observação",
        "Primeiro uso", "Último uso", "Horário local",
    }
    headers = {cell.value: cell.column for cell in ws[header_row]}
    for label in datetime_headers:
        column = headers.get(label)
        if not column:
            continue
        for row in range(header_row + 1, ws.max_row + 1):
            cell = ws.cell(row, column)
            if not isinstance(cell.value, str) or cell.value == "Não informado":
                continue
            try:
                parsed = datetime.fromisoformat(cell.value.replace("Z", "+00:00"))
            except ValueError:
                continue
            # O modelo já normaliza os eventos no fuso declarado pelo relatório.
            # Excel não aceita datetime com tzinfo; o fuso permanece explícito
            # na planilha Resumo Executivo.
            if parsed.tzinfo is not None:
                try:
                    parsed = parsed.astimezone(ZoneInfo(timezone_name))
                except Exception:
                    # Fuso inválido mantém o horário original; a célula segue
                    # legível e o fuso declarado permanece no resumo.
                    pass  # nosec B110
            cell.value = parsed.replace(tzinfo=None)
            cell.number_format = "dd/mm/yyyy hh:mm:ss"
    _format_date_columns(ws, header_row)


def _format_date_columns(ws, header_row=2):
    date_headers = {"Data local"}
    headers = {cell.value: cell.column for cell in ws[header_row]}
    for label in date_headers:
        column = headers.get(label)
        if not column:
            continue
        for row in range(header_row + 1, ws.max_row + 1):
            cell = ws.cell(row, column)
            if not isinstance(cell.value, str) or cell.value == "Não informado":
                continue
            try:
                parsed = datetime.strptime(cell.value[:10], "%Y-%m-%d")
            except ValueError:
                continue
            cell.value = parsed.date()
            cell.number_format = "dd/mm/yyyy"


def _apply_uor_styles(ws, header_row=2):
    headers = {cell.value: cell.column for cell in ws[header_row]}
    column = headers.get("Alerta UOR")
    if not column:
        return
    for row in range(header_row + 1, ws.max_row + 1):
        cell = ws.cell(row, column)
        text = str(cell.value or "")
        matches = [code for code, payload in UOR_ALERTS.items() if payload["label"] in text]
        code = "MULTIPLE" if len(matches) > 1 else (matches[0] if matches else None)
        if code:
            cell.fill = UOR_FILLS[code]
            cell.font = Font(bold=True, color="7F6000" if code == "YELLOW_UOR_20259" else "7F0000" if code == "RED_OTHER_UOR" else "404040")


def _apply_severity_styles(ws, header_row=2):
    headers = {cell.value: cell.column for cell in ws[header_row]}
    column = headers.get("Severidade")
    if not column:
        return
    for row in range(header_row + 1, ws.max_row + 1):
        cell = ws.cell(row, column)
        if cell.value in SEVERITY_FILLS:
            cell.fill = SEVERITY_FILLS[cell.value]
            if cell.value == "CRÍTICA":
                cell.font = Font(bold=True, color="FFFFFF")


def _occurrence_alert_for_user(occurrence: dict, user_id) -> str:
    normalized = str(user_id) if user_id not in (None, "") else None
    for alert in occurrence.get("uor_alerts") or []:
        if normalized is not None and str(alert.get("user_id")) == normalized:
            return alert["uor_alert_label"]
    return occurrence.get("uor_alert_label") or UOR_ALERTS["GRAY_UNKNOWN_UOR"]["label"]


def write_xlsx(model: dict, path) -> Path:
    if Workbook is None:
        raise RuntimeError("openpyxl não está instalado; instale as dependências do projeto para gerar XLSX.")
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    workbook = Workbook()
    workbook.remove(workbook.active)
    used = set()
    table_counter = 1
    index_entries: list[tuple[str, str]] = []

    def sheet(name, title, headers, rows, *, purpose=""):
        nonlocal table_counter
        if len(rows) > SHEET_ROW_LIMIT:
            raise ValueError(
                "Planilha {0} teria {1} linhas, acima do limite operacional de "
                "{2}. Use o pacote CSV para este volume.".format(name, len(rows), SHEET_ROW_LIMIT)
            )
        ws = workbook.create_sheet(_valid_sheet_name(name, used))
        _write_table(
            ws, title, headers, rows, "BacktestTable{0}".format(table_counter),
            model["report"]["timezone"],
        )
        table_counter += 1
        _apply_uor_styles(ws)
        _apply_severity_styles(ws)
        index_entries.append((ws.title, purpose or title))
        return ws

    report = model["report"]
    ex = model["executive"]
    index_sheet = workbook.create_sheet(_valid_sheet_name("Índice", used))

    summary_rows = [[label, value, ""] for label, value in _metadata_rows(report)]
    summary_rows += [
        ["Linhas do banco analisadas", ex["total_database_rows"], ""],
        ["Eventos deduplicados analisados", ex["total_analyzed_events"], ""],
        ["Usuários únicos analisados", ex["total_analyzed_users"], ""],
        ["Dispositivos únicos analisados", ex["total_analyzed_devices"], ""],
        ["Usuários sinalizados", ex["flagged_users"], ""],
        ["Dispositivos sinalizados", ex["flagged_devices"], ""],
        ["Ocorrências", ex["total_occurrences"], ""],
        ["Ocorrências apresentadas para leitura rápida", ex["presented_occurrences"], ""],
        ["Ocorrências omitidas do detalhamento", ex["omitted_occurrences"], ""],
        [
            "Política de apresentação",
            "Até {0} casos prioritários por regra".format(
                model["presentation"]["occurrence_limit_per_rule"]
            ),
            "Os totais abrangem todos os achados; o bundle original preserva a lista completa.",
        ],
        ["Usuários sinalizados por mais de uma regra", ex["multirule_users"], ""],
        ["Consolidações entre regras", ex.get("cross_rule_consolidations", 0), ""],
        ["Registros de evidência na cronologia", ex.get("timeline_entries", 0), ""],
        ["Usuários com UOR 20259", ex["uor_alert_user_totals"]["YELLOW_UOR_20259"], UOR_ALERTS["YELLOW_UOR_20259"]["label"]],
        ["Usuários com outra UOR válida", ex["uor_alert_user_totals"]["RED_OTHER_UOR"], UOR_ALERTS["RED_OTHER_UOR"]["label"]],
        ["Usuários sem UOR determinada", ex["uor_alert_user_totals"]["GRAY_UNKNOWN_UOR"], UOR_ALERTS["GRAY_UNKNOWN_UOR"]["label"]],
        ["Aviso", NOTICE, "A classificação UOR não altera a severidade da anomalia."],
    ]
    for severity, count in sorted(ex["findings_by_severity"].items()):
        summary_rows.append(["Ocorrências com severidade " + severity, count, ""])
    for rule in model["rule_catalog"]:
        breakdown = ex["findings_by_rule_and_uor"].get(rule["rule_id"], {})
        summary_rows.append([
            "{0} — {1}".format(rule["rule_id"], rule["title"]),
            rule["finding_count"],
            "Amarelo: {0}; vermelho: {1}; UOR não determinada: {2}".format(
                breakdown.get("YELLOW_UOR_20259", 0),
                breakdown.get("RED_OTHER_UOR", 0),
                breakdown.get("GRAY_UNKNOWN_UOR", 0),
            ),
        ])
    ws_summary = sheet(
        "Resumo Executivo", "Resumo Executivo", ["Indicador", "Valor", "Alerta UOR"],
        summary_rows,
        purpose="Metadados da execução, totais analisados, sinalizados e classificação de UOR.",
    )
    _apply_uor_styles(ws_summary)

    catalog_rows = []
    for rule in model["rule_catalog"]:
        breakdown = ex["findings_by_rule_and_uor"].get(rule["rule_id"], {})
        catalog_rows.append([
            rule["rule_id"], rule["title"], rule["version"], rule["severity"],
            rule["question"], rule["condition"], rule["grouping"],
            display_value(rule["parameters"]), rule["finding_count"],
            rule["flagged_users"], rule["flagged_devices"],
            breakdown.get("YELLOW_UOR_20259", 0),
            breakdown.get("RED_OTHER_UOR", 0),
            breakdown.get("GRAY_UNKNOWN_UOR", 0),
            rule["legitimate_causes"], rule["limitation"],
        ])
    sheet(
        "Catálogo de Regras", "Catálogo de Regras",
        ["Regra", "Título", "Versão", "Severidade", "Pergunta de negócio",
         "Condição implementada", "Agrupamento", "Limiares e janelas",
         "Ocorrências", "Usuários sinalizados", "Dispositivos sinalizados",
         "UOR 20259", "Outra UOR válida", "UOR não determinada",
         "Causas legítimas comuns", "Limitações"],
        catalog_rows,
        purpose="O que cada regra pergunta, a condição exata aplicada e seus limites.",
    )

    user_headers = [
        "Usuário", "Nome", "Matrícula", "UOR", "Alerta UOR", "Local de trabalho",
        "Cargo", "Prefixo", "Tipo de usuário", "Função", "Departamento", "Unidade", "Regras",
        "Severidades", "Ocorrências", "Dispositivos", "IPs",
        "Primeiro evento", "Último evento",
    ]
    user_rows = [[
        u["user_id"], u["full_name"], u["registration"], u["uor"], u["uor_alert_label"],
        u["workplace"], u["position"], u["prefix"], u["user_type"], u["function"],
        u["department"], u["unit"],
        u["rules_triggered"], u["severities"], u["occurrence_count"], u["devices"],
        u["ips"], u["first_timestamp"], u["last_timestamp"],
    ] for u in model["users"]]
    sheet(
        "Usuários Sinalizados", "Usuários Sinalizados", user_headers, user_rows,
        purpose="Um registro por usuário sinalizado, com dados organizacionais autorizados.",
    )

    device_headers = [
        "Dispositivo", "Usuários distintos", "Usuários", "Uso por usuário",
        "UORs", "Alerta UOR", "Funções", "Primeiro evento", "Último evento",
        "Mesmo dia", "7 dias", "30 dias", "Sobreposição", "Allowlist", "Regras",
    ]
    device_rows = [[
        d["device_id"], d["distinct_users"], d["associated_users"],
        d["per_user_usage"], d["associated_uors"],
        "; ".join(
            "{0}: {1}".format(item["user_id"], item["uor_alert_label"])
            for item in d["associated_uor_alerts"]
        ) or UOR_ALERTS["GRAY_UNKNOWN_UOR"]["label"],
        d["associated_functions"], d["first_timestamp"], d["last_timestamp"],
        d["same_day_association"], d["seven_day_association"], d["thirty_day_association"],
        d["concurrent_or_overlapping"], d["allowlist_classification"], d["rules_triggered"],
    ] for d in model["devices"]]
    sheet(
        "Dispositivos Sinalizados", "Dispositivos Sinalizados", device_headers, device_rows,
        purpose="Um registro por dispositivo sinalizado, com janelas de associação.",
    )

    occurrence_headers = [
        "Ocorrência", "Regra", "Título", "Versão", "Severidade", "Usuário",
        "Dispositivo", "Data local", "Início", "Fim", "Valor observado",
        "Limiar", "Alerta UOR", "Explicação", "Eventos de suporte",
        "Exclusões consideradas", "Detalhes", "Chave de deduplicação",
    ]
    occurrence_rows = [[
        o["occurrence_id"], o["rule_id"], o["rule_title"], o["rule_version"], o["severity"],
        o.get("user_id"), o.get("device_id"), o.get("local_date"), o.get("window_start"),
        o.get("window_end"), o.get("triggering_value"), o.get("configured_threshold"),
        o.get("uor_alert_label"), o.get("explanation"),
        o.get("supporting_event_identifiers"), o.get("applicable_exclusions"),
        o.get("details"), o.get("deduplication_key"),
    ] for o in model["occurrences"]]
    sheet(
        "Ocorrências", "Ocorrências consolidadas", occurrence_headers, occurrence_rows,
        purpose=(
            "Até {0} ocorrências prioritárias por regra, com condição, valor, "
            "limiar e janela; os totais completos estão no Resumo Executivo."
        ).format(model["presentation"]["occurrence_limit_per_rule"]),
    )

    evidence_headers = ["Ocorrência", "Regra", "Severidade", "Usuário", "Dispositivo", "Timestamp", "Evento", "Sessão", "IP de origem", "IP corporativo/túnel", "Alerta UOR", "Método de deduplicação"]
    evidence_rows = []
    for occurrence in model["occurrences"]:
        for evidence in occurrence.get("evidence_records") or [{}]:
            evidence_user = (
                evidence.get("user_id") or evidence.get("USER_KEY")
                or occurrence.get("user_id")
            )
            evidence_rows.append([
                occurrence["occurrence_id"], occurrence["rule_id"], occurrence["severity"],
                evidence_user,
                evidence.get("device_id") or evidence.get("DEVICE_ID") or occurrence.get("device_id"),
                evidence.get("timestamp") or evidence.get("EVENT_TS") or evidence.get("VPN_TS"),
                evidence.get("event_id") or evidence.get("EVENT_ID"),
                evidence.get("session_id") or evidence.get("SESSION_ID"),
                evidence.get("source_ip") or evidence.get("SOURCE_IP"),
                evidence.get("corporate_ip") or evidence.get("CORPORATE_IP") or evidence.get("VPN_CPTV_IP"),
                _occurrence_alert_for_user(occurrence, evidence_user),
                occurrence.get("deduplication_method"),
            ])
    sheet(
        "Evidências", "Evidências por ocorrência", evidence_headers, evidence_rows,
        purpose="Registros de evidência que sustentam cada ocorrência.",
    )

    timeline_rows = [[
        entry.get("timestamp"), entry.get("local_date"), entry.get("rule_id"),
        entry.get("occurrence_id"), entry.get("user_id"), entry.get("device_id"),
        entry.get("event_id"), entry.get("source_ip"), entry.get("corporate_ip"),
        entry.get("uor_alert_label"),
    ] for entry in (model.get("timeline") or [])]
    sheet(
        "Cronologia", "Cronologia consolidada",
        ["Horário local", "Data local", "Regra", "Ocorrência", "Usuário",
         "Dispositivo", "Evento", "IP de origem", "IP corporativo/túnel", "Alerta UOR"],
        timeline_rows,
        purpose="Todas as evidências em ordem cronológica local.",
    )

    rule_sheet_names = {
        "R1": "R1 - Alterações de IP",
        "R2": "R2 - Nomes de Computador",
        "R3": "R3 - Dispositivos no Período",
        "R4": "R4 - Logins VPN",
        "R5": "R5 - Correlação OpenAM",
        "R6": "R6 - R5 e Equipamentos",
        "R7": "R7 - Dispositivo Compart.",
        "R8": "R8 - Múltiplos Dispositivos",
        "R9": "R9 - Troca Rápida de IP",
    }
    for rule in model["rule_catalog"]:
        matches = [row for row in occurrence_rows if row[1] == rule["rule_id"]]
        if matches:
            sheet(
                rule_sheet_names.get(rule["rule_id"], rule["rule_id"] + " - Ocorrências"),
                rule["rule_id"] + " — " + rule["title"], occurrence_headers, matches,
                purpose=(
                    "Até {0} ocorrências prioritárias da regra {1}; o total "
                    "completo está no Resumo Executivo."
                ).format(model["presentation"]["occurrence_limit_per_rule"], rule["rule_id"]),
            )

    multi_rows = [[u["user_id"], u["uor"], u["uor_alert_label"], u["rules_triggered"], u["occurrence_count"], u["severities"]] for u in model["multirule_users"]]
    sheet(
        "Usuários Multirregra", "Usuários sinalizados por múltiplas regras",
        ["Usuário", "UOR", "Alerta UOR", "Regras", "Ocorrências", "Severidades"],
        multi_rows,
        purpose="Usuários acionados por mais de uma regra no período.",
    )

    consolidation_rows = [[
        item["consolidation_id"], item["entities"], item["rules"],
        item["occurrence_count"], item["occurrence_ids"],
        item["shared_event_identifiers"], "; ".join(item["uor_alert_labels"]) or UOR_ALERTS["GRAY_UNKNOWN_UOR"]["label"],
    ] for item in model["cross_rule_consolidations"]]
    sheet(
        "Consolidações", "Achados consolidados entre regras",
        ["Consolidação", "Entidades", "Regras", "Ocorrências", "Identificadores de ocorrência",
         "Eventos compartilhados", "Alerta UOR"],
        consolidation_rows,
        purpose="Ocorrências de regras diferentes que compartilham a mesma evidência.",
    )

    parameter_rows = [[key, display_value(value)] for key, value in sorted(model["parameters"].items())]
    parameter_rows += [
        ["execution.{0}".format(key), display_value(value)]
        for key, value in sorted(model["execution"].items())
    ]
    sheet(
        "Parâmetros", "Parâmetros da execução", ["Parâmetro", "Valor"], parameter_rows,
        purpose="Parâmetros, limites de concorrência e agendamento desta execução.",
    )

    methodology_rows = [["Metodologia", item] for item in model["methodology"]]
    methodology_rows += [["Como ler", item] for item in model["reading_guide"]]
    methodology_rows += [["Revisão humana", item] for item in model["human_review_guidance"]]
    methodology_rows += [["Legenda UOR", item["label"] + " — " + item["reason"]] for item in model["uor_alert_legend"]]
    methodology_rows += [["Limitação", item] for item in model["limitations"]]
    methodology_rows += [["Aviso", NOTICE]]
    sheet(
        "Metodologia", "Metodologia e interpretação", ["Categoria", "Descrição"],
        methodology_rows,
        purpose="Como o resultado foi produzido e como interpretá-lo.",
    )

    quality_rows = [[key, display_value(value)] for key, value in sorted(model["data_quality"].items())]
    quality_rows += [[key, display_value(value)] for key, value in sorted(model["missing_data_indicators"].items())]
    quality_rows += [[key, display_value(value)] for key, value in sorted(model["allowlist_effects"].items())]
    sheet(
        "Qualidade dos Dados", "Qualidade, dados ausentes e allowlists",
        ["Indicador", "Valor"], quality_rows,
        purpose="Contadores de qualidade, dados ausentes e efeito das allowlists.",
    )

    dictionary_rows = [
        ["Ocorrência", "Identificador estável de um achado consolidado."],
        ["Consolidação", "Grupo de ocorrências de regras diferentes sobre a mesma evidência."],
        ["Evento", "Linha deduplicada de AUT_CPTV usada como evidência."],
        ["Login VPN", "Evento deduplicado de AUT_CPTV; a fonte consultada não expõe início/fim de sessão."],
        ["Sessão", "Identificador de sessão somente quando fornecido pela fonte; não é inferido."],
        ["IP de origem", "Valor de CD_END_LGC_OGM normalizado como IPv4/IPv6."],
        ["IP corporativo/túnel", "Valor de CD_END_LGC_CPTV; mantido separado do IP de origem."],
        ["Severidade", "Classificação da anomalia pela regra."],
        ["Alerta UOR", "Classificação organizacional independente da severidade da regra."],
        ["Data local", "Data civil no fuso do relatório; base da agregação diária de R1 e R4."],
        ["Corte de dados", "Instante até onde a leitura da fonte foi considerada nesta execução."],
        ["Não informado", "Dado ausente, vazio, malformado ou não determinado com confiabilidade."],
    ]
    sheet(
        "Dicionário de Dados", "Dicionário de Dados", ["Termo", "Definição"], dictionary_rows,
        purpose="Definição precisa dos termos usados em todas as planilhas.",
    )

    csv_rows = [[
        entry["file"], entry["relative_link"], entry["row_count"],
        entry["part"], entry["total_parts"], entry["purpose"],
    ] for entry in csvpackage.describe_datasets(model)]
    sheet(
        "Detalhamento CSV", "Pacote de detalhamento em CSV",
        ["Arquivo", "Caminho relativo", "Linhas", "Parte", "Total de partes", "Finalidade"],
        csv_rows,
        purpose="Índice do pacote CSV que acompanha este relatório, com caminhos relativos.",
    )

    # ── Índice com hiperlinks internos ───────────────────────────────
    index_sheet.append(["Índice de planilhas"])
    index_sheet["A1"].font = Font(bold=True, size=14, color="1F1F1F")
    index_sheet["A1"].fill = TITLE_FILL
    index_sheet.append(["Planilha", "Conteúdo"])
    for cell in index_sheet[2]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(wrap_text=True, vertical="top")
    for name, purpose in index_entries:
        index_sheet.append([name, safe_excel_value(purpose)])
        row = index_sheet.max_row
        cell = index_sheet.cell(row, 1)
        # Hiperlink interno: o nome da planilha é gerado pelo próprio código,
        # nunca por dado externo, portanto não há injeção de referência.
        cell.hyperlink = "#'{0}'!A1".format(name.replace("'", "''"))
        cell.font = Font(color="0563C1", underline="single")
    index_sheet.freeze_panes = "A3"
    index_sheet.column_dimensions["A"].width = 30
    index_sheet.column_dimensions["B"].width = 90
    index_sheet.sheet_view.showGridLines = False

    workbook.properties.title = model["report"]["title"]
    workbook.properties.subject = NOTICE
    workbook.properties.creator = "acr-controle-acesso-dashboard"
    workbook.properties.description = "Relatório de backtesting; revisão humana obrigatória."
    workbook.save(output)
    # Reabre para detectar arquivos que exigiriam reparo e confirmar os estilos UOR.
    reopened = load_workbook(output, read_only=False, data_only=False)
    required = {
        "Índice", "Resumo Executivo", "Catálogo de Regras", "Usuários Sinalizados",
        "Dispositivos Sinalizados", "Ocorrências", "Evidências", "Cronologia",
        "Usuários Multirregra", "Consolidações", "Parâmetros", "Metodologia",
        "Qualidade dos Dados", "Dicionário de Dados", "Detalhamento CSV",
    }
    missing = sorted(required - set(reopened.sheetnames))
    if missing:
        raise ValueError(
            "XLSX gerado sem as planilhas obrigatórias: {0}".format(", ".join(missing))
        )
    user_sheet = reopened["Usuários Sinalizados"]
    user_headers = {cell.value: cell.column for cell in user_sheet[2]}
    alert_column = user_headers.get("Alerta UOR")
    if alert_column:
        for row in range(3, user_sheet.max_row + 1):
            alert_cell = user_sheet.cell(row, alert_column)
            if alert_cell.fill.fill_type != "solid":
                raise ValueError("XLSX gerado sem formatação visual de Alerta UOR.")
    reopened.close()
    return output


#: Formatos aceitos, na ordem canônica de geração.
REPORT_FORMATS = ("tex", "xlsx", "csv")


def normalize_report_formats(value) -> tuple[str, ...]:
    """Valida a seleção de formatos, preservando a ordem canônica."""
    if value is None:
        return REPORT_FORMATS
    if isinstance(value, str):
        chosen = {item.strip().lower() for item in value.split(",") if item.strip()}
    else:
        chosen = {str(item).strip().lower() for item in value if str(item).strip()}
    unknown = sorted(chosen - set(REPORT_FORMATS))
    if unknown:
        raise ValueError(
            "Formatos de relatório desconhecidos: {0}. Use {1}.".format(
                ", ".join(unknown), ", ".join(REPORT_FORMATS)
            )
        )
    if not chosen:
        raise ValueError("Selecione pelo menos um formato de relatório.")
    return tuple(item for item in REPORT_FORMATS if item in chosen)


def write_reports(
    model: dict,
    output_dir,
    *,
    formats=None,
    csv_package: bool = True,
    csv_use_bom: bool = False,
) -> dict[str, Path]:
    """Gera os formatos selecionados a partir do mesmo modelo normalizado.

    O modelo normalizado é sempre gravado, porque é a fonte única de verdade
    dos três formatos e serve de insumo para conferência.
    """
    selected = set(normalize_report_formats(formats))
    if not csv_package:
        selected.discard("csv")
    if not selected:
        raise ValueError("Selecione pelo menos um formato de relatório.")
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    model_path = out / "backtesting_report_model.json"
    model_path.write_text(json.dumps(model, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
    paths: dict[str, Path] = {"model": model_path}
    if "tex" in selected:
        paths["tex"] = write_latex(model, out / "backtesting_dossier.tex")
    if "xlsx" in selected:
        paths["xlsx"] = write_xlsx(model, out / "backtesting_dossier.xlsx")
    if "csv" in selected:
        csvpackage.write_package(model, out, use_bom=csv_use_bom)
        paths["csv_package"] = out / csvpackage.PACKAGE_DIRNAME
        paths["csv_manifest"] = out / csvpackage.PACKAGE_DIRNAME / csvpackage.MANIFEST_NAME
    return paths
