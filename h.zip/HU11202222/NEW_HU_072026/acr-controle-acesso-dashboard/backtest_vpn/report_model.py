"""Modelo normalizado compartilhado pelos relatórios LaTeX e XLSX."""

from __future__ import annotations

import hashlib
import json
import re
from collections import Counter, defaultdict
from datetime import datetime, timedelta

from .detection import APP_TIMEZONE
from .report_selection import REPORT_OCCURRENCE_LIMIT, select_top_occurrences_by_rule


UOR_ALERTS = {
    "YELLOW_UOR_20259": {
        "label": "ALERTA AMARELO — UOR 20259",
        "reason": "UOR válida normalizada exatamente como 20259.",
    },
    "RED_OTHER_UOR": {
        "label": "ALERTA VERMELHO — UOR diferente de 20259",
        "reason": "UOR válida normalizada é diferente de 20259.",
    },
    "GRAY_UNKNOWN_UOR": {
        "label": "UOR NÃO INFORMADA OU NÃO DETERMINADA",
        "reason": "UOR ausente, vazia, malformada ou não determinada com confiabilidade.",
    },
}

_RULE_META = {
    "R1": ("Alteração de endereço IP no mesmo dia", "2.1.0", "MÉDIA"),
    "R2": ("Múltiplos nomes de computador no período", "2.0.0", "BAIXA"),
    "R3": ("Múltiplos dispositivos no período", "2.0.0", "BAIXA"),
    "R4": ("Mais de dois logins VPN no mesmo dia", "2.2.0", "VARIÁVEL"),
    "R5": ("Correlação temporal VPN e OpenAM em IP diferente", "2.1.0", "ALTA"),
    "R6": ("Correlação R5 com múltiplos equipamentos", "2.1.0", "ALTA"),
    "R7": ("Dispositivo associado a múltiplos usuários", "1.1.0", "VARIÁVEL"),
    "R8": ("Usuário em múltiplos dispositivos em curto intervalo", "1.1.0", "MÉDIA"),
    "R9": ("Troca rápida de endereços IP", "1.1.0", "MÉDIA"),
}
#: Resumo de negócio de cada regra, reutilizado por PDF, XLSX e CSV.
#: Nenhum campo aqui é inferido de dados: são as condições efetivamente
#: implementadas em ``detection.py`` e ``rules.py``.
RULE_GUIDE: dict[str, dict] = {
    "R1": {
        "question": "O usuário mudou de endereço IP dentro do mesmo dia local?",
        "condition": (
            "No mesmo usuário e na mesma data local, pelo menos N endereços IP "
            "válidos distintos no campo de origem OU pelo menos N no campo "
            "corporativo/túnel. Os dois campos são contados separadamente e a "
            "contagem reinicia à meia-noite local."
        ),
        "grouping": "usuário + data local",
        "legitimate": (
            "troca de rede (fixa/móvel), NAT, reconexão, renovação do túnel ou "
            "failover de concentrador"
        ),
        "limitation": (
            "IP de origem e IP corporativo/túnel são dimensões simultâneas e não "
            "são misturados; a classificação de rede só existe quando faixas são "
            "configuradas."
        ),
    },
    "R2": {
        "question": "A mesma chave apareceu com vários nomes de computador no período?",
        "condition": (
            "Mais de N valores válidos e distintos de nome de computador para o "
            "mesmo usuário, no período completo selecionado."
        ),
        "grouping": "usuário (período completo)",
        "legitimate": "renomeação, reinstalação, substituição ou padronização de nomes",
        "limitation": "não há cadastro de ativos para confirmar identidade do equipamento",
    },
    "R3": {
        "question": "A mesma chave apareceu com vários identificadores de dispositivo no período?",
        "condition": (
            "Mais de N identificadores de dispositivo válidos e distintos para o "
            "mesmo usuário, no período completo selecionado."
        ),
        "grouping": "usuário (período completo)",
        "legitimate": "substituição de equipamento ou uso autorizado de equipamento alternativo",
        "limitation": "o ciclo de vida do identificador de dispositivo não está documentado na fonte",
    },
    "R4": {
        "question": "Houve mais de dois logins VPN do mesmo usuário no mesmo dia local?",
        "condition": (
            "Contagem de eventos de login VPN deduplicados por usuário e data "
            "local maior que 2: zero, um e dois não sinalizam; três ou mais "
            "sinalizam. A contagem reinicia à meia-noite local. Por padrão, "
            "3–10 têm severidade média, 11–20 alta e 21 ou mais crítica; os "
            "dois limiares de severidade são configuráveis."
        ),
        "grouping": "usuário + data local",
        "legitimate": "reconexões necessárias, instabilidade de rede ou comportamento do cliente VPN",
        "limitation": (
            "a fonte consultada não distingue refresh, retry, heartbeat ou "
            "reconexão além de linhas exatamente idênticas — decisão pendente do "
            "dono da fonte"
        ),
    },
    "R5": {
        "question": (
            "Houve um evento VPN e uma autenticação OpenAM bem-sucedida do mesmo "
            "usuário, em IPs privados diferentes, dentro da janela de correlação?"
        ),
        "condition": (
            "Para cada evento VPN com IP corporativo/túnel válido, existe fluxo "
            "OpenAM bem-sucedido do mesmo usuário nos nós de decisão "
            "configurados, dentro de ±Δ minutos, com IP de cliente em faixa "
            "privada configurada e diferente do IP tunelado."
        ),
        "grouping": "par (evento VPN, fluxo OpenAM)",
        "legitimate": "coincidência temporal dentro da janela e ausência de semântica completa de sessão",
        "limitation": (
            "correlação temporal não comprova sessão VPN ativa: as fontes não "
            "fornecem início e fim confiáveis de sessão"
        ),
    },
    "R6": {
        "question": "O usuário com correlação R5 também apresentou diversidade de equipamentos no período?",
        "condition": (
            "Ocorrência R5 cujo usuário apresenta, no período completo, mais "
            "nomes de computador que o limite de R2 OU mais identificadores de "
            "dispositivo que o limite independente de R3."
        ),
        "grouping": "ocorrência R5 + usuário",
        "legitimate": "troca legítima de equipamento durante o período",
        "limitation": "a diversidade é medida no período completo, não dentro da janela de R5",
    },
    "R7": {
        "question": "Um mesmo dispositivo foi usado por usuários autenticados diferentes?",
        "condition": (
            "Pelo menos dois usuários autenticados válidos e distintos no mesmo "
            "identificador de dispositivo válido, dentro de uma das janelas "
            "configuradas (mesmo dia, 7 dias móveis e 30 dias móveis por padrão). "
            "Janelas sobrepostas com o mesmo conjunto de usuários são consolidadas "
            "em uma única ocorrência."
        ),
        "grouping": "dispositivo + janela consolidada",
        "legitimate": (
            "estação compartilhada, quiosque, sala de treinamento, terminal de "
            "serviço ou equipamento de unidade — quando formalmente autorizados e "
            "presentes na allowlist configurada"
        ),
        "limitation": (
            "sem início/fim de sessão, uso concorrente é “não determinável”; "
            "horários distintos demonstram apenas a ordem observada"
        ),
    },
    "R8": {
        "question": "O usuário usou vários dispositivos em um intervalo curto?",
        "condition": (
            "Pelo menos N identificadores de dispositivo válidos e distintos "
            "para o mesmo usuário dentro de uma janela móvel de M minutos. "
            "Janelas qualificadas sobrepostas são consolidadas e o valor "
            "acionador é o máximo observado em uma única janela."
        ),
        "grouping": "usuário + janela móvel de minutos",
        "legitimate": "transição entre estação e equipamento móvel, suporte técnico ou nova estação",
        "limitation": "distingue transição aguda de substituição de longo prazo, mas não prova simultaneidade",
    },
    "R9": {
        "question": "O usuário trocou de IP de origem várias vezes em intervalo curto?",
        "condition": (
            "Pelo menos N endereços IP de origem válidos e distintos para o "
            "mesmo usuário dentro de uma janela móvel de M minutos. IP de "
            "origem e IP corporativo/túnel não são misturados. Janelas "
            "qualificadas sobrepostas são consolidadas sem somar valores de "
            "janelas diferentes."
        ),
        "grouping": "usuário + janela móvel de minutos",
        "legitimate": "rede móvel, balanceamento de carga, NAT ou reconexões",
        "limitation": "sem geolocalização confiável não é possível avaliar deslocamento",
    },
}

_SENSITIVE_KEYS = {
    "password", "passwd", "pwd", "secret", "cookie", "credentials",
    "credential", "access_token", "refresh_token", "id_token",
    "authorization", "oauth2_client_secret", "session_secret",
    "authentication_data", "auth_data", "api_key", "private_key",
    "js_inf_cli",
}


def _missing(value):
    return value in (None, "", [], {})


def display_value(value) -> str:
    if _missing(value):
        return "Não informado"
    if isinstance(value, (list, tuple, set)):
        return ", ".join(display_value(item) for item in value) if value else "Não informado"
    if isinstance(value, dict):
        return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
    return str(value)


def _is_sensitive_key(key) -> bool:
    normalized = re.sub(r"[^a-z0-9]+", "_", str(key).lower()).strip("_")
    return (
        normalized in _SENSITIVE_KEYS
        or normalized.endswith(("_password", "_secret", "_cookie", "_credentials", "_token"))
        or normalized in {"jdbc_url", "credentials_file"}
    )


def _scrub_sensitive(value):
    """Remove segredos e localizadores de credenciais antes do modelo."""
    if isinstance(value, dict):
        return {
            str(key): _scrub_sensitive(item)
            for key, item in value.items()
            if not _is_sensitive_key(key)
        }
    if isinstance(value, list):
        return [_scrub_sensitive(item) for item in value]
    if isinstance(value, tuple):
        return tuple(_scrub_sensitive(item) for item in value)
    return value


def normalize_uor(value) -> str | None:
    """Normaliza UOR numérica positiva; valores não confiáveis ficam ausentes."""
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, int):
        return str(value) if value > 0 else None
    if isinstance(value, float):
        return str(int(value)) if value.is_integer() and value > 0 else None
    text = str(value).strip()
    if not re.fullmatch(r"\d+", text):
        return None
    normalized = str(int(text))
    return normalized if normalized != "0" else None


def classify_uor(value) -> dict:
    normalized = normalize_uor(value)
    code = (
        "GRAY_UNKNOWN_UOR" if normalized is None
        else "YELLOW_UOR_20259" if normalized == "20259"
        else "RED_OTHER_UOR"
    )
    return {
        "uor": normalized,
        "uor_alert_code": code,
        "uor_alert_label": UOR_ALERTS[code]["label"],
        "uor_alert_reason": UOR_ALERTS[code]["reason"],
    }


def _case_rule_id(case: dict) -> str | None:
    if case.get("rule_id"):
        return str(case["rule_id"]).upper()
    names = {
        "ips_distintos_acima_do_limite": "R1",
        "hostnames_distintos_acima_do_limite": "R2",
        "dispositivos_distintos_acima_do_limite": "R3",
        "logins_diarios_acima_do_limite": "R4",
        "vpn_ativa_com_login_em_rede_fisica_mta": "R5",
        "vpn_ativa_com_login_em_rede_fisica_mta_multiplos_dispositivos": "R6",
        "dispositivo_multiplos_usuarios": "R7",
        "usuario_multiplos_dispositivos_intervalo_curto": "R8",
        "troca_rapida_ips": "R9",
    }
    return names.get(case.get("name"))


def _fallback_occurrence(case: dict, rule_id: str, sample: dict, index: int) -> dict:
    """Compatibilidade explícita com bundles antigos, sem inventar evidência."""
    user = sample.get("USER_KEY") or sample.get("user_key")
    local_date = sample.get("LOCAL_DATE") or sample.get("LOGIN_DATE")
    stable = hashlib.sha256(
        json.dumps((rule_id, sample, index), sort_keys=True, default=str).encode("utf-8")
    ).hexdigest()[:20]
    title, version, severity = _RULE_META[rule_id]
    return {
        "occurrence_id": "{0}-LEGACY-{1}".format(rule_id, stable),
        "rule_id": rule_id,
        "rule_title": title,
        "rule_version": version,
        "severity": severity,
        "user_id": user,
        "device_id": sample.get("DEVICE_ID"),
        "local_date": str(local_date) if local_date else None,
        "window_start": sample.get("FIRST_SEEN") or sample.get("VPN_TS") or local_date,
        "window_end": sample.get("LAST_SEEN") or sample.get("VPN_TS") or local_date,
        "triggering_value": sample.get("LOGIN_COUNT"),
        "configured_threshold": None,
        "explanation": case.get("note") or "Ocorrência importada de bundle legado; evidência detalhada indisponível.",
        "supporting_event_identifiers": [],
        "evidence_records": [dict(sample)],
        "relevant_ips": [
            value for key, value in sample.items()
            if "IP" in str(key).upper() and value not in (None, "")
        ],
        "relevant_devices": [sample.get("DEVICE_ID")] if sample.get("DEVICE_ID") else [],
        "relevant_sessions": [],
        "deduplication_key": "legacy|{0}|{1}".format(rule_id, stable),
        "deduplication_method": "bundle legado; deduplicação original não informada",
        "first_event_timestamp": sample.get("FIRST_SEEN"),
        "last_event_timestamp": sample.get("LAST_SEEN"),
        "applicable_exclusions": [],
        "details": {"legacy_bundle": True},
    }


def _employee_record(employee_details: dict, user_id: str) -> dict:
    raw = employee_details.get(user_id) or employee_details.get(str(user_id).upper()) or {}
    if not isinstance(raw, dict):
        raw = {}
    aliases = {
        "full_name": ("full_name", "nomeUsuario", "nomeFuncionario", "Nome"),
        "registration": ("registration", "numeroMatriculaUsuario", "Matrícula"),
        "uor": ("uor", "codigoUnidadeOrganizacionalDependenciaUsuario", "Unidade Organizacional"),
        "organizational_hierarchy": ("organizational_hierarchy", "Hierarquia Organizacional"),
        "department": ("department", "Departamento"),
        "unit": ("unit", "Unidade"),
        "workplace": ("workplace", "nomeDependenciaLotacao", "Local de Trabalho"),
        "position": ("position", "nomeFuncaoLotacao", "Cargo"),
        "function": ("function", "Função", "codigoComissaoUsuario"),
        "prefix": ("prefix", "codigoPrefixoDependenciaAtual", "Prefixo Dependência"),
        "user_type": ("user_type", "codigoTipoUsuario", "Tipo Usuário"),
    }
    out = {}
    for target, candidates in aliases.items():
        out[target] = next((raw[key] for key in candidates if key in raw and not _missing(raw[key])), None)
    out.update(classify_uor(out["uor"]))
    accepted_source_fields = {
        key for candidates in aliases.values() for key in candidates if key in raw
    }
    out["source_fields"] = sorted(accepted_source_fields)
    return out


def _validate_bundle(bundle: dict) -> None:
    if not isinstance(bundle, dict):
        raise ValueError("Bundle de backtesting deve ser um objeto JSON.")
    try:
        bundle_version = int(bundle.get("bundle_version") or 0)
    except (TypeError, ValueError):
        raise ValueError("Bundle inválido: 'bundle_version' deve ser um inteiro.")
    if bundle_version < 2:
        raise ValueError(
            "Bundle legado incompatível: execute novamente o backtest para gerar a versão 2."
        )
    if not isinstance(bundle.get("summary"), dict):
        raise ValueError("Bundle inválido: estrutura 'summary' ausente.")
    cases = bundle["summary"].get("cases")
    if not isinstance(cases, list):
        raise ValueError("Bundle inválido: 'summary.cases' deve ser uma lista.")


def _execution_metadata(bundle: dict, params: dict) -> dict:
    """Metadados de execução, sempre derivados do bundle publicado."""
    execution = dict(bundle.get("execution") or {})
    period = dict(execution.get("period") or params.get("period") or {})
    start_date = period.get("start_date") or str(params.get("start") or "")[:10] or None
    end_inclusive = period.get("end_date_inclusive")
    if not end_inclusive and params.get("end"):
        # A janela técnica é semiaberta: o último dia inclusivo é o dia anterior
        # à meia-noite final.
        try:
            end_exclusive = datetime.fromisoformat(str(params["end"]).replace(" ", "T"))
            end_inclusive = (end_exclusive - timedelta(seconds=1)).date().isoformat()
        except ValueError:
            end_inclusive = None
    return {
        "job_id": execution.get("job_id"),
        "trigger_type": execution.get("trigger"),
        "trigger_label": execution.get("trigger_label"),
        "attempt": execution.get("attempt"),
        "worker": execution.get("worker"),
        "configuration_hash": execution.get("config_hash") or params.get("configuration_hash"),
        "period_start_date": start_date,
        "period_end_inclusive": end_inclusive,
        "total_calendar_days": period.get("total_calendar_days"),
        "cutoff_mode": period.get("cutoff_mode"),
        "data_cutoff": period.get("data_cutoff") or params.get("end"),
        "data_cutoff_description": period.get("data_cutoff_description"),
        "boundary_semantics": period.get("boundary_semantics") or (
            "início inclusivo e fim exclusivo no processamento; a interface por "
            "data inclui ambos os dias"
        ),
        "worker_limits": execution.get("worker_limits") or {},
        "schedule": execution.get("schedule") or {},
    }


def _build_timeline(occurrences: list[dict], user_alert_map: dict) -> list[dict]:
    """Cronologia consolidada e determinística de todas as evidências."""
    entries = []
    for occurrence in occurrences:
        for evidence in occurrence.get("evidence_records") or []:
            user = (
                evidence.get("user_id") or evidence.get("USER_KEY")
                or occurrence.get("user_id")
            )
            timestamp = str(
                evidence.get("timestamp") or evidence.get("EVENT_TS")
                or evidence.get("VPN_TS") or ""
            )
            alert = user_alert_map.get(str(user)) if user else None
            entries.append({
                "timestamp": timestamp or None,
                "local_date": evidence.get("local_date") or occurrence.get("local_date"),
                "rule_id": occurrence["rule_id"],
                "occurrence_id": occurrence["occurrence_id"],
                "user_id": user,
                "device_id": (
                    evidence.get("device_id") or evidence.get("DEVICE_ID")
                    or occurrence.get("device_id")
                ),
                "event_id": evidence.get("event_id") or evidence.get("EVENT_ID"),
                "source_ip": evidence.get("source_ip") or evidence.get("SOURCE_IP"),
                "corporate_ip": (
                    evidence.get("corporate_ip") or evidence.get("CORPORATE_IP")
                    or evidence.get("VPN_CPTV_IP")
                ),
                "uor_alert_label": (alert or {}).get("uor_alert_label") or UOR_ALERTS["GRAY_UNKNOWN_UOR"]["label"],
            })
    entries.sort(
        key=lambda item: (
            str(item["timestamp"] or ""),
            str(item["occurrence_id"]),
            str(item["event_id"] or ""),
        )
    )
    return entries


def _cross_rule_consolidations(occurrences: list[dict], user_alert_map: dict) -> list[dict]:
    """Agrupa ocorrências de regras diferentes que compartilham evidência.

    O agrupamento usa a interseção de identificadores de evento e a mesma
    entidade (usuário ou dispositivo). Ocorrências sem evidência comum
    permanecem separadas: nada é fundido por coincidência de data.
    """
    groups: list[dict] = []
    for occurrence in occurrences:
        events = {str(item) for item in occurrence.get("supporting_event_identifiers") or []}
        entities = set(occurrence.get("associated_users") or [])
        entities.update(occurrence.get("associated_devices") or [])
        target = None
        for group in groups:
            if events and (events & group["events"]) and (entities & group["entities"]):
                target = group
                break
        if target is None:
            groups.append({
                "events": set(events),
                "entities": set(entities),
                "occurrence_ids": [occurrence["occurrence_id"]],
                "rules": {occurrence["rule_id"]},
            })
            continue
        target["events"].update(events)
        target["entities"].update(entities)
        target["occurrence_ids"].append(occurrence["occurrence_id"])
        target["rules"].add(occurrence["rule_id"])
    out = []
    for group in groups:
        if len(group["rules"]) < 2:
            continue
        entities = sorted(group["entities"])
        out.append({
            "consolidation_id": "CONS-{0}".format(
                hashlib.sha256(
                    "|".join(sorted(group["occurrence_ids"])).encode("utf-8")
                ).hexdigest()[:16].upper()
            ),
            "entities": entities,
            "rules": sorted(group["rules"], key=lambda item: (len(item), item)),
            "occurrence_ids": sorted(group["occurrence_ids"]),
            "occurrence_count": len(set(group["occurrence_ids"])),
            "shared_event_identifiers": sorted(group["events"]),
            "uor_alert_labels": sorted({
                (user_alert_map.get(entity) or {}).get("uor_alert_label")
                for entity in entities
                if user_alert_map.get(entity)
            }),
        })
    out.sort(key=lambda item: item["consolidation_id"])
    return out


def build_report_model(bundle: dict, application_version: str, employee_details: dict | None = None) -> dict:
    """Constrói o único modelo usado por LaTeX, XLSX e pacote CSV."""
    _validate_bundle(bundle)
    params = _scrub_sensitive(dict(bundle.get("parameters") or {}))
    employees_source = dict(employee_details or bundle.get("employee_details") or {})
    occurrences = []
    for case in bundle["summary"].get("cases") or []:
        if not isinstance(case, dict):
            raise ValueError("Bundle inválido: cada caso deve ser um objeto.")
        rule_id = _case_rule_id(case)
        if not rule_id or rule_id not in _RULE_META:
            continue
        case_occurrences = case.get("occurrences")
        if case_occurrences is None:
            case_occurrences = [
                _fallback_occurrence(case, rule_id, sample, index)
                for index, sample in enumerate(case.get("sample") or [])
                if isinstance(sample, dict)
            ]
        if not isinstance(case_occurrences, list):
            raise ValueError("Bundle inválido: occurrences de {0} deve ser uma lista.".format(rule_id))
        for occurrence in case_occurrences:
            if not isinstance(occurrence, dict):
                raise ValueError("Bundle inválido: ocorrência de {0} deve ser um objeto.".format(rule_id))
            normalized = dict(occurrence)
            normalized.setdefault("rule_id", rule_id)
            title, version, severity = _RULE_META[rule_id]
            normalized.setdefault("rule_title", title)
            normalized.setdefault("rule_version", version)
            normalized.setdefault("severity", severity)
            normalized.setdefault("evidence_records", [])
            normalized.setdefault("supporting_event_identifiers", [])
            normalized.setdefault("relevant_ips", [])
            normalized.setdefault("relevant_devices", [])
            normalized.setdefault("relevant_sessions", [])
            normalized.setdefault("applicable_exclusions", [])
            normalized.setdefault("details", {})
            normalized["evidence_records"] = _scrub_sensitive(normalized["evidence_records"])
            normalized["details"] = _scrub_sensitive(normalized["details"])
            if not normalized.get("occurrence_id"):
                raise ValueError("Bundle inválido: ocorrência sem occurrence_id em {0}.".format(rule_id))
            occurrences.append(normalized)
    by_id = {}
    for occurrence in occurrences:
        occurrence_id = str(occurrence["occurrence_id"])
        if occurrence_id in by_id and by_id[occurrence_id] != occurrence:
            raise ValueError("Bundle inválido: occurrence_id duplicado com conteúdo divergente: {0}".format(occurrence_id))
        by_id[occurrence_id] = occurrence
    occurrences = sorted(
        by_id.values(),
        key=lambda item: (
            int(str(item["rule_id"])[1:]) if str(item["rule_id"])[1:].isdigit() else 999,
            str(item.get("window_start") or ""),
            str(item["occurrence_id"]),
        ),
    )

    user_occurrences = defaultdict(list)
    device_occurrences = defaultdict(list)
    for occurrence in occurrences:
        users = set()
        if occurrence.get("user_id"):
            users.add(str(occurrence["user_id"]))
        users.update(str(item) for item in (occurrence.get("details") or {}).get("users") or [] if item)
        occurrence["associated_users"] = sorted(users)
        for user in users:
            user_occurrences[user].append(occurrence)
        devices = set(str(item) for item in occurrence.get("relevant_devices") or [] if item)
        if occurrence.get("device_id"):
            devices.add(str(occurrence["device_id"]))
        occurrence["associated_devices"] = sorted(devices)
        for device in devices:
            device_occurrences[device].append(occurrence)

    # Os totais executivos refletem toda a execução. Os formatos destinados à
    # leitura humana recebem somente os casos prioritários, evitando dossiês
    # intragáveis sem destruir a fonte completa preservada no bundle.
    all_occurrences = occurrences
    full_rule_counts = Counter(item["rule_id"] for item in all_occurrences)
    full_severity_counts = Counter(
        str(item.get("severity") or "Não informado") for item in all_occurrences
    )
    full_users = {
        user
        for occurrence in all_occurrences
        for user in occurrence.get("associated_users") or []
    }
    full_devices = {
        device
        for occurrence in all_occurrences
        for device in occurrence.get("associated_devices") or []
    }
    full_user_profiles = {
        user: _employee_record(employees_source, user)
        for user in sorted(full_users)
    }
    full_uor_counts = Counter(
        profile["uor_alert_code"] for profile in full_user_profiles.values()
    )
    full_rules_by_user = defaultdict(set)
    for occurrence in all_occurrences:
        for user in occurrence.get("associated_users") or []:
            full_rules_by_user[user].add(occurrence["rule_id"])
    full_multirule_user_count = sum(
        1 for rules in full_rules_by_user.values() if len(rules) > 1
    )
    presented_by_rule = Counter(
        item["rule_id"]
        for item in select_top_occurrences_by_rule(all_occurrences)
    )
    occurrences = select_top_occurrences_by_rule(all_occurrences)
    user_occurrences = defaultdict(list)
    device_occurrences = defaultdict(list)
    for occurrence in occurrences:
        for user in occurrence.get("associated_users") or []:
            user_occurrences[user].append(occurrence)
        for device in occurrence.get("associated_devices") or []:
            device_occurrences[device].append(occurrence)

    users = []
    for user_id, items in sorted(user_occurrences.items()):
        employee = _employee_record(employees_source, user_id)
        profile = {
            "user_id": user_id,
            **employee,
            "rules_triggered": sorted({item["rule_id"] for item in items}),
            "severities": sorted({item.get("severity") or "Não informado" for item in items}),
            "occurrence_count": len({item["occurrence_id"] for item in items}),
            "devices": sorted({device for item in items for device in item.get("associated_devices") or []}),
            "ips": sorted({ip for item in items for ip in item.get("relevant_ips") or [] if ip}),
            "first_timestamp": min((str(item.get("first_event_timestamp")) for item in items if item.get("first_event_timestamp")), default=None),
            "last_timestamp": max((str(item.get("last_event_timestamp")) for item in items if item.get("last_event_timestamp")), default=None),
            "supporting_event_identifiers": sorted({event for item in items for event in item.get("supporting_event_identifiers") or []}),
        }
        users.append(profile)

    user_alert_map = {item["user_id"]: item for item in users}
    for occurrence in occurrences:
        associated_alerts = [
            {
                "user_id": user,
                "uor_alert_code": user_alert_map[user]["uor_alert_code"],
                "uor_alert_label": user_alert_map[user]["uor_alert_label"],
            }
            for user in occurrence["associated_users"] if user in user_alert_map
        ]
        occurrence["uor_alerts"] = associated_alerts
        if len(associated_alerts) == 1:
            occurrence.update(associated_alerts[0])
        elif not associated_alerts:
            occurrence.update(classify_uor(None))
        else:
            occurrence["uor_alert_code"] = "MULTIPLE"
            occurrence["uor_alert_label"] = "; ".join(
                "{0}: {1}".format(item["user_id"], item["uor_alert_label"])
                for item in associated_alerts
            )

    devices = []
    for device_id, items in sorted(device_occurrences.items()):
        users_for_device = sorted({user for item in items for user in item.get("associated_users") or []})
        usage_events = defaultdict(dict)
        for item in items:
            if item.get("rule_id") != "R7":
                continue
            for evidence in item.get("evidence_records") or []:
                event_device = evidence.get("device_id") or evidence.get("DEVICE_ID")
                user = evidence.get("user_id") or evidence.get("USER_KEY")
                if not user or (event_device and str(event_device) != device_id):
                    continue
                stable_event = (
                    evidence.get("event_id") or evidence.get("EVENT_ID")
                    or hashlib.sha256(
                        json.dumps(evidence, sort_keys=True, default=str).encode("utf-8")
                    ).hexdigest()[:20]
                )
                usage_events[str(user)][str(stable_event)] = evidence
        # A regra R7 já calcula ``details.per_user`` com primeiro/último uso,
        # volume e IPs. Preferimos esse cálculo e usamos a reconstrução a partir
        # das evidências apenas como complemento, para não perder informação
        # quando a ocorrência é mais rica que os registros de evidência.
        rule_per_user: dict = {}
        for item in items:
            if item.get("rule_id") != "R7":
                continue
            for user, payload in ((item.get("details") or {}).get("per_user") or {}).items():
                if isinstance(payload, dict):
                    rule_per_user.setdefault(str(user), dict(payload))
        per_user_usage = {
            user: {
                "first_use": min(
                    (str(event.get("timestamp") or event.get("EVENT_TS")) for event in events.values()
                     if event.get("timestamp") or event.get("EVENT_TS")),
                    default=None,
                ),
                "last_use": max(
                    (str(event.get("timestamp") or event.get("EVENT_TS")) for event in events.values()
                     if event.get("timestamp") or event.get("EVENT_TS")),
                    default=None,
                ),
                "event_count": len(events),
                "source_ips": sorted({
                    event.get("source_ip") or event.get("SOURCE_IP")
                    for event in events.values()
                    if event.get("source_ip") or event.get("SOURCE_IP")
                }),
                "corporate_tunnel_ips": sorted({
                    event.get("corporate_ip") or event.get("CORPORATE_IP")
                    for event in events.values()
                    if event.get("corporate_ip") or event.get("CORPORATE_IP")
                }),
            }
            for user, events in sorted(usage_events.items())
        }
        for user, payload in sorted(rule_per_user.items()):
            merged = dict(payload)
            reconstructed = per_user_usage.get(user) or {}
            for key in ("first_use", "last_use", "event_count", "source_ips", "corporate_tunnel_ips"):
                if _missing(merged.get(key)) and not _missing(reconstructed.get(key)):
                    merged[key] = reconstructed[key]
            merged.setdefault("first_use", None)
            merged.setdefault("last_use", None)
            merged.setdefault("event_count", reconstructed.get("event_count", 0))
            merged.setdefault("source_ips", [])
            merged.setdefault("corporate_tunnel_ips", [])
            per_user_usage[user] = merged
        per_user_usage = {user: per_user_usage[user] for user in sorted(per_user_usage)}
        devices.append({
            "device_id": device_id,
            "classification": "Não informado",
            "description": "Não informado",
            "first_timestamp": min((str(item.get("first_event_timestamp")) for item in items if item.get("first_event_timestamp")), default=None),
            "last_timestamp": max((str(item.get("last_event_timestamp")) for item in items if item.get("last_event_timestamp")), default=None),
            "distinct_users": len(users_for_device),
            "associated_users": users_for_device,
            "associated_uors": sorted({user_alert_map[user]["uor"] for user in users_for_device if user in user_alert_map and user_alert_map[user]["uor"]}),
            "associated_uor_alerts": [
                {
                    "user_id": user,
                    "uor_alert_code": user_alert_map[user]["uor_alert_code"],
                    "uor_alert_label": user_alert_map[user]["uor_alert_label"],
                }
                for user in users_for_device if user in user_alert_map
            ],
            "per_user_usage": per_user_usage,
            "associated_functions": sorted({user_alert_map[user]["function"] for user in users_for_device if user in user_alert_map and user_alert_map[user]["function"]}),
            "relevant_ips": sorted({ip for item in items for ip in item.get("relevant_ips") or []}),
            "relevant_sessions": sorted({session for item in items for session in item.get("relevant_sessions") or []}),
            "same_day_association": any((item.get("details") or {}).get("same_day_association") for item in items),
            "seven_day_association": any((item.get("details") or {}).get("seven_day_association") for item in items),
            "thirty_day_association": any((item.get("details") or {}).get("thirty_day_association") for item in items),
            "concurrent_or_overlapping": "Não determinável sem timestamps de início/fim de sessão",
            "allowlist_classification": "Não incluído na allowlist aplicada",
            "rules_triggered": sorted({item["rule_id"] for item in items}),
            "supporting_event_identifiers": sorted({event for item in items for event in item.get("supporting_event_identifiers") or []}),
        })

    enabled_rules = [str(item) for item in params.get("enabled_rules") or sorted({item["rule_id"] for item in occurrences})]
    catalog = []
    rule_counts = full_rule_counts
    severity_counts = full_severity_counts
    per_rule_uor = {}
    for rule_id in enabled_rules:
        title, version, severity = _RULE_META.get(rule_id, ("Não informado", "Não informado", "Não informado"))
        guide = RULE_GUIDE.get(rule_id, {})
        catalog.append({
            "rule_id": rule_id,
            "title": title,
            "version": version,
            "severity": severity,
            "parameters": (params.get("rule_parameters") or {}),
            "finding_count": rule_counts[rule_id],
            "question": guide.get("question", "Não informado"),
            "condition": guide.get("condition", "Não informado"),
            "grouping": guide.get("grouping", "Não informado"),
            "legitimate_causes": guide.get("legitimate", "Não informado"),
            "limitation": guide.get("limitation", "Não informado"),
            "flagged_users": len({
                user
                for occurrence in all_occurrences if occurrence["rule_id"] == rule_id
                for user in occurrence.get("associated_users") or []
            }),
            "flagged_devices": len({
                device
                for occurrence in all_occurrences if occurrence["rule_id"] == rule_id
                for device in occurrence.get("associated_devices") or []
            }),
        })
        per_rule_uor[rule_id] = dict(Counter(
            full_user_profiles[user]["uor_alert_code"]
            for occurrence in all_occurrences if occurrence["rule_id"] == rule_id
            for user in occurrence.get("associated_users") or []
            if user in full_user_profiles
        ))

    multirule_users = [
        user for user in users if len(user["rules_triggered"]) > 1
    ]
    execution = _execution_metadata(bundle, params)
    timeline = _build_timeline(occurrences, user_alert_map)
    consolidations = _cross_rule_consolidations(occurrences, user_alert_map)
    report_seed = json.dumps(
        {
            "generated_at": bundle.get("generated_at"),
            "period": [params.get("start"), params.get("end")],
            "job_id": execution.get("job_id"),
            "config_hash": execution.get("configuration_hash"),
            "occurrences": [item["occurrence_id"] for item in all_occurrences],
        },
        sort_keys=True,
    )
    report_id = "BT-{0}".format(hashlib.sha256(report_seed.encode("utf-8")).hexdigest()[:16].upper())
    metrics = (bundle.get("summary") or {}).get("metrics") or {}
    rule_versions = {
        item["rule_id"]: item["version"] for item in catalog
    }
    model = {
        "schema_version": 2,
        "report": {
            "report_id": report_id,
            "title": "Dossiê de Backtesting de Acessos VPN",
            "classification": "INFORMAÇÃO INTERNA — ACESSO RESTRITO",
            "application_version": application_version,
            # Não introduz relógio do gerador quando o bundle é incompleto:
            # entrada equivalente deve resultar no mesmo modelo.
            "generation_timestamp": bundle.get("generated_at"),
            "period_start": params.get("start"),
            "period_end_exclusive": params.get("end"),
            "period_start_date": execution.get("period_start_date"),
            "period_end_inclusive": execution.get("period_end_inclusive"),
            "total_calendar_days": execution.get("total_calendar_days"),
            "period_semantics": execution.get("boundary_semantics"),
            "data_cutoff": execution.get("data_cutoff"),
            "data_cutoff_mode": execution.get("cutoff_mode"),
            "data_cutoff_description": execution.get("data_cutoff_description"),
            "job_id": execution.get("job_id"),
            "trigger_type": execution.get("trigger_type"),
            "trigger_label": execution.get("trigger_label"),
            "execution_attempt": execution.get("attempt"),
            "configuration_hash": execution.get("configuration_hash"),
            "rule_versions": rule_versions,
            "timezone": params.get("timezone") or APP_TIMEZONE,
            "safe_fixture": bool(bundle.get("safe_fixture")),
            "csv_package_directory": "detalhamento_csv",
        },
        "execution": execution,
        "parameters": params,
        "enabled_rules": enabled_rules,
        "rule_catalog": sorted(catalog, key=lambda item: int(item["rule_id"][1:])),
        "executive": {
            "total_database_rows": int(metrics.get("database_rows_analyzed") or metrics.get("total_events_analyzed") or 0),
            "total_analyzed_events": int(metrics.get("deduplicated_events_analyzed") or metrics.get("total_events_analyzed") or 0),
            "total_analyzed_users": int(metrics.get("total_users_analyzed") or 0),
            "total_analyzed_devices": int(metrics.get("total_devices_analyzed") or 0),
            "flagged_users": len(full_users),
            "flagged_devices": len(full_devices),
            "total_occurrences": len(all_occurrences),
            "presented_occurrences": len(occurrences),
            "omitted_occurrences": len(all_occurrences) - len(occurrences),
            "presented_by_rule": dict(sorted(presented_by_rule.items())),
            "multirule_users": full_multirule_user_count,
            "findings_by_rule": dict(sorted(rule_counts.items())),
            "findings_by_severity": dict(sorted(severity_counts.items())),
            "uor_alert_user_totals": {
                code: full_uor_counts.get(code, 0) for code in UOR_ALERTS
            },
            "findings_by_rule_and_uor": per_rule_uor,
        },
        "users": users,
        "devices": devices,
        "occurrences": occurrences,
        "multirule_users": multirule_users,
        "cross_rule_consolidations": consolidations,
        "timeline": timeline,
        "cross_rule_findings": bundle.get("cross_rule") or {},
        "methodology": [
            "Resultados são sinais automatizados para revisão humana, não prova de irregularidade.",
            "Linhas idênticas de AUT_CPTV são deduplicadas pela tupla usuário, timestamp, IP de origem, IP corporativo/túnel, hostname e dispositivo.",
            "R1 e R4 reiniciam a agregação no início de cada dia local America/Sao_Paulo.",
            "A classificação visual de UOR é organizacional e independente da severidade da regra.",
            "O período informado usa duas datas locais inclusivas; o processamento aplica a janela técnica semiaberta [início, fim).",
            "O corte de dados registrado indica exatamente até onde a leitura da fonte foi considerada nesta execução.",
            "Ocorrências de regras diferentes só são consolidadas quando compartilham identificadores de evento e a mesma entidade.",
        ],
        "reading_guide": [
            "Comece pelo Resumo Executivo: ele traz os totais que orientam a priorização.",
            "Os detalhamentos exibem no máximo 10 ocorrências prioritárias por regra; os totais executivos abrangem todos os achados da execução.",
            "Use os identificadores de ocorrência (por exemplo, R1-…) para localizar a mesma evidência no dossiê, na planilha e nos CSV.",
            "Severidade descreve a anomalia detectada pela regra; o Alerta UOR descreve a unidade organizacional. São dimensões independentes.",
            "Cada seção de regra apresenta primeiro o resumo da regra e só depois os achados detalhados.",
            "“Não informado” significa dado ausente, vazio, malformado ou não determinado com confiabilidade — nunca um valor presumido.",
            "Um alerta é um caso para análise humana. Ele não comprova irregularidade, fraude ou má conduta.",
        ],
        "human_review_guidance": [
            "Confirme o contexto operacional do período com a área responsável antes de qualquer conclusão.",
            "Verifique as causas legítimas comuns listadas em cada regra.",
            "Registre a conclusão da análise fora deste documento, no processo formal aplicável.",
        ],
        "presentation": {
            "occurrence_limit_per_rule": REPORT_OCCURRENCE_LIMIT,
            "selection_method": (
                "prioridade determinística por severidade, magnitude do valor "
                "acionador, volume de evidência, abrangência e identificador"
            ),
            "source_of_complete_results": (
                "bundle JSON original da execução, preservado fora dos formatos "
                "de leitura rápida"
            ),
        },
        "limitations": list(bundle.get("limitations") or []),
        "data_quality": metrics.get("data_quality") or {},
        "missing_data_indicators": {
            "users_without_employee_details": sum(
                1 for profile in full_user_profiles.values()
                if not profile["source_fields"]
            ),
            "users_without_determined_uor": full_uor_counts.get("GRAY_UNKNOWN_UOR", 0),
            "occurrences_without_evidence_records": sum(
                1 for item in occurrences if not item.get("evidence_records")
            ),
            "occurrences_without_local_date": sum(
                1 for item in occurrences if _missing(item.get("local_date"))
            ),
        },
        "allowlist_effects": params.get("allowlist_effects") or {},
        "uor_alert_legend": [
            {"code": code, **payload} for code, payload in UOR_ALERTS.items()
        ],
    }
    model["executive"]["cross_rule_consolidations"] = len(consolidations)
    model["executive"]["timeline_entries"] = len(timeline)
    return model


def safe_fixture_bundle() -> dict:
    """Fixture sintética, sem dados de pessoas reais, para validação offline."""
    def occurrence(rule, suffix, user, device, day, severity, value, details=None):
        event_id = "EVT-FIX-{0}".format(suffix)
        source_ip = "192.0.2.{0}".format(int(suffix[-1]) + 1)
        return {
            "occurrence_id": "{0}-FIX-{1}".format(rule, suffix),
            "rule_id": rule,
            "rule_title": _RULE_META[rule][0],
            "rule_version": _RULE_META[rule][1],
            "severity": severity,
            "user_id": user,
            "device_id": device,
            "local_date": day,
            "window_start": day + "T09:00:00-03:00",
            "window_end": day + "T10:00:00-03:00",
            "triggering_value": value,
            "configured_threshold": {"fixture": True},
            "explanation": "Ocorrência sintética criada exclusivamente para testar os geradores.",
            "supporting_event_identifiers": [event_id],
            "evidence_records": [{
                "event_id": event_id,
                "timestamp": day + "T09:00:00-03:00",
                "local_date": day,
                "user_id": user,
                "device_id": device,
                "source_ip": source_ip,
                "source_ip_classification": "não determinada (faixas não configuradas)",
                "corporate_ip": "10.0.0.9",
                "corporate_ip_classification": "não determinada (faixas não configuradas)",
                "hostname": "EST-FIXTURE-{0}".format(suffix),
                "session_id": None,
                "authentication_id": None,
            }],
            "relevant_ips": [source_ip],
            "relevant_devices": [device],
            "relevant_sessions": [],
            "deduplication_key": "fixture|" + suffix,
            "deduplication_method": "fixture sintética",
            "first_event_timestamp": day + "T09:00:00-03:00",
            "last_event_timestamp": day + "T10:00:00-03:00",
            "applicable_exclusions": [],
            "details": details or {},
        }

    r1 = occurrence(
        "R1", "01", "T0000001", "DEV-A", "2026-06-27", "MÉDIA",
        {"source_ip_count": 2, "corporate_ip_count": 1},
        {
            "distinct_source_ips": ["192.0.2.2", "198.51.100.7"],
            "distinct_corporate_ips": ["10.0.0.9"],
            "ip_sequence": [
                {
                    "timestamp": "2026-06-27T09:00:00-03:00", "source_ip": "192.0.2.2",
                    "corporate_ip": "10.0.0.9", "source_classification": "não determinada",
                    "corporate_classification": "não determinada", "event_id": "EVT-FIX-01",
                },
                {
                    "timestamp": "2026-06-27T10:00:00-03:00", "source_ip": "198.51.100.7",
                    "corporate_ip": "10.0.0.9", "source_classification": "não determinada",
                    "corporate_classification": "não determinada", "event_id": "EVT-FIX-01B",
                },
            ],
        },
    )
    r4 = occurrence(
        "R4", "02", "T0000002", "DEV-B", "2026-07-11", "MÉDIA", 3,
        {
            "login_timestamps": [
                "2026-07-11T09:00:00-03:00",
                "2026-07-11T09:40:00-03:00",
                "2026-07-11T10:00:00-03:00",
            ]
        },
    )
    r7 = occurrence(
        "R7", "03", None, "DEV-SHARED", "2026-07-12", "ALTA",
        {"distinct_users": 2, "horizon": "MESMO_DIA"},
        {
            "users": ["T0000001", "T0000003"],
            "same_day_association": True,
            "seven_day_association": True,
            "thirty_day_association": True,
            "per_user": {
                "T0000001": {
                    "first_use": "2026-07-12T09:00:00-03:00",
                    "last_use": "2026-07-12T09:30:00-03:00",
                    "event_count": 2, "source_ips": ["192.0.2.4"],
                    "corporate_tunnel_ips": ["10.0.0.9"],
                },
                "T0000003": {
                    "first_use": "2026-07-12T14:00:00-03:00",
                    "last_use": "2026-07-12T14:10:00-03:00",
                    "event_count": 1, "source_ips": ["192.0.2.5"],
                    "corporate_tunnel_ips": [],
                },
            },
        },
    )
    # Mesmo usuário-dia sinalizado por R1 e R4 sobre os mesmos eventos
    # deduplicados: exercita consolidação entre regras e usuário multirregra.
    r1_shared = occurrence(
        "R1", "04", "T0000002", "DEV-B", "2026-07-11", "MÉDIA",
        {"source_ip_count": 2, "corporate_ip_count": 1},
        {
            "distinct_source_ips": ["192.0.2.5", "198.51.100.9"],
            "distinct_corporate_ips": ["10.0.0.9"],
            "ip_sequence": [
                {
                    "timestamp": "2026-07-11T09:00:00-03:00", "source_ip": "192.0.2.5",
                    "corporate_ip": "10.0.0.9", "source_classification": "não determinada",
                    "corporate_classification": "não determinada", "event_id": "EVT-FIX-02",
                },
                {
                    "timestamp": "2026-07-11T10:00:00-03:00", "source_ip": "198.51.100.9",
                    "corporate_ip": "10.0.0.9", "source_classification": "não determinada",
                    "corporate_classification": "não determinada", "event_id": "EVT-FIX-02B",
                },
            ],
        },
    )
    r1_shared["supporting_event_identifiers"] = ["EVT-FIX-02"]
    r1_shared["evidence_records"] = [{
        "event_id": "EVT-FIX-02",
        "timestamp": "2026-07-11T09:00:00-03:00",
        "user_id": "T0000002",
        "device_id": "DEV-B",
        "local_date": "2026-07-11",
        "source_ip": "192.0.2.5",
        "corporate_ip": "10.0.0.9",
    }]
    cases = [
        {"name": "ips_distintos_acima_do_limite", "rule_id": "R1", "status": "ok", "count": 2, "sample": [], "occurrences": [r1, r1_shared]},
        {"name": "logins_diarios_acima_do_limite", "rule_id": "R4", "status": "ok", "count": 1, "sample": [], "occurrences": [r4]},
        {"name": "dispositivo_multiplos_usuarios", "rule_id": "R7", "status": "ok", "count": 1, "sample": [], "occurrences": [r7]},
    ]
    return {
        "bundle_version": 2,
        "safe_fixture": True,
        "generated_at": "2026-07-29T12:00:00-03:00",
        "execution": {
            "job_id": "bt-fixture0000000000000000000000000000000",
            "trigger": "manual",
            "trigger_label": "Execução parametrizada por pessoa autorizada",
            "attempt": 1,
            "worker": "fixture-worker",
            "config_hash": "0" * 64,
            "worker_limits": {"rule_workers": 1, "report_workers": 1, "db2_pool_limit": 1},
            "schedule": {"schedule_enabled": False},
            "period": {
                "start_date": "2026-06-27",
                "end_date_inclusive": "2026-07-29",
                "start": "2026-06-27 00:00:00",
                "end_exclusive": "2026-07-30 00:00:00",
                "timezone": APP_TIMEZONE,
                "total_calendar_days": 33,
                "boundary_semantics": (
                    "datas inclusivas na interface; janela técnica [início, fim) no "
                    "processamento"
                ),
                "cutoff_mode": "current_day",
                "data_cutoff": "2026-07-30 00:00:00",
                "data_cutoff_description": (
                    "dia local corrente, que pode estar parcial no momento da execução"
                ),
            },
        },
        "parameters": {
            "start": "2026-06-27 00:00:00",
            "end": "2026-07-30 00:00:00",
            "timezone": APP_TIMEZONE,
            "enabled_rules": ["R1", "R4", "R7"],
            "rule_parameters": {"r1_min_distinct_ips": 2, "r4_vpn_login_limit": 2, "device_windows_days": [1, 7, 30]},
            "allowlist_effects": {"shared_device_entries": 0, "excluded_user_entries": 0},
        },
        "summary": {
            "metrics": {
                "database_rows_analyzed": 12,
                "deduplicated_events_analyzed": 10,
                "total_users_analyzed": 3,
                "total_devices_analyzed": 3,
                "data_quality": {"duplicate_rows": 2},
            },
            "cases": cases,
        },
        "employee_details": {
            "T0000001": {"nomeUsuario": "Pessoa de Teste Amarela", "codigoUnidadeOrganizacionalDependenciaUsuario": " 20259 ", "codigoTipoUsuario": "TESTE"},
            "T0000002": {"nomeUsuario": "Pessoa de Teste Vermelha", "codigoUnidadeOrganizacionalDependenciaUsuario": 12345, "codigoTipoUsuario": "TESTE"},
            "T0000003": {"nomeUsuario": "Pessoa de Teste Sem UOR", "codigoUnidadeOrganizacionalDependenciaUsuario": None, "codigoTipoUsuario": "TESTE"},
        },
        "cross_rule": {},
        "limitations": ["Fixture sintética: não representa pessoas, eventos ou resultados internos reais."],
    }
