"""Estado durável compartilhado dos jobs de backtesting.

Motivação
---------
A aplicação roda com ``hpa.minReplicas: 2`` no chart, portanto **vários pods**
podem tentar iniciar o backtest padrão, disparar o agendamento de 24 h ou
consultar o status. Um temporizador em memória, um booleano de processo, um
lock de arquivo local ou um ``threading.Lock`` **não** coordenam pods
distintos. Este módulo define a abstração e duas implementações:

* :class:`InMemoryJobStore` — só para desenvolvimento e testes. Declara
  ``cluster_safe = False`` e é rejeitada pelo agendador quando a aplicação
  está configurada para vários pods.
* :class:`MongoJobStore` — usa o MongoDB já provisionado para auditoria
  (``MONGODB_AUDIT_URI``). Oferece reserva atômica (``find_one_and_update``),
  unicidade por chave de idempotência (``_id``), *lease* com expiração,
  *heartbeat*, retomada de lease expirado, token de *fencing* e marca d'água
  (*watermark*) de publicação.

Garantias
---------
* **Efeito exatamente-uma-vez por idempotência**: a chave lógica é
  ``_id``; um segundo ``enqueue`` do mesmo período/regras/configuração não
  cria um novo job.
* **Reserva atômica**: apenas um worker recebe o documento em ``RUNNING``.
* **Fencing**: cada reserva incrementa ``fence``. A publicação só é aceita
  quando o ``fence`` do worker ainda é o vigente, de modo que um worker
  antigo não sobrescreve um resultado mais novo.
* **Recuperação**: um lease expirado pode ser retomado por outro pod, com
  ``attempt`` incrementado e limite de tentativas.
* **O último resultado bem-sucedido nunca é apagado por uma falha**: os
  campos ``last_successful_*`` só são escritos após publicação validada.
"""

from __future__ import annotations

import hashlib
import json
import os
import threading
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta
from typing import Iterable, Optional

from .clock import Clock, SystemClock

# ── Estados ──────────────────────────────────────────────────────────────
STATE_QUEUED = "QUEUED"
STATE_RUNNING = "RUNNING"
STATE_SUCCEEDED = "SUCCEEDED"
STATE_FAILED_RETRYABLE = "FAILED_RETRYABLE"
STATE_FAILED_TERMINAL = "FAILED_TERMINAL"
STATE_CANCELLED = "CANCELLED"

CLAIMABLE_STATES = (STATE_QUEUED, STATE_FAILED_RETRYABLE)
ACTIVE_STATES = (STATE_QUEUED, STATE_RUNNING)
TERMINAL_STATES = (STATE_SUCCEEDED, STATE_FAILED_TERMINAL, STATE_CANCELLED)

STATE_LABELS_PT = {
    STATE_QUEUED: "Na fila",
    STATE_RUNNING: "Em execução",
    STATE_SUCCEEDED: "Concluído com sucesso",
    STATE_FAILED_RETRYABLE: "Falhou; nova tentativa prevista",
    STATE_FAILED_TERMINAL: "Falhou definitivamente",
    STATE_CANCELLED: "Cancelado",
}

# ── Gatilhos ─────────────────────────────────────────────────────────────
TRIGGER_INITIAL = "initial"
TRIGGER_SCHEDULED = "scheduled"
TRIGGER_MANUAL = "manual"
TRIGGER_RETRY = "retry"

TRIGGERS = (TRIGGER_INITIAL, TRIGGER_SCHEDULED, TRIGGER_MANUAL, TRIGGER_RETRY)

TRIGGER_LABELS_PT = {
    TRIGGER_INITIAL: "Execução inicial após implantação",
    TRIGGER_SCHEDULED: "Atualização automática de 24 horas",
    TRIGGER_MANUAL: "Execução parametrizada por pessoa autorizada",
    TRIGGER_RETRY: "Nova tentativa de uma execução anterior",
}

SCHEDULER_WATERMARK_ID = "scheduler:default"

_MONGO_DB_NAME = "telemetria"
_MONGO_COLLECTION = "BACKTEST_VPN_JOBS"


def configuration_hash(payload: dict) -> str:
    """Digest estável da configuração efetiva de uma execução."""
    normalized = json.dumps(payload or {}, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def idempotency_key(
    *,
    trigger: str,
    start_date: str,
    end_date_inclusive: str,
    timezone_name: str,
    rules: Iterable[str],
    rule_versions: dict,
    config_hash: str,
    nonce: str = "",
) -> str:
    """Chave lógica estável de um job.

    Para ``initial``/``scheduled`` a chave depende apenas do gatilho, da
    janela lógica, do fuso, das regras/versões e do hash de configuração —
    é isso que garante um único efeito quando vários pods sobem juntos.
    Execuções ``manual`` recebem um ``nonce`` porque repetir o mesmo período
    sob demanda é um pedido legítimo de dado mais recente.
    """
    if trigger not in TRIGGERS:
        raise ValueError("Gatilho desconhecido: {0}".format(trigger))
    seed = json.dumps(
        {
            "trigger": trigger,
            "start_date": str(start_date),
            "end_date_inclusive": str(end_date_inclusive),
            "timezone": str(timezone_name),
            "rules": sorted(str(rule).upper() for rule in rules),
            "rule_versions": {str(k): str(v) for k, v in sorted((rule_versions or {}).items())},
            "config_hash": str(config_hash),
            "nonce": str(nonce or ""),
        },
        ensure_ascii=False,
        sort_keys=True,
    )
    return "bt-{0}".format(hashlib.sha256(seed.encode("utf-8")).hexdigest()[:40])


@dataclass
class JobRecord:
    """Documento de um job, legível de qualquer pod."""

    job_id: str
    trigger: str
    state: str = STATE_QUEUED
    period: dict = field(default_factory=dict)
    rules: list = field(default_factory=list)
    rule_versions: dict = field(default_factory=dict)
    config_hash: str = ""
    config_snapshot: dict = field(default_factory=dict)
    application_version: str = ""
    requested_by: str = ""
    owner: Optional[str] = None
    attempt: int = 0
    max_attempts: int = 3
    fence: int = 0
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    claimed_at: Optional[str] = None
    heartbeat_at: Optional[str] = None
    lease_expires_at: Optional[str] = None
    finished_at: Optional[str] = None
    next_attempt_at: Optional[str] = None
    progress: dict = field(default_factory=dict)
    error_summary: Optional[str] = None
    report_status: dict = field(default_factory=dict)
    result_reference: dict = field(default_factory=dict)
    data_cutoff: Optional[str] = None

    def as_document(self) -> dict:
        payload = asdict(self)
        payload["_id"] = payload.pop("job_id")
        return payload

    @classmethod
    def from_document(cls, document: dict) -> "JobRecord":
        data = dict(document or {})
        data.pop("_kind", None)
        job_id = data.pop("_id", None) or data.pop("job_id", None)
        allowed = {item for item in cls.__dataclass_fields__ if item != "job_id"}
        filtered = {key: value for key, value in data.items() if key in allowed}
        return cls(job_id=str(job_id), **filtered)

    def public_view(self, *, include_config: bool = False) -> dict:
        """Visão para a UI/API: sem segredos e sem caminhos absolutos."""
        view = {
            "job_id": self.job_id,
            "trigger": self.trigger,
            "trigger_label": TRIGGER_LABELS_PT.get(self.trigger, self.trigger),
            "state": self.state,
            "state_label": STATE_LABELS_PT.get(self.state, self.state),
            "period": dict(self.period),
            "rules": list(self.rules),
            "rule_versions": dict(self.rule_versions),
            "config_hash": self.config_hash,
            "application_version": self.application_version,
            "attempt": self.attempt,
            "max_attempts": self.max_attempts,
            "owner": self.owner,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "claimed_at": self.claimed_at,
            "heartbeat_at": self.heartbeat_at,
            "lease_expires_at": self.lease_expires_at,
            "finished_at": self.finished_at,
            "next_attempt_at": self.next_attempt_at,
            "progress": dict(self.progress),
            "error_summary": self.error_summary,
            "report_status": dict(self.report_status),
            "data_cutoff": self.data_cutoff,
            "result_reference": {
                key: value
                for key, value in (self.result_reference or {}).items()
                if key in ("bundle_name", "report_id", "stamp", "published_at", "occurrences")
            },
        }
        if include_config:
            view["config_snapshot"] = dict(self.config_snapshot)
        return view


class JobStore:
    """Interface de persistência de jobs, independente de tecnologia."""

    #: ``True`` apenas quando a implementação coordena vários processos/pods.
    cluster_safe = False
    #: Nome legível usado em logs e no painel de status.
    backend_name = "abstrato"

    def enqueue(self, record: JobRecord) -> JobRecord:  # pragma: no cover - interface
        raise NotImplementedError

    def get(self, job_id: str) -> Optional[JobRecord]:  # pragma: no cover - interface
        raise NotImplementedError

    def claim(
        self, job_id: str, owner: str, *, lease_seconds: int
    ) -> Optional[JobRecord]:  # pragma: no cover - interface
        raise NotImplementedError

    def claim_next(
        self, owner: str, *, lease_seconds: int, triggers: Iterable[str] = TRIGGERS
    ) -> Optional[JobRecord]:  # pragma: no cover - interface
        raise NotImplementedError

    def heartbeat(
        self, job_id: str, owner: str, *, fence: int, lease_seconds: int, progress: dict | None = None
    ) -> bool:  # pragma: no cover - interface
        raise NotImplementedError

    def mark_succeeded(
        self, job_id: str, owner: str, *, fence: int, result_reference: dict, report_status: dict, progress: dict
    ) -> bool:  # pragma: no cover - interface
        raise NotImplementedError

    def mark_failed(
        self, job_id: str, owner: str, *, fence: int, error_summary: str, retry_delay_seconds: int = 0
    ) -> bool:  # pragma: no cover - interface
        raise NotImplementedError

    def release(self, job_id: str, owner: str, *, fence: int, reason: str) -> bool:  # pragma: no cover
        raise NotImplementedError

    def list_recent(self, limit: int = 20) -> list[JobRecord]:  # pragma: no cover - interface
        raise NotImplementedError

    def active_jobs(self) -> list[JobRecord]:  # pragma: no cover - interface
        raise NotImplementedError

    def last_successful(self) -> Optional[JobRecord]:  # pragma: no cover - interface
        raise NotImplementedError

    def read_watermark(self) -> dict:  # pragma: no cover - interface
        raise NotImplementedError

    def write_watermark(self, payload: dict) -> None:  # pragma: no cover - interface
        raise NotImplementedError


def _iso(moment: datetime) -> str:
    return moment.isoformat(timespec="seconds")


def _parse(value) -> Optional[datetime]:
    if not value:
        return None
    if isinstance(value, datetime):
        return value
    try:
        return datetime.fromisoformat(str(value))
    except ValueError:
        return None


class InMemoryJobStore(JobStore):
    """Implementação de processo único, apenas para desenvolvimento e testes.

    Coordena threads do mesmo processo, **não** pods distintos. O agendador
    recusa usá-la quando ``BACKTEST_REQUIRE_CLUSTER_STORE`` está ativo.
    """

    cluster_safe = False
    backend_name = "memória do processo (não coordena vários pods)"

    def __init__(self, clock: Clock | None = None) -> None:
        self._clock = clock or SystemClock()
        self._lock = threading.Lock()
        self._jobs: dict[str, JobRecord] = {}
        self._watermark: dict = {}

    # ── escrita ──────────────────────────────────────────────────────
    def enqueue(self, record: JobRecord) -> JobRecord:
        now = _iso(self._clock.now())
        with self._lock:
            existing = self._jobs.get(record.job_id)
            if existing is not None:
                return existing
            stored = JobRecord(**asdict(record))
            stored.state = record.state or STATE_QUEUED
            stored.created_at = record.created_at or now
            stored.updated_at = now
            self._jobs[record.job_id] = stored
            return stored

    def claim(self, job_id: str, owner: str, *, lease_seconds: int) -> Optional[JobRecord]:
        now = self._clock.now()
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None or not self._is_claimable(job, now):
                return None
            return self._apply_claim(job, owner, now, lease_seconds)

    def claim_next(
        self, owner: str, *, lease_seconds: int, triggers: Iterable[str] = TRIGGERS
    ) -> Optional[JobRecord]:
        allowed = {str(item) for item in triggers}
        now = self._clock.now()
        with self._lock:
            candidates = [
                job for job in self._jobs.values()
                if job.trigger in allowed and self._is_claimable(job, now)
            ]
            candidates.sort(key=lambda job: (job.created_at or "", job.job_id))
            if not candidates:
                return None
            return self._apply_claim(candidates[0], owner, now, lease_seconds)

    def heartbeat(
        self, job_id: str, owner: str, *, fence: int, lease_seconds: int, progress: dict | None = None
    ) -> bool:
        now = self._clock.now()
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None or job.owner != owner or job.fence != fence or job.state != STATE_RUNNING:
                return False
            job.heartbeat_at = _iso(now)
            job.lease_expires_at = _iso(now + timedelta(seconds=lease_seconds))
            job.updated_at = _iso(now)
            if progress is not None:
                job.progress = dict(progress)
            return True

    def mark_succeeded(
        self, job_id: str, owner: str, *, fence: int, result_reference: dict, report_status: dict, progress: dict
    ) -> bool:
        now = self._clock.now()
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None or job.owner != owner or job.fence != fence:
                return False
            job.state = STATE_SUCCEEDED
            job.finished_at = _iso(now)
            job.updated_at = _iso(now)
            job.lease_expires_at = None
            job.error_summary = None
            job.result_reference = dict(result_reference)
            job.report_status = dict(report_status)
            job.progress = dict(progress)
            return True

    def mark_failed(
        self, job_id: str, owner: str, *, fence: int, error_summary: str, retry_delay_seconds: int = 0
    ) -> bool:
        now = self._clock.now()
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None or job.owner != owner or job.fence != fence:
                return False
            exhausted = job.attempt >= job.max_attempts
            job.state = STATE_FAILED_TERMINAL if exhausted else STATE_FAILED_RETRYABLE
            job.owner = None
            job.lease_expires_at = None
            job.finished_at = _iso(now) if exhausted else None
            job.updated_at = _iso(now)
            job.error_summary = str(error_summary)[:2000]
            job.next_attempt_at = (
                None if exhausted else _iso(now + timedelta(seconds=max(0, retry_delay_seconds)))
            )
            return True

    def release(self, job_id: str, owner: str, *, fence: int, reason: str) -> bool:
        now = self._clock.now()
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None or job.owner != owner or job.fence != fence:
                return False
            job.state = STATE_QUEUED
            job.owner = None
            job.lease_expires_at = None
            job.updated_at = _iso(now)
            job.error_summary = str(reason)[:2000]
            return True

    # ── leitura ──────────────────────────────────────────────────────
    def get(self, job_id: str) -> Optional[JobRecord]:
        with self._lock:
            job = self._jobs.get(job_id)
            return None if job is None else JobRecord(**asdict(job))

    def list_recent(self, limit: int = 20) -> list[JobRecord]:
        with self._lock:
            items = [JobRecord(**asdict(job)) for job in self._jobs.values()]
        items.sort(key=lambda job: (job.created_at or "", job.job_id), reverse=True)
        return items[: max(1, int(limit))]

    def active_jobs(self) -> list[JobRecord]:
        with self._lock:
            return [
                JobRecord(**asdict(job)) for job in self._jobs.values()
                if job.state in ACTIVE_STATES
            ]

    def last_successful(self) -> Optional[JobRecord]:
        with self._lock:
            items = [job for job in self._jobs.values() if job.state == STATE_SUCCEEDED]
        if not items:
            return None
        items.sort(key=lambda job: (job.finished_at or "", job.job_id))
        return JobRecord(**asdict(items[-1]))

    def read_watermark(self) -> dict:
        with self._lock:
            return dict(self._watermark)

    def write_watermark(self, payload: dict) -> None:
        with self._lock:
            self._watermark = dict(payload)

    # ── internos ─────────────────────────────────────────────────────
    def _is_claimable(self, job: JobRecord, now: datetime) -> bool:
        if job.state in CLAIMABLE_STATES:
            due = _parse(job.next_attempt_at)
            return due is None or due <= now
        if job.state == STATE_RUNNING:
            expires = _parse(job.lease_expires_at)
            return expires is not None and expires < now
        return False

    def _apply_claim(
        self, job: JobRecord, owner: str, now: datetime, lease_seconds: int
    ) -> Optional[JobRecord]:
        if job.attempt >= job.max_attempts:
            job.state = STATE_FAILED_TERMINAL
            job.owner = None
            job.finished_at = _iso(now)
            job.updated_at = _iso(now)
            job.error_summary = (
                "Número máximo de tentativas ({0}) atingido; execução em falha "
                "terminal.".format(job.max_attempts)
            )
            return None
        job.state = STATE_RUNNING
        job.owner = owner
        job.attempt += 1
        job.fence += 1
        job.claimed_at = _iso(now)
        job.heartbeat_at = _iso(now)
        job.lease_expires_at = _iso(now + timedelta(seconds=lease_seconds))
        job.updated_at = _iso(now)
        job.next_attempt_at = None
        return JobRecord(**asdict(job))


class MongoJobStore(JobStore):
    """Estado compartilhado em MongoDB, seguro para múltiplos pods.

    Usa a mesma instância já provisionada para auditoria
    (``MONGODB_AUDIT_URI``), em coleção própria
    ``telemetria.BACKTEST_VPN_JOBS``. Nenhuma credencial é registrada em log.
    """

    cluster_safe = True
    backend_name = "MongoDB compartilhado (telemetria.BACKTEST_VPN_JOBS)"

    def __init__(
        self,
        collection,
        clock: Clock | None = None,
    ) -> None:
        self._collection = collection
        self._clock = clock or SystemClock()

    # ── construção ───────────────────────────────────────────────────
    @classmethod
    def from_uri(
        cls,
        uri: str,
        *,
        clock: Clock | None = None,
        server_selection_timeout_ms: int = 5000,
        database: str = _MONGO_DB_NAME,
        collection: str = _MONGO_COLLECTION,
    ) -> "MongoJobStore":
        if not uri:
            raise ValueError("URI do MongoDB não informada para o estado de jobs.")
        from pymongo import ASCENDING, MongoClient

        client = MongoClient(uri, serverSelectionTimeoutMS=server_selection_timeout_ms)
        handle = client[database][collection]
        # ``_id`` já é único: é a chave de idempotência. Os índices abaixo
        # apenas aceleram as varreduras de reserva/listagem.
        handle.create_index([("state", ASCENDING), ("lease_expires_at", ASCENDING)])
        handle.create_index([("trigger", ASCENDING), ("created_at", ASCENDING)])
        handle.create_index([("finished_at", ASCENDING)])
        return cls(handle, clock=clock)

    # ── escrita ──────────────────────────────────────────────────────
    def enqueue(self, record: JobRecord) -> JobRecord:
        now = _iso(self._clock.now())
        document = record.as_document()
        document.setdefault("created_at", now)
        document["updated_at"] = now
        document["_kind"] = "job"
        document.pop("_id", None)
        self._collection.update_one(
            {"_id": record.job_id},
            {"$setOnInsert": {**document, "state": record.state or STATE_QUEUED}},
            upsert=True,
        )
        stored = self._collection.find_one({"_id": record.job_id})
        return JobRecord.from_document(stored)

    def claim(self, job_id: str, owner: str, *, lease_seconds: int) -> Optional[JobRecord]:
        return self._atomic_claim({"_id": job_id}, owner, lease_seconds)

    def claim_next(
        self, owner: str, *, lease_seconds: int, triggers: Iterable[str] = TRIGGERS
    ) -> Optional[JobRecord]:
        return self._atomic_claim(
            {"trigger": {"$in": sorted({str(item) for item in triggers})}},
            owner,
            lease_seconds,
            sort=[("created_at", 1)],
        )

    def heartbeat(
        self, job_id: str, owner: str, *, fence: int, lease_seconds: int, progress: dict | None = None
    ) -> bool:
        now = self._clock.now()
        update = {
            "$set": {
                "heartbeat_at": _iso(now),
                "lease_expires_at": _iso(now + timedelta(seconds=lease_seconds)),
                "updated_at": _iso(now),
            }
        }
        if progress is not None:
            update["$set"]["progress"] = dict(progress)
        result = self._collection.update_one(
            {"_id": job_id, "owner": owner, "fence": int(fence), "state": STATE_RUNNING},
            update,
        )
        return bool(result.matched_count)

    def mark_succeeded(
        self, job_id: str, owner: str, *, fence: int, result_reference: dict, report_status: dict, progress: dict
    ) -> bool:
        now = _iso(self._clock.now())
        result = self._collection.update_one(
            {"_id": job_id, "owner": owner, "fence": int(fence)},
            {"$set": {
                "state": STATE_SUCCEEDED,
                "finished_at": now,
                "updated_at": now,
                "lease_expires_at": None,
                "error_summary": None,
                "result_reference": dict(result_reference),
                "report_status": dict(report_status),
                "progress": dict(progress),
            }},
        )
        return bool(result.matched_count)

    def mark_failed(
        self, job_id: str, owner: str, *, fence: int, error_summary: str, retry_delay_seconds: int = 0
    ) -> bool:
        now = self._clock.now()
        current = self._collection.find_one({"_id": job_id, "owner": owner, "fence": int(fence)})
        if not current:
            return False
        exhausted = int(current.get("attempt") or 0) >= int(current.get("max_attempts") or 1)
        payload = {
            "state": STATE_FAILED_TERMINAL if exhausted else STATE_FAILED_RETRYABLE,
            "owner": None,
            "lease_expires_at": None,
            "updated_at": _iso(now),
            "error_summary": str(error_summary)[:2000],
            "finished_at": _iso(now) if exhausted else None,
            "next_attempt_at": (
                None if exhausted
                else _iso(now + timedelta(seconds=max(0, retry_delay_seconds)))
            ),
        }
        result = self._collection.update_one(
            {"_id": job_id, "owner": owner, "fence": int(fence)}, {"$set": payload}
        )
        return bool(result.matched_count)

    def release(self, job_id: str, owner: str, *, fence: int, reason: str) -> bool:
        now = _iso(self._clock.now())
        result = self._collection.update_one(
            {"_id": job_id, "owner": owner, "fence": int(fence)},
            {"$set": {
                "state": STATE_QUEUED,
                "owner": None,
                "lease_expires_at": None,
                "updated_at": now,
                "error_summary": str(reason)[:2000],
            }},
        )
        return bool(result.matched_count)

    # ── leitura ──────────────────────────────────────────────────────
    def get(self, job_id: str) -> Optional[JobRecord]:
        document = self._collection.find_one({"_id": job_id})
        return None if document is None else JobRecord.from_document(document)

    def list_recent(self, limit: int = 20) -> list[JobRecord]:
        cursor = self._collection.find({"_kind": "job"}).sort("created_at", -1).limit(max(1, int(limit)))
        return [JobRecord.from_document(document) for document in cursor]

    def active_jobs(self) -> list[JobRecord]:
        cursor = self._collection.find({"state": {"$in": list(ACTIVE_STATES)}})
        return [JobRecord.from_document(document) for document in cursor]

    def last_successful(self) -> Optional[JobRecord]:
        cursor = self._collection.find({"state": STATE_SUCCEEDED}).sort("finished_at", -1).limit(1)
        for document in cursor:
            return JobRecord.from_document(document)
        return None

    def read_watermark(self) -> dict:
        document = self._collection.find_one({"_id": SCHEDULER_WATERMARK_ID}) or {}
        payload = dict(document)
        payload.pop("_id", None)
        payload.pop("_kind", None)
        return payload

    def write_watermark(self, payload: dict) -> None:
        document = dict(payload)
        document["_kind"] = "watermark"
        document["updated_at"] = _iso(self._clock.now())
        self._collection.update_one(
            {"_id": SCHEDULER_WATERMARK_ID}, {"$set": document}, upsert=True
        )

    # ── internos ─────────────────────────────────────────────────────
    def _atomic_claim(self, base_filter: dict, owner: str, lease_seconds: int, sort=None):
        """Reserva atômica: apenas um worker recebe o documento em RUNNING."""
        from pymongo import ReturnDocument

        now = self._clock.now()
        now_text = _iso(now)
        claim_filter = {
            **base_filter,
            "$and": [
                {"$expr": {"$lt": ["$attempt", "$max_attempts"]}},
                {"$or": [
                    {"state": {"$in": list(CLAIMABLE_STATES)},
                     "$or": [{"next_attempt_at": None}, {"next_attempt_at": {"$lte": now_text}}]},
                    {"state": STATE_RUNNING, "lease_expires_at": {"$lt": now_text}},
                ]},
            ],
        }
        document = self._collection.find_one_and_update(
            claim_filter,
            {
                "$set": {
                    "state": STATE_RUNNING,
                    "owner": str(owner),
                    "claimed_at": now_text,
                    "heartbeat_at": now_text,
                    "lease_expires_at": _iso(now + timedelta(seconds=lease_seconds)),
                    "updated_at": now_text,
                    "next_attempt_at": None,
                },
                "$inc": {"attempt": 1, "fence": 1},
            },
            sort=sort,
            return_document=ReturnDocument.AFTER,
        )
        if document is None:
            return None
        return JobRecord.from_document(document)


def build_job_store(
    *,
    clock: Clock | None = None,
    uri: str | None = None,
    require_cluster_store: bool | None = None,
    logger=None,
) -> JobStore:
    """Escolhe a implementação disponível, sem inventar infraestrutura.

    Ordem: MongoDB (quando ``MONGODB_AUDIT_URI`` estiver configurada) e, na
    ausência dela, o armazenamento em memória. Se
    ``BACKTEST_REQUIRE_CLUSTER_STORE`` estiver ativo e o MongoDB não estiver
    disponível, levanta erro em vez de simular segurança distribuída.
    """
    resolved_uri = uri if uri is not None else os.environ.get("MONGODB_AUDIT_URI", "").strip()
    if require_cluster_store is None:
        require_cluster_store = os.environ.get(
            "BACKTEST_REQUIRE_CLUSTER_STORE", "false"
        ).strip().lower() in ("1", "true", "yes", "on")
    if resolved_uri:
        try:
            return MongoJobStore.from_uri(resolved_uri, clock=clock)
        except Exception as exc:  # noqa: BLE001 - degradação explícita
            if require_cluster_store:
                raise RuntimeError(
                    "Estado compartilhado de jobs exigido, mas o MongoDB não está "
                    "acessível. Configure MONGODB_AUDIT_URI e a conectividade "
                    "antes de habilitar o agendamento em vários pods."
                ) from exc
            if logger is not None:
                logger.warning(
                    "MongoDB indisponível para o estado de jobs; usando estado em "
                    "memória, que NÃO coordena vários pods: %s", exc,
                )
    elif require_cluster_store:
        raise RuntimeError(
            "BACKTEST_REQUIRE_CLUSTER_STORE está ativo, porém MONGODB_AUDIT_URI "
            "não foi configurada. Sem estado durável compartilhado o agendamento "
            "não pode garantir efeito único entre pods."
        )
    return InMemoryJobStore(clock=clock)


__all__ = [
    "ACTIVE_STATES",
    "CLAIMABLE_STATES",
    "InMemoryJobStore",
    "JobRecord",
    "JobStore",
    "MongoJobStore",
    "SCHEDULER_WATERMARK_ID",
    "STATE_CANCELLED",
    "STATE_FAILED_RETRYABLE",
    "STATE_FAILED_TERMINAL",
    "STATE_LABELS_PT",
    "STATE_QUEUED",
    "STATE_RUNNING",
    "STATE_SUCCEEDED",
    "TERMINAL_STATES",
    "TRIGGERS",
    "TRIGGER_INITIAL",
    "TRIGGER_LABELS_PT",
    "TRIGGER_MANUAL",
    "TRIGGER_RETRY",
    "TRIGGER_SCHEDULED",
    "build_job_store",
    "configuration_hash",
    "idempotency_key",
]
