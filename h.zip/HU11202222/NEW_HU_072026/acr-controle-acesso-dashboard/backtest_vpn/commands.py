"""Camada de comandos (Command pattern) do backtesting.

Decisão de arquitetura
----------------------
O projeto já tinha três pontos de entrada com risco real de divergência:
a rota HTTP ``/backtest/executar``, o CLI ``backtest-vpn`` e (novo) o
agendamento de 24 h. O padrão Command foi adotado justamente para que os
três executem **o mesmo caso de uso**:

* os comandos são *dataclasses* imutáveis e **validadas na construção**;
* os handlers orquestram o caso de uso e dependem apenas de **interfaces**
  (relógio, repositório de jobs, reserva/lease, pipeline de leitura e regras,
  gerador de relatórios, publicador, reporter de progresso);
* nenhuma regra de domínio conhece HTTP, CLI ou Kubernetes;
* não há framework de CQRS: o projeto continua usando somente suas
  dependências atuais. A separação é apenas comando (escrita/execução) versus
  consultas de status, que leem o mesmo estado durável compartilhado.
"""

from __future__ import annotations

import logging
import os
import socket
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Callable, Optional, Sequence

from .clock import Clock, SystemClock
from .concurrency import CancellationToken, TaskCancelled, WorkerLimits, run_bounded
from .detection import RULE_CATALOG
from .jobstore import (
    JobRecord,
    JobStore,
    STATE_QUEUED,
    TRIGGER_INITIAL,
    TRIGGER_LABELS_PT,
    TRIGGER_MANUAL,
    TRIGGER_RETRY,
    TRIGGER_SCHEDULED,
    configuration_hash,
    idempotency_key,
)
from .period import BacktestPeriod, window_to_period
from .progress import (
    PHASE_BUILDING_MODEL,
    PHASE_CLAIMED,
    PHASE_GENERATING_CSV,
    PHASE_GENERATING_LATEX,
    PHASE_GENERATING_XLSX,
    PHASE_PUBLISHING,
    PHASE_VALIDATING_CONFIG,
    PHASE_VALIDATING_OUTPUT,
    ProgressReporter,
    queued_progress_payload,
)
from .scheduler import ScheduleConfig

#: Regras aceitas em qualquer comando. R5/R6 não estão em ``RULE_CATALOG``
#: porque dependem da tabela OpenAM, mas continuam válidas.
ALL_RULES: tuple[str, ...] = ("R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8", "R9")

RULE_VERSIONS: dict[str, str] = {
    **{rule: meta["version"] for rule, meta in RULE_CATALOG.items()},
    "R5": "2.1.0",
    "R6": "2.1.0",
}


class CommandValidationError(ValueError):
    """Comando rejeitado antes de qualquer efeito colateral."""


class JobNotClaimable(RuntimeError):
    """Nenhum job elegível foi reservado por este worker."""


def worker_identity(clock: Clock | None = None) -> str:
    """Identidade estável do worker: pod/host + PID.

    Usada apenas como dono do *lease*. Nunca é usada para roteamento: o status
    é lido do estado durável compartilhado por qualquer pod.
    """
    pod = os.environ.get("HOSTNAME") or os.environ.get("POD_NAME") or socket.gethostname()
    return "{0}#{1}".format(str(pod)[:80], os.getpid())


def normalize_rules(rules: Sequence[str] | str | None) -> tuple[str, ...]:
    """Valida e ordena as regras selecionadas."""
    if rules is None:
        selected = list(ALL_RULES)
    elif isinstance(rules, str):
        selected = [item.strip().upper() for item in rules.split(",") if item.strip()]
    else:
        selected = [str(item).strip().upper() for item in rules if str(item).strip()]
    if not selected:
        raise CommandValidationError("Selecione pelo menos uma regra.")
    unknown = sorted(set(selected) - set(ALL_RULES))
    if unknown:
        raise CommandValidationError(
            "Regras desconhecidas: {0}.".format(", ".join(unknown))
        )
    return tuple(rule for rule in ALL_RULES if rule in set(selected))


# ── Comandos ─────────────────────────────────────────────────────────────
@dataclass(frozen=True)
class _EnqueueBacktestCommand:
    """Base imutável dos comandos que enfileiram uma execução."""

    period: BacktestPeriod
    rules: tuple[str, ...]
    config_snapshot: dict
    application_version: str
    requested_by: str = "sistema"
    max_attempts: int = 3
    nonce: str = ""

    trigger: str = field(init=False, default=TRIGGER_MANUAL)

    def __post_init__(self) -> None:
        if not isinstance(self.period, BacktestPeriod):
            raise CommandValidationError("Período inválido: informe um BacktestPeriod validado.")
        object.__setattr__(self, "rules", normalize_rules(self.rules))
        if not isinstance(self.config_snapshot, dict):
            raise CommandValidationError("Snapshot de configuração deve ser um objeto.")
        if not str(self.application_version or "").strip():
            raise CommandValidationError("Versão da aplicação é obrigatória no comando.")
        if not 1 <= int(self.max_attempts) <= 10:
            raise CommandValidationError("max_attempts deve estar entre 1 e 10.")

    @property
    def rule_versions(self) -> dict:
        return {rule: RULE_VERSIONS.get(rule, "Não informado") for rule in self.rules}

    @property
    def config_hash(self) -> str:
        return configuration_hash(
            {
                "rules": list(self.rules),
                "rule_versions": self.rule_versions,
                "period": self.period.as_payload(),
                "config": self.config_snapshot,
            }
        )

    @property
    def job_id(self) -> str:
        return idempotency_key(
            trigger=self.trigger,
            start_date=self.period.start_text,
            end_date_inclusive=self.period.end_inclusive_text,
            timezone_name=self.period.timezone_name,
            rules=self.rules,
            rule_versions=self.rule_versions,
            config_hash=self.config_hash,
            nonce=self.nonce,
        )

    def to_record(self, clock: Clock) -> JobRecord:
        now = clock.now().isoformat(timespec="seconds")
        return JobRecord(
            job_id=self.job_id,
            trigger=self.trigger,
            state=STATE_QUEUED,
            period=self.period.as_payload(),
            rules=list(self.rules),
            rule_versions=self.rule_versions,
            config_hash=self.config_hash,
            config_snapshot=dict(self.config_snapshot),
            application_version=str(self.application_version),
            requested_by=str(self.requested_by),
            max_attempts=int(self.max_attempts),
            created_at=now,
            updated_at=now,
            data_cutoff=self.period.end_exclusive_timestamp,
            progress=queued_progress_payload(
                job_id=self.job_id,
                trigger=self.trigger,
                updated_at=now,
            ),
        )


@dataclass(frozen=True)
class RunInitialBacktestCommand(_EnqueueBacktestCommand):
    """Execução padrão disparada uma única vez por implantação/configuração."""

    def __post_init__(self) -> None:
        object.__setattr__(self, "trigger", TRIGGER_INITIAL)
        object.__setattr__(self, "nonce", "")
        super().__post_init__()


@dataclass(frozen=True)
class RunScheduledBacktestCommand(_EnqueueBacktestCommand):
    """Atualização automática de 24 horas para a janela devida."""

    def __post_init__(self) -> None:
        object.__setattr__(self, "trigger", TRIGGER_SCHEDULED)
        object.__setattr__(self, "nonce", "")
        super().__post_init__()


@dataclass(frozen=True)
class RunManualBacktestCommand(_EnqueueBacktestCommand):
    """Execução parametrizada por pessoa autorizada.

    Recebe um ``nonce`` porque repetir o mesmo período sob demanda é um
    pedido legítimo de leitura mais recente da fonte; sem ele o segundo
    pedido seria absorvido pela idempotência.
    """

    def __post_init__(self) -> None:
        object.__setattr__(self, "trigger", TRIGGER_MANUAL)
        if not str(self.nonce or "").strip():
            raise CommandValidationError(
                "Execução manual exige um identificador de submissão (nonce)."
            )
        super().__post_init__()


@dataclass(frozen=True)
class ResumeOrRetryBacktestCommand:
    """Retoma um job existente: lease expirado, falha reprocessável ou fila."""

    job_id: str
    owner: str
    lease_seconds: int = 1800

    def __post_init__(self) -> None:
        if not str(self.job_id or "").strip():
            raise CommandValidationError("job_id é obrigatório para retomar uma execução.")
        if not str(self.owner or "").strip():
            raise CommandValidationError("owner é obrigatório para retomar uma execução.")
        if not 60 <= int(self.lease_seconds) <= 86400:
            raise CommandValidationError("lease_seconds deve estar entre 60 e 86400.")


@dataclass(frozen=True)
class GenerateBacktestReportsCommand:
    """Gera dossiê, planilha, modelo normalizado e pacote CSV de um bundle."""

    bundle: dict
    output_dir: Path
    application_version: str
    employee_details: Optional[dict] = None
    formats: tuple[str, ...] = ("tex", "xlsx", "csv")
    csv_use_bom: bool = False
    report_workers: int = 1

    def __post_init__(self) -> None:
        if not isinstance(self.bundle, dict) or not self.bundle:
            raise CommandValidationError("Bundle de resultados ausente ou inválido.")
        object.__setattr__(self, "output_dir", Path(self.output_dir))
        allowed = {"tex", "xlsx", "csv"}
        chosen = tuple(str(item).strip().lower() for item in self.formats if str(item).strip())
        unknown = sorted(set(chosen) - allowed)
        if unknown:
            raise CommandValidationError(
                "Formatos de relatório desconhecidos: {0}.".format(", ".join(unknown))
            )
        if not chosen:
            raise CommandValidationError("Selecione pelo menos um formato de relatório.")
        object.__setattr__(self, "formats", tuple(item for item in ("tex", "xlsx", "csv") if item in set(chosen)))
        if self.employee_details is not None and not isinstance(self.employee_details, dict):
            raise CommandValidationError("Dados funcionais devem ser um objeto indexado por usuário.")
        if not 1 <= int(self.report_workers) <= 8:
            raise CommandValidationError("report_workers deve estar entre 1 e 8.")


@dataclass(frozen=True)
class PublishBacktestResultCommand:
    """Publica de forma atômica somente saída completa e validada."""

    job_id: str
    fence: int
    reports_dir: Path
    artifacts: dict
    metadata: dict = field(default_factory=dict)
    required_files: tuple[str, ...] = ()
    retention_keep: int = 0

    def __post_init__(self) -> None:
        if not str(self.job_id or "").strip():
            raise CommandValidationError("job_id é obrigatório para publicar um resultado.")
        try:
            fence = int(self.fence)
        except (TypeError, ValueError):
            raise CommandValidationError("fence inválido para publicação.")
        if fence < 0:
            raise CommandValidationError("fence inválido para publicação.")
        object.__setattr__(self, "fence", fence)
        object.__setattr__(self, "reports_dir", Path(self.reports_dir))
        if not isinstance(self.artifacts, dict) or not self.artifacts:
            raise CommandValidationError("Nenhum artefato informado para publicação.")


# ── Portas ───────────────────────────────────────────────────────────────
@dataclass(frozen=True)
class PipelineRequest:
    """Entrada imutável do pipeline de leitura e avaliação de regras."""

    period: BacktestPeriod
    rules: tuple[str, ...]
    config_snapshot: dict
    job: JobRecord
    progress: ProgressReporter
    cancellation: CancellationToken
    worker_limits: WorkerLimits


@dataclass(frozen=True)
class PipelineResult:
    """Saída do pipeline: bundle publicável e contadores de qualidade."""

    bundle: dict
    metrics: dict = field(default_factory=dict)
    counters: dict = field(default_factory=dict)


class BacktestPipeline:
    """Porta do pipeline de dados; implementada por DB2 ou por fixture."""

    def execute(self, request: PipelineRequest) -> PipelineResult:  # pragma: no cover
        raise NotImplementedError


class ReportGeneratorPort:
    """Porta de geração de relatórios a partir do bundle publicado."""

    def generate(self, command: GenerateBacktestReportsCommand, *, progress: ProgressReporter) -> dict:  # pragma: no cover
        raise NotImplementedError


class ResultPublisherPort:
    """Porta de publicação atômica e versionada."""

    def publish(self, command: PublishBacktestResultCommand) -> dict:  # pragma: no cover
        raise NotImplementedError


# ── Handlers ─────────────────────────────────────────────────────────────
class EnqueueBacktestHandler:
    """Enfileira uma execução de forma idempotente.

    Vários pods podem chamar este handler simultaneamente na subida: a chave
    de idempotência é o ``_id`` do documento, portanto apenas o primeiro
    ``enqueue`` cria o job e todos recebem o mesmo registro.
    """

    def __init__(self, store: JobStore, clock: Clock | None = None, logger: logging.Logger | None = None) -> None:
        self._store = store
        self._clock = clock or SystemClock()
        self._logger = logger or logging.getLogger("backtest_vpn.commands")

    def handle(self, command: _EnqueueBacktestCommand) -> JobRecord:
        record = command.to_record(self._clock)
        # Leitura antes da escrita apenas para registrar em log se o efeito foi
        # criação ou absorção pela idempotência. A garantia de efeito único vem
        # do ``_id`` do documento, não desta consulta.
        already_known = self._store.get(record.job_id) is not None
        stored = self._store.enqueue(record)
        created = not already_known
        self._logger.info(
            "backtest_job_enqueued job_id=%s trigger=%s period=%s..%s days=%s rules=%s "
            "config_hash=%s created=%s store=%s",
            stored.job_id,
            stored.trigger,
            command.period.start_text,
            command.period.end_inclusive_text,
            command.period.total_calendar_days,
            ",".join(command.rules),
            command.config_hash[:16],
            created,
            self._store.backend_name,
        )
        return stored


class ExecuteBacktestHandler:
    """Reserva, executa, gera relatórios e publica — com lease e fencing."""

    def __init__(
        self,
        *,
        store: JobStore,
        pipeline: BacktestPipeline,
        report_generator: ReportGeneratorPort,
        publisher: ResultPublisherPort,
        clock: Clock | None = None,
        logger: logging.Logger | None = None,
        schedule: ScheduleConfig | None = None,
        worker_limits: WorkerLimits | None = None,
        progress_factory: Callable[..., ProgressReporter] | None = None,
        on_success: Callable[[JobRecord, dict], None] | None = None,
    ) -> None:
        self._store = store
        self._pipeline = pipeline
        self._report_generator = report_generator
        self._publisher = publisher
        self._clock = clock or SystemClock()
        self._logger = logger or logging.getLogger("backtest_vpn.commands")
        self._schedule = schedule or ScheduleConfig()
        self._limits = worker_limits or WorkerLimits()
        self._progress_factory = progress_factory
        self._on_success = on_success

    # ── reserva ──────────────────────────────────────────────────────
    def claim(self, command: ResumeOrRetryBacktestCommand) -> JobRecord:
        claimed = self._store.claim(
            command.job_id, command.owner, lease_seconds=command.lease_seconds
        )
        if claimed is None:
            raise JobNotClaimable(
                "Nenhum job elegível para reserva com o identificador informado. "
                "Ele pode estar concluído, em execução com lease válido em outro "
                "pod, ou em falha terminal."
            )
        return claimed

    def claim_next(self, owner: str, *, lease_seconds: int, triggers=None) -> JobRecord:
        claimed = self._store.claim_next(
            owner,
            lease_seconds=lease_seconds,
            triggers=triggers or (TRIGGER_INITIAL, TRIGGER_SCHEDULED, TRIGGER_MANUAL, TRIGGER_RETRY),
        )
        if claimed is None:
            raise JobNotClaimable("Nenhum job pendente para reservar.")
        return claimed

    # ── execução ─────────────────────────────────────────────────────
    def execute(
        self,
        job: JobRecord,
        *,
        reports_dir,
        employee_details: dict | None = None,
        cancellation: CancellationToken | None = None,
        lease_seconds: int | None = None,
        retention_keep: int = 0,
        csv_use_bom: bool = False,
        formats: tuple[str, ...] = ("tex", "xlsx", "csv"),
    ) -> JobRecord:
        """Executa um job já reservado por este worker.

        O ``fence`` recebido na reserva é revalidado em cada escrita: um
        worker antigo nunca sobrescreve o resultado de um worker mais novo.
        """
        cancellation = cancellation or CancellationToken()
        lease = int(lease_seconds or self._schedule.lease_seconds)
        owner = job.owner or worker_identity(self._clock)
        fence = int(job.fence)
        period_payload = dict(job.period or {})
        period = window_to_period(
            period_payload.get("start"),
            period_payload.get("end_exclusive"),
            timezone_name=period_payload.get("timezone") or self._clock.timezone_name,
        )
        period = replace(
            period,
            cutoff_mode=period_payload.get("cutoff_mode") or period.cutoff_mode,
        )
        progress = self._build_progress(job, owner, fence, lease)
        publication: dict = {}
        try:
            progress.start_phase(
                PHASE_CLAIMED,
                total_units=1,
                message="Job reservado por {0} (tentativa {1} de {2}).".format(
                    owner, job.attempt, job.max_attempts
                ),
            )
            progress.advance(1)
            progress.start_phase(
                PHASE_VALIDATING_CONFIG,
                total_units=1,
                message="Validando período de {0} dias e {1} regra(s).".format(
                    period.total_calendar_days, len(job.rules)
                ),
            )
            cancellation.raise_if_cancelled()
            progress.advance(1)

            request = PipelineRequest(
                period=period,
                rules=tuple(job.rules),
                config_snapshot=dict(job.config_snapshot),
                job=job,
                progress=progress,
                cancellation=cancellation,
                worker_limits=self._limits,
            )
            outcome = self._pipeline.execute(request)
            cancellation.raise_if_cancelled()
            bundle = self._decorate_bundle(outcome.bundle, job, period, owner)

            progress.start_phase(
                PHASE_BUILDING_MODEL, total_units=1,
                message="Montando o modelo normalizado compartilhado pelos formatos.",
            )
            resolved_employees = employee_details
            if resolved_employees is None:
                resolved_employees = self._resolve_employee_details(bundle)
            report_command = GenerateBacktestReportsCommand(
                bundle=bundle,
                output_dir=Path(reports_dir),
                application_version=job.application_version,
                employee_details=resolved_employees,
                formats=formats,
                csv_use_bom=csv_use_bom,
                report_workers=self._limits.report_workers,
            )
            artifacts = self._report_generator.generate(report_command, progress=progress)
            cancellation.raise_if_cancelled()

            progress.start_phase(
                PHASE_PUBLISHING, total_units=1,
                message="Publicando o resultado de forma atômica.",
            )
            publish_command = PublishBacktestResultCommand(
                job_id=job.job_id,
                fence=fence,
                reports_dir=Path(reports_dir),
                artifacts=artifacts,
                metadata={
                    "trigger": job.trigger,
                    "period": period.as_payload(),
                    "rules": list(job.rules),
                    "rule_versions": dict(job.rule_versions),
                    "config_hash": job.config_hash,
                    "application_version": job.application_version,
                    "published_at": self._clock.now().isoformat(timespec="seconds"),
                    "report_id": (artifacts.get("report_id") or None),
                    "occurrences": int(artifacts.get("occurrences") or 0),
                },
                retention_keep=retention_keep,
            )
            publication = self._publisher.publish(publish_command)
            progress.advance(1)
            progress.finish(
                message="Resultado e relatórios publicados para o período {0} a {1}.".format(
                    period.start_text, period.end_inclusive_text
                )
            )
            accepted = self._store.mark_succeeded(
                job.job_id,
                owner,
                fence=fence,
                result_reference=publication,
                report_status={
                    key: str(value) for key, value in artifacts.items()
                    if key in ("tex", "xlsx", "model", "csv_manifest", "report_id")
                },
                progress=progress.snapshot.as_payload(),
            )
            if not accepted:
                # Outro worker assumiu o job: este resultado é descartado sem
                # sobrescrever o mais novo.
                self._logger.warning(
                    "backtest_publication_fenced job_id=%s fence=%s owner=%s",
                    job.job_id, fence, owner,
                )
                raise JobNotClaimable(
                    "O lease deste job expirou e outro processador assumiu a "
                    "execução; o resultado desta tentativa foi descartado."
                )
            if self._on_success is not None:
                self._on_success(job, publication)
        except TaskCancelled as exc:
            # Encerramento graceful (SIGTERM) ou cancelamento explícito: o job
            # volta para a fila em vez de ser marcado como concluído ou como
            # falha definitiva. Trabalho inacabado nunca é declarado sucesso.
            cancellation.cancel()
            summary = self._safe_error_summary(exc)
            progress.cancel(message=summary)
            self._store.release(
                job.job_id, owner, fence=fence,
                reason="Execução interrompida antes de concluir; job devolvido à fila.",
            )
            self._logger.warning(
                "backtest_job_released job_id=%s trigger=%s attempt=%s owner=%s reason=%s",
                job.job_id, job.trigger, job.attempt, owner, summary,
            )
            raise
        except BaseException as exc:  # noqa: BLE001 - registra e devolve estado
            cancellation.cancel()
            summary = self._safe_error_summary(exc)
            progress.fail(message=summary)
            self._store.mark_failed(
                job.job_id, owner, fence=fence, error_summary=summary,
                retry_delay_seconds=self._schedule.retry_delay_seconds(job.attempt),
            )
            self._logger.error(
                "backtest_job_failed job_id=%s trigger=%s attempt=%s owner=%s reason=%s",
                job.job_id, job.trigger, job.attempt, owner, summary,
            )
            raise
        refreshed = self._store.get(job.job_id)
        return refreshed or job

    # ── internos ─────────────────────────────────────────────────────
    def _build_progress(self, job: JobRecord, owner: str, fence: int, lease: int) -> ProgressReporter:
        def sink(snapshot) -> None:
            self._store.heartbeat(
                job.job_id, owner, fence=fence, lease_seconds=lease,
                progress=snapshot.as_payload(),
            )

        if self._progress_factory is not None:
            return self._progress_factory(job=job, owner=owner, sink=sink)
        return ProgressReporter(
            job_id=job.job_id,
            trigger=job.trigger,
            attempt=job.attempt,
            clock=self._clock,
            sink=sink,
            logger=self._logger,
            static_fields={
                "application_version": job.application_version,
                "worker": owner,
                "config_hash": job.config_hash[:16],
                "rules": list(job.rules),
                "period_start": (job.period or {}).get("start_date"),
                "period_end_inclusive": (job.period or {}).get("end_date_inclusive"),
                "data_cutoff": job.data_cutoff,
                "total_calendar_days": (job.period or {}).get("total_calendar_days"),
                "worker_limits": self._limits.as_payload(),
            },
        )

    def _resolve_employee_details(self, bundle: dict) -> Optional[dict]:
        """Consulta o Curio para preencher nome, matrícula e UOR do dossiê.

        Falhas nunca interrompem a execução: sem Curio o relatório continua
        sendo gerado, apenas com os campos organizacionais em branco.
        """
        try:
            from .org_lookup import fetch_employee_details

            details = fetch_employee_details(bundle)
        except Exception:
            logging.getLogger("backtest_vpn.commands").warning(
                "Enriquecimento organizacional indisponível.", exc_info=True
            )
            return None
        return details or None

    def _decorate_bundle(self, bundle: dict, job: JobRecord, period: BacktestPeriod, owner: str) -> dict:
        """Anexa metadados de execução ao bundle, sem alterar os resultados."""
        payload = dict(bundle)
        payload["execution"] = {
            "job_id": job.job_id,
            "trigger": job.trigger,
            "trigger_label": TRIGGER_LABELS_PT.get(job.trigger, job.trigger),
            "attempt": job.attempt,
            "worker": owner,
            "config_hash": job.config_hash,
            "worker_limits": self._limits.as_payload(),
            "schedule": self._schedule.as_payload(),
            "period": period.as_payload(),
        }
        return payload

    @staticmethod
    def _safe_error_summary(exc: BaseException) -> str:
        """Resumo não técnico sem reutilizar texto potencialmente sensível."""
        error_type = type(exc).__name__
        if isinstance(exc, (CommandValidationError, ValueError)):
            message = "Configuração ou parâmetro inválido."
        elif error_type == "MtaResultLimitExceeded":
            message = "A consulta de correlação excedeu o limite seguro e foi interrompida."
        elif isinstance(exc, TaskCancelled):
            message = "Execução cancelada antes da publicação."
        else:
            message = "A execução não pôde ser concluída; consulte o log operacional protegido."
        return "{0}: {1}".format(error_type, message)


class GenerateReportsHandler(ReportGeneratorPort):
    """Gera os formatos a partir de **um único** modelo normalizado."""

    def __init__(self, clock: Clock | None = None, logger: logging.Logger | None = None) -> None:
        self._clock = clock or SystemClock()
        self._logger = logger or logging.getLogger("backtest_vpn.commands")

    def generate(self, command: GenerateBacktestReportsCommand, *, progress: ProgressReporter) -> dict:
        from . import csvpackage
        from .dossier import write_latex, write_xlsx
        from .report_model import build_report_model

        model = build_report_model(
            command.bundle, command.application_version, employee_details=command.employee_details
        )
        progress.advance(1, message="Modelo normalizado com {0} ocorrência(s).".format(
            model["executive"]["total_occurrences"]
        ))
        output = Path(command.output_dir)
        output.mkdir(parents=True, exist_ok=True)
        model_path = output / "backtesting_report_model.json"
        import json as _json

        model_path.write_text(
            _json.dumps(model, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8"
        )

        phases = {
            "tex": (PHASE_GENERATING_LATEX, "Gerando o dossiê LaTeX."),
            "xlsx": (PHASE_GENERATING_XLSX, "Gerando a planilha XLSX."),
            "csv": (PHASE_GENERATING_CSV, "Gerando o pacote de detalhamento em CSV."),
        }
        artifacts: dict = {
            "model": model_path,
            "report_id": model["report"]["report_id"],
            "occurrences": model["executive"]["total_occurrences"],
        }

        def _writer(fmt: str):
            if fmt == "tex":
                return lambda: ("tex", write_latex(model, output / "backtesting_dossier.tex"))
            if fmt == "xlsx":
                return lambda: ("xlsx", write_xlsx(model, output / "backtesting_dossier.xlsx"))
            return lambda: ("csv", csvpackage.write_package(model, output, use_bom=command.csv_use_bom))

        def _absorb(outcome) -> None:
            fmt, value = outcome
            if fmt == "csv":
                artifacts["csv_manifest"] = output / csvpackage.PACKAGE_DIRNAME / csvpackage.MANIFEST_NAME
                artifacts["csv_package"] = output / csvpackage.PACKAGE_DIRNAME
                artifacts["csv_files"] = [entry["file"] for entry in value.get("files") or []]
            else:
                artifacts[fmt] = value

        # Cada escritor possui o seu próprio arquivo; nada mutável é
        # compartilhado entre tarefas e a ordem do resultado é a de submissão,
        # portanto 1 ou N workers produzem exatamente o mesmo conteúdo.
        if int(command.report_workers) == 1:
            for fmt in command.formats:
                phase, message = phases[fmt]
                progress.start_phase(phase, total_units=1, message=message)
                _absorb(_writer(fmt)())
                progress.advance(1)
        else:
            first_phase, _ = phases[command.formats[0]]
            progress.start_phase(
                first_phase,
                total_units=len(command.formats),
                subphase="geração paralela de {0} formato(s)".format(len(command.formats)),
                message="Gerando {0} em paralelo com {1} worker(s).".format(
                    ", ".join(command.formats), command.report_workers
                ),
            )
            outcomes = run_bounded(
                [_writer(fmt) for fmt in command.formats],
                max_workers=int(command.report_workers),
                on_result=lambda index, value: progress.advance(1),
            )
            for outcome in outcomes:
                _absorb(outcome)

        progress.start_phase(
            PHASE_VALIDATING_OUTPUT, total_units=1,
            message="Conferindo integridade dos arquivos gerados.",
        )
        if "csv" in command.formats:
            problems = csvpackage.verify_package(output)
            if problems:
                raise ValueError(
                    "Pacote CSV inválido: {0}".format("; ".join(problems[:5]))
                )
        progress.advance(1)
        self._logger.info(
            "backtest_reports_generated report_id=%s formats=%s occurrences=%s",
            artifacts["report_id"], ",".join(command.formats), artifacts["occurrences"],
        )
        return artifacts


class PublishResultHandler(ResultPublisherPort):
    """Publicação atômica em diretório versionado, com ponteiro e retenção."""

    def __init__(self, clock: Clock | None = None, logger: logging.Logger | None = None) -> None:
        self._clock = clock or SystemClock()
        self._logger = logger or logging.getLogger("backtest_vpn.commands")

    def publish(self, command: PublishBacktestResultCommand) -> dict:
        from . import publication

        target = publication.prepare(command.reports_dir, command.job_id, command.fence)
        try:
            copied = _stage_artifacts(target.staging_dir, command.artifacts)
            required = list(command.required_files) or [
                name for name in copied if name.endswith((".tex", ".xlsx", ".json"))
            ]
            pointer = publication.publish(
                target, required_files=required, metadata=dict(command.metadata)
            )
        except BaseException:
            publication.discard(target)
            raise
        removed = publication.apply_retention(command.reports_dir, command.retention_keep)
        if removed:
            self._logger.info(
                "backtest_retention_applied job_id=%s removed=%s keep=%s",
                command.job_id, len(removed), command.retention_keep,
            )
        self._logger.info(
            "backtest_result_published job_id=%s fence=%s files=%s",
            command.job_id, command.fence, len(pointer.get("files") or []),
        )
        return pointer


def _stage_artifacts(staging_dir: Path, artifacts: dict) -> list[str]:
    """Copia os artefatos para o staging preservando a estrutura do pacote."""
    import shutil

    names: list[str] = []
    # ``csv_manifest`` já está dentro de ``csv_package``; copiá-lo à parte
    # duplicaria o arquivo na raiz do pacote publicado.
    for key, value in sorted(artifacts.items()):
        if key in ("report_id", "occurrences", "csv_files", "csv_manifest"):
            continue
        source = Path(value)
        if source.is_dir():
            destination = staging_dir / source.name
            if destination.exists():
                shutil.rmtree(destination)
            shutil.copytree(source, destination)
            names.append(source.name)
            continue
        if not source.is_file():
            continue
        shutil.copy2(source, staging_dir / source.name)
        names.append(source.name)
    return names


__all__ = [
    "ALL_RULES",
    "BacktestPipeline",
    "CommandValidationError",
    "EnqueueBacktestHandler",
    "ExecuteBacktestHandler",
    "GenerateBacktestReportsCommand",
    "GenerateReportsHandler",
    "JobNotClaimable",
    "PipelineRequest",
    "PipelineResult",
    "PublishBacktestResultCommand",
    "PublishResultHandler",
    "RULE_VERSIONS",
    "ReportGeneratorPort",
    "ResultPublisherPort",
    "ResumeOrRetryBacktestCommand",
    "RunInitialBacktestCommand",
    "RunManualBacktestCommand",
    "RunScheduledBacktestCommand",
    "normalize_rules",
    "worker_identity",
]
