"""Concorrência limitada e determinística para tarefas independentes.

Decisão de projeto
------------------
A avaliação de regras deste projeto é CPU-bound e feita em estruturas Python
puras. Com o GIL do CPython, threads **não** aumentam a vazão desse trecho, e
o driver ``ibm_db`` não documenta segurança de thread para uma mesma conexão.
Por isso:

* o executor abaixo é **limitado** e configurável, com **1 worker por padrão**
  (execução sequencial), e nunca compartilha conexões, cursores, acumuladores
  mutáveis nem escritores de relatório entre tarefas;
* a ordem do resultado é **sempre a ordem de submissão**, independentemente da
  ordem de conclusão, para que identificadores de ocorrência e o conteúdo dos
  relatórios sejam idênticos com 1 ou N workers;
* há **backpressure**: no máximo ``max_workers`` tarefas ficam pendentes ao
  mesmo tempo, evitando filas de futures ilimitadas;
* a primeira exceção é propagada ao chamador, as tarefas restantes são
  canceladas e o cancelamento cooperativo é sinalizado por um evento.

Threads não substituem coordenação entre pods: veja
:mod:`backtest_vpn.jobstore`.
"""

from __future__ import annotations

import os
import threading
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from dataclasses import dataclass
from typing import Callable, Iterable, Sequence

DEFAULT_MAX_WORKERS = 1
MAX_ALLOWED_WORKERS = 8


class TaskCancelled(RuntimeError):
    """Levantada quando o cancelamento cooperativo interrompe o lote."""


@dataclass(frozen=True)
class WorkerLimits:
    """Limites por carga de trabalho, lidos da configuração do ambiente."""

    rule_workers: int = DEFAULT_MAX_WORKERS
    report_workers: int = DEFAULT_MAX_WORKERS
    db_pool_limit: int = 1

    @classmethod
    def from_env(cls, env: dict | None = None) -> "WorkerLimits":
        source = dict(os.environ if env is None else env)

        def _bounded(name: str, default: int, ceiling: int) -> int:
            raw = str(source.get(name, "")).strip()
            if not raw:
                return default
            try:
                value = int(raw)
            except ValueError:
                raise ValueError("{0} deve ser um inteiro entre 1 e {1}.".format(name, ceiling))
            if not 1 <= value <= ceiling:
                raise ValueError("{0} deve estar entre 1 e {1}.".format(name, ceiling))
            return value

        db_pool_limit = _bounded("BACKTEST_DB2_POOL_LIMIT", 1, MAX_ALLOWED_WORKERS)
        rule_workers = _bounded("BACKTEST_RULE_WORKERS", DEFAULT_MAX_WORKERS, MAX_ALLOWED_WORKERS)
        report_workers = _bounded("BACKTEST_REPORT_WORKERS", DEFAULT_MAX_WORKERS, MAX_ALLOWED_WORKERS)
        return cls(
            rule_workers=rule_workers,
            report_workers=report_workers,
            db_pool_limit=db_pool_limit,
        )

    def as_payload(self) -> dict:
        return {
            "rule_workers": self.rule_workers,
            "report_workers": self.report_workers,
            "db2_pool_limit": self.db_pool_limit,
        }


class CancellationToken:
    """Sinal cooperativo de cancelamento compartilhado pelas tarefas."""

    def __init__(self) -> None:
        self._event = threading.Event()

    def cancel(self) -> None:
        self._event.set()

    @property
    def cancelled(self) -> bool:
        return self._event.is_set()

    def raise_if_cancelled(self) -> None:
        if self._event.is_set():
            raise TaskCancelled("Execução cancelada antes de concluir a tarefa.")


def run_bounded(
    tasks: Sequence[Callable[[], object]],
    *,
    max_workers: int = DEFAULT_MAX_WORKERS,
    cancellation: CancellationToken | None = None,
    on_result: Callable[[int, object], None] | None = None,
) -> list:
    """Executa ``tasks`` com no máximo ``max_workers`` em voo.

    Retorna os resultados **na ordem de submissão**. ``on_result`` é chamado
    na thread do chamador, na ordem de conclusão, e serve para progresso
    parcial — nunca para acumular o resultado final.
    """
    if max_workers < 1 or max_workers > MAX_ALLOWED_WORKERS:
        raise ValueError(
            "max_workers deve estar entre 1 e {0}.".format(MAX_ALLOWED_WORKERS)
        )
    ordered = list(tasks)
    results: list = [None] * len(ordered)
    if not ordered:
        return results
    cancellation = cancellation or CancellationToken()
    if max_workers == 1:
        for index, task in enumerate(ordered):
            cancellation.raise_if_cancelled()
            results[index] = task()
            if on_result is not None:
                on_result(index, results[index])
        return results

    pending: dict = {}
    next_index = 0
    with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="backtest-task") as pool:
        try:
            while next_index < len(ordered) or pending:
                # Backpressure: nunca mais de ``max_workers`` futures vivos.
                while next_index < len(ordered) and len(pending) < max_workers:
                    cancellation.raise_if_cancelled()
                    future = pool.submit(ordered[next_index])
                    pending[future] = next_index
                    next_index += 1
                if not pending:
                    break
                done, _ = wait(list(pending), return_when=FIRST_COMPLETED)
                for future in done:
                    index = pending.pop(future)
                    results[index] = future.result()
                    if on_result is not None:
                        on_result(index, results[index])
        except BaseException:
            cancellation.cancel()
            for future in list(pending):
                future.cancel()
            raise
    return results


def merge_rule_results(
    rule_ids: Iterable[str], outcomes: Iterable[object]
) -> dict:
    """Une resultados por regra em ordem estável de identificador."""
    paired = list(zip([str(item) for item in rule_ids], list(outcomes)))
    paired.sort(key=lambda item: (len(item[0]), item[0]))
    return {rule_id: outcome for rule_id, outcome in paired}


__all__ = [
    "CancellationToken",
    "DEFAULT_MAX_WORKERS",
    "MAX_ALLOWED_WORKERS",
    "TaskCancelled",
    "WorkerLimits",
    "merge_rule_results",
    "run_bounded",
]
