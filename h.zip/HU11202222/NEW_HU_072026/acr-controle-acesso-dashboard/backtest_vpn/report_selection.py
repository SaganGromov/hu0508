"""Seleção determinística dos achados que merecem leitura imediata.

O bundle de execução continua sendo a fonte completa e auditável. Os formatos
de apresentação usam esta seleção para evitar que centenas de ocorrências
ocultem os casos que exigem atenção primeiro.
"""

from __future__ import annotations

from collections import defaultdict
from decimal import Decimal, InvalidOperation


REPORT_OCCURRENCE_LIMIT = 10

_SEVERITY_PRIORITY = {
    "CRÍTICA": 5,
    "CRITICA": 5,
    "ALTA": 4,
    "MÉDIA": 3,
    "MEDIA": 3,
    "BAIXA": 2,
    "VARIÁVEL": 1,
    "VARIAVEL": 1,
}


def _numeric_magnitude(value) -> Decimal:
    """Extrai a maior magnitude numérica de um valor estruturado."""
    if value is None or isinstance(value, bool):
        return Decimal(0)
    if isinstance(value, (int, float, Decimal)):
        try:
            return abs(Decimal(str(value)))
        except InvalidOperation:
            return Decimal(0)
    if isinstance(value, dict):
        return max(
            (_numeric_magnitude(item) for item in value.values()),
            default=Decimal(0),
        )
    if isinstance(value, (list, tuple, set)):
        return max((_numeric_magnitude(item) for item in value), default=Decimal(0))
    try:
        return abs(Decimal(str(value).strip().replace(",", ".")))
    except InvalidOperation:
        return Decimal(0)


def _priority_key(occurrence: dict) -> tuple:
    severity = str(occurrence.get("severity") or "").strip().upper()
    evidence_count = len(occurrence.get("evidence_records") or [])
    supporting_count = len(occurrence.get("supporting_event_identifiers") or [])
    entity_count = (
        len(occurrence.get("associated_users") or [])
        + len(occurrence.get("associated_devices") or [])
    )
    return (
        -_SEVERITY_PRIORITY.get(severity, 0),
        -_numeric_magnitude(occurrence.get("triggering_value")),
        -evidence_count,
        -supporting_count,
        -entity_count,
        str(occurrence.get("window_start") or ""),
        str(occurrence.get("occurrence_id") or ""),
    )


def select_top_occurrences_by_rule(
    occurrences: list[dict],
    *,
    limit: int = REPORT_OCCURRENCE_LIMIT,
) -> list[dict]:
    """Retorna no máximo ``limit`` casos prioritários de cada regra.

    A ordem é estável e explicável: severidade, magnitude do valor acionador,
    volume de evidência, abrangência de entidades e identificador. Nenhum dado
    é alterado e a função não escolhe casos aleatoriamente.
    """
    if isinstance(limit, bool) or not isinstance(limit, int) or limit < 1:
        raise ValueError("O limite de ocorrências do relatório deve ser inteiro positivo.")
    grouped: dict[str, list[dict]] = defaultdict(list)
    for occurrence in occurrences:
        grouped[str(occurrence.get("rule_id") or "SEM_REGRA")].append(occurrence)
    selected = []
    for rule_id in sorted(
        grouped,
        key=lambda value: (
            int(value[1:]) if value.startswith("R") and value[1:].isdigit() else 999,
            value,
        ),
    ):
        selected.extend(sorted(grouped[rule_id], key=_priority_key)[:limit])
    return selected

