"""Raiz de composição do backtesting.

Este módulo é o único lugar que lê variáveis de ambiente para montar o caso de
uso completo (relógio, estado de jobs, agendamento, limites de concorrência,
pipeline, geração de relatórios e publicação). CLI, worker, agendador e a
aplicação web pedem a mesma montagem, de modo que os comportamentos não podem
divergir entre pontos de entrada.
"""

from __future__ import annotations

import logging
import os
import signal
from dataclasses import dataclass
from pathlib import Path

from . import scheduler as scheduler_mod
from .clock import Clock, SystemClock
from .commands import (
    EnqueueBacktestHandler,
    ExecuteBacktestHandler,
    GenerateReportsHandler,
    JobNotClaimable,
    PublishResultHandler,
    ResumeOrRetryBacktestCommand,
    RunInitialBacktestCommand,
    RunManualBacktestCommand,
    RunScheduledBacktestCommand,
    normalize_rules,
    worker_identity,
)
from .concurrency import CancellationToken, TaskCancelled, WorkerLimits
from .jobstore import (
    JobRecord,
    JobStore,
    TRIGGER_INITIAL,
    TRIGGER_MANUAL,
    TRIGGER_SCHEDULED,
    build_job_store,
)
from .period import BacktestPeriod, default_period
from .pipeline import Db2BacktestPipeline, FixtureBacktestPipeline

LOGGER_NAME = "backtest_vpn.runtime"

#: Quantidade de resultados publicados que a limpeza preserva. ``0`` desativa
#: qualquer remoção automática — nada é apagado sem política explícita.
DEFAULT_RETENTION_KEEP = 0


def _int_env(name: str, default: int, low: int, high: int) -> int:
    raw = str(os.environ.get(name, "")).strip()
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError:
        raise ValueError("{0} deve ser um inteiro entre {1} e {2}.".format(name, low, high))
    if not low <= value <= high:
        raise ValueError("{0} deve estar entre {1} e {2}.".format(name, low, high))
    return value


def _flag_env(name: str, default: bool) -> bool:
    raw = str(os.environ.get(name, "")).strip().lower()
    if not raw:
        return default
    if raw in ("1", "true", "yes", "on"):
        return True
    if raw in ("0", "false", "no", "off"):
        return False
    raise ValueError("{0} deve ser um booleano (true/false).".format(name))


def resolve_reports_dir(base_dir=None) -> Path:
    """Diretório de saída dos artefatos, sempre absoluto."""
    configured = str(os.environ.get("BACKTEST_VPN_REPORTS_DIR", "")).strip()
    if configured:
        return Path(configured).expanduser().resolve()
    root = Path(base_dir) if base_dir else Path(__file__).resolve().parent.parent
    return (root / "reports").resolve()


@dataclass
class BacktestRuntime:
    """Conjunto montado de dependências e handlers."""

    clock: Clock
    store: JobStore
    schedule: scheduler_mod.ScheduleConfig
    limits: WorkerLimits
    reports_dir: Path
    application_version: str
    enqueue: EnqueueBacktestHandler
    execute: ExecuteBacktestHandler
    logger: logging.Logger
    retention_keep: int = DEFAULT_RETENTION_KEEP
    csv_use_bom: bool = False
    report_formats: tuple[str, ...] = ("tex", "xlsx", "csv")

    # ── consultas ────────────────────────────────────────────────────
    def status(self, job_id: str) -> dict | None:
        record = self.store.get(job_id)
        return None if record is None else record.public_view()

    def recent(self, limit: int = 20) -> list[dict]:
        return [record.public_view() for record in self.store.list_recent(limit)]

    def last_successful(self) -> dict | None:
        record = self.store.last_successful()
        return None if record is None else record.public_view()

    def watermark(self) -> dict:
        return self.store.read_watermark()

    def active(self) -> list[dict]:
        return [record.public_view() for record in self.store.active_jobs()]

    def dashboard_state(self) -> dict:
        """Estado resumido para o painel, legível de qualquer pod."""
        active = self.active()
        last = self.last_successful()
        watermark = self.watermark()
        return {
            "store_backend": self.store.backend_name,
            "store_cluster_safe": bool(self.store.cluster_safe),
            "schedule": self.schedule.as_payload(),
            "worker_limits": self.limits.as_payload(),
            "active_jobs": active,
            "initial_dataset_pending": bool(active) and last is None,
            "last_successful": last,
            "last_successful_at": (last or {}).get("finished_at"),
            "watermark": watermark,
            "application_version": self.application_version,
            "timezone": self.clock.timezone_name,
        }

    # ── comandos ─────────────────────────────────────────────────────
    def default_period_for(self, trigger: str) -> BacktestPeriod:
        if trigger == TRIGGER_SCHEDULED:
            return scheduler_mod.scheduled_period(self.schedule, self.clock.today())
        return default_period(
            self.clock,
            window_days=self.schedule.window_days,
            cutoff_mode=self.schedule.cutoff_mode if trigger == TRIGGER_INITIAL else "current_day",
        )

    def enqueue_initial(self, *, rules=None, config_snapshot: dict | None = None) -> JobRecord:
        period = self.default_period_for(TRIGGER_INITIAL)
        return self.enqueue.handle(RunInitialBacktestCommand(
            period=period,
            rules=normalize_rules(rules),
            config_snapshot=dict(config_snapshot or self.config_snapshot()),
            application_version=self.application_version,
            requested_by="implantação",
            max_attempts=self.schedule.max_attempts,
        ))

    def enqueue_scheduled(self, period: BacktestPeriod, *, rules=None, config_snapshot: dict | None = None) -> JobRecord:
        return self.enqueue.handle(RunScheduledBacktestCommand(
            period=period,
            rules=normalize_rules(rules),
            config_snapshot=dict(config_snapshot or self.config_snapshot()),
            application_version=self.application_version,
            requested_by="agendador",
            max_attempts=self.schedule.max_attempts,
        ))

    def enqueue_manual(
        self,
        period: BacktestPeriod,
        *,
        rules=None,
        config_snapshot: dict | None = None,
        requested_by: str = "usuário autorizado",
        nonce: str | None = None,
    ) -> JobRecord:
        return self.enqueue.handle(RunManualBacktestCommand(
            period=period,
            rules=normalize_rules(rules),
            config_snapshot=dict(config_snapshot or self.config_snapshot()),
            application_version=self.application_version,
            requested_by=requested_by,
            max_attempts=self.schedule.max_attempts,
            nonce=nonce or self.clock.now().strftime("%Y%m%dT%H%M%S%f"),
        ))

    def config_snapshot(self) -> dict:
        """Configuração não sensível que participa da chave de idempotência."""
        return {
            "schedule": self.schedule.as_payload(),
            "worker_limits": self.limits.as_payload(),
            "rules_config": str(os.environ.get("BACKTEST_RULES_CONFIG", "")).strip() or None,
        }

    def run_job(
        self,
        job: JobRecord,
        *,
        employee_details: dict | None = None,
        cancellation: CancellationToken | None = None,
    ) -> JobRecord:
        return self.execute.execute(
            job,
            reports_dir=self.reports_dir,
            employee_details=employee_details,
            cancellation=cancellation,
            lease_seconds=self.schedule.lease_seconds,
            retention_keep=self.retention_keep,
            csv_use_bom=self.csv_use_bom,
            formats=self.report_formats,
        )

    def claim_and_run(
        self,
        job_id: str,
        *,
        employee_details: dict | None = None,
        cancellation: CancellationToken | None = None,
    ) -> JobRecord:
        claimed = self.execute.claim(ResumeOrRetryBacktestCommand(
            job_id=job_id,
            owner=worker_identity(self.clock),
            lease_seconds=self.schedule.lease_seconds,
        ))
        return self.run_job(claimed, employee_details=employee_details, cancellation=cancellation)

    def evaluate_schedule(self) -> scheduler_mod.ScheduleDecision:
        return scheduler_mod.evaluate(self.schedule, self.clock, self.store.read_watermark())


def build_runtime(
    *,
    application_version: str,
    base_dir=None,
    clock: Clock | None = None,
    store: JobStore | None = None,
    pipeline=None,
    logger: logging.Logger | None = None,
    reports_dir=None,
    schedule: scheduler_mod.ScheduleConfig | None = None,
    limits: WorkerLimits | None = None,
) -> BacktestRuntime:
    """Monta a aplicação a partir do ambiente e das dependências fornecidas."""
    logger = logger or logging.getLogger(LOGGER_NAME)
    schedule = schedule or scheduler_mod.ScheduleConfig.from_env()
    resolved_clock = clock or SystemClock(schedule.timezone_name)
    resolved_limits = limits or WorkerLimits.from_env()
    resolved_store = store or build_job_store(clock=resolved_clock, logger=logger)
    resolved_reports = Path(reports_dir).resolve() if reports_dir else resolve_reports_dir(base_dir)
    resolved_pipeline = pipeline or FixtureBacktestPipeline(logger=logger)
    execute = ExecuteBacktestHandler(
        store=resolved_store,
        pipeline=resolved_pipeline,
        report_generator=GenerateReportsHandler(clock=resolved_clock, logger=logger),
        publisher=PublishResultHandler(clock=resolved_clock, logger=logger),
        clock=resolved_clock,
        logger=logger,
        schedule=schedule,
        worker_limits=resolved_limits,
        on_success=lambda job, publication: _advance_watermark(
            resolved_store, resolved_clock, job, publication, logger
        ),
    )
    return BacktestRuntime(
        clock=resolved_clock,
        store=resolved_store,
        schedule=schedule,
        limits=resolved_limits,
        reports_dir=resolved_reports,
        application_version=str(application_version),
        enqueue=EnqueueBacktestHandler(resolved_store, clock=resolved_clock, logger=logger),
        execute=execute,
        logger=logger,
        retention_keep=_int_env("BACKTEST_REPORTS_RETENTION_KEEP", DEFAULT_RETENTION_KEEP, 0, 100),
        csv_use_bom=_flag_env("BACKTEST_CSV_BOM", False),
        report_formats=_report_formats_env(),
    )


def _report_formats_env() -> tuple[str, ...]:
    """Formatos publicados por execução; o padrão gera os três."""
    raw = str(os.environ.get("BACKTEST_REPORT_FORMATS", "")).strip()
    if not raw:
        return ("tex", "xlsx", "csv")
    chosen = {item.strip().lower() for item in raw.split(",") if item.strip()}
    unknown = sorted(chosen - {"tex", "xlsx", "csv"})
    if unknown:
        raise ValueError(
            "BACKTEST_REPORT_FORMATS aceita apenas tex, xlsx e csv; recebido: "
            "{0}.".format(", ".join(unknown))
        )
    if not chosen:
        raise ValueError("BACKTEST_REPORT_FORMATS deve conter pelo menos um formato.")
    return tuple(item for item in ("tex", "xlsx", "csv") if item in chosen)


def _advance_watermark(
    store: JobStore, clock: Clock, job: JobRecord, publication: dict, logger: logging.Logger
) -> None:
    """Avança a marca d'água **somente** após publicação bem-sucedida.

    Execuções manuais não movem a marca d'água: elas podem cobrir qualquer
    período escolhido pela pessoa e não representam o avanço do ciclo diário.
    """
    if job.trigger == TRIGGER_MANUAL:
        return
    from dataclasses import replace as _replace

    from .period import window_to_period

    period_payload = dict(job.period or {})
    period = window_to_period(
        period_payload.get("start"),
        period_payload.get("end_exclusive"),
        timezone_name=period_payload.get("timezone") or clock.timezone_name,
    )
    if period_payload.get("cutoff_mode"):
        period = _replace(period, cutoff_mode=period_payload["cutoff_mode"])
    current = store.read_watermark()
    previous = str(current.get("last_published_end_date") or "")
    if previous and previous >= period.end_inclusive_text:
        # Nunca retrocede a marca d'água nem a reescreve com janela mais antiga.
        return
    store.write_watermark(
        scheduler_mod.watermark_after_success(
            period, job.job_id, clock, report_id=(publication or {}).get("report_id")
        )
    )
    logger.info(
        "backtest_watermark_advanced job_id=%s end_date=%s",
        job.job_id, period.end_inclusive_text,
    )


class WorkerLoop:
    """Loop de worker com reserva atômica e encerramento graceful.

    Não há temporizador em memória decidindo o agendamento: cada iteração
    consulta o estado durável compartilhado. Assim vários pods podem rodar o
    mesmo loop sem duplicar efeito.
    """

    def __init__(
        self,
        runtime: BacktestRuntime,
        *,
        install_signal_handlers: bool = True,
        sleep=None,
    ) -> None:
        self._runtime = runtime
        self._cancellation = CancellationToken()
        self._sleep = sleep
        if install_signal_handlers:
            self._install_signal_handlers()

    @property
    def cancellation(self) -> CancellationToken:
        return self._cancellation

    def _install_signal_handlers(self) -> None:
        def _handler(signum, _frame):  # pragma: no cover - depende do sinal real
            self._runtime.logger.warning(
                "backtest_worker_shutdown_requested signal=%s", signum
            )
            self._cancellation.cancel()

        for name in ("SIGTERM", "SIGINT"):
            candidate = getattr(signal, name, None)
            if candidate is None:
                continue
            try:
                signal.signal(candidate, _handler)
            except (ValueError, OSError):  # pragma: no cover - thread secundária
                continue

    def run_once(self, *, employee_details: dict | None = None) -> JobRecord | None:
        """Reserva e executa no máximo um job; devolve ``None`` se não houver."""
        try:
            job = self._runtime.execute.claim_next(
                worker_identity(self._runtime.clock),
                lease_seconds=self._runtime.schedule.lease_seconds,
            )
        except JobNotClaimable:
            return None
        try:
            return self._runtime.run_job(
                job, employee_details=employee_details, cancellation=self._cancellation
            )
        except TaskCancelled:
            return None

    def run(
        self,
        *,
        max_jobs: int | None = None,
        poll_seconds: float = 15.0,
        idle_limit: int | None = None,
        employee_details: dict | None = None,
    ) -> int:
        """Processa jobs até o limite, o encerramento ou a fila vazia."""
        import time

        sleep = self._sleep or time.sleep
        processed = 0
        idle = 0
        while not self._cancellation.cancelled:
            if max_jobs is not None and processed >= max_jobs:
                break
            result = None
            try:
                result = self.run_once(employee_details=employee_details)
            except Exception as exc:  # noqa: BLE001 - já registrado no handler
                self._runtime.logger.error(
                    "backtest_worker_job_error error_type=%s",
                    type(exc).__name__,
                )
                processed += 1
                continue
            if result is None:
                idle += 1
                if idle_limit is not None and idle >= idle_limit:
                    break
                if self._cancellation.cancelled:
                    break
                sleep(max(0.0, float(poll_seconds)))
                continue
            idle = 0
            processed += 1
        return processed


def ensure_initial_job(runtime: BacktestRuntime, *, rules=None) -> JobRecord | None:
    """Garante **um** job padrão por implantação/configuração.

    Idempotente por construção: a chave lógica depende do gatilho, da janela,
    do fuso, das regras e do hash de configuração. Vários pods subindo ao mesmo
    tempo produzem o mesmo ``job_id`` e, portanto, um único efeito.
    """
    if not runtime.schedule.run_initial_on_startup:
        runtime.logger.info(
            "backtest_initial_skipped reason=BACKTEST_RUN_INITIAL_ON_STARTUP desativado"
        )
        return None
    existing = runtime.store.last_successful()
    if existing is not None:
        decision = runtime.evaluate_schedule()
        runtime.logger.info(
            "backtest_initial_skipped reason=resultado publicado disponível "
            "last_success_at=%s next_due_at=%s",
            existing.finished_at, decision.next_due_at,
        )
        return None
    return runtime.enqueue_initial(rules=rules)


def run_scheduled_if_due(runtime: BacktestRuntime, *, rules=None, execute: bool = True) -> dict:
    """Avalia a política de 24 h e, se devida, enfileira e executa a janela."""
    decision = runtime.evaluate_schedule()
    payload = decision.as_payload()
    if not decision.should_run or decision.period is None:
        runtime.logger.info("backtest_schedule_not_due reason=%s", decision.reason)
        payload["job_id"] = None
        return payload
    job = runtime.enqueue_scheduled(decision.period, rules=rules)
    payload["job_id"] = job.job_id
    if not execute:
        return payload
    try:
        final = runtime.claim_and_run(job.job_id)
        payload["final_state"] = final.state
    except JobNotClaimable:
        # Outro pod já reservou a mesma janela: comportamento esperado.
        runtime.logger.info(
            "backtest_schedule_already_claimed job_id=%s", job.job_id
        )
        payload["final_state"] = "CLAIMED_ELSEWHERE"
    return payload


def summarize_active(runtime: BacktestRuntime) -> str:
    """Mensagem curta em português para UI e logs enquanto não há resultado."""
    state = runtime.dashboard_state()
    if state["last_successful"]:
        return "Resultado disponível, atualizado em {0}.".format(
            state["last_successful_at"] or "data não informada"
        )
    if state["active_jobs"]:
        first = state["active_jobs"][0]
        progress = first.get("progress") or {}
        return (
            "Execução em andamento ({0}). Fase atual: {1}."
        ).format(
            first.get("state_label") or first.get("state"),
            progress.get("phase_label") or "iniciando",
        )
    return (
        "Nenhum resultado publicado ainda e nenhuma execução em andamento. "
        "Use a página Executar para solicitar um backtest com a janela desejada."
    )


__all__ = [
    "BacktestRuntime",
    "DEFAULT_RETENTION_KEEP",
    "Db2BacktestPipeline",
    "FixtureBacktestPipeline",
    "WorkerLoop",
    "build_runtime",
    "ensure_initial_job",
    "resolve_reports_dir",
    "run_scheduled_if_due",
    "summarize_active",
]
