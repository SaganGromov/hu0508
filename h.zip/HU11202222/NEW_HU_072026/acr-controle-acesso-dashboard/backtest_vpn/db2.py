"""Acesso DB2 via ibm_db: conexao, consulta parametrizada e encerramento.

Nenhuma funcao deste modulo imprime nada nem registra credenciais.
"""

import os
import time

import ibm_db


_TRANSIENT_DB2_MARKERS = (
    "SQL1224N",  # database manager forced/terminated requests
    "SQL30081N",  # TCP/IP communication error
    "CLI0106E",  # connection is closed
    "Connection is closed",
    "SQLSTATE=55032",
)


def _build_dsn(db2_config):
    dsn = (
        "DATABASE={database};"
        "HOSTNAME={hostname};"
        "PORT={port};"
        "PROTOCOL=TCPIP;"
        "UID={username};"
        "PWD={password};"
    ).format(
        database=db2_config.database,
        hostname=db2_config.hostname,
        port=db2_config.port,
        username=db2_config.username,
        password=db2_config.password,
    )
    return dsn


def _open(db2_config):
    return ibm_db.connect(_build_dsn(db2_config), "", "")


class ReconnectingDb2Connection:
    """Small wrapper that can reopen DB2 after transient connection failures."""

    def __init__(self, db2_config):
        self._db2_config = db2_config
        self.handle = _open(db2_config)

    def reconnect(self):
        try:
            ibm_db.close(self.handle)
        except Exception:
            # A conexão já está inutilizável e será substituída imediatamente;
            # falha no fechamento não altera autenticação nem consistência.
            pass  # nosec B110
        self.handle = _open(self._db2_config)

    def close(self):
        ibm_db.close(self.handle)


def connect(db2_config):
    """Abre uma conexao ibm_db a partir de um Db2ConnectionConfig."""
    return ReconnectingDb2Connection(db2_config)


def _raw_handle(conn):
    return conn.handle if isinstance(conn, ReconnectingDb2Connection) else conn


def _is_transient_db2_error(exc):
    msg = str(exc)
    return any(marker in msg for marker in _TRANSIENT_DB2_MARKERS)


def _retry_attempts():
    raw = os.environ.get("DB2_FETCH_RETRY_ATTEMPTS", "3").strip()
    try:
        attempts = int(raw)
    except ValueError:
        attempts = 3
    return max(1, min(attempts, 6))


def _retry_delay_seconds():
    raw = os.environ.get("DB2_FETCH_RETRY_DELAY_SECONDS", "2").strip()
    try:
        delay = float(raw)
    except ValueError:
        delay = 2.0
    return max(0.0, min(delay, 30.0))


def _fetch_all_once(conn, sql, params):
    stmt = ibm_db.prepare(_raw_handle(conn), sql)
    if stmt is False:
        raise RuntimeError("Falha ao preparar SQL: {0}".format(sql))
    executed = ibm_db.execute(stmt, tuple(params))
    if executed is False:
        raise RuntimeError("Falha ao executar SQL: {0}".format(sql))
    rows = []
    row = ibm_db.fetch_assoc(stmt)
    while row:
        rows.append({str(key).upper(): value for key, value in row.items()})
        row = ibm_db.fetch_assoc(stmt)
    return rows


def fetch_all(conn, sql, params=()):
    """Prepara e executa `sql` com binding `?`, retornando list[dict].

    As chaves de cada linha sao normalizadas para maiusculas.
    """
    attempts = _retry_attempts()
    delay = _retry_delay_seconds()
    for attempt in range(attempts):
        try:
            return _fetch_all_once(conn, sql, params)
        except Exception as exc:
            if (
                attempt >= attempts - 1
                or not isinstance(conn, ReconnectingDb2Connection)
                or not _is_transient_db2_error(exc)
            ):
                raise
            time.sleep(delay * (attempt + 1))
            conn.reconnect()
    raise RuntimeError("Falha inesperada ao executar SQL: {0}".format(sql))


def close(conn):
    """Fecha a conexao ibm_db, ignorando conexoes nulas."""
    if conn is not None:
        if isinstance(conn, ReconnectingDb2Connection):
            conn.close()
        else:
            ibm_db.close(conn)
