"""Backtest local (somente leitura) das regras de deteccao de VPN sobre DB2."""

__version__ = "2.3.0"
