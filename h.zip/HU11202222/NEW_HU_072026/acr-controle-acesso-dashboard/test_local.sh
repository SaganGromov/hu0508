#!/usr/bin/env bash
# =============================================================================
#  test_local.sh — End-to-end local smoke test for acr-controle-acesso-dashboard
# =============================================================================
#  What it does:
#    1. Verifies prerequisites (uv, python).
#    2. Syncs dependencies with uv.
#    3. Runs the Python syntax check on app.py + package modules.
#    4. Runs the pytest suite (unit + integration).
#    5. Provisions local dev secrets (matricula HMAC key + allowed digest for
#       the test matricula F0000000).
#    6. Boots FastAPI (uvicorn) + Streamlit in the background.
#    7. Hits the backtest and dashboard endpoints without a session cookie and
#       asserts they redirect to "/" (matricula allow-list gate).
#    8. Hits /healthz and asserts 200.
#    9. Prints URLs and, unless --ci is passed, keeps servers running so you
#       can log in via OAuth and click around. Ctrl+C tears everything down.
#
#  Usage:
#      chmod +x test_local.sh
#      ./test_local.sh           # full run, keeps servers up at the end
#      ./test_local.sh --ci      # non-interactive: shut down after checks
#      ./test_local.sh --no-serve  # only run syntax + pytest, no servers
#      ./test_local.sh --no-tests  # skip pytest, just boot + smoke-test
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

MODE_CI=0
MODE_SERVE=1
MODE_TESTS=1
for arg in "$@"; do
    case "$arg" in
        --ci)         MODE_CI=1 ;;
        --no-serve)   MODE_SERVE=0 ;;
        --no-tests)   MODE_TESTS=0 ;;
        -h|--help)
            sed -n '2,25p' "$0"
            exit 0
            ;;
        *)
            echo "Unknown flag: $arg" >&2
            exit 2
            ;;
    esac
done

STREAMLIT_PORT="${STREAMLIT_PORT:-8501}"
FASTAPI_PORT="${FASTAPI_PORT:-8000}"
STREAMLIT_BASE_URL_PATH="${STREAMLIT_BASE_URL_PATH:-/streamlit}"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'
log()  { echo -e "${CYAN}[test_local]${NC} $*"; }
warn() { echo -e "${YELLOW}[test_local]${NC} $*"; }
ok()   { echo -e "${GREEN}[test_local]${NC} $*"; }
err()  { echo -e "${RED}[test_local]${NC} $*"; }

PIDS=()
CURIO_CONTAINER="curio-sidecar-local"
CURIO_CONTAINER_STARTED=0
FAILED=0
UV_LOCK_BACKUP=""
restore_uv_lock() {
    if [ -n "$UV_LOCK_BACKUP" ] && [ -f "$UV_LOCK_BACKUP" ]; then
        mv -f "$UV_LOCK_BACKUP" "$SCRIPT_DIR/uv.lock"
        UV_LOCK_BACKUP=""
    fi
}
cleanup() {
    local rc=$?
    trap - EXIT INT TERM
    restore_uv_lock
    log "Shutting down background processes..."
    for pid in "${PIDS[@]:-}"; do
        if [ -n "${pid:-}" ]; then
            # Kill the whole process group so uv-run's child (uvicorn/streamlit)
            # goes away too, not only the uv wrapper.
            kill -TERM -- "-$pid" 2>/dev/null || kill "$pid" 2>/dev/null || true
        fi
    done
    sleep 1
    for pid in "${PIDS[@]:-}"; do
        [ -n "${pid:-}" ] && kill -KILL "$pid" 2>/dev/null || true
    done
    if [ "$CURIO_CONTAINER_STARTED" -eq 1 ]; then
        docker rm -f "$CURIO_CONTAINER" >/dev/null 2>&1 || true
    fi
    if [ "$FAILED" -eq 0 ] && [ "$rc" -ne 0 ]; then
        FAILED="$rc"
    fi
    if [ "$FAILED" -ne 0 ]; then
        err "One or more checks FAILED (exit=$FAILED)."
    else
        ok "All checks passed."
    fi
    exit "$FAILED"
}
trap cleanup EXIT INT TERM

fail() { err "$*"; FAILED=1; }

# ── 1. Prereqs ───────────────────────────────────────────────
log "Checking prerequisites..."
if ! command -v uv >/dev/null 2>&1; then
    err "uv not found. Install: curl -LsSf https://astral.sh/uv/install.sh | sh"
    FAILED=1
    exit "$FAILED"
fi
if ! command -v curl >/dev/null 2>&1; then
    err "curl not found."
    FAILED=1
    exit "$FAILED"
fi
if ! uv --help 2>&1 | grep -q -- "--system-certs"; then
    err "This script requires a uv release with --system-certs support."
    err "Upgrade uv before running the local test suite."
    FAILED=1
    exit "$FAILED"
fi
ok "uv $(uv --version 2>&1 | awk '{print $2}') and curl available."

export UV_CACHE_DIR="${UV_CACHE_DIR:-/tmp/uv-cache}"
# Use the operating system trust store for every uv operation in this script.
# This is required on corporate workstations where the internal CA is managed
# by the platform. UV_NATIVE_TLS is the deprecated predecessor; do not use it.
export UV_SYSTEM_CERTS=true
ok "uv system certificate store enabled (UV_SYSTEM_CERTS=true)."

# ── 2. Dependencies ──────────────────────────────────────────
# Try the project's default index (corporate artifactory) first. If it
# returns 401/403/network errors — common outside the corporate VPN, or when
# the artifactory session expired — retry once against public PyPI.
run_uv_sync() {
    local extra=("$@")
    if [ -f "$SCRIPT_DIR/uv.lock" ]; then
        uv sync --frozen "${extra[@]}"
    else
        uv sync "${extra[@]}"
    fi
}

log "Synchronising dependencies with uv..."
set +e
run_uv_sync
SYNC_RC=$?
set -e
if [ "$SYNC_RC" -eq 0 ]; then
    ok "Dependencies ready via project default index."
else
    warn "uv sync failed (rc=$SYNC_RC). Retrying with public PyPI as fallback index..."
    warn "Set UV_TEST_LOCAL_INDEX to override this fallback (default: https://pypi.org/simple)."
    FALLBACK_INDEX="${UV_TEST_LOCAL_INDEX:-https://pypi.org/simple}"
    # uv.lock pins the binarios URL for every package. Preserve the committed
    # lock while generating an ephemeral fallback lock, including on Ctrl+C.
    if [ -f "$SCRIPT_DIR/uv.lock" ]; then
        UV_LOCK_BACKUP="$(mktemp)"
        cp "$SCRIPT_DIR/uv.lock" "$UV_LOCK_BACKUP"
        rm -f "$SCRIPT_DIR/uv.lock"
    fi
    set +e
    UV_DEFAULT_INDEX="$FALLBACK_INDEX" UV_INDEX_STRATEGY=first-index \
        uv sync --index "$FALLBACK_INDEX"
    FALLBACK_RC=$?
    set -e
    restore_uv_lock
    if [ "$FALLBACK_RC" -eq 0 ]; then
        ok "Dependencies ready via fallback index ($FALLBACK_INDEX)."
        ok "The committed uv.lock was restored after the fallback sync."
    else
        err "uv sync failed on both the project index and $FALLBACK_INDEX."
        err "If you are on the corporate network, refresh your artifactory"
        err "credentials and try again. Otherwise, check outbound HTTPS access."
        FAILED=1
        exit "$FAILED"
    fi
fi
ok "Python: $(uv run --no-sync python --version 2>&1)"

# ── 3. Syntax / import check ─────────────────────────────────
log "Checking Python syntax and package imports..."
if ! uv run --no-sync python -m compileall -q app.py acr_controle_acesso_dashboard backtest_vpn 2>&1; then
    fail "compileall reported errors."
else
    ok "Bytecode compilation ok."
fi

# ── 4. pytest ────────────────────────────────────────────────
if [ "$MODE_TESTS" -eq 1 ]; then
    log "Running pytest suite (tests/)..."
    if uv run --no-sync pytest -x -q tests; then
        ok "pytest passed."
    else
        fail "pytest failed."
    fi
else
    warn "Skipping pytest (--no-tests)."
fi

if [ "$MODE_SERVE" -eq 0 ]; then
    log "Not booting servers (--no-serve). Exiting."
    exit "$FAILED"
fi

# ── 5. Secrets and env ───────────────────────────────────────
SECRETS_DIR="$SCRIPT_DIR/secrets"
mkdir -p "$SECRETS_DIR"

if [ ! -s "$SECRETS_DIR/matricula_hmac_key" ]; then
    warn "Generating local dev HMAC key in secrets/matricula_hmac_key"
    uv run --no-sync python -c "import secrets; print(secrets.token_hex(32))" > "$SECRETS_DIR/matricula_hmac_key"
fi
if [ ! -s "$SECRETS_DIR/allowed_matricula_digests" ]; then
    warn "Registering test matricula F0000000 in secrets/allowed_matricula_digests"
    HMAC_KEY=$(cat "$SECRETS_DIR/matricula_hmac_key")
    HMAC_KEY="$HMAC_KEY" uv run --no-sync python -c "
import hmac, hashlib, os
key = os.environ['HMAC_KEY'].encode()
print(hmac.new(key, b'F0000000', hashlib.sha256).hexdigest())
" > "$SECRETS_DIR/allowed_matricula_digests"
fi

if [ ! -f "$SCRIPT_DIR/.env" ]; then
    if [ -f "$SCRIPT_DIR/.env.example" ]; then
        warn ".env not found — copying from .env.example"
        cp "$SCRIPT_DIR/.env.example" "$SCRIPT_DIR/.env"
    else
        warn ".env not found — writing minimal defaults"
        cat > "$SCRIPT_DIR/.env" <<'ENVEOF'
AMBIENTE=desenv
RODANDO_LOCALMENTE=YES
PROMETHEUS_MONITORING_ENABLED=false
REDIS_MONITORING_ENABLED=false
METRICS_NOTIFICATIONS_ENABLED=false
ENVEOF
    fi
fi

export MATRICULA_HMAC_KEY_FILE="$SECRETS_DIR/matricula_hmac_key"
export ALLOWED_MATRICULA_DIGESTS_FILE="$SECRETS_DIR/allowed_matricula_digests"
export SESSION_SECRET="${SESSION_SECRET:-local-dev-session-secret-do-not-use-in-prod}"
export STREAMLIT_BASE_URL_PATH
export STREAMLIT_SERVER_ENABLE_CORS="false"
export STREAMLIT_SERVER_ENABLE_XSRF_PROTECTION="true"
export OAUTH2_AMBIENTE="${OAUTH2_AMBIENTE:-intranet}"
export OAUTH2_CLIENT_ID="${OAUTH2_CLIENT_ID:-acr-controle-acesso-dashboard}"
export OAUTH2_ISSUER_BASE_URL="${OAUTH2_ISSUER_BASE_URL:-}"
export OAUTH2_REDIRECT_URI="${OAUTH2_REDIRECT_URI:-http://localhost:$FASTAPI_PORT/auth/callback}"
export SESSION_COOKIE_SECURE="${SESSION_COOKIE_SECURE:-false}"
export SSL_CA_BUNDLE="${SSL_CA_BUNDLE:-}"
export CURIO_BASE_URL="${CURIO_BASE_URL:-http://localhost:8081}"
export CURIO_IMAGE="${CURIO_IMAGE:-docker.binarios.intranet.bb.com.br/bb/iib/iib-curio:0.9.10}"
export KAFKA_REALTIME_LOOKBACK_MINUTES="${KAFKA_REALTIME_LOOKBACK_MINUTES:-60}"

# ── Backtest VPN runner (page /backtest/executar) ────────────
# The FastAPI page reads BACKTEST_VPN_BIN + DB2 credentials to decide whether
# to expose the "Executar" form. Wire the local wrapper by default so the
# page renders; jobs will still fail if DB2 is unreachable locally.
_LOCAL_BACKTEST_BIN="$SCRIPT_DIR/scripts/backtest-vpn"
if [ -z "${BACKTEST_VPN_BIN:-}" ] && [ -x "$_LOCAL_BACKTEST_BIN" ]; then
    export BACKTEST_VPN_BIN="$_LOCAL_BACKTEST_BIN"
fi
# The wrapper defaults to /app/.venv/bin/python (container path). Override
# with the local uv-managed venv so local jobs can spawn.
if [ -z "${PYTHON_BIN:-}" ] && [ -x "$SCRIPT_DIR/.venv/bin/python" ]; then
    export PYTHON_BIN="$SCRIPT_DIR/.venv/bin/python"
fi
# The runner's default reports dir is <bin>/../../reports, which resolves to
# the *parent* of the dashboard when BACKTEST_VPN_BIN=scripts/backtest-vpn.
# Point it at the in-repo reports/ so the report-html step finds the bundle.
if [ -z "${BACKTEST_VPN_REPORTS_DIR:-}" ]; then
    export BACKTEST_VPN_REPORTS_DIR="$SCRIPT_DIR/reports"
    mkdir -p "$BACKTEST_VPN_REPORTS_DIR"
fi
if [ -n "${BACKTEST_VPN_BIN:-}" ]; then
    log "BACKTEST_VPN_BIN=$BACKTEST_VPN_BIN"
    log "PYTHON_BIN=${PYTHON_BIN:-<default>}"
    log "BACKTEST_VPN_REPORTS_DIR=$BACKTEST_VPN_REPORTS_DIR"
fi

# DB2 credentials for the runner — prefer an existing local JSON if present,
# otherwise fall back to dummy env vars so ``credentials_ok()`` returns True
# and the page renders. Actual DB2 calls will still fail without real creds.
if [ -z "${DB2_CREDENTIALS_FILE:-}" ] && [ -z "${DB2_USERNAME:-}${DB2_USER:-}" ]; then
    for candidate in \
        "$SCRIPT_DIR/secrets/db2_credentials.json" \
        "$SCRIPT_DIR/../../gravar_dados_vpn/db2_credentials.json" \
        "$SCRIPT_DIR/../gravar_dados_vpn/db2_credentials.json"
    do
        if [ -f "$candidate" ]; then
            export DB2_CREDENTIALS_FILE="$(cd "$(dirname "$candidate")" && pwd)/$(basename "$candidate")"
            log "DB2_CREDENTIALS_FILE=$DB2_CREDENTIALS_FILE"
            break
        fi
    done
fi
if [ -z "${DB2_CREDENTIALS_FILE:-}" ] && [ -z "${DB2_USERNAME:-}${DB2_USER:-}" ]; then
    warn "No DB2 credentials found. Setting DB2_USERNAME/DB2_PASSWORD to dummies"
    warn "so /backtest/executar renders. Jobs will fail against real DB2."
    export DB2_USERNAME="${DB2_USERNAME:-local-dev-user}"
    export DB2_PASSWORD="${DB2_PASSWORD:-local-dev-password}"
fi

if [ -f "$SCRIPT_DIR/bb.bundle.crt" ]; then
    export SSL_CERT_FILE="${SSL_CERT_FILE:-$SCRIPT_DIR/bb.bundle.crt}"
    export REQUESTS_CA_BUNDLE="${REQUESTS_CA_BUNDLE:-$SSL_CERT_FILE}"
    export KAFKA_SSL_CA_LOCATION="${KAFKA_SSL_CA_LOCATION:-$SCRIPT_DIR/bb.bundle.crt}"
fi

set -a
# shellcheck disable=SC1091
source "$SCRIPT_DIR/.env"
set +a

# ── 5b. Curio sidecar ────────────────────────────────────────
if [ ! -f "$SCRIPT_DIR/.env_curio" ] && [ -f "$SCRIPT_DIR/.env_curio.example" ]; then
    warn ".env_curio not found — creating it from .env_curio.example"
    cp "$SCRIPT_DIR/.env_curio.example" "$SCRIPT_DIR/.env_curio"
fi
CURIO_LOTACAO_OPERATION="br.com.bb.arh.operacao:Op5360402-v1:3.0.1"
if [ -f "$SCRIPT_DIR/.env_curio" ]; then
    current_ops="$(grep '^CURIO_OP_CONSUMIDOR=' "$SCRIPT_DIR/.env_curio" | tail -n 1 | cut -d= -f2-)"
    case "|$current_ops|" in
        *"|$CURIO_LOTACAO_OPERATION|"*) ;;
        *)
            merged_ops="${current_ops:+${current_ops}|}${CURIO_LOTACAO_OPERATION}"
            tmp_env="$SCRIPT_DIR/.env_curio.tmp.$$"
            awk -v merged="$merged_ops" '
                BEGIN { written = 0 }
                /^CURIO_OP_CONSUMIDOR=/ {
                    if (!written) {
                        print "CURIO_OP_CONSUMIDOR=" merged
                        written = 1
                    }
                    next
                }
                { print }
                END {
                    if (!written) print "CURIO_OP_CONSUMIDOR=" merged
                }
            ' "$SCRIPT_DIR/.env_curio" > "$tmp_env"
            mv "$tmp_env" "$SCRIPT_DIR/.env_curio"
            warn ".env_curio updated with required operation Op5360402-v1:3.0.1."
            ;;
    esac
fi
# Um teste interrompido pode deixar o container antigo em execução. O health
# check continuaria verde, mas a rota nova devolveria 404 porque operações são
# registradas somente na inicialização do Curio.
if command -v docker >/dev/null 2>&1 \
    && [ "$(docker inspect -f '{{.State.Running}}' "$CURIO_CONTAINER" 2>/dev/null || true)" = "true" ]; then
    container_ops="$(docker inspect -f '{{range .Config.Env}}{{println .}}{{end}}' \
        "$CURIO_CONTAINER" 2>/dev/null | grep '^CURIO_OP_CONSUMIDOR=' | tail -n 1 || true)"
    case "|$container_ops|" in
        *"$CURIO_LOTACAO_OPERATION"*) ;;
        *)
            warn "Restarting stale Curio sidecar to register Op5360402-v1."
            docker rm -f "$CURIO_CONTAINER" >/dev/null
            ;;
    esac
fi
if curl -fsS --max-time 2 "$CURIO_BASE_URL/health/ready" >/dev/null 2>&1; then
    export CURIO_ENABLED=true
    ok "Curio sidecar already available at $CURIO_BASE_URL."
elif [ "$CURIO_BASE_URL" = "http://localhost:8081" ] || [ "$CURIO_BASE_URL" = "http://127.0.0.1:8081" ]; then
    if command -v docker >/dev/null 2>&1 && [ -f "$SCRIPT_DIR/.env_curio" ]; then
        docker rm -f "$CURIO_CONTAINER" >/dev/null 2>&1 || true
        log "Starting Curio sidecar on localhost:8081..."
        if docker run -d --name "$CURIO_CONTAINER" \
            --env-file "$SCRIPT_DIR/.env_curio" \
            -p 8081:8081 \
            "$CURIO_IMAGE" >/dev/null; then
            CURIO_CONTAINER_STARTED=1
            CURIO_READY=0
            for _ in $(seq 1 30); do
                if curl -fsS --max-time 2 "$CURIO_BASE_URL/health/ready" >/dev/null 2>&1; then
                    CURIO_READY=1
                    break
                fi
                sleep 1
            done
            if [ "$CURIO_READY" -eq 1 ]; then
                export CURIO_ENABLED=true
                ok "Curio sidecar ready."
            else
                export CURIO_ENABLED=false
                warn "Curio sidecar did not become ready; organizational enrichment is disabled."
            fi
        else
            export CURIO_ENABLED=false
            warn "Unable to start Curio sidecar; organizational enrichment is disabled."
        fi
    else
        export CURIO_ENABLED=false
        warn ".env_curio or Docker is unavailable; organizational enrichment is disabled."
    fi
else
    export CURIO_ENABLED=true
    warn "Configured remote Curio endpoint is not ready yet: $CURIO_BASE_URL"
fi

# ── 6. Boot Streamlit + FastAPI ──────────────────────────────
STREAMLIT_LOG="$(mktemp)"
FASTAPI_LOG="$(mktemp)"

log "Starting Streamlit on 0.0.0.0:$STREAMLIT_PORT (log: $STREAMLIT_LOG)"
uv run --no-sync streamlit run \
    acr_controle_acesso_dashboard/streamlit_app/real_time_dashboard.py \
    --server.port="$STREAMLIT_PORT" \
    --server.address=0.0.0.0 \
    --server.headless=true \
    --server.enableCORS=false \
    --server.baseUrlPath="$STREAMLIT_BASE_URL_PATH" \
    --server.enableXsrfProtection=true \
    >"$STREAMLIT_LOG" 2>&1 &
PIDS+=($!)

log "Starting FastAPI on 0.0.0.0:$FASTAPI_PORT (log: $FASTAPI_LOG)"
uv run --no-sync uvicorn app:app --host 0.0.0.0 --port "$FASTAPI_PORT" \
    >"$FASTAPI_LOG" 2>&1 &
PIDS+=($!)

# ── 7. Wait for FastAPI to answer ────────────────────────────
log "Waiting for FastAPI /healthz..."
HEALTH_URL="http://localhost:$FASTAPI_PORT/healthz"
for i in $(seq 1 40); do
    if curl -fsS -o /dev/null "$HEALTH_URL"; then
        ok "FastAPI healthy after ${i}s."
        break
    fi
    if [ "$i" -eq 40 ]; then
        fail "FastAPI never became ready. Last log lines:"
        tail -n 30 "$FASTAPI_LOG" || true
        exit "$FAILED"
    fi
    sleep 1
done

log "Waiting for Streamlit ${STREAMLIT_BASE_URL_PATH}/_stcore/health..."
STREAMLIT_HEALTH_URL="http://localhost:$STREAMLIT_PORT${STREAMLIT_BASE_URL_PATH%/}/_stcore/health"
STREAMLIT_READY=0
for i in $(seq 1 40); do
    if curl -fsS -o /dev/null "$STREAMLIT_HEALTH_URL"; then
        ok "Streamlit healthy after ${i}s."
        STREAMLIT_READY=1
        break
    fi
    sleep 1
done
if [ "$STREAMLIT_READY" -eq 0 ]; then
    warn "Streamlit did not answer $STREAMLIT_HEALTH_URL yet. Last log lines:"
    tail -n 20 "$STREAMLIT_LOG" || true
fi

# ── 8. Endpoint smoke tests ──────────────────────────────────
check_redirect_or_401() {
    local url="$1"
    local label="$2"
    local code
    code=$(curl -s -o /dev/null -w '%{http_code}' -L --max-redirs 0 "$url" || true)
    case "$code" in
        302|303|307)
            ok "$label -> $code (redirect to login) ✓"
            ;;
        401|403)
            ok "$label -> $code (blocked) ✓"
            ;;
        200)
            fail "$label -> 200 but no session; auth gate not enforced."
            ;;
        *)
            fail "$label -> unexpected $code."
            ;;
    esac
}

log "Smoke-testing session-protected endpoints (expected redirect/401)..."
BASE="http://localhost:$FASTAPI_PORT"
check_redirect_or_401 "$BASE/dashboard"                  "GET /dashboard"
check_redirect_or_401 "$BASE/backtest/vpn"               "GET /backtest/vpn"
check_redirect_or_401 "$BASE/backtest/vpn/raw"           "GET /backtest/vpn/raw"
check_redirect_or_401 "$BASE/backtest/vpn/fragment"      "GET /backtest/vpn/fragment"
check_redirect_or_401 "$BASE/backtest/sumario"           "GET /backtest/sumario"
check_redirect_or_401 "$BASE/backtest/segmentacao"       "GET /backtest/segmentacao"
check_redirect_or_401 "$BASE/backtest/executar"          "GET /backtest/executar"
check_redirect_or_401 "$BASE/backtest/executar/00000000000000000000000000000000/status" \
                      "GET /backtest/executar/{job_id}/status"

log "Verifying / renders login page..."
CODE=$(curl -s -o /dev/null -w '%{http_code}' "$BASE/")
if [ "$CODE" = "200" ]; then
    ok "GET / -> 200 ✓"
else
    fail "GET / -> $CODE (expected 200)."
fi

log "Verifying /healthz..."
CODE=$(curl -s -o /dev/null -w '%{http_code}' "$BASE/healthz")
if [ "$CODE" = "200" ]; then
    ok "GET /healthz -> 200 ✓"
else
    fail "GET /healthz -> $CODE (expected 200)."
fi

# ── 9. Interactive mode ──────────────────────────────────────
echo ""
ok "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ok "  ${BOLD}Local app ready:${NC}"
ok "    FastAPI    → http://localhost:$FASTAPI_PORT"
ok "    Streamlit  → http://localhost:$STREAMLIT_PORT${STREAMLIT_BASE_URL_PATH%/}/"
ok "    Backtest   → http://localhost:$FASTAPI_PORT/backtest/vpn"
ok "  Test matricula whitelisted for allow-list: ${BOLD}F0000000${NC}"
ok "  Logs:"
ok "    FastAPI    → $FASTAPI_LOG"
ok "    Streamlit  → $STREAMLIT_LOG"
ok "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

if [ "$MODE_CI" -eq 1 ]; then
    log "--ci passed. Shutting down."
    exit "$FAILED"
fi

log "Press Ctrl+C to stop. Tailing FastAPI log:"
tail -n 0 -f "$FASTAPI_LOG" &
PIDS+=($!)
wait -n "${PIDS[@]}" 2>/dev/null || true
