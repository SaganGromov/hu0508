# Matricula Auth em OpenShift

Este guia descreve como publicar os arquivos de segredo de matricula no OpenShift e validar o funcionamento no dashboard.

## 0. Login no OpenShift (contexto atual)

Exemplo usado no seu ambiente:

```bash
oc login --token='<SEU_TOKEN>' --server='https://api.k8shmlbb111b.nuvem.bb.com.br:6443'
oc project acr-controle-acesso-dashboard
```

Observacoes:

- O projeto atual informado foi `acr-controle-acesso-dashboard`.
- Evite registrar token real em historico de shell, screenshots ou arquivos versionados.
- O warning `Using insecure TLS client config` pode aparecer conforme a configuracao local do cliente OC.

## 1. Pre-requisitos locais

- Arquivo de chave HMAC:
  - /home/wsl/acr-controle-acesso-dashboard/secrets/matricula_hmac_key
- Arquivo de digests permitidos:
  - /home/wsl/acr-controle-acesso-dashboard/secrets/allowed_matricula_digests
- Cliente OC autenticado no cluster

## 2. Criar ou atualizar a Secret no namespace

Defina o namespace desejado:

```bash
NS=acr-controle-acesso-dashboard
```

Crie ou atualize a Secret com apply:

```bash
oc -n "$NS" create secret generic acr-dashboard-auth-secrets \
  --from-file=matricula_hmac_key=/home/wsl/acr-controle-acesso-dashboard/secrets/matricula_hmac_key \
  --from-file=allowed_matricula_digests=/home/wsl/acr-controle-acesso-dashboard/secrets/allowed_matricula_digests \
  --dry-run=client -o yaml | oc apply -f -
```

## 3. Garantir que o values.yaml está apontando para os arquivos

No chart do dashboard, confirme:

- Variáveis de arquivo:
  - MATRICULA_HMAC_KEY_FILE=/run/secrets/matricula_hmac_key
  - ALLOWED_MATRICULA_DIGESTS_FILE=/run/secrets/allowed_matricula_digests
- Volume montando a Secret acr-dashboard-auth-secrets em /run/secrets

## 4. Aplicar rollout

```bash
oc -n "$NS" rollout restart deploy/acr-controle-acesso-dashboard
oc -n "$NS" rollout status deploy/acr-controle-acesso-dashboard
```

## 5. Validar em runtime

Verifique se os arquivos existem no pod:

```bash
POD=$(oc -n "$NS" get pod -l app=acr-controle-acesso-dashboard -o jsonpath='{.items[0].metadata.name}')
oc -n "$NS" exec "$POD" -- ls -l /run/secrets
```

Verifique logs de autorizacao:

```bash
oc -n "$NS" logs deploy/acr-controle-acesso-dashboard --tail=200 | grep -Ei "Login autorizado|Login negado|matricula"
```

## 6. Rotacao de segredos

Quando incluir ou remover matriculas:

1. Gere novamente os arquivos locais de segredo.
2. Reaplique o comando da etapa 2.
3. Execute rollout restart (etapa 4).

## 7. Troubleshooting rapido

- Erro de permissao para ler arquivo no container:
  - Confirme montagem do volume em /run/secrets.
  - Confirme se a Secret existe no mesmo namespace.
  - Em execucao local com Docker bind mount, normalize owner/permissoes:

```bash
cd /home/wsl/acr-controle-acesso-dashboard
./generate_matricula_secrets.local.sh
chmod 755 secrets
chmod 644 secrets/matricula_hmac_key secrets/allowed_matricula_digests
```

  - Se ainda falhar localmente, valide com usuario root no container (somente para teste local):

```bash
docker run --user 0:0 -p 8000:8000 -p 8501:8501 \
  -v "$(pwd)/secrets/matricula_hmac_key:/run/secrets/matricula_hmac_key:ro" \
  -v "$(pwd)/secrets/allowed_matricula_digests:/run/secrets/allowed_matricula_digests:ro" \
  --env-file .env acr-dashboard
```

- Todos os logins negados:
  - Confirme que as chaves da Secret sao exatamente:
    - matricula_hmac_key
    - allowed_matricula_digests
  - Confirme que os digests foram gerados com a mesma chave HMAC em uso.
