#!/usr/bin/env bash
set -euo pipefail

SECRETS_DIR="${1:-secrets}"
KEY_FILE="${SECRETS_DIR}/matricula_hmac_key"
DIGESTS_FILE="${SECRETS_DIR}/allowed_matricula_digests"

LISTA_MATRICULAS=(
  "F7021988"
  "F2243159"
  "F2549558"
  "F4696119"
  "F6768948"
  "F7021217"
  "F8241998"
  "F0720413"
  "C1331036"
  "F3855455"
  "F1693434"
  "F3514487"
  "F9456017"
  "F0621759"
  "F6002598"
  "C1340074"
)

if ! command -v openssl >/dev/null 2>&1; then
  echo "Erro: openssl nao encontrado no PATH."
  exit 1
fi

mkdir -p "${SECRETS_DIR}"
chmod 755 "${SECRETS_DIR}" || true

if [[ ! -s "${KEY_FILE}" ]]; then
  openssl rand -hex 32 > "${KEY_FILE}"
  echo "Chave HMAC criada em ${KEY_FILE}"
else
  echo "Chave HMAC existente sera reutilizada: ${KEY_FILE}"
fi

# Normaliza permissao/owner tambem para chaves antigas ja existentes.
chown "$(id -u):$(id -g)" "${KEY_FILE}" 2>/dev/null || true
chmod 644 "${KEY_FILE}" || true

: > "${DIGESTS_FILE}"
while IFS= read -r matricula; do
  [[ -z "${matricula}" ]] && continue
  digest=$(printf "%s" "${matricula}" | openssl dgst -sha256 -hmac "$(cat "${KEY_FILE}")" | awk '{print $2}')
  printf "%s\n" "${digest}" >> "${DIGESTS_FILE}"
done < <(printf "%s\n" "${LISTA_MATRICULAS[@]}")

chmod 644 "${DIGESTS_FILE}" || true
chown "$(id -u):$(id -g)" "${DIGESTS_FILE}" 2>/dev/null || true

cat <<EOF
Segredos gerados com sucesso.

Arquivos:
- ${KEY_FILE}
- ${DIGESTS_FILE}

Use no docker run:
  -v \
    $(pwd)/${KEY_FILE}:/run/secrets/matricula_hmac_key:ro \
  -v \
    $(pwd)/${DIGESTS_FILE}:/run/secrets/allowed_matricula_digests:ro

Se houver erro de permissao ao montar arquivos locais, execute:
  chmod a+r "${KEY_FILE}" "${DIGESTS_FILE}"
EOF
