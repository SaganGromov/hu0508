#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

if ! command -v uv >/dev/null 2>&1; then
    echo "Erro: uv nao encontrado no PATH."
    echo "Instale o uv antes de continuar: https://docs.astral.sh/uv/getting-started/installation/"
    exit 1
fi

export UV_CACHE_DIR="${UV_CACHE_DIR:-/tmp/uv-cache}"

if [ -f "$SCRIPT_DIR/bb.bundle.crt" ]; then
    export SSL_CERT_FILE="${SSL_CERT_FILE:-$SCRIPT_DIR/bb.bundle.crt}"
    export REQUESTS_CA_BUNDLE="${REQUESTS_CA_BUNDLE:-$SSL_CERT_FILE}"
fi

if [ -f "$SCRIPT_DIR/uv.lock" ]; then
    echo "Sincronizando ambiente virtual com uv.lock..."
    uv sync --frozen
else
    echo "uv.lock nao encontrado. Executando sincronizacao sem lock..."
    uv sync
fi

echo ""
echo "Ambiente configurado com sucesso."
echo "Para executar manualmente:"
echo "  source .venv/bin/activate"
echo "  ./run.sh"
