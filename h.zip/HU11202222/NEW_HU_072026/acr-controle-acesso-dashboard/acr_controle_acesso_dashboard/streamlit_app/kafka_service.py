"""Kafka service — shared configuration, parsers, store and consumer logic."""

import json
import logging
import os
import re
import secrets
import socket
import threading
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import pandas as pd
from confluent_kafka import Consumer, TopicPartition
from ip_utils import normalize_ip

BR_TZ = ZoneInfo("America/Sao_Paulo")

# ── Reusable constants (avoids duplicating literals) ──────────

_CONF_AUTO_OFFSET_RESET = "auto.offset.reset"
_CONF_ENABLE_AUTO_COMMIT = "enable.auto.commit"
_GROUP_ID_TS_FMT = "%Y%m%d%H%M%S"
_FIELD_OFFICE_MODE_IP = "office_mode_ip"
LOGGER = logging.getLogger(__name__)

# ── Kafka Configuration ───────────────────────────────────────

def _env_value(name: str, default: str = "") -> str:
    return os.environ.get(name, default).strip()


def _env_int(name: str, default: int) -> int:
    raw = _env_value(name)
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        LOGGER.warning("Ignoring invalid integer value for %s: %r", name, raw)
        return default


def _build_kafka_conf_base() -> dict:
    conf = {
        'bootstrap.servers': _env_value(
            'KAFKA_BOOTSTRAP_SERVERS',
            'acr-kafka-seguranca.desenv.bb.com.br:443',
        ),
        'security.protocol': _env_value('KAFKA_SECURITY_PROTOCOL', 'SASL_SSL'),
        'sasl.mechanism': _env_value('KAFKA_SASL_MECHANISM', 'SCRAM-SHA-512'),
        'sasl.username': _env_value('KAFKA_SASL_USERNAME'),
        'sasl.password': _env_value('KAFKA_SASL_PASSWORD'),
    }
    ca_location = _env_value('KAFKA_SSL_CA_LOCATION')
    if ca_location:
        conf['ssl.ca.location'] = ca_location
    return conf


KAFKA_CONF_BASE = _build_kafka_conf_base()

TOPIC = _env_value('KAFKA_TOPIC', 'acr.vpn.redis.logs')
MAX_EVENTS = 15000
_CONF_GROUP_ID = 'group.id'
REALTIME_GROUP_PREFIX = _env_value('KAFKA_GROUP_ID', 'dashboard-consumer') or 'dashboard-consumer'
REALTIME_GROUP_ID = (
    f"{REALTIME_GROUP_PREFIX}-{socket.gethostname()}-{os.getpid()}-{secrets.token_hex(4)}"
)


def _new_consumer(conf: dict) -> Consumer:
    """Cria consumer somente com destino explicitamente configurado."""
    if not str(conf.get("bootstrap.servers") or "").strip():
        raise RuntimeError("KAFKA_BOOTSTRAP_SERVERS não configurado.")
    return Consumer(conf)

# Fields extracted per login transaction
_LOGIN_FIELDS = [
    ("status", lambda m: m.get("status", "")),
    ("src_ip", lambda m: normalize_ip(m.get("src")) or ""),
    ("hostname", lambda m: m.get("hostname", "")),
    ("os", lambda m: f"{m.get('os_name', '')} {m.get('os_version', '')}".strip()),
    ("tunnel", lambda m: m.get("tunnel_protocol", "")),
    ("client_version", lambda m: m.get("client_version", "")),
    ("login_option", lambda m: m.get("login_option", "")),
    ("mac_address", lambda m: m.get("mac_address", "")),
    ("origin", lambda m: m.get("origin", "")),
    ("session_uid", lambda m: m.get("session_uid", "")),
    ("user_group", lambda m: m.get("user_group", "")),
    ("fingerprint", lambda m: m.get("fingerprint", "")),
]


# ── Parsers ───────────────────────────────────────────────────

def extract_username(user_field: str) -> str:
    if not user_field:
        return "Desconhecido"
    if "(" in user_field:
        inside = user_field.split("(", 1)[1].rstrip(")")
        name = re.sub(r'^[A-Za-z]\d{7}\s*', '', inside).strip()
        return name.title() if name else user_field.split("(")[0].strip()
    return user_field


def extract_chave(user_dn: str) -> str:
    if not user_dn:
        return ""
    match = re.search(r'\b([A-Za-z]\d{7})\b', user_dn)
    return match.group(1).upper() if match else ""


def parse_timestamp(msg: dict) -> datetime:
    ts_raw = msg.get("login_timestamp") or msg.get("time", 0)
    try:
        if ts_raw:
            dt = datetime.fromtimestamp(ts_raw, tz=BR_TZ)
            return dt.replace(tzinfo=None)
        return datetime.now(tz=BR_TZ).replace(tzinfo=None)
    except (ValueError, OSError):
        return datetime.now(tz=BR_TZ).replace(tzinfo=None)


def _build_login_dict(msg: dict, ts: datetime, chave: str, user: str, user_dn: str, loguid: str) -> dict:
    """Build a new login transaction dict from a raw message."""
    login = {
        "timestamp": ts,
        "loguid": loguid,
        "chave": chave,
        "user": user,
        "user_dn": user_dn,
        _FIELD_OFFICE_MODE_IP: normalize_ip(msg.get(_FIELD_OFFICE_MODE_IP)) or "",
        "eventos": 1,
    }
    for field, extractor in _LOGIN_FIELDS:
        login[field] = extractor(msg)
    return login


def _merge_login(login: dict, msg: dict, ts: datetime, chave: str, user: str, user_dn: str):
    """Merge a new message into an existing login transaction."""
    login["eventos"] += 1
    login["timestamp"] = min(login["timestamp"], ts)
    for field, extractor in _LOGIN_FIELDS:
        if not login.get(field):
            val = extractor(msg)
            if val:
                login[field] = val
    for field, val in [("chave", chave), ("user", user), ("user_dn", user_dn)]:
        if not login.get(field) and val:
            login[field] = val
    oip = normalize_ip(msg.get(_FIELD_OFFICE_MODE_IP))
    if oip:
        login[_FIELD_OFFICE_MODE_IP] = oip


# ── KafkaStore (real-time) ────────────────────────────────────

class KafkaStore:
    """Thread-safe store for raw events and pre-aggregated login transactions."""

    def __init__(self, max_events: int = MAX_EVENTS):
        self._lock = threading.Lock()
        self._raw_events: list[dict] = []
        self._logins: dict[str, dict] = {}
        self._event_count = 0
        self._last_received_at: datetime | None = None
        self._max_events = max_events

    @property
    def event_count(self) -> int:
        with self._lock:
            return self._event_count

    def get_status(self) -> dict:
        with self._lock:
            return {
                "event_count": self._event_count,
                "last_received_at": self._last_received_at,
            }

    def add_event(self, msg: dict):
        loguid = msg.get("loguid", "")
        ts = parse_timestamp(msg)
        user_dn = msg.get("user_dn", "")
        chave = extract_chave(user_dn)
        user = extract_username(msg.get("user", ""))

        with self._lock:
            self._raw_events.append(msg)
            if len(self._raw_events) > self._max_events:
                self._raw_events = self._raw_events[-self._max_events:]
                remaining_uids = {e.get("loguid", "") for e in self._raw_events}
                for uid in list(self._logins.keys()):
                    if uid not in remaining_uids:
                        del self._logins[uid]
            self._event_count += 1
            self._last_received_at = datetime.now(tz=BR_TZ).replace(tzinfo=None)

            if loguid in self._logins:
                _merge_login(self._logins[loguid], msg, ts, chave, user, user_dn)
            else:
                self._logins[loguid] = _build_login_dict(msg, ts, chave, user, user_dn, loguid)

    def get_logins_df(self) -> pd.DataFrame:
        with self._lock:
            if not self._logins:
                return pd.DataFrame()
            return pd.DataFrame(list(self._logins.values()))

    def clear(self):
        with self._lock:
            self._raw_events.clear()
            self._logins.clear()
            self._event_count = 0
            self._last_received_at = None


def start_realtime_consumer(store: KafkaStore, stop_event: threading.Event):
    """Background thread: continuously polls Kafka and feeds the store."""
    conf = {
        **KAFKA_CONF_BASE,
        _CONF_GROUP_ID: REALTIME_GROUP_ID,
        _CONF_AUTO_OFFSET_RESET: _env_value('KAFKA_AUTO_OFFSET_RESET', 'latest'),
    }
    consumer = _new_consumer(conf)
    try:
        _start_realtime_assignment(consumer)
        logged_errors: set[str] = set()
        while not stop_event.is_set():
            msg = consumer.poll(0.3)
            if msg is None:
                continue
            if msg.error():
                error_text = str(msg.error())
                if error_text not in logged_errors:
                    LOGGER.warning("Kafka realtime consumer error: %s", error_text)
                    logged_errors.add(error_text)
                continue
            try:
                valor = json.loads(msg.value().decode('utf-8'))
                store.add_event(valor)
            except (json.JSONDecodeError, UnicodeDecodeError, AttributeError):
                continue
    finally:
        consumer.close()


# ── Historical consumer ──────────────────────────────────────

def _get_topic_partitions(consumer: Consumer) -> dict:
    metadata = consumer.list_topics(topic=TOPIC, timeout=10)
    topic_metadata = metadata.topics.get(TOPIC)
    if topic_metadata is None:
        raise RuntimeError(f"Kafka topic not found: {TOPIC}")
    if getattr(topic_metadata, "error", None):
        raise RuntimeError(f"Kafka topic metadata error for {TOPIC}: {topic_metadata.error}")
    return topic_metadata.partitions


def _assign_partitions_from_beginning(consumer: Consumer, partitions: dict) -> list[TopicPartition]:
    tps = [TopicPartition(TOPIC, pid, 0) for pid in partitions]
    consumer.assign(tps)
    return tps


def _assign_partitions_from_time(consumer: Consumer, partitions: dict, minutes_ago: int) -> list[TopicPartition]:
    target_ts_ms = int((datetime.now() - timedelta(minutes=minutes_ago)).timestamp() * 1000)
    offsets = consumer.offsets_for_times(
        [TopicPartition(TOPIC, pid, target_ts_ms) for pid in partitions]
    )
    valid_tps = [TopicPartition(TOPIC, tp.partition, tp.offset) for tp in offsets if tp.offset >= 0]
    if valid_tps:
        consumer.assign(valid_tps)
    return valid_tps


def _assign_partitions_at_end(consumer: Consumer, partitions: dict) -> list[TopicPartition]:
    tps = []
    for pid in partitions:
        _, hi = consumer.get_watermark_offsets(TopicPartition(TOPIC, pid))
        tps.append(TopicPartition(TOPIC, pid, hi))
    if tps:
        consumer.assign(tps)
    return tps


def _start_realtime_assignment(consumer: Consumer):
    lookback_minutes = _env_int("KAFKA_REALTIME_LOOKBACK_MINUTES", 0)
    if lookback_minutes <= 0:
        consumer.subscribe([TOPIC])
        return

    partitions = _get_topic_partitions(consumer)
    assigned = _assign_partitions_from_time(consumer, partitions, lookback_minutes)
    if assigned:
        LOGGER.info(
            "Kafka realtime consumer assigned %s partition(s) from the last %s minute(s)",
            len(assigned),
            lookback_minutes,
        )
        return

    fallback = _assign_partitions_at_end(consumer, partitions)
    LOGGER.info(
        "Kafka realtime lookback found no retained messages; assigned %s partition(s) at end",
        len(fallback),
    )


def _estimate_total_messages(consumer: Consumer, assigned_partitions: list[TopicPartition]) -> int:
    total = 0
    for tp in assigned_partitions:
        _, hi = consumer.get_watermark_offsets(TopicPartition(TOPIC, tp.partition))
        total += max(0, hi - tp.offset)
    return total


def _consume_aggregated_logins(
    consumer: Consumer,
    effective_max: int,
    on_progress=None,
    target_chave: str | None = None,
) -> tuple[pd.DataFrame, int]:
    logins: dict[str, dict] = {}
    rejected_loguids: set[str] = set()
    consumed = 0
    empty_polls = 0
    normalized_target = target_chave.strip().upper() if target_chave else None

    while consumed < effective_max:
        msg = consumer.poll(1.0)
        if msg is None:
            empty_polls += 1
            if empty_polls > 10:
                break
            continue

        empty_polls = 0
        if msg.error():
            continue

        consumed += 1
        try:
            payload = json.loads(msg.value().decode('utf-8'))
        except (json.JSONDecodeError, UnicodeDecodeError, AttributeError):
            if on_progress and consumed % 1000 == 0:
                on_progress(consumed, effective_max)
            continue

        loguid = payload.get("loguid", "")
        if not loguid:
            if on_progress and consumed % 1000 == 0:
                on_progress(consumed, effective_max)
            continue

        if normalized_target and loguid in rejected_loguids:
            if on_progress and consumed % 1000 == 0:
                on_progress(consumed, effective_max)
            continue

        ts = parse_timestamp(payload)
        user_dn = payload.get("user_dn", "")
        chave_atual = extract_chave(user_dn)
        user = extract_username(payload.get("user", ""))

        if loguid in logins:
            _merge_login(logins[loguid], payload, ts, chave_atual, user, user_dn)
        else:
            logins[loguid] = _build_login_dict(payload, ts, chave_atual, user, user_dn, loguid)

        if normalized_target:
            login_chave = logins[loguid].get("chave", "")
            if login_chave and login_chave != normalized_target:
                rejected_loguids.add(loguid)
                del logins[loguid]

        if on_progress and consumed % 1000 == 0:
            on_progress(consumed, effective_max)

    if on_progress:
        on_progress(consumed, effective_max)

    if not logins:
        return pd.DataFrame(), consumed

    df = pd.DataFrame(list(logins.values()))
    if normalized_target:
        df = df[df["chave"] == normalized_target]
    return df, consumed


def consume_all_logins(
    max_messages: int | None = None,
    on_progress=None,
    target_chave: str | None = None,
) -> tuple[pd.DataFrame, int]:
    """Consume Kafka from the beginning and aggregate login transactions on the fly."""
    conf = {
        **KAFKA_CONF_BASE,
        _CONF_GROUP_ID: f'historical-report-{datetime.now().strftime(_GROUP_ID_TS_FMT)}',
        _CONF_AUTO_OFFSET_RESET: 'earliest',
        _CONF_ENABLE_AUTO_COMMIT: False,
    }
    consumer = _new_consumer(conf)

    try:
        partitions = _get_topic_partitions(consumer)
        assigned_partitions = _assign_partitions_from_beginning(consumer, partitions)
        total_messages = _estimate_total_messages(consumer, assigned_partitions)
        if total_messages == 0:
            return pd.DataFrame(), 0

        effective_max = total_messages if max_messages is None else min(max_messages, total_messages)
        return _consume_aggregated_logins(
            consumer,
            effective_max,
            on_progress=on_progress,
            target_chave=target_chave,
        )
    finally:
        consumer.close()


def consume_logins_since(
    minutes_ago: int,
    max_messages: int | None = None,
    on_progress=None,
    target_chave: str | None = None,
) -> tuple[pd.DataFrame, int]:
    """Consume Kafka from a relative timestamp and aggregate login transactions on the fly."""
    conf = {
        **KAFKA_CONF_BASE,
        _CONF_GROUP_ID: f'retroactive-{datetime.now().strftime(_GROUP_ID_TS_FMT)}',
        _CONF_AUTO_OFFSET_RESET: 'latest',
        _CONF_ENABLE_AUTO_COMMIT: False,
    }
    consumer = _new_consumer(conf)

    try:
        partitions = _get_topic_partitions(consumer)
        assigned_partitions = _assign_partitions_from_time(consumer, partitions, minutes_ago)
        if not assigned_partitions:
            return pd.DataFrame(), 0

        total_messages = _estimate_total_messages(consumer, assigned_partitions)
        if total_messages == 0:
            return pd.DataFrame(), 0

        effective_max = total_messages if max_messages is None else min(max_messages, total_messages)
        return _consume_aggregated_logins(
            consumer,
            effective_max,
            on_progress=on_progress,
            target_chave=target_chave,
        )
    finally:
        consumer.close()

def consume_all_messages(max_messages: int | None = None, on_progress=None) -> list[dict]:
    """Consume all available messages from Kafka topic from the beginning.

    on_progress(consumed, total): optional callback for progress updates.
    """
    conf = {
        **KAFKA_CONF_BASE,
        _CONF_GROUP_ID: f'historical-report-{datetime.now().strftime(_GROUP_ID_TS_FMT)}',
        _CONF_AUTO_OFFSET_RESET: 'earliest',
        _CONF_ENABLE_AUTO_COMMIT: False,
    }
    consumer = _new_consumer(conf)

    metadata = consumer.list_topics(topic=TOPIC, timeout=10)
    partitions = metadata.topics[TOPIC].partitions
    tps = [TopicPartition(TOPIC, pid, 0) for pid in partitions]
    consumer.assign(tps)

    end_offsets = {}
    for tp in tps:
        _, hi = consumer.get_watermark_offsets(tp)
        end_offsets[tp.partition] = hi
    total_messages = sum(end_offsets.values())

    if total_messages == 0:
        consumer.close()
        return []

    effective_max = total_messages if max_messages is None else min(max_messages, total_messages)
    messages: list[dict] = []
    empty_polls = 0

    while len(messages) < effective_max:
        msg = consumer.poll(1.0)
        if msg is None:
            empty_polls += 1
            if empty_polls > 10:
                break
            continue
        empty_polls = 0
        if msg.error():
            continue
        try:
            messages.append(json.loads(msg.value().decode('utf-8')))
        except (json.JSONDecodeError, UnicodeDecodeError, AttributeError):
            continue

        if on_progress and len(messages) % 500 == 0:
            on_progress(len(messages), effective_max)

    consumer.close()
    if on_progress:
        on_progress(len(messages), effective_max)
    return messages


def consume_messages_since(minutes_ago: int, max_messages: int | None = None, on_progress=None) -> list[dict]:
    """Consume messages from the last *minutes_ago* minutes.

    Uses offsets_for_times to seek each partition to the target timestamp.
    """
    conf = {
        **KAFKA_CONF_BASE,
        'group.id': f'retroactive-{datetime.now().strftime(_GROUP_ID_TS_FMT)}',
        _CONF_AUTO_OFFSET_RESET: 'latest',
        _CONF_ENABLE_AUTO_COMMIT: False,
    }
    consumer = _new_consumer(conf)

    metadata = consumer.list_topics(topic=TOPIC, timeout=10)
    partitions = metadata.topics[TOPIC].partitions

    target_ts_ms = int((datetime.now() - timedelta(minutes=minutes_ago)).timestamp() * 1000)
    tps = [TopicPartition(TOPIC, pid, target_ts_ms) for pid in partitions]
    offsets = consumer.offsets_for_times(tps)

    valid_tps = [tp for tp in offsets if tp.offset >= 0]
    if not valid_tps:
        consumer.close()
        return []

    consumer.assign(valid_tps)

    total = 0
    for tp in valid_tps:
        _, hi = consumer.get_watermark_offsets(tp)
        total += max(0, hi - tp.offset)

    if total == 0:
        consumer.close()
        return []

    effective_max = total if max_messages is None else min(max_messages, total)
    messages: list[dict] = []
    empty_polls = 0

    while len(messages) < effective_max:
        msg = consumer.poll(1.0)
        if msg is None:
            empty_polls += 1
            if empty_polls > 10:
                break
            continue
        empty_polls = 0
        if msg.error():
            continue
        try:
            messages.append(json.loads(msg.value().decode('utf-8')))
        except (json.JSONDecodeError, UnicodeDecodeError, AttributeError):
            continue

        if on_progress and len(messages) % 500 == 0:
            on_progress(len(messages), effective_max)

    consumer.close()
    if on_progress:
        on_progress(len(messages), effective_max)
    return messages


def search_logins_by_chave_since(
    chave: str,
    minutes_ago: int,
    max_messages: int | None = 50000,
    on_progress=None,
) -> tuple[pd.DataFrame, int]:
    """Scan Kafka for a single matrícula and keep only matching login aggregations."""
    target_chave = chave.strip().upper()
    if not target_chave:
        return pd.DataFrame(), 0

    return consume_logins_since(
        minutes_ago,
        max_messages=max_messages,
        on_progress=on_progress,
        target_chave=target_chave,
    )


def build_logins_df(messages: list[dict]) -> pd.DataFrame:
    """Aggregate raw messages into login transactions."""
    logins: dict[str, dict] = {}
    for msg in messages:
        loguid = msg.get("loguid", "")
        ts = parse_timestamp(msg)
        user_dn = msg.get("user_dn", "")
        chave = extract_chave(user_dn)
        user = extract_username(msg.get("user", ""))

        if loguid in logins:
            _merge_login(logins[loguid], msg, ts, chave, user, user_dn)
        else:
            logins[loguid] = _build_login_dict(msg, ts, chave, user, user_dn, loguid)

    if not logins:
        return pd.DataFrame()
    return pd.DataFrame(list(logins.values()))
