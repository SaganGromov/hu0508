import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import timedelta
import re
import threading
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))
from kafka_service import KafkaStore, start_realtime_consumer, MAX_EVENTS, consume_logins_since
from auth_token import resolve_authenticated_user
from curio_service import integracao_curio
from curio_models import PAYLOAD_OP292018V3
from export_utils import render_csv_downloads, set_export_audit_context
from audit_service import record_action

_LBL_USUARIOS_UNICOS = "Usuários Únicos"
_LBL_USUARIO = "Usuário"
_LBL_IPS_UNICOS = "IPs Únicos"
_LBL_HOSTNAMES_UNICOS = "Hostnames Únicos"
_LBL_EXPORTAR_ALERTA = "Exportar alerta"

st.set_page_config(page_title="VPN Login Dashboard", layout="wide")

# ── Auth gate ─────────────────────────────────────────────────
_user_id = resolve_authenticated_user()
if _user_id is None:
    st.error("Acesso não autorizado. Faça login novamente pelo portal principal do dashboard.")
    st.stop()
set_export_audit_context(_user_id, "tempo_real")

st.title("Dashboard VPN - Logins")


@st.cache_resource
def get_store_and_thread():
    store = KafkaStore(max_events=MAX_EVENTS)
    stop_event = threading.Event()
    t = threading.Thread(target=start_realtime_consumer, args=(store, stop_event), daemon=True)
    t.start()
    return store, stop_event


@st.cache_data(ttl=300)
def fetch_curio_funcionario(chave: str) -> dict | None:
    """Consulta dados organizacionais do funcionário via sidecar curio."""
    payload = {**PAYLOAD_OP292018V3, "codigoClientePesquisa": chave.upper()}
    return integracao_curio("op292018v3", payload)


# ── Shared display logic ─────────────────────────────────────

def render_dashboard(df_logins, search_chave, table_rows):
    """Render KPIs, charts, alerts and login table for a given DataFrame."""

    # Filter
    if search_chave:
        if re.match(r'^[A-Za-z]\d{0,7}$', search_chave):
            df_filtered = df_logins[df_logins["chave"].str.startswith(search_chave, na=False)]
        else:
            df_filtered = df_logins[df_logins["chave"] == search_chave]
        if df_filtered.empty:
            st.warning(f"Nenhum login encontrado para a chave '{search_chave}'")
            return
    else:
        df_filtered = df_logins

    # ── Dados Organizacionais (curio) ─────────────────────────
    if search_chave and re.match(r'^[A-Za-z]\d{7}$', search_chave):
        curio = fetch_curio_funcionario(search_chave)
        with st.expander("📋 Dados Organizacionais do Funcionário (curio)", expanded=True):
            if curio:
                curio_df = pd.DataFrame([curio])
                c1, c2, c3, c4 = st.columns(4)
                c1.metric("Nome", curio.get("nomeUsuario", "-"))
                c2.metric("Prefixo Dependência Atual", curio.get("codigoPrefixoDependenciaAtual", "-"))
                c3.metric("Código Técnico", curio.get("codigoTecnico", "-"))
                c4.metric("Comissão", curio.get("codigoComissaoUsuario", "-"))
                c5, c6, c7, c8 = st.columns(4)
                c5.metric("UO Dependência", curio.get("codigoUnidadeOrganizacionalDependenciaUsuario", "-"))
                c6.metric("Tipo UO Dependência", curio.get("codigoTipoUnidadeOrganizacionalDependencia", "-"))
                c7.metric("Perfil Org.", curio.get("codigoReferenciaOrganizacionalPerfil", "-"))
                c8.metric("Tipo Usuário", curio.get("codigoTipoUsuario", "-"))
                render_csv_downloads(
                    [("dados do funcionario", curio_df, f"curio_{search_chave}.csv")],
                    heading="Exportar dados do funcionário",
                    columns=1,
                )
            else:
                st.warning("Não foi possível obter dados organizacionais do sidecar curio.")

    # KPIs
    col1, col2, col3, col4, col5 = st.columns(5)
    total_logins = len(df_filtered)
    unique_users = df_filtered["chave"].nunique()
    success_rate = (
        len(df_filtered[df_filtered["status"] == "Success"]) / total_logins * 100
        if total_logins > 0 else 0
    )
    unique_hosts = df_filtered["hostname"].nunique()
    total_events = int(df_filtered["eventos"].sum())

    col1.metric("Logins Únicos", total_logins)
    col2.metric(_LBL_USUARIOS_UNICOS, unique_users)
    col3.metric("Taxa de Sucesso", f"{success_rate:.1f}%")
    col4.metric("Hosts Únicos", unique_hosts)
    col5.metric("Eventos (msgs)", total_events)

    st.markdown("---")

    df_time = df_filtered.copy()
    df_time["minute"] = df_time["timestamp"].dt.floor("min")
    login_rate = df_time.groupby("minute").size().reset_index(name="logins")

    user_counts = df_filtered.groupby(["chave", "user"]).size().reset_index(name="Logins")
    user_counts["label"] = user_counts["chave"] + " - " + user_counts["user"]
    top_user_counts = user_counts.nlargest(15, "Logins")

    os_counts = df_filtered["os"].value_counts().reset_index()
    os_counts.columns = ["SO", "Quantidade"]

    tunnel_counts = df_filtered["tunnel"].value_counts().reset_index()
    tunnel_counts.columns = ["Protocolo", "Quantidade"]

    # Charts row 1
    chart1, chart2 = st.columns(2)

    with chart1:
        st.subheader("Taxa de Logins ao Longo do Tempo")
        fig_rate = px.area(login_rate, x="minute", y="logins",
                           labels={"minute": "Horário", "logins": "Logins/min"})
        fig_rate.update_layout(height=350, margin=dict(l=20, r=20, t=10, b=20))
        st.plotly_chart(fig_rate, width='stretch')

    with chart2:
        st.subheader("Top 15 Usuários (Logins)")
        fig_users = px.bar(top_user_counts, x="Logins", y="label", orientation="h",
                           color="Logins", color_continuous_scale="Blues",
                           labels={"label": _LBL_USUARIO})
        fig_users.update_layout(height=350, margin=dict(l=20, r=20, t=10, b=20),
                                yaxis=dict(autorange="reversed"))
        st.plotly_chart(fig_users, width='stretch')

    # Charts row 2
    chart3, chart4 = st.columns(2)

    with chart3:
        st.subheader("Distribuição por Sistema Operacional")
        fig_os = px.pie(os_counts, names="SO", values="Quantidade", hole=0.4)
        fig_os.update_layout(height=350, margin=dict(l=20, r=20, t=10, b=20))
        st.plotly_chart(fig_os, width='stretch')

    with chart4:
        st.subheader("Protocolo de Túnel")
        fig_tunnel = px.pie(tunnel_counts, names="Protocolo", values="Quantidade", hole=0.4)
        fig_tunnel.update_layout(height=350, margin=dict(l=20, r=20, t=10, b=20))
        st.plotly_chart(fig_tunnel, width='stretch')

    render_csv_downloads(
        [
            ("taxa de logins", login_rate, "dashboard_taxa_logins.csv"),
            ("top usuarios", top_user_counts[["chave", "user", "Logins"]], "dashboard_top_usuarios.csv"),
            ("distribuicao por so", os_counts, "dashboard_distribuicao_so.csv"),
            ("protocolo de tunel", tunnel_counts, "dashboard_protocolos_tunel.csv"),
        ],
        heading="Exportar dados dos gráficos",
    )

    # Alerts
    host_user = df_filtered.groupby("hostname")["chave"].nunique().reset_index()
    host_user.columns = ["Hostname", _LBL_USUARIOS_UNICOS]
    host_user = host_user[host_user["Hostname"] != ""].sort_values(_LBL_USUARIOS_UNICOS, ascending=False)
    multi_user_hosts = host_user[host_user[_LBL_USUARIOS_UNICOS] > 1]
    shared_hosts_df = pd.DataFrame()
    if not multi_user_hosts.empty:
        shared_rows = []
        for hostname in multi_user_hosts["Hostname"].tolist():
            users = df_filtered[df_filtered["hostname"] == hostname][["chave", "user"]].drop_duplicates()
            for _, u in users.iterrows():
                shared_rows.append({"Hostname": hostname, "Chave": u["chave"], _LBL_USUARIO: u["user"]})
        shared_hosts_df = pd.DataFrame(shared_rows)

    user_ips = df_filtered.groupby("chave")["src_ip"].nunique().reset_index()
    user_ips.columns = ["Chave", _LBL_IPS_UNICOS]
    user_ips = user_ips[user_ips["Chave"] != ""].sort_values(_LBL_IPS_UNICOS, ascending=False)
    multi_ip_users = user_ips[user_ips[_LBL_IPS_UNICOS] > 1]
    multi_ip_df = pd.DataFrame()
    if not multi_ip_users.empty:
        multi_ip_rows = []
        for chave in multi_ip_users["Chave"].tolist():
            rr = df_filtered[df_filtered["chave"] == chave][["chave", "user", "src_ip", "hostname"]].drop_duplicates(subset=["chave", "src_ip"])
            for _, r in rr.iterrows():
                multi_ip_rows.append({"Chave": r["chave"], _LBL_USUARIO: r["user"], "IP Origem": r["src_ip"], "Hostname": r["hostname"]})
        multi_ip_df = pd.DataFrame(multi_ip_rows)

    user_hosts = df_filtered.groupby("chave")["hostname"].nunique().reset_index()
    user_hosts.columns = ["Chave", _LBL_HOSTNAMES_UNICOS]
    user_hosts = user_hosts[user_hosts["Chave"] != ""].sort_values(_LBL_HOSTNAMES_UNICOS, ascending=False)
    multi_host_users = user_hosts[user_hosts[_LBL_HOSTNAMES_UNICOS] > 1]
    multi_host_df = pd.DataFrame()
    if not multi_host_users.empty:
        multi_host_rows = []
        for chave in multi_host_users["Chave"].tolist():
            rr = df_filtered[df_filtered["chave"] == chave][["chave", "user", "hostname"]].drop_duplicates(subset=["chave", "hostname"])
            for _, r in rr.iterrows():
                multi_host_rows.append({"Chave": r["chave"], _LBL_USUARIO: r["user"], "Hostname": r["hostname"]})
        multi_host_df = pd.DataFrame(multi_host_rows)

    alert1, alert2, alert3 = st.columns(3)

    with alert1:
        st.subheader("Hostnames com Múltiplos Usuários")
        if not multi_user_hosts.empty:
            st.warning(f"{len(multi_user_hosts)} hostname(s) com múltiplos usuários")
            st.dataframe(shared_hosts_df, width='stretch', hide_index=True)
            render_csv_downloads(
                [("hostnames compartilhados", shared_hosts_df, "dashboard_hostnames_compartilhados.csv")],
                heading=_LBL_EXPORTAR_ALERTA,
                columns=1,
            )
        else:
            st.success("Nenhum hostname compartilhado entre múltiplos usuários")

    with alert2:
        st.subheader("Usuários com Múltiplos IPs")
        if not multi_ip_users.empty:
            st.warning(f"{len(multi_ip_users)} usuário(s) logaram de múltiplos IPs")
            st.dataframe(multi_ip_df, width='stretch', hide_index=True)
            render_csv_downloads(
                [("usuarios multiplos ips", multi_ip_df, "dashboard_multiplos_ips.csv")],
                heading=_LBL_EXPORTAR_ALERTA,
                columns=1,
            )
        else:
            st.success("Nenhum usuário logou de múltiplos IPs")

    with alert3:
        st.subheader("Usuários com Múltiplos Hostnames")
        if not multi_host_users.empty:
            st.warning(f"{len(multi_host_users)} usuário(s) logaram de múltiplos hostnames")
            st.dataframe(multi_host_df, width='stretch', hide_index=True)
            render_csv_downloads(
                [("usuarios multiplos hostnames", multi_host_df, "dashboard_multiplos_hostnames.csv")],
                heading=_LBL_EXPORTAR_ALERTA,
                columns=1,
            )
        else:
            st.success("Nenhum usuário logou de múltiplos hostnames")

    # Logins table
    st.subheader("Logins (Transações Correlacionadas)")
    display_cols = [
        "timestamp", "chave", "user", "src_ip",
        "office_mode_ip", "hostname", "os", "tunnel", "login_option",
        "client_version", "mac_address", "fingerprint", "user_group",
    ]
    display_df = df_filtered.sort_values("timestamp", ascending=False)
    display_cols = [c for c in display_cols if c in display_df.columns]
    visible_logins_df = display_df[display_cols].head(table_rows)
    st.dataframe(
        visible_logins_df,
        width='stretch',
        hide_index=True,
        column_config={
            "timestamp": st.column_config.DatetimeColumn("Horário", format="DD/MM/YYYY HH:mm:ss"),
            "chave": "Chave", "user": _LBL_USUARIO, "status": "Status",
            "src_ip": "IP Origem", "hostname": "Hostname", "os": "SO",
            "tunnel": "Túnel", "login_option": "Opção Login",
            "client_version": "Versão Cliente", "mac_address": "MAC",
            "office_mode_ip": "IP Office Mode", "fingerprint": "Fingerprint",
            "user_group": "Grupo",
        },
    )
    render_csv_downloads(
        [
            ("logins visiveis", visible_logins_df, "dashboard_logins_visiveis.csv"),
            ("logins filtrados", display_df[display_cols], "dashboard_logins_filtrados.csv"),
        ],
        heading="Exportar logins",
        columns=2,
    )


# ── Mode selection ────────────────────────────────────────────
mode = st.radio("Modo", ["Tempo Real", "Retroativo"], horizontal=True, key="dashboard_mode")


# ══════════════════════════════════════════════════════════════
# TEMPO REAL
# ══════════════════════════════════════════════════════════════
if mode == "Tempo Real":
    store, _stop = get_store_and_thread()

    ctrl1, ctrl2, ctrl3 = st.columns([1, 1, 1])
    with ctrl1:
        search_chave = st.text_input(
            "Pesquisar por chave",
            placeholder="Ex: F1234567",
            key="rt_search",
        ).strip().upper()
    with ctrl2:
        refresh_rate = st.selectbox("Atualização (s)", [1, 3, 5, 10, 15, 30], index=1, key="rt_refresh")
    with ctrl3:
        table_rows = st.selectbox("Linhas na tabela", [50, 100, 500, 2500, 5000], index=1, key="rt_rows")

    if search_chave and search_chave != st.session_state.get("_audit_rt_last_search"):
        record_action(_user_id, "BUSCA_TEMPO_REAL", "tempo_real", {"chave": search_chave})
        st.session_state["_audit_rt_last_search"] = search_chave

    @st.fragment(run_every=timedelta(seconds=refresh_rate))
    def live_dashboard():
        df_logins = store.get_logins_df()
        status = store.get_status()
        last_received = status.get("last_received_at")
        if last_received:
            st.caption(
                f"{status['event_count']:,} eventos Kafka recebidos neste processo "
                f"desde que ele iniciou. Última mensagem recebida em "
                f"{last_received.strftime('%d/%m/%Y %H:%M:%S')}."
            )
        if df_logins.empty:
            st.info("Aguardando mensagens do Kafka... O consumer está rodando em background.")
            return
        render_dashboard(df_logins, search_chave, table_rows)

    live_dashboard()


else:
    TIME_OPTIONS = {
        "30 minutos": 30,
        "1 hora": 60,
        "2 horas": 120,
        "4 horas": 240,
        "8 horas": 480,
        "12 horas": 720,
        "24 horas": 1440,
        "3 dias": 3 * 24 * 60,
        "7 dias": 7 * 24 * 60,
    }

    ctrl1, ctrl2, ctrl3, ctrl4 = st.columns([1, 1, 1, 1])
    with ctrl1:
        time_window = st.selectbox("Janela de tempo", list(TIME_OPTIONS.keys()), index=1, key="retro_window")
    with ctrl2:
        search_matricula = st.text_input(
            "Filtrar por matrícula",
            placeholder="Ex: F1234567",
            key="retro_search",
        ).strip().upper()
    with ctrl3:
        table_rows = st.selectbox("Linhas na tabela", [50, 100, 500, 2500, 5000], index=1, key="retro_rows")
    with ctrl4:
        st.markdown("<br>", unsafe_allow_html=True)
        if st.button("🔍 Buscar", type="primary"):
            record_action(_user_id, "BUSCA_RETROATIVA", "tempo_real", {
                "janela": time_window, "chave": search_matricula,
            })
            st.session_state["retro_run"] = True
            st.session_state["retro_minutes"] = TIME_OPTIONS[time_window]
            st.session_state["retro_target_chave"] = search_matricula
            st.session_state.pop("retro_df", None)
            st.session_state.pop("retro_msg_count", None)

    # ── Consume retroactive data ──────────────────────────────
    if st.session_state.get("retro_run") and "retro_df" not in st.session_state:
        minutes = st.session_state["retro_minutes"]
        st.info(f"Consumindo mensagens dos últimos {minutes} minutos do Kafka...")
        progress_bar = st.progress(0, text="Conectando ao Kafka...")

        def _on_progress(consumed, total):
            pct = consumed / total if total else 0
            progress_bar.progress(min(pct, 1.0), text=f"{consumed:,} / {total:,} mensagens")

        target_chave = st.session_state.get("retro_target_chave", "")
        optimized_target = target_chave if re.fullmatch(r'[A-Za-z]\d{7}', target_chave) else None
        df, consumed_messages = consume_logins_since(
            minutes,
            max_messages=None,
            on_progress=_on_progress,
            target_chave=optimized_target,
        )

        if consumed_messages == 0:
            st.warning("Nenhuma mensagem encontrada no período selecionado.")
            st.session_state["retro_run"] = False
            st.stop()

        progress_bar.progress(1.0, text=f"{consumed_messages:,} mensagens consumidas")
        st.session_state["retro_df"] = df
        st.session_state["retro_msg_count"] = consumed_messages
        st.session_state["retro_run"] = False
        st.rerun()

    if "retro_df" not in st.session_state:
        st.info("Selecione a janela de tempo e clique em **Buscar** para carregar dados retroativos.")
        st.stop()

    # ── Display retroactive data ──────────────────────────────
    df = st.session_state["retro_df"]
    msg_count = st.session_state.get("retro_msg_count", 0)

    if df.empty:
        st.warning("Nenhum login encontrado no período selecionado.")
        st.stop()

    st.caption(f"{msg_count:,} mensagens consumidas — {len(df):,} logins correlacionados")
    if re.fullmatch(r'[A-Za-z]\d{7}', st.session_state.get("retro_target_chave", "")):
        st.caption(
            f"Busca otimizada aplicada no consumo para a matrícula "
            f"**{st.session_state['retro_target_chave']}**."
        )
    render_dashboard(df, search_matricula, table_rows)
