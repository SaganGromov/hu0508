"""MongoDB audit service — records logins, searches, exports, and user actions to
TELEMETRIA.AUDIT_LOGINS_DASHBOARD_VPN.

Environment variable:
    MONGODB_AUDIT_URI  — MongoDB connection string (required for audit functionality).

All writes are fire-and-forget so that a MongoDB outage never blocks the main
application flow.
"""

import logging
import os
import re
from datetime import datetime
from zoneinfo import ZoneInfo

from pymongo import MongoClient

logger = logging.getLogger(__name__)
APP_TZ = ZoneInfo("America/Sao_Paulo")

MONGODB_AUDIT_URI = os.environ.get("MONGODB_AUDIT_URI", "")
_DB_NAME = "telemetria"
_COLLECTION_NAME = "AUDIT_LOGINS_DASHBOARD_VPN"
_FIELD_TYPE = "tipo"
_FIELD_MATRICULA = "matricula"
_FIELD_USERINFO = "userinfo"
_FIELD_IP = "ip"
_FIELD_TIMESTAMP = "timestamp"
_FIELD_PAGE = "pagina"
_FIELD_USER_ID = "user_id"
_FIELD_DETAILS = "detalhes"

_client: MongoClient | None = None
_collection = None
_warned_no_uri = False


def _get_collection():
    """Lazy-initialise the MongoDB client and return the audit collection."""
    global _client, _collection, _warned_no_uri
    if _collection is not None:
        return _collection

    if not MONGODB_AUDIT_URI:
        if not _warned_no_uri:
            logger.warning("MONGODB_AUDIT_URI nao configurada; auditoria desabilitada.")
            _warned_no_uri = True
        return None

    try:
        _client = MongoClient(MONGODB_AUDIT_URI, serverSelectionTimeoutMS=5000)
        db = _client[_DB_NAME]
        if _COLLECTION_NAME not in db.list_collection_names():
            db.create_collection(_COLLECTION_NAME)
            logger.info("Colecao %s criada em %s.", _COLLECTION_NAME, _DB_NAME)
        _collection = db[_COLLECTION_NAME]
        return _collection
    except Exception as exc:
        logger.error(
            "Falha ao conectar ao MongoDB para auditoria (%s).",
            type(exc).__name__,
        )
        return None


def _now_brasilia() -> datetime:
    return datetime.now(APP_TZ)


_SAFE_SCALAR_TYPES = (int, float, bool, datetime)
_MAX_SANITIZE_DEPTH = 5
_MAX_AUDIT_STRING_LENGTH = 4096
_CONTROL_CHARS_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def _is_safe_document_key(key: object) -> bool:
    """Return True when a key can be safely persisted as a MongoDB field name."""
    return (
        isinstance(key, str)
        and bool(key)
        and not key.startswith("$")
        and "." not in key
        and "\x00" not in key
    )


def _sanitize_string(value: str) -> str:
    """Normalize untrusted string values before audit persistence."""
    return _CONTROL_CHARS_RE.sub("", value)[:_MAX_AUDIT_STRING_LENGTH]


def _sanitize_value(value, *, _depth: int = 0):
    """Recursively sanitize a value for safe MongoDB insertion.

    * Strips dict keys that start with ``$`` (MongoDB operator injection).
    * Strips dict keys containing ``.`` or null bytes, which MongoDB treats as
      special field-name syntax in several APIs and tools.
    * Enforces a nesting limit to avoid unbounded recursion from malicious input.
    * Removes control characters and truncates strings from untrusted sources.
    * Rejects unknown types by converting them to their string representation.
    """
    if _depth > _MAX_SANITIZE_DEPTH:
        return _sanitize_string(str(value))

    if isinstance(value, dict):
        return {
            k: _sanitize_value(v, _depth=_depth + 1)
            for k, v in value.items()
            if _is_safe_document_key(k)
        }
    if isinstance(value, list):
        return [_sanitize_value(item, _depth=_depth + 1) for item in value]
    if isinstance(value, str):
        return _sanitize_string(value)
    if isinstance(value, _SAFE_SCALAR_TYPES) or value is None:
        return value
    return _sanitize_string(str(value))


def _insert(doc: dict) -> None:
    """Insert a document into the audit collection (fire-and-forget).

    The document is sanitized to prevent NoSQL operator injection (e.g.
    ``$``-prefixed keys) before being inserted.  A copy is used because
    pymongo mutates the dict by adding an ``_id`` key — without the copy,
    callers that reuse the dict (e.g. storing ``userinfo`` in the session)
    would end up with a non-JSON-serialisable ``ObjectId`` that breaks
    cookie serialisation.
    """
    col = _get_collection()
    if col is None:
        return
    try:
        col.insert_one(_sanitize_value(doc))
    except Exception as exc:
        logger.error(
            "Falha ao registrar auditoria no MongoDB (%s).",
            type(exc).__name__,
        )


def record_login(matricula: str, userinfo: dict, ip: str = "") -> None:
    """Record a successful login event (called from FastAPI)."""
    _insert({
        _FIELD_TYPE: "LOGIN",
        _FIELD_MATRICULA: matricula,
        _FIELD_USERINFO: userinfo,
        _FIELD_IP: ip,
        _FIELD_TIMESTAMP: _now_brasilia(),
    })


def record_search(matricula: str, userinfo: dict, search_query: str, page: str, ip: str = "") -> None:
    """Record a search action (called from FastAPI)."""
    _insert({
        _FIELD_TYPE: "SEARCH",
        _FIELD_MATRICULA: matricula,
        _FIELD_USERINFO: userinfo,
        "busca": search_query,
        _FIELD_PAGE: page,
        _FIELD_IP: ip,
        _FIELD_TIMESTAMP: _now_brasilia(),
    })


def record_action(user_id: str, action: str, page: str, details: dict | None = None) -> None:
    """Record any user interaction from a Streamlit page.

    Args:
        user_id: Identifier extracted from the auth token (matricula or sub).
        action:  Short description of the action (e.g. "BUSCA_MATRICULA", "FILTRO_CHAVE").
        page:    Name of the Streamlit page originating the action.
        details: Optional dict with action-specific data (search terms, filters, etc.).
    """
    doc = {
        _FIELD_TYPE: "ACTION",
        _FIELD_USER_ID: user_id,
        "acao": action,
        _FIELD_PAGE: page,
        _FIELD_TIMESTAMP: _now_brasilia(),
    }
    if details:
        doc[_FIELD_DETAILS] = details
    _insert(doc)


def record_csv_export(
    user_id: str,
    page: str,
    export_label: str,
    filename: str,
    row_count: int,
    column_count: int,
    details: dict | None = None,
) -> None:
    """Record a CSV export action."""
    doc = {
        _FIELD_TYPE: "CSV_EXPORT",
        _FIELD_USER_ID: user_id,
        _FIELD_PAGE: page,
        "export_label": export_label,
        "filename": filename,
        "row_count": row_count,
        "column_count": column_count,
        _FIELD_TIMESTAMP: _now_brasilia(),
    }
    if details:
        doc[_FIELD_DETAILS] = details
    _insert(doc)
