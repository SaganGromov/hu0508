import hashlib
import os
from datetime import datetime

import pandas as pd
import streamlit as st

from audit_service import record_csv_export


def to_csv_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False).encode("utf-8")


def set_export_audit_context(user_id: str, page: str, details: dict | None = None) -> None:
    st.session_state["_export_audit_context"] = {
        "user_id": user_id,
        "page": page,
        "details": details or {},
    }


def _build_unique_csv_filename(filename: str, payload: bytes) -> str:
    stem, ext = os.path.splitext(filename)
    ext = ext or ".csv"
    timestamp = datetime.now().strftime("%Y%m%dT%H%M%S%f")
    digest = hashlib.sha256(payload + timestamp.encode("utf-8")).hexdigest()[:8]
    return f"{stem}_{timestamp}_{digest}{ext}"


def _audit_csv_export(
    label: str,
    unique_filename: str,
    df: pd.DataFrame,
    details: dict | None = None,
) -> None:
    context = st.session_state.get("_export_audit_context", {})
    user_id = str(context.get("user_id", "")).strip()
    page = str(context.get("page", "")).strip()
    if not user_id or not page:
        return

    merged_details = dict(context.get("details", {}))
    if details:
        merged_details.update(details)

    record_csv_export(
        user_id=user_id,
        page=page,
        export_label=label,
        filename=unique_filename,
        row_count=len(df.index),
        column_count=len(df.columns),
        details=merged_details,
    )


def render_csv_download_button(
    button_label: str,
    df: pd.DataFrame,
    filename: str,
    *,
    export_label: str | None = None,
    key: str | None = None,
    details: dict | None = None,
) -> None:
    if df is None or df.empty:
        return

    payload = to_csv_bytes(df)
    unique_filename = _build_unique_csv_filename(filename, payload)
    clicked = st.download_button(
        button_label,
        payload,
        unique_filename,
        "text/csv",
        key=key or f"csv-{unique_filename}",
    )
    if clicked:
        _audit_csv_export(export_label or button_label, unique_filename, df, details=details)


def render_csv_downloads(
    exports: list[tuple[str, pd.DataFrame, str]],
    heading: str = "Exportar dados em CSV",
    columns: int = 3,
):
    valid_exports = [(label, df, filename) for label, df, filename in exports if df is not None and not df.empty]
    if not valid_exports:
        return

    st.markdown(f"##### {heading}")
    for start in range(0, len(valid_exports), columns):
        chunk = valid_exports[start:start + columns]
        cols = st.columns(len(chunk))
        for col, (label, df, filename) in zip(cols, chunk):
            with col:
                render_csv_download_button(
                    f"Exportar {label}",
                    df,
                    filename,
                    export_label=label,
                    key=f"csv-{filename}",
                )
