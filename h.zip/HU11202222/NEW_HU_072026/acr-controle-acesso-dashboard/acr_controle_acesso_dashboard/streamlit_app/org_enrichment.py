"""Enriquecimento organizacional via sidecar curio (op292018v3).

Módulo compartilhado usado pelas páginas Streamlit que precisam mapear
uma matrícula (``USER_KEY``) para os dados organizacionais correspondentes
(prefixo de dependência, unidade organizacional, tipo de usuário, etc.).

Notas:
    * ``USER_KEY`` pode ser uma matrícula real (``F1234567``) ou uma chave
      pseudonimizada (``U-<hash>``). Somente matrículas válidas disparam a
      chamada ao curio; para chaves pseudonimizadas devolvemos ``None``.
    * A função :func:`fetch_org_data` é decorada com ``st.cache_data``
      (TTL 10 minutos) quando executada dentro do Streamlit. Fora do
      Streamlit (por exemplo, em testes), o decorador é um no-op para
      permitir chamadas diretas.
"""

from __future__ import annotations

import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Callable, Optional

try:  # pragma: no cover - Streamlit presente em produção
    import streamlit as st

    _CACHE_DECORATOR: Callable = st.cache_data(ttl=600, show_spinner=False)
except Exception:  # pragma: no cover - fallback usado por testes
    def _CACHE_DECORATOR(func):
        return func

from curio_service import integracao_curio
from curio_models import PAYLOAD_OP292018V3

_MATRICULA_RE = re.compile(r"^[A-Za-z]\d{7}$")


def is_matricula(chave: Optional[str]) -> bool:
    """Retorna ``True`` se ``chave`` for uma matrícula válida (``F1234567``)."""
    if not chave:
        return False
    return bool(_MATRICULA_RE.match(str(chave).strip()))


@_CACHE_DECORATOR
def fetch_org_data(matricula: str) -> Optional[dict]:
    """Consulta o curio para obter os dados organizacionais da matrícula.

    Tenta até 2 vezes em caso de falha transitória (timeout/erro HTTP).
    Devolve ``None`` quando a chave não é uma matrícula válida ou quando
    ambas as tentativas falham.
    """
    if not is_matricula(matricula):
        return None
    payload = {**PAYLOAD_OP292018V3, "codigoClientePesquisa": matricula.strip().upper()}
    for attempt in range(2):
        try:
            record = integracao_curio("op292018v3", payload)
        except Exception:
            record = None
        if record:
            return record
    return None


# Mapeamento estável de campos do payload op292018v3 para rótulos em pt-BR.
ORG_COLUMNS_PT: dict[str, str] = {
    "numeroMatriculaUsuario": "Matrícula",
    "nomeFuncionario": "Nome",
    "nomeDependenciaLotacao": "Local de Trabalho",
    "nomeFuncaoLotacao": "Cargo",
    "codigoPrefixoDependenciaAtual": "Prefixo Dependência",
    "codigoUnidadeOrganizacionalDependenciaUsuario": "Unidade Organizacional",
    "codigoInstituicaoOrganizacionalUsuario": "Instituição Organizacional",
    "codigoTipoUsuario": "Tipo Usuário",
    "codigoComissaoUsuario": "Comissão",
    "codigoReferenciaOrganizacionalPerfil": "Referência Perfil",
}


def _blank(value) -> bool:
    """``True`` para os valores de preenchimento da op5360402v1.

    A operação devolve uma lista de tamanho fixo; as posições não utilizadas
    vêm com strings vazias e códigos ``"0"``.
    """
    if value is None:
        return True
    text = str(value).strip()
    return text in ("", "0")


def _is_padding(record: dict) -> bool:
    return all(
        _blank(record.get(key))
        for key in ("codigoMatriculaFuncionarioPesquisa", "nomeFuncionario", "nomeDependenciaLotacao")
    )


@_CACHE_DECORATOR
def fetch_lotacao_data(matricula: str) -> Optional[dict]:
    """Consulta a op5360402v1 (ARH) para obter lotação e função da matrícula.

    Devolve o registro correspondente à matrícula pesquisada, descartando os
    registros de preenchimento da lista de tamanho fixo. ``None`` quando a
    chave não é uma matrícula válida ou quando ambas as tentativas falham.
    """
    if not is_matricula(matricula):
        return None
    numeric = re.sub(r"\D", "", str(matricula))
    if not numeric:
        return None
    payload = {"listaFuncionario": [{"codigoMatriculaFuncionario": numeric}]}
    resposta = None
    for _attempt in range(2):
        try:
            resposta = integracao_curio("op5360402v1", payload)
        except Exception:
            resposta = None
        if resposta:
            break
    if not isinstance(resposta, dict):
        return None
    registros = [
        item
        for item in (resposta.get("listaDadoFuncionario") or [])
        if isinstance(item, dict) and not _is_padding(item)
    ]
    if not registros:
        return None
    alvo = str(int(numeric)) if numeric.isdigit() else numeric
    for item in registros:
        pesquisada = str(item.get("codigoMatriculaFuncionarioPesquisa") or "").strip()
        if pesquisada and pesquisada.lstrip("0") == alvo.lstrip("0"):
            return item
    # Consulta de uma única matrícula: o primeiro registro válido é o dela.
    return registros[0]


def fetch_lotacao_batch(matriculas: list[str]) -> dict[str, dict]:
    """Consulta até 100 matrículas por chamada da op5360402v1.

    A operação foi desenhada para receber uma lista e devolve exatamente 100
    posições, completando as não utilizadas com registros vazios. Consultá-la
    uma vez por funcionário transforma relatórios grandes em milhares de
    chamadas desnecessárias.
    """
    normalized: dict[str, str] = {}
    for matricula in matriculas:
        if not is_matricula(matricula):
            continue
        key = str(matricula).strip().upper()
        numeric = re.sub(r"\D", "", key)
        if numeric:
            normalized[numeric.lstrip("0") or "0"] = key
    if not normalized:
        return {}
    if len(normalized) > 100:
        raise ValueError("fetch_lotacao_batch aceita no máximo 100 matrículas.")

    payload = {
        "listaFuncionario": [
            {"codigoMatriculaFuncionario": numeric}
            for numeric in normalized
        ]
    }
    resposta = None
    for _attempt in range(2):
        try:
            resposta = integracao_curio("op5360402v1", payload)
        except Exception:
            resposta = None
        if resposta:
            break
    if not isinstance(resposta, dict):
        return {}

    result: dict[str, dict] = {}
    for item in resposta.get("listaDadoFuncionario") or []:
        if not isinstance(item, dict) or _is_padding(item):
            continue
        numeric = str(item.get("codigoMatriculaFuncionarioPesquisa") or "").strip()
        key = normalized.get(numeric.lstrip("0") or "0")
        if key:
            result[key] = item
    return result


def fetch_employee_profiles(
    matriculas: list[str], *, max_workers: int = 12
) -> dict[str, dict]:
    """Reúne ATC e ARH para muitas matrículas sem chamadas sequenciais.

    ``op292018v3`` aceita uma matrícula por chamada e é executada com
    paralelismo limitado. ``op5360402v1`` recebe lotes de 100, respeitando o
    tamanho fixo do contrato. Falhas individuais não interrompem o relatório.
    """
    keys = sorted({
        str(item).strip().upper() for item in matriculas if is_matricula(item)
    })
    if not keys:
        return {}

    profiles: dict[str, dict] = {key: {} for key in keys}
    workers = max(1, min(int(max_workers), 24, len(keys)))
    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(fetch_org_data, key): key for key in keys}
        for future in as_completed(futures):
            key = futures[future]
            try:
                org = future.result()
            except Exception:
                org = None
            if isinstance(org, dict):
                profiles[key].update(org)

    for start in range(0, len(keys), 100):
        try:
            lotacoes = fetch_lotacao_batch(keys[start:start + 100])
        except Exception:
            lotacoes = {}
        for key, lotacao in lotacoes.items():
            profiles[key].update({
                field: value for field, value in lotacao.items()
                if not _blank(value)
            })

    result: dict[str, dict] = {}
    for key, profile in profiles.items():
        if not profile:
            continue
        profile.update(split_dependencia(profile.get("nomeDependenciaLotacao")))
        profile.setdefault("numeroMatriculaUsuario", key)
        result[key] = profile
    return result


def split_dependencia(nome: Optional[str]) -> dict:
    """Separa o nome da dependência em departamento, unidade e hierarquia.

    Os nomes devolvidos pela op5360402v1 usam ``-`` ou ``/`` como separador
    (``"DITEC - UST 2 DF"``, ``"PTT/PLAT. GEST DF"``). Não inventa dados:
    apenas reapresenta o nome recebido. Quando não há separador, o próprio
    nome é usado como departamento e não há unidade.
    """
    texto = str(nome or "").strip()
    if not texto:
        return {"department": None, "unit": None, "organizational_hierarchy": None}
    partes = [parte.strip() for parte in re.split(r"[/-]", texto) if parte.strip()]
    if len(partes) < 2:
        return {"department": texto, "unit": None, "organizational_hierarchy": texto}
    return {
        "department": partes[0],
        "unit": " - ".join(partes[1:]),
        "organizational_hierarchy": " > ".join(partes),
    }


def fetch_employee_profile(matricula: str) -> dict:
    """Reúne as duas operações no registro único usado por páginas e dossiê.

    Combina op292018v3 (ATC, códigos organizacionais) com op5360402v1 (ARH,
    nome da dependência e da função). Devolve ``{}`` quando nenhuma das duas
    responde — nunca levanta exceção.
    """
    if not is_matricula(matricula):
        return {}
    registro: dict = {}
    org = fetch_org_data(matricula)
    if isinstance(org, dict):
        registro.update(org)
    lotacao = fetch_lotacao_data(matricula)
    if isinstance(lotacao, dict):
        registro.update({key: value for key, value in lotacao.items() if not _blank(value)})
    if not registro:
        return {}
    registro.update(split_dependencia(registro.get("nomeDependenciaLotacao")))
    registro.setdefault("numeroMatriculaUsuario", str(matricula).strip().upper())
    return registro


def flatten_org(record: Optional[dict]) -> dict:
    """Achata a resposta do curio no dicionário pt-BR usado pelas tabelas.

    Se ``record`` for ``None`` ou vazio, devolve todos os campos com ``None``.
    """
    if not record:
        return {label: None for label in ORG_COLUMNS_PT.values()}
    return {
        label: (None if str(record.get(key) or "").strip() == "" else record.get(key))
        for key, label in ORG_COLUMNS_PT.items()
    }


__all__ = [
    "ORG_COLUMNS_PT",
    "fetch_employee_profile",
    "fetch_employee_profiles",
    "fetch_lotacao_batch",
    "fetch_lotacao_data",
    "fetch_org_data",
    "flatten_org",
    "is_matricula",
    "split_dependencia",
]
