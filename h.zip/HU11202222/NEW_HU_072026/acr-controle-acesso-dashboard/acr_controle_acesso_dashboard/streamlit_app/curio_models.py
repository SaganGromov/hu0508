"""Modelos de payload e resposta para as operações do sidecar curio (IIB).

Cada operação possui:
  - PAYLOAD_<OPERACAO>: dict com os campos de requisição e seus valores padrão.
  - RESPONSE_<OPERACAO>: dict com os campos de resposta e seus tipos padrão (apenas referência).

Uso:
    from curio_models import PAYLOAD_OP292018V3
    payload = {**PAYLOAD_OP292018V3, "codigoClientePesquisa": "F1234567"}
"""

# ─────────────────────────────────────────────────────────────────────────────
# CONTRATO DA OPERAÇÃO 292018 VRS 3
# Consulta dados organizacionais do funcionário pela chave (código cliente)
# ─────────────────────────────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────────────────────────────
# CONTRATO DA OPERAÇÃO 2076328 VRS 2
# Limite de férias e ausências do funcionário
# ─────────────────────────────────────────────────────────────────────────────

PAYLOAD_OP2076328V2: dict = {
    "codigoMatriculaFuncionarioPesquisa": 0,
    "dataInicioPerPesquisa": "",
    "dataFimPerPesquisa": "",
    "codigoChaveUsuario": "",
}

RESPONSE_OP2076328V2: dict = {
    "codigoErro": 0,
    "textoMensagemErro": "",
    "dataInicioLimiteFerias": "",
    "dataFimLimiteFerias": "",
    "codigoEstadoLimiteFerias": 0,
    "dataInicioPerProximo": "",
    "quantidadeOcorrenciaAusencia": 0,
    "listaAusencia": [
        {
            "numeroSequencialPlanejamentoFuncionario": 0,
            "dataInicioAusencia": "",
            "dataFimAusencia": "",
            "quantidadeDiaAusencia": 0,
            "codigoAusencia": 0,
            "nomeAusencia": "",
            "indicadorExigenciaDespacho": "",
            "codigoEstadoPlanejamento": 0,
            "indicadorDespachoEfetivado": "",
        }
    ],
}

PAYLOAD_OP292018V3: dict = {
    "codigoClientePesquisa": "",
}

RESPONSE_OP292018V3: dict = {
    "codigoChaveCliente": "",
    "codigoTecnico": "",
    "nomeUsuario": "",
    "codigoClienteUsuario": 0,
    "codigoComissaoUsuario": 0,
    "codigoInstituicaoOrganizacionalUsuario": 0,
    "codigoTipoUnidadeOrganizacionalDependencia": 0,
    "codigoUnidadeOrganizacionalDependenciaUsuario": 0,
    "codigoPrefixoDependenciaAtual": 0,
    "codigoUnidadeOrganizacionalPosicaoUsuario": 0,
    "codigoTipoUnidadeOrganizacionalTempo": 0,
    "codigoUnidadeOrganizacionalDependenciaTempo": 0,
    "codigoPrefixoDependenciaTempo": 0,
    "codigoReferenciaOrganizacionalPerfil": "",
    "codigoReferenciaOrganizacionalSubstituicao": "",
    "codigoComissaoUsuarioSubstituicao": 0,
    "codigoTipoUsuario": "",
    "numeroMatriculaUsuario": 0,
    "codigoTipoUnidadeOrganizacionalAtendimento": 0,
    "codigoUnidadeOrganizacionalDependenciaAtendimento": 0,
    "codigoPrefixoDependenciaAtendimento": 0,
}


# ─────────────────────────────────────────────────────────────────────────────
# CONTRATO DA OPERAÇÃO 5360402 VRS 1 (ARH)
# Dados de lotação do funcionário: nome da dependência onde trabalha e função
# exercida. Complementa a op292018v3 (ATC), que devolve apenas códigos.
#
# A requisição aceita uma lista de matrículas e a resposta devolve uma lista de
# tamanho fixo, preenchida com registros vazios (strings "" e códigos "0") nas
# posições não utilizadas. Esses registros de preenchimento devem ser
# descartados pelo consumidor — ver ``org_enrichment.fetch_lotacao_data``.
# ─────────────────────────────────────────────────────────────────────────────

PAYLOAD_OP5360402V1: dict = {
    "listaFuncionario": [
        {
            "codigoMatriculaFuncionario": "",
        }
    ],
}

RESPONSE_OP5360402V1: dict = {
    "listaDadoFuncionario": [
        {
            "codigoMatriculaFuncionarioPesquisa": "",
            "textoMatriculaFuncionarioDigitoVerificador": "",
            "nomeFuncionario": "",
            "codigoDependenciaLotacao": "",
            "textoDependenciaLotacaoDigitoVerificador": "",
            "nomeDependenciaLotacao": "",
            "dataDependenciaLotacao": "",
            "codigoFuncaoLotacao": "",
            "nomeFuncaoLotacao": "",
            "dataFuncaoLotacao": "",
            "codigoCategoria": "",
        }
    ],
    "retornoPrograma": {
        "codigoRetornoPrograma": "",
        "textoMensagemErro": "",
    },
}
