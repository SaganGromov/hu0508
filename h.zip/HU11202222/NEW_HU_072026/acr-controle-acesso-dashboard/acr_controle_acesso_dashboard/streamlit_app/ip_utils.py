import ipaddress


def normalize_ip(value: object) -> str | None:
    """Return a canonical usable IP, excluding missing/unspecified values.

    Source placeholders such as ``0.0.0.0`` and every equivalent IPv6
    spelling of ``::`` mean “address not supplied”. They must not contribute
    to distinct-IP counters, evidence lists, or distance calculations.
    """
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    try:
        address = ipaddress.ip_address(text)
    except ValueError:
        return None
    if address.is_unspecified:
        return None
    return address.compressed.lower()


def ip_distance(ip1: str, ip2: str) -> int:
    """Calculate the distance between two usable IPv4 addresses.

    ``-1`` means that either value is invalid, unspecified, or IPv6. IPv6 is
    normalized elsewhere but has no meaningful distance comparable to the
    historical IPv4 metric exposed by this dashboard.
    """
    normalized_1 = normalize_ip(ip1)
    normalized_2 = normalize_ip(ip2)
    if normalized_1 is None or normalized_2 is None:
        return -1
    try:
        ip1_int = int(ipaddress.IPv4Address(normalized_1))
        ip2_int = int(ipaddress.IPv4Address(normalized_2))
        return abs(ip1_int - ip2_int)
    except (ValueError, TypeError):
        return -1
