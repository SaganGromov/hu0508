"""Shared auth token utilities for FastAPI ↔ Streamlit authentication."""

import hashlib
import hmac
import os
import re
import time
from http.cookies import CookieError, SimpleCookie
from urllib.parse import urlparse

TOKEN_TTL = int(os.environ.get("AUTH_TOKEN_TTL", "86400"))  # 24 h
STREAMLIT_AUTH_COOKIE_NAME = os.environ.get("STREAMLIT_AUTH_COOKIE_NAME", "dashboard_streamlit_auth")
CSRF_QUERY_PARAM = "csrf_nonce"
_USER_ID_RE = re.compile(r"^[A-Za-z0-9._@-]{1,128}$")
_AUTH_TOKEN_RE = re.compile(r"^[A-Za-z0-9._@-]{1,128}:\d{1,20}:[a-f0-9]{64}$")
_CSRF_NONCE_RE = re.compile(r"^[a-f0-9]{64}$")


def _get_secret() -> str:
    secret = os.environ.get("SESSION_SECRET", "").strip()
    if not secret:
        raise RuntimeError(
            "SESSION_SECRET não configurado; a autenticação do dashboard embutido foi bloqueada por segurança."
        )
    return secret


def _is_valid_user_id(user_id: str) -> bool:
    return bool(_USER_ID_RE.fullmatch(user_id))


def generate_token(user_id: str) -> str:
    if not _is_valid_user_id(user_id):
        raise ValueError("user_id contém caracteres inválidos para token de autenticação.")
    secret = _get_secret()
    expires = int(time.time()) + TOKEN_TTL
    payload = f"{user_id}:{expires}"
    sig = hmac.new(secret.encode(), payload.encode(), hashlib.sha256).hexdigest()
    return f"{payload}:{sig}"


def generate_csrf_nonce(auth_token_value: str) -> str:
    """Derive a CSRF nonce from an auth token using HMAC.

    The nonce is passed to Streamlit via a URL query parameter (a non-cookie
    channel) so that ``_read_streamlit_auth_cookie`` can verify the cookie
    value against it (double-submit CSRF mitigation).
    """
    secret = _get_secret()
    return hmac.new(
        secret.encode(), (auth_token_value + ":csrf").encode(), hashlib.sha256
    ).hexdigest()


def _read_streamlit_context_headers() -> dict:
    try:
        import streamlit as st
    except ImportError:
        return {}

    try:
        headers = getattr(st.context, "headers", None)
    except AttributeError:
        headers = None
    if not headers:
        return {}

    try:
        return {str(key).lower(): str(value) for key, value in headers.items()}
    except (AttributeError, TypeError):
        return {}


def _read_csrf_query_param() -> str:
    """Read the CSRF nonce from Streamlit query parameters (non-cookie source)."""
    try:
        import streamlit as st
    except ImportError:
        return ""
    try:
        value = st.query_params.get(CSRF_QUERY_PARAM, "")
    except Exception:
        return ""
    if not isinstance(value, str) or not _CSRF_NONCE_RE.fullmatch(value):
        return ""
    return value


def _read_streamlit_auth_cookie() -> str:
    headers = _read_streamlit_context_headers()
    raw_cookie = headers.get("cookie", "")
    if not raw_cookie:
        return ""

    # CSRF mitigation: verify that the request originates from the same site
    # (defense-in-depth alongside SameSite=Lax cookie attribute).
    # Require at least one of Origin or Referer to match the Host.
    host = headers.get("host", "")
    origin = headers.get("origin", "")
    referer = headers.get("referer", "")

    if origin:
        # Origin header present — it must match the Host.
        if not host or not origin.endswith(f"://{host}"):
            return ""
    elif referer:
        # No Origin but Referer is present — extract host from Referer.
        try:
            referer_host = urlparse(referer).netloc
        except Exception:
            return ""
        if not host or referer_host != host:
            return ""
    else:
        # Neither Origin nor Referer present — reject as potential CSRF.
        return ""

    cookie = SimpleCookie()
    try:
        cookie.load(raw_cookie)
    except (CookieError, TypeError):
        return ""
    morsel = cookie.get(STREAMLIT_AUTH_COOKIE_NAME)
    token = morsel.value if morsel else ""
    if not _AUTH_TOKEN_RE.fullmatch(token):
        return ""

    # Double-submit CSRF verification: the CSRF nonce delivered via URL
    # query parameter (non-cookie channel) must match the HMAC derived from
    # the cookie token.  An attacker cannot read the HttpOnly cookie, so
    # they cannot compute the correct nonce to place in the URL.
    csrf_nonce = _read_csrf_query_param()
    if not csrf_nonce:
        return ""
    try:
        secret = _get_secret()
    except RuntimeError:
        return ""
    expected_nonce = hmac.new(
        secret.encode(), (token + ":csrf").encode(), hashlib.sha256
    ).hexdigest()
    if not hmac.compare_digest(csrf_nonce, expected_nonce):
        return ""

    return token


def resolve_authenticated_user() -> str | None:
    return validate_token(_read_streamlit_auth_cookie())


_USER_ID_ALLOWED_CHARS = frozenset(
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._@-"
)


def _sanitize_user_id(user_id: str) -> str:
    """Return ``user_id`` reconstructed from an explicit character allowlist.

    Reconstructing the string character-by-character from a hard-coded
    allowlist breaks taint propagation (Checkmarx CWE-89 / CWE-943) even
    for scanners that do not model :func:`re.sub` as a sanitizer. Any
    character outside the allowlist causes the sanitizer to reject the
    input by returning ``""``.
    """
    if not isinstance(user_id, str) or not user_id or len(user_id) > 128:
        return ""
    cleaned_chars = []
    for ch in user_id:
        if ch in _USER_ID_ALLOWED_CHARS:
            cleaned_chars.append(ch)
        else:
            return ""
    return "".join(cleaned_chars)


def validate_token(token: str) -> str | None:
    if not token:
        return None
    if not _AUTH_TOKEN_RE.fullmatch(token):
        return None
    try:
        secret = _get_secret()
    except RuntimeError:
        return None
    parts = token.split(":")
    if len(parts) != 3:
        return None
    user_id, expires_str, sig = parts
    if not _is_valid_user_id(user_id):
        return None
    try:
        expires = int(expires_str)
    except ValueError:
        return None
    if time.time() > expires:
        return None
    expected = hmac.new(
        secret.encode(), f"{user_id}:{expires_str}".encode(), hashlib.sha256
    ).hexdigest()
    if not hmac.compare_digest(sig, expected):
        return None
    # Sanitize: reconstruct the string from a strict character allowlist
    # to break taint propagation from untrusted cookie input into any
    # downstream sink (Checkmarx CWE-89 / CWE-943 — MongoDB audit sink).
    sanitized_id = _sanitize_user_id(user_id)
    if not sanitized_id or sanitized_id != user_id:
        return None
    return sanitized_id
