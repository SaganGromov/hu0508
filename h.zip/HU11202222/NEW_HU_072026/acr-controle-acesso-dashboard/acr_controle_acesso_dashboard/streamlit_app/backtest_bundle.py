"""Funções puras para agregação do bundle do backtest VPN.

Extraídas das páginas Streamlit ``sumario_negocial`` e
``segmentacao_suspeitos`` para permitir testes unitários sem carregar
``streamlit``. Todas as funções operam sobre dicionários Python.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Iterable, Optional

# Ordem estável das regras e o nome do "case" no bundle que corresponde
# a cada regra do backtest.
RULE_ORDER: tuple[str, ...] = ("R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8", "R9")

RULE_CASE_NAMES: dict[str, str] = {
    "R1": "ips_distintos_acima_do_limite",
    "R2": "hostnames_distintos_acima_do_limite",
    "R3": "dispositivos_distintos_acima_do_limite",
    "R4": "logins_diarios_acima_do_limite",
    "R5": "vpn_ativa_com_login_em_rede_fisica_mta",
    "R6": "vpn_ativa_com_login_em_rede_fisica_mta_multiplos_dispositivos",
    "R7": "dispositivo_multiplos_usuarios",
    "R8": "usuario_multiplos_dispositivos_intervalo_curto",
    "R9": "troca_rapida_ips",
}

RULE_TITLES_PT: dict[str, str] = {
    "R1": "R1 — Alteração de endereço IP no mesmo dia",
    "R2": "R2 — Múltiplos nomes de computador no período",
    "R3": "R3 — Múltiplos dispositivos no período",
    "R4": "R4 — Mais de dois logins VPN no mesmo dia",
    "R5": "R5 — Evento VPN e autenticação OpenAM próximos, em IPs diferentes",
    "R6": "R6 — R5 com múltiplos equipamentos no período",
    "R7": "R7 — Dispositivo associado a múltiplos usuários",
    "R8": "R8 — Usuário em múltiplos dispositivos em curto intervalo",
    "R9": "R9 — Troca rápida de endereços IP",
}

RULE_DESCRIPTIONS_PT: dict[str, str] = {
    "R1": (
        "Sinaliza um usuário-dia quando há pelo menos {r1_min_distinct_ips} endereços IP válidos "
        "distintos no campo de origem (CD_END_LGC_OGM) ou pelo menos {r1_min_distinct_ips} no "
        "campo corporativo/túnel (CD_END_LGC_CPTV). Os campos são contados "
        "separadamente e a contagem reinicia em cada dia local."
    ),
    "R2": (
        "Sinaliza um usuário com mais de {distinct_limit} nomes de computador "
        "válidos (NM_DSVO) distintos no período {start} → {end}. É um caso "
        "para análise e pode refletir troca legítima de equipamento."
    ),
    "R3": (
        "Sinaliza um usuário com mais de {distinct_limit} identificadores de "
        "dispositivo válidos (CD_IDFC_DSVO) distintos no período {start} → {end}."
    ),
    "R4": (
        "Sinaliza um usuário-dia com mais de dois eventos de login VPN "
        "deduplicados: zero, um ou dois não sinalizam; três ou mais sinalizam. "
        "Por padrão, 3–{r4_high_severity_above} têm severidade média, "
        "{r4_high_start}–{r4_critical_severity_above} alta e valores acima de "
        "{r4_critical_severity_above} crítica. A contagem reinicia à "
        "meia-noite no fuso America/Sao_Paulo."
    ),
    "R5": (
        "Correlaciona um evento VPN em ``DB2PEP.AUT_CPTV`` com IP "
        "corporativo/túnel ``X`` e uma autenticação do mesmo usuário "
        "bem-sucedida na tabela ``DB2PEP.MTA_AUT_CLI_TRAN`` — tabela de "
        "produção dos logins do OpenAM — a partir de um IP privado pertencente "
        "às faixas configuradas e **diferente de ``X``**, dentro de uma janela de correlação "
        "de **±{mta_delta_minutes} minutos** em torno do evento VPN. Indica "
        "uma correlação temporal para análise. A fonte não permite comprovar "
        "sessões simultâneas porque não há início/fim confiáveis. Somente "
        "``ipCliente`` pertencentes às faixas privadas configuradas são "
        "considerados, e as "
        "autenticações em ``DB2PEP.MTA_AUT_CLI_TRAN`` são deduplicadas por "
        "``CD_UNCO_TRAN``."
    ),
    "R6": (
        "Usuários já sinalizados por R5 (VPN em ``DB2PEP.AUT_CPTV`` + login "
        "em ``DB2PEP.MTA_AUT_CLI_TRAN`` com IPs distintos, na mesma janela de "
        "**±{mta_delta_minutes} minutos**) que, adicionalmente, apresentaram "
        "**no período de análise inteiro ({start} → {end})** mais de "
        "{distinct_limit} hostnames OU mais de {distinct_limit} "
        "identificadores de dispositivo distintos na tabela VPN "
        "``DB2PEP.AUT_CPTV``. A diversidade ocorre no período completo e não "
        "comprova que os equipamentos foram usados simultaneamente."
    ),
    "R7": (
        "Sinaliza um CD_IDFC_DSVO válido associado a pelo menos dois "
        "CD_USU_AUT válidos. Consolida associações de mesmo dia, janela móvel "
        "nas janelas configuradas ({device_windows_days} dias), sem emitir um alerta para cada "
        "janela sobreposta. Dispositivos e contas presentes nas allowlists "
        "configuradas são excluídos."
    ),
    "R8": (
        "Sinaliza um usuário associado a pelo menos {multi_device_min_devices} dispositivos válidos "
        "em até {multi_device_window_minutes} minutos. A regra busca transições agudas e não trata a "
        "substituição de equipamento ao longo de períodos maiores como alerta."
    ),
    "R9": (
        "Sinaliza um usuário com pelo menos {rapid_ip_min_distinct} IPs de origem válidos distintos "
        "em até {rapid_ip_window_minutes} minutos, conforme a convenção já existente na análise de "
        "troca rápida. IP de origem e IP corporativo/túnel não são misturados."
    ),
}


def rule_case(bundle: dict, rule: str) -> dict:
    """Devolve o dicionário do caso correspondente à regra dada.

    Se o caso não estiver presente, devolve ``{}``.
    """
    case_name = RULE_CASE_NAMES.get(rule)
    if not case_name:
        return {}
    for case in (bundle.get("summary", {}) or {}).get("cases", []) or []:
        if case.get("name") == case_name:
            return case
    return {}


def rule_samples(bundle: dict, rule: str) -> list[dict]:
    """Devolve todas as ocorrências; usa ``sample`` apenas em bundles legados."""
    case = rule_case(bundle, rule)
    occurrences = case.get("occurrences")
    if occurrences is None:
        return list(case.get("sample") or [])
    rows = []
    for occurrence in occurrences:
        users = []
        if occurrence.get("user_id"):
            users.append(occurrence["user_id"])
        users.extend((occurrence.get("details") or {}).get("users") or [])
        if not users:
            users = [None]
        for user in sorted(set(users), key=lambda value: str(value or "")):
            row = dict(occurrence)
            row["USER_KEY"] = user
            row["LAST_SEEN"] = occurrence.get("last_event_timestamp")
            row["LOGIN_DATE"] = occurrence.get("local_date")
            value = occurrence.get("triggering_value")
            if rule == "R1" and isinstance(value, dict):
                row["DISTINCT_CD_END_LGC_OGM"] = value.get("source_ip_count")
                row["DISTINCT_CD_END_LGC_CPTV"] = value.get("corporate_ip_count")
            elif rule == "R2":
                row["DISTINCT_NM_DSVO"] = value
            elif rule == "R3":
                row["DISTINCT_CD_IDFC_DSVO"] = value
            elif rule == "R4":
                row["LOGIN_COUNT"] = value
            elif rule == "R7" and isinstance(value, dict):
                row["DISTINCT_USERS"] = value.get("distinct_users")
                row["HORIZON"] = value.get("horizon")
            elif rule == "R8":
                row["DISTINCT_DEVICES_SHORT_WINDOW"] = value
            elif rule == "R9":
                row["DISTINCT_SOURCE_IPS_SHORT_WINDOW"] = value
            rows.append(row)
    return rows


def rule_flagged_counts(bundle: dict) -> dict[str, dict[str, int]]:
    """Para cada regra, devolve ``{"events": N, "users": M}``.

    * ``events`` = ``rules[R].flagged`` (número de ocorrências detectadas).
    * ``users``  = ``rules[R].flagged_users`` (funcionários únicos afetados).

    Quando um valor não estiver disponível, cai para 0.
    """
    rules = bundle.get("rules", {}) or {}
    out: dict[str, dict[str, int]] = {}
    for rule in RULE_ORDER:
        payload = rules.get(rule, {}) or {}
        out[rule] = {
            "events": int(payload.get("flagged") or 0),
            "users": int(payload.get("flagged_users") or 0),
        }
    return out


RULE_METRIC_LABELS: dict[str, str] = {
    "R1": "IPs distintos",
    "R2": "Hostnames distintos",
    "R3": "Dispositivos distintos",
    "R4": "Logins no dia",
    "R5": "IPs (VPN ↔ OpenAM), CD_IDFR_MTA, CD_UNCO_TRAN e CD_CLI_TRAN",
    "R6": "Hostnames/Dispositivos",
    "R7": "Usuários distintos e horizonte",
    "R8": "Dispositivos distintos em curto intervalo",
    "R9": "IPs de origem distintos em curto intervalo",
}


def _sample_metric_value(rule: str, sample: dict) -> Optional[str]:
    """Extrai a métrica-chave de um item de sample, formatada para exibição."""
    if rule == "R1":
        a = sample.get("DISTINCT_CD_END_LGC_OGM")
        b = sample.get("DISTINCT_CD_END_LGC_CPTV")
        vals = [v for v in (a, b) if isinstance(v, (int, float))]
        if not vals:
            return None
        return "IPs de origem distintos: {0} · IPs corporativos/túnel distintos: {1}".format(
            a if a is not None else "não informado",
            b if b is not None else "não informado",
        )
    if rule == "R2":
        v = sample.get("DISTINCT_NM_DSVO")
        return str(v) if v is not None else None
    if rule == "R3":
        v = sample.get("DISTINCT_CD_IDFC_DSVO")
        return str(v) if v is not None else None
    if rule == "R4":
        v = sample.get("LOGIN_COUNT")
        return str(v) if v is not None else None
    if rule == "R5":
        vpn_ip = sample.get("VPN_CPTV_IP")
        mta_ip = sample.get("MTA_IP_CLIENTE")
        if not vpn_ip and not mta_ip:
            return None
        return "VPN={0} ↔ OpenAM={1}".format(vpn_ip or "?", mta_ip or "?")
    if rule == "R6":
        h = sample.get("DISTINCT_HOSTNAMES")
        d = sample.get("DISTINCT_DEVICES")
        if h is None and d is None:
            return None
        return "hostnames={0} · dispositivos={1}".format(
            h if h is not None else "?", d if d is not None else "?"
        )
    if rule == "R7":
        return "{0} usuário(s) · horizonte {1}".format(
            sample.get("DISTINCT_USERS", "?"), sample.get("HORIZON", "?")
        )
    if rule == "R8":
        value = sample.get("DISTINCT_DEVICES_SHORT_WINDOW")
        return "{0} dispositivo(s) em curto intervalo".format(value) if value is not None else None
    if rule == "R9":
        value = sample.get("DISTINCT_SOURCE_IPS_SHORT_WINDOW")
        return "{0} IP(s) de origem em curto intervalo".format(value) if value is not None else None
    return None


def _sample_timestamp(rule: str, sample: dict) -> str:
    """Escolhe o timestamp/data disponível para exibir como 'última ocorrência'."""
    if rule == "R4":
        return str(sample.get("LOGIN_DATE") or "")
    if rule in ("R5", "R6"):
        return str(sample.get("VPN_TS") or sample.get("MTA_TS") or "")
    # R1/R2/R3 e demais casos que agregam por usuário passam a expor
    # o valor de MAX(TS_TRAN) na chave ``LAST_SEEN`` (adicionado ao
    # sample no CLI a partir da versão 2.0.39). Bundles anteriores
    # sem essa coluna caem no fallback vazio.
    return str(sample.get("LAST_SEEN") or "")


def affected_users_by_rule(bundle: dict) -> dict[str, list[dict]]:
    """Agrega, por regra, uma lista de ``{USER_KEY, occurrences, last_seen, metric}``.

    ``metric`` guarda a métrica-chave (contagem/valor) associada à regra;
    ``last_seen`` recebe o maior timestamp/data disponível na amostra
    (ou ``""`` quando o caso não expõe timestamp).
    """
    out: dict[str, list[dict]] = {}
    for rule in RULE_ORDER:
        agg: dict[str, dict] = {}
        for sample in rule_samples(bundle, rule):
            key = sample.get("USER_KEY") or sample.get("user_key")
            if not key:
                continue
            entry = agg.setdefault(key, {
                "USER_KEY": key,
                "occurrences": 0,
                "last_seen": "",
                "metric": None,
                "explanation": None,
                "_metric_num": -1.0,
            })
            entry["occurrences"] += 1
            if sample.get("explanation") or sample.get("EXPLANATION"):
                entry["explanation"] = sample.get("explanation") or sample.get("EXPLANATION")
            ts = _sample_timestamp(rule, sample)
            if ts and (not entry["last_seen"] or ts > entry["last_seen"]):
                entry["last_seen"] = ts
            metric_txt = _sample_metric_value(rule, sample)
            if metric_txt is not None:
                if rule == "R5":
                    # Acumula todos os pares distintos de IPs (VPN ↔ OpenAM)
                    # e todos os CD_UNCO_TRAN / CD_CLI_TRAN / CD_IDFR_MTA
                    # distintos observados ao longo da janela para o mesmo
                    # funcionário.
                    pairs = entry.setdefault("_pairs", [])
                    if metric_txt not in pairs:
                        pairs.append(metric_txt)
                    codes = entry.setdefault("_tran_codes", [])
                    code = sample.get("MTA_CD_UNCO_TRAN")
                    if code and str(code).lower() != "null" and str(code) not in codes:
                        codes.append(str(code))
                    cli_codes = entry.setdefault("_cli_tran_codes", [])
                    cli = sample.get("MTA_CD_CLI_TRAN")
                    if cli and str(cli).lower() != "null" and str(cli) not in cli_codes:
                        cli_codes.append(str(cli))
                    idfr = entry.setdefault("_idfr", [])
                    idfr_v = sample.get("MTA_CD_IDFR_MTA")
                    if idfr_v is not None and str(idfr_v) not in idfr:
                        idfr.append(str(idfr_v))
                    parts = ["IPs: " + "; ".join(pairs)]
                    if idfr:
                        parts.append("CD_IDFR_MTA: " + ", ".join(idfr))
                    if codes:
                        parts.append("CD_UNCO_TRAN: " + ", ".join(codes))
                    if cli_codes:
                        parts.append("CD_CLI_TRAN: " + ", ".join(cli_codes))
                    entry["metric"] = " · ".join(parts)
                    continue
                # Guardamos o maior valor observado no sample (peor caso).
                num = 0.0
                for token in str(metric_txt).replace("=", " ").split():
                    try:
                        n = float(token)
                    except ValueError:
                        continue
                    num = max(num, n)
                if num >= entry["_metric_num"]:
                    entry["_metric_num"] = num
                    entry["metric"] = metric_txt
        rows = sorted(agg.values(), key=lambda r: (-r["occurrences"], r["USER_KEY"]))
        for r in rows:
            r.pop("_metric_num", None)
            r.pop("_pairs", None)
            r.pop("_tran_codes", None)
            r.pop("_cli_tran_codes", None)
            r.pop("_idfr", None)
        out[rule] = rows
    return out


def all_flagged_users(bundle: dict) -> list[str]:
    """Retorna a lista deduplicada de ``USER_KEY`` marcados por qualquer regra."""
    seen: set[str] = set()
    order: list[str] = []
    for rule in RULE_ORDER:
        for entry in affected_users_by_rule(bundle).get(rule, []):
            k = entry["USER_KEY"]
            if k not in seen:
                seen.add(k)
                order.append(k)
    return order


def build_rule_user_matrix(bundle: dict) -> list[dict]:
    """Constrói a matriz regras × usuários (uma linha por usuário).

    Cada linha contém: ``USER_KEY``, colunas ``R1``..``R5`` com 0/1, e
    ``total_regras`` (soma).
    """
    per_rule = affected_users_by_rule(bundle)
    users = all_flagged_users(bundle)
    rows: list[dict] = []
    for user in users:
        row: dict = {"USER_KEY": user}
        total = 0
        for rule in RULE_ORDER:
            hit = 1 if any(e["USER_KEY"] == user for e in per_rule.get(rule, [])) else 0
            row[rule] = hit
            total += hit
        row["total_regras"] = total
        rows.append(row)
    rows.sort(key=lambda r: (-r["total_regras"], r["USER_KEY"]))
    return rows


def top_reincident_users(bundle: dict) -> list[dict]:
    """Filtra a matriz de ``build_rule_user_matrix`` para usuários com >1 regra."""
    return [row for row in build_rule_user_matrix(bundle) if row["total_regras"] > 1]


def redundancy_count(bundle: dict) -> int:
    """Quantidade de funcionários sinalizados por mais de uma regra."""
    return sum(1 for row in build_rule_user_matrix(bundle) if row["total_regras"] > 1)


def rule_labels_from_matrix(row: dict) -> str:
    """Concatena as regras marcadas em um único texto ``"R1, R5"``."""
    return ", ".join(rule for rule in RULE_ORDER if row.get(rule))


def group_counts(rows: Iterable[dict], key: str) -> list[tuple[str, int]]:
    """Agrupa ``rows`` por ``row[key]`` e devolve pares ``(valor, contagem)``
    ordenados por contagem desc, então por valor asc. Ignora ``None``/``""``.
    """
    counter: dict[str, int] = defaultdict(int)
    for row in rows:
        value = row.get(key)
        if value in (None, ""):
            continue
        counter[str(value)] += 1
    return sorted(counter.items(), key=lambda kv: (-kv[1], kv[0]))


def group_rule_by_dimension(rows: Iterable[dict], dimension: str) -> list[dict]:
    """Constrói uma linha por ``dimension`` com contagem de cada regra e total.

    ``rows`` deve conter, para cada usuário, as colunas ``R1..R5`` (0/1) e a
    coluna ``dimension`` (ex.: ``"Prefixo Dependência"``).
    """
    agg: dict[str, dict[str, int]] = {}
    for row in rows:
        value = row.get(dimension)
        if value in (None, ""):
            continue
        bucket = agg.setdefault(str(value), {rule: 0 for rule in RULE_ORDER})
        for rule in RULE_ORDER:
            bucket[rule] += int(row.get(rule) or 0)
    out: list[dict] = []
    for value, counts in agg.items():
        entry = {dimension: value, **counts}
        entry["total"] = sum(counts.values())
        out.append(entry)
    out.sort(key=lambda r: (-r["total"], r[dimension]))
    return out


def curio_coverage(rows: Iterable[dict], org_column: str = "Prefixo Dependência") -> float:
    """Fração dos usuários enriquecidos com sucesso no curio.

    Considera enriquecido quando ``row[org_column]`` não for ``None``/``""``.
    Devolve 0.0 quando a lista for vazia.
    """
    rows = list(rows)
    if not rows:
        return 0.0
    hits = sum(1 for r in rows if r.get(org_column) not in (None, ""))
    return hits / len(rows)


def should_use_org_fallback(rows: Iterable[dict], org_column: str = "Prefixo Dependência", threshold: float = 0.7) -> bool:
    """Ativa o fallback quando a cobertura do curio ficar abaixo de ``threshold``.

    O prompt define o gatilho como "curio None para >30% dos usuários" → aqui
    isso equivale a *coverage < 0.7*.
    """
    return curio_coverage(rows, org_column) < threshold


def load_latest_bundle(directory: str) -> Optional[tuple[str, dict]]:
    """Localiza o bundle v2 mais recente em ``directory``.

    Bundles v1 têm as antigas agregações de R1/R4 e não podem ser exibidos
    sob as descrições atuais. Eles são preservados, mas ignorados até uma
    nova execução produzir ocorrências normalizadas.
    """
    import glob
    import json
    import os

    bundles = sorted(glob.glob(os.path.join(directory, "results_bundle_*.json")))
    for path in reversed(bundles):
        try:
            with open(path, "r", encoding="utf-8") as fh:
                payload = json.load(fh)
        except (OSError, ValueError):
            continue
        try:
            version = int(payload.get("bundle_version") or 0)
        except (TypeError, ValueError):
            continue
        if version >= 2:
            return path, payload
    return None


__all__ = [
    "RULE_ORDER",
    "RULE_CASE_NAMES",
    "RULE_TITLES_PT",
    "RULE_DESCRIPTIONS_PT",
    "RULE_METRIC_LABELS",
    "affected_users_by_rule",
    "all_flagged_users",
    "build_rule_user_matrix",
    "curio_coverage",
    "group_counts",
    "group_rule_by_dimension",
    "load_latest_bundle",
    "redundancy_count",
    "rule_case",
    "rule_flagged_counts",
    "rule_labels_from_matrix",
    "rule_samples",
    "should_use_org_fallback",
    "top_reincident_users",
]
