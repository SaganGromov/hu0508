"""Serviço de integração com o sidecar curio (IIB).

Expõe uma única função pública:

    integracao_curio(operacao, payload) -> dict | None

Onde:
  - operacao: código da operação, ex.: "op292018v3"
  - payload:  dict de requisição, idealmente construído a partir dos modelos em curio_models.py

Exemplo de uso:
    from curio_service import integracao_curio
    from curio_models import PAYLOAD_OP292018V3

    payload = {**PAYLOAD_OP292018V3, "codigoClientePesquisa": "F1234567"}
    resultado = integracao_curio("op292018v3", payload)
"""

import logging
import os
import re
import threading
import time

import requests

logger = logging.getLogger(__name__)

DEFAULT_CURIO_BASE_URL = "http://localhost:8081"
CURIO_TIMEOUT = 5  # segundos
CURIO_CONNECTION_COOLDOWN = 30  # segundos
_OPERATION_RE = re.compile(r"^op[0-9]{1,12}v[0-9]{1,4}$")
_connection_lock = threading.Lock()
_connection_unavailable_until = 0.0


def _curio_enabled() -> bool:
    return os.environ.get("CURIO_ENABLED", "true").strip().lower() not in {
        "0",
        "false",
        "no",
        "off",
    }


def _connection_is_available() -> bool:
    with _connection_lock:
        return time.monotonic() >= _connection_unavailable_until


def _mark_connection_unavailable() -> None:
    global _connection_unavailable_until
    with _connection_lock:
        _connection_unavailable_until = time.monotonic() + CURIO_CONNECTION_COOLDOWN


def _mark_connection_available() -> None:
    global _connection_unavailable_until
    with _connection_lock:
        _connection_unavailable_until = 0.0


def integracao_curio(operacao: str, payload: dict) -> dict | None:
    """Realiza uma chamada POST ao sidecar curio para a operação informada.

    Args:
        operacao: Código da operação IIB (ex.: "op292018v3").
        payload:  Dict com os campos de requisição da operação.

    Returns:
        Dict com a resposta da operação, ou None em caso de erro.
    """
    if not _curio_enabled() or not _connection_is_available():
        return None
    if not _OPERATION_RE.fullmatch(str(operacao or "")):
        logger.warning("Operação Curio rejeitada por formato inválido.")
        return None
    base_url = os.environ.get("CURIO_BASE_URL", DEFAULT_CURIO_BASE_URL)
    url = f"{base_url.rstrip('/')}/{operacao}"
    try:
        resp = requests.post(url, json=payload, timeout=CURIO_TIMEOUT)
        resp.raise_for_status()
        result = resp.json()
        _mark_connection_available()
        return result
    except requests.exceptions.Timeout:
        logger.warning("Timeout ao chamar a operação Curio %s.", operacao)
        return None
    except requests.exceptions.ConnectionError:
        _mark_connection_unavailable()
        logger.warning(
            "Sidecar Curio indisponível em %s; novas chamadas serão pausadas por %ss.",
            base_url,
            CURIO_CONNECTION_COOLDOWN,
        )
        return None
    except requests.exceptions.HTTPError as exc:
        status = exc.response.status_code if exc.response is not None else "desconhecido"
        logger.warning(
            "Erro HTTP %s ao chamar a operação Curio %s.", status, operacao
        )
        return None
    except Exception as exc:
        logger.error(
            "Erro inesperado ao chamar a operação Curio %s (%s).",
            operacao,
            type(exc).__name__,
        )
        return None
