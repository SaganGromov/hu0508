from ip_utils import ip_distance
import streamlit as st
import pandas as pd
import plotly.express as px
import re
import sys
import os
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from kafka_service import BR_TZ, TOPIC, search_logins_by_chave_since
from auth_token import resolve_authenticated_user
from curio_service import integracao_curio
from curio_models import PAYLOAD_OP292018V3
from export_utils import render_csv_downloads, set_export_audit_context
from audit_service import record_action

st.set_page_config(page_title="Busca por Matrícula", layout="wide")

# ── Auth gate ─────────────────────────────────────────────────
_user_id = resolve_authenticated_user()
if _user_id is None:
    st.error("Acesso não autorizado. Faça login novamente pelo portal principal do dashboard.")
    st.stop()
set_export_audit_context(_user_id, "busca_matricula")

st.title("🔍 Busca por Matrícula")
st.caption(
    "Pesquisa todos os logins de uma matrícula nos últimos **7 dias** "
    "de dados disponíveis no Kafka."
)

SEVEN_DAYS_MINUTES = 7 * 24 * 60  # 10 080
LABEL_HORARIO = "Horário"


@st.cache_data(ttl=300)
def fetch_curio(chave: str) -> dict | None:
    payload = {**PAYLOAD_OP292018V3, "codigoClientePesquisa": chave.upper()}
    return integracao_curio("op292018v3", payload)


# ── Controls ──────────────────────────────────────────────────
ctrl1, ctrl2 = st.columns([2, 1])
with ctrl1:
    matricula = st.text_input(
        "Matrícula",
        placeholder="Ex: F1234567",
        key="busca_mat_input",
    ).strip().upper()
with ctrl2:
    st.markdown("<br>", unsafe_allow_html=True)
    buscar = st.button("🔍 Buscar", type="primary", disabled=not matricula)

if matricula and not re.match(r'^[A-Za-z]\d{7}$', matricula):
    st.warning("Formato de matrícula inválido. Use o formato F1234567.")
    st.stop()

if buscar and matricula:
    record_action(_user_id, "BUSCA_MATRICULA", "busca_matricula", {"matricula": matricula})
    st.session_state["busca_mat_run"] = True
    st.session_state["busca_mat_target"] = matricula
    st.session_state.pop("busca_mat_df", None)
    st.session_state.pop("busca_mat_msg_count", None)


# ── Consume ───────────────────────────────────────────────────
if st.session_state.get("busca_mat_run") and "busca_mat_df" not in st.session_state:
    target = st.session_state["busca_mat_target"]
    st.info(f"Consumindo mensagens dos últimos 7 dias para buscar logins de **{target}**...")
    progress_bar = st.progress(0, text="Conectando ao Kafka...")

    def _on_progress(consumed, total):
        pct = consumed / total if total else 0
        progress_bar.progress(min(pct, 1.0), text=f"{consumed:,} / {total:,} mensagens")

    df, consumed_messages = search_logins_by_chave_since(
        target, SEVEN_DAYS_MINUTES, max_messages=None, on_progress=_on_progress,
    )

    st.session_state["busca_mat_df"] = df
    st.session_state["busca_mat_msg_count"] = consumed_messages
    st.session_state["busca_mat_searched_at"] = datetime.now(tz=BR_TZ).strftime("%d/%m/%Y %H:%M:%S")
    st.session_state["busca_mat_run"] = False
    st.rerun()


if "busca_mat_df" not in st.session_state:
    st.info("Digite uma matrícula e clique em **Buscar**.")
    st.stop()


# ── Results ───────────────────────────────────────────────────
df = st.session_state["busca_mat_df"]
target = st.session_state.get("busca_mat_target", "")
msg_count = st.session_state.get("busca_mat_msg_count", 0)
searched_at = st.session_state.get("busca_mat_searched_at")
if searched_at:
    st.caption(f"Resultado gerado em {searched_at} — tópico Kafka `{TOPIC}`.")

if df.empty:
    if msg_count == 0:
        st.error(
            f"Nenhuma mensagem encontrada no tópico Kafka `{TOPIC}` para a janela dos últimos 7 dias. "
            "Não foi possível confirmar se há logins para essa matrícula."
        )
        st.stop()
    st.warning(f"Nenhum login encontrado para a matrícula **{target}** nos últimos 7 dias.")
    st.caption(f"{msg_count:,} mensagens varridas no Kafka.")
    st.stop()

st.success(f"**{len(df):,}** login(s) encontrado(s) para **{target}**")
st.caption(f"{msg_count:,} mensagens varridas no Kafka — {len(df):,} logins encontrados")
st.markdown("---")

# ── Curio ─────────────────────────────────────────────────────
curio = fetch_curio(target)
with st.expander("📋 Dados Organizacionais do Funcionário (curio)", expanded=True):
    if curio:
        curio_df = pd.DataFrame([curio])
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Nome", curio.get("nomeUsuario", "-"))
        c2.metric("Prefixo Dep. Atual", curio.get("codigoPrefixoDependenciaAtual", "-"))
        c3.metric("Código Técnico", curio.get("codigoTecnico", "-"))
        c4.metric("Comissão", curio.get("codigoComissaoUsuario", "-"))
        c5, c6, c7, c8 = st.columns(4)
        c5.metric("UO Dependência", curio.get("codigoUnidadeOrganizacionalDependenciaUsuario", "-"))
        c6.metric("Tipo UO Dep.", curio.get("codigoTipoUnidadeOrganizacionalDependencia", "-"))
        c7.metric("Perfil Org.", curio.get("codigoReferenciaOrganizacionalPerfil", "-"))
        c8.metric("Tipo Usuário", curio.get("codigoTipoUsuario", "-"))
        render_csv_downloads(
            [("dados do funcionario", curio_df, f"busca_matricula_curio_{target}.csv")],
            heading="Exportar dados do funcionário",
            columns=1,
        )
    else:
        st.warning("Não foi possível obter dados organizacionais do sidecar curio.")

# ── KPIs ──────────────────────────────────────────────────────
k1, k2, k3, k4, k5 = st.columns(5)
unique_hosts = df["hostname"].nunique()
unique_ips = df["src_ip"].nunique()
success = len(df[df["status"] == "Success"])
success_rate = success / len(df) * 100 if len(df) > 0 else 0
total_events = int(df["eventos"].sum())

k1.metric("Total Logins", len(df))
k2.metric("Hostnames Únicos", unique_hosts)
k3.metric("IPs Únicos", unique_ips)
k4.metric("Taxa de Sucesso", f"{success_rate:.1f}%")
k5.metric("Eventos (msgs)", total_events)

st.markdown("---")

# ── Timeline ──────────────────────────────────────────────────
st.subheader("Timeline de Logins")
df_sorted = df.sort_values("timestamp")
fig_tl = px.scatter(
    df_sorted, x="timestamp", y="hostname", color="hostname",
    hover_data=["src_ip", "mac_address", "os", "tunnel"],
    labels={"timestamp": LABEL_HORARIO, "hostname": "Hostname"},
)
fig_tl.update_layout(height=300, margin=dict(l=20, r=20, t=10, b=20), showlegend=True)
st.plotly_chart(fig_tl, use_container_width=True)

# ── Charts ────────────────────────────────────────────────────
df_time = df.copy()
df_time["hora"] = df_time["timestamp"].dt.floor("h")
rate = df_time.groupby("hora").size().reset_index(name="logins")
os_ct = df["os"].value_counts().reset_index()
os_ct.columns = ["SO", "Qty"]

ch1, ch2 = st.columns(2)
with ch1:
    st.subheader("Logins ao Longo do Tempo")
    fig = px.area(rate, x="hora", y="logins", labels={"hora": LABEL_HORARIO, "logins": "Logins/hora"})
    fig.update_layout(height=300, margin=dict(l=20, r=20, t=10, b=20))
    st.plotly_chart(fig, use_container_width=True)

with ch2:
    st.subheader("Distribuição por SO")
    fig_os = px.pie(os_ct, names="SO", values="Qty", hole=0.4)
    fig_os.update_layout(height=300, margin=dict(l=20, r=20, t=10, b=20))
    st.plotly_chart(fig_os, use_container_width=True)

render_csv_downloads(
    [
        ("timeline de logins", df_sorted, f"busca_matricula_timeline_{target}.csv"),
        ("logins por hora", rate, f"busca_matricula_logins_por_hora_{target}.csv"),
        ("distribuicao por so", os_ct, f"busca_matricula_so_{target}.csv"),
    ],
    heading="Exportar dados dos gráficos",
)

# ── Alerts ────────────────────────────────────────────────────
if unique_hosts > 1:
    st.warning(f"⚠️ Matrícula **{target}** logou de **{unique_hosts}** hostnames distintos")
    host_detail = df[["hostname", "src_ip", "mac_address"]].drop_duplicates().sort_values("hostname")
    st.dataframe(host_detail, use_container_width=True, hide_index=True)
    render_csv_downloads(
        [("hostnames distintos", host_detail, f"busca_matricula_hostnames_{target}.csv")],
        heading="Exportar alerta",
        columns=1,
    )

if unique_ips > 1:
    st.warning(f"⚠️ Matrícula **{target}** logou de **{unique_ips}** IPs distintos")
    ip_detail = df[["src_ip", "hostname"]].drop_duplicates().sort_values("src_ip")
    # Calculate pairwise IP distances
    ip_list = ip_detail["src_ip"].dropna().unique()
    distances = []
    for i in range(len(ip_list)):
        for j in range(i + 1, len(ip_list)):
            d = ip_distance(ip_list[i], ip_list[j])
            if d >= 0:
                distances.append(d)
    if distances:
        min_dist = min(distances)
        max_dist = max(distances)
        st.info(f"Distância mínima entre IPs: {min_dist:,} | máxima: {max_dist:,}")
    st.dataframe(ip_detail, use_container_width=True, hide_index=True)
    render_csv_downloads(
        [("ips distintos", ip_detail, f"busca_matricula_ips_{target}.csv")],
        heading="Exportar alerta",
        columns=1,
    )

# ── Full table ────────────────────────────────────────────────
st.subheader("Todos os Logins")
display_cols = [
    "timestamp", "chave", "user", "status", "src_ip",
    "office_mode_ip", "hostname", "os", "tunnel", "login_option",
    "client_version", "mac_address", "fingerprint", "user_group", "eventos",
]
display_cols = [c for c in display_cols if c in df.columns]
display_df = df.sort_values("timestamp", ascending=False)[display_cols]
st.dataframe(
    display_df,
    use_container_width=True,
    hide_index=True,
    column_config={
        "timestamp": st.column_config.DatetimeColumn(LABEL_HORARIO, format="DD/MM/YYYY HH:mm:ss"),
        "chave": "Chave", "user": "Usuário", "status": "Status",
        "src_ip": "IP Origem", "hostname": "Hostname", "os": "SO",
        "tunnel": "Túnel", "login_option": "Opção Login",
        "client_version": "Versão Cliente", "mac_address": "MAC",
        "office_mode_ip": "IP Office Mode", "fingerprint": "Fingerprint",
        "user_group": "Grupo", "eventos": "Eventos",
    },
)
render_csv_downloads(
    [("todos os logins", display_df, f"busca_matricula_logins_{target}.csv")],
    heading="Exportar logins",
    columns=1,
)
