from ip_utils import ip_distance, normalize_ip
"""Logins Suspeitos — consolidated suspicious-login detection.

Applies multiple detection policies against VPN login data from Kafka:
  1. Logins during formal absences (vacation, leave) via curio op2076328v2
  2. Shared fingerprints — same device fingerprint used by different employees
  3. Shared MAC addresses — same MAC address across different employees
  4. Off-hours logins — activity outside normal business hours
  5. Rapid IP switching — same user changing source IP many times in a short window
  6. High failure rate — users with abnormally high login failure ratios
"""

import re
import sys
import os
from collections import Counter, deque
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import pandas as pd
import plotly.express as px
import streamlit as st

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from auth_token import resolve_authenticated_user
from curio_service import integracao_curio
from kafka_service import consume_logins_since
from export_utils import render_csv_downloads, set_export_audit_context
from audit_service import record_action

_DT_COL_FORMAT = "DD/MM/YYYY HH:mm"
_DT_COL_FORMAT_SEC = "DD/MM/YYYY HH:mm:ss"

BR_TZ = ZoneInfo("America/Sao_Paulo")

st.set_page_config(page_title="Sinais de acesso para análise", layout="wide")

# ── Auth gate ─────────────────────────────────────────────────
_user_id = resolve_authenticated_user()
if not _user_id:
    st.error("Acesso nao autorizado. Faca login novamente pelo portal principal do dashboard.")
    st.stop()
set_export_audit_context(_user_id, "logins_suspeitos")

st.title("🔒 Sinais de acesso para análise")
st.caption(
    "Análise consolidada de ocorrências sinalizadas na VPN. Os resultados "
    "exigem revisão humana e, isoladamente, não comprovam irregularidade, "
    "fraude ou má conduta."
)

# ── Target matriculas for absence check ─────────────────────
_DEFAULT_MATRICULAS = [
    "F0734273", "F8456159", "F0744898", "F3514379",
    "F6333868", "F6002110", "F8711439", "F9813878",
]
_restrict_env = os.environ.get("SUSPECT_MATRICULAS_RESTRICT", "true").strip().lower()
RESTRICT_MATRICULAS = _restrict_env not in ("false", "0", "no")
_configured_raw = os.environ.get("SUSPECT_MATRICULAS", "").strip()
_configured_matriculas = {
    value.upper()
    for value in re.split(r"[,;\s]+", _configured_raw)
    if re.fullmatch(r"[A-Za-z]\d{7}", value.strip())
}
TARGET_MATRICULAS = (
    sorted(_configured_matriculas) if _configured_raw else list(_DEFAULT_MATRICULAS)
) if RESTRICT_MATRICULAS else None

# ── Helpers ──────────────────────────────────────────────────

def _parse_curio_date(date_str: str) -> datetime | None:
    if not date_str:
        return None
    for fmt in ("%d.%m.%Y", "%Y-%m-%d", "%d/%m/%Y"):
        try:
            return datetime.strptime(date_str, fmt)
        except ValueError:
            continue
    return None


def fetch_absences(matricula: str, year: int) -> list[dict]:
    numeric = re.sub(r"\D", "", matricula)
    payload = {
        "codigoMatriculaFuncionarioPesquisa": numeric,
        "dataInicioPerPesquisa": f"01.01.{year}",
        "dataFimPerPesquisa": f"31.12.{year}",
        "codigoChaveUsuario": "",
    }
    resp = integracao_curio("op2076328v2", payload)
    if not resp or "listaAusencia" not in resp:
        return []
    return [a for a in resp["listaAusencia"] if a.get("dataInicioAusencia")]


def check_login_during_absence(login_ts: datetime, absences: list[dict]) -> dict | None:
    for absence in absences:
        start = _parse_curio_date(absence.get("dataInicioAusencia", ""))
        end = _parse_curio_date(absence.get("dataFimAusencia", ""))
        if start and end and start.date() <= login_ts.date() <= end.date():
            return absence
    return None


# ── Detection functions ──────────────────────────────────────

def detect_shared_fingerprints(df: pd.DataFrame) -> pd.DataFrame:
    """Find fingerprints used by more than one distinct employee."""
    fingerprint = df["fingerprint"].fillna("").astype(str).str.strip()
    user_key = df["chave"].fillna("").astype(str).str.strip()
    fp = df[(fingerprint != "") & (user_key != "")].copy()
    if fp.empty:
        return pd.DataFrame()
    fp_users = fp.groupby("fingerprint")["chave"].nunique()
    shared = fp_users[fp_users > 1].index
    if shared.empty:
        return pd.DataFrame()
    detail = fp[fp["fingerprint"].isin(shared)]
    rows = []
    for fingerprint in shared:
        subset = detail[detail["fingerprint"] == fingerprint]
        users = subset[["chave", "user"]].drop_duplicates()
        for _, u in users.iterrows():
            user_logins = subset[subset["chave"] == u["chave"]]
            rows.append({
                "fingerprint": fingerprint,
                "chave": u["chave"],
                "usuario": u["user"],
                "hostnames": " | ".join(sorted(user_logins["hostname"].dropna().unique())),
                "ips": " | ".join(sorted({
                    normalized
                    for value in user_logins["src_ip"]
                    if (normalized := normalize_ip(value)) is not None
                })),
                "logins": len(user_logins),
                "primeiro_login": user_logins["timestamp"].min(),
                "ultimo_login": user_logins["timestamp"].max(),
            })
    return pd.DataFrame(rows).sort_values("fingerprint")


def detect_shared_macs(df: pd.DataFrame) -> pd.DataFrame:
    """Find MAC addresses used by more than one distinct employee."""
    address = df["mac_address"].fillna("").astype(str).str.strip().str.upper()
    user_key = df["chave"].fillna("").astype(str).str.strip()
    mac = df[(~address.isin(["", "00:00:00:00:00:00"])) & (user_key != "")].copy()
    if mac.empty:
        return pd.DataFrame()
    mac_users = mac.groupby("mac_address")["chave"].nunique()
    shared = mac_users[mac_users > 1].index
    if shared.empty:
        return pd.DataFrame()
    detail = mac[mac["mac_address"].isin(shared)]
    rows = []
    for address in shared:
        subset = detail[detail["mac_address"] == address]
        users = subset[["chave", "user"]].drop_duplicates()
        for _, u in users.iterrows():
            user_logins = subset[subset["chave"] == u["chave"]]
            rows.append({
                "mac_address": address,
                "chave": u["chave"],
                "usuario": u["user"],
                "hostnames": " | ".join(sorted(user_logins["hostname"].dropna().unique())),
                "logins": len(user_logins),
                "primeiro_login": user_logins["timestamp"].min(),
                "ultimo_login": user_logins["timestamp"].max(),
            })
    return pd.DataFrame(rows).sort_values("mac_address")


def detect_off_hours(df: pd.DataFrame) -> pd.DataFrame:
    """Flag logins outside business hours (before 06:00 or after 22:00, or weekends)."""
    ts = df["timestamp"].copy()
    if ts.dt.tz is None:
        ts = ts.dt.tz_localize(BR_TZ)
    else:
        ts = ts.dt.tz_convert(BR_TZ)
    hour = ts.dt.hour
    weekday = ts.dt.weekday
    is_weekend = weekday >= 5
    is_late = (hour < 6) | (hour >= 22)
    mask = is_weekend | is_late

    if not mask.any():
        return pd.DataFrame()

    off = df[mask].copy()
    off["hora_local"] = ts[mask]
    off["motivo"] = ""
    off.loc[is_weekend[mask].values, "motivo"] = "Fim de semana"
    off.loc[(is_late[mask].values) & (~is_weekend[mask].values), "motivo"] = "Horario atipico"
    off.loc[(is_late[mask].values) & (is_weekend[mask].values), "motivo"] = "Fim de semana + horario atipico"
    return off


def detect_rapid_ip_switching(df: pd.DataFrame, window_hours: int = 2, min_ips: int = 3) -> pd.DataFrame:
    """Flag users who logged in from many distinct IPs within a rolling time window."""
    if df.empty:
        return pd.DataFrame()
    clean = df.copy()
    clean["src_ip"] = clean["src_ip"].map(normalize_ip)
    clean = clean[clean["src_ip"].notna()]
    if clean.empty:
        return pd.DataFrame()
    rows = []
    for chave, user_df in clean.groupby("chave", sort=True):
        user_df = user_df.sort_values("timestamp")
        if user_df["src_ip"].nunique() < min_ips:
            continue
        ips_seen = deque()
        ip_counts = Counter()
        for _, row in user_df.iterrows():
            ts = row["timestamp"]
            ip = row["src_ip"]
            cutoff = ts - timedelta(hours=window_hours)
            while ips_seen and ips_seen[0][0] < cutoff:
                _, expired_ip = ips_seen.popleft()
                ip_counts[expired_ip] -= 1
                if ip_counts[expired_ip] <= 0:
                    del ip_counts[expired_ip]
            ips_seen.append((ts, ip))
            ip_counts[ip] += 1
            unique_ips = set(ip_counts)
            if len(unique_ips) >= min_ips:
                # Calculate IP distances in the window
                ip_list = list(unique_ips)
                distances = []
                for i in range(len(ip_list)):
                    for j in range(i + 1, len(ip_list)):
                        d = ip_distance(ip_list[i], ip_list[j])
                        if d >= 0:
                            distances.append(d)
                min_dist = min(distances) if distances else None
                max_dist = max(distances) if distances else None
                rows.append({
                    "chave": chave,
                    "usuario": row["user"],
                    "timestamp": ts,
                    "ip_atual": ip,
                    "ips_na_janela": " | ".join(sorted(unique_ips)),
                    "qtd_ips": len(unique_ips),
                    "hostname": row["hostname"],
                    "ip_dist_min": min_dist,
                    "ip_dist_max": max_dist,
                })
    if not rows:
        return pd.DataFrame()
    return pd.DataFrame(rows).sort_values("qtd_ips", ascending=False)


def detect_high_failure_rate(df: pd.DataFrame, min_attempts: int = 5, min_fail_pct: float = 50.0) -> pd.DataFrame:
    """Flag users with a high proportion of failed login attempts."""
    stats = df.groupby(["chave", "user"]).agg(
        total=("status", "size"),
        failures=("status", lambda s: (s != "Success").sum()),
    ).reset_index()
    stats["taxa_falha_pct"] = (stats["failures"] / stats["total"] * 100).round(1)
    flagged = stats[(stats["total"] >= min_attempts) & (stats["taxa_falha_pct"] >= min_fail_pct)]
    if flagged.empty:
        return pd.DataFrame()
    result = flagged.copy()
    result.columns = ["chave", "usuario", "total_tentativas", "falhas", "taxa_falha_pct"]
    return result.sort_values("taxa_falha_pct", ascending=False)


# ── Controls ─────────────────────────────────────────────────

TIME_OPTIONS = {
    "7 dias": 7 * 24 * 60,
    "14 dias": 14 * 24 * 60,
    "30 dias": 30 * 24 * 60,
}

ctrl1, ctrl2, ctrl3 = st.columns([1, 1, 1])
with ctrl1:
    time_window = st.selectbox(
        "Janela de tempo (Kafka)", list(TIME_OPTIONS.keys()), index=0, key="suspect_window",
    )
with ctrl2:
    check_absences = st.checkbox("Cruzar com ferias/ausencias (curio)", value=True, key="suspect_check_abs")
with ctrl3:
    st.markdown("<br>", unsafe_allow_html=True)
    buscar = st.button("Analisar sinais de acesso", type="primary", key="suspect_buscar")


if buscar:
    record_action(_user_id, "BUSCA_LOGINS_SUSPEITOS", "logins_suspeitos", {
        "janela": time_window, "check_absences": check_absences,
    })
    st.session_state["suspect_run"] = True
    st.session_state.pop("suspect_results", None)


# ── Main logic ───────────────────────────────────────────────

if st.session_state.get("suspect_run") and "suspect_results" not in st.session_state:
    minutes = TIME_OPTIONS[time_window]
    st.info("Consumindo logins do Kafka...")
    progress_bar = st.progress(0, text="Conectando ao Kafka...")

    def _on_progress(consumed, total):
        pct = consumed / total if total else 0
        progress_bar.progress(min(pct, 1.0), text=f"{consumed:,} / {total:,} mensagens")

    df_all, consumed = consume_logins_since(
        minutes, max_messages=None, on_progress=_on_progress,
    )
    progress_bar.progress(1.0, text=f"{consumed:,} mensagens consumidas")

    if df_all.empty:
        st.warning("Nenhum login encontrado no periodo selecionado.")
        st.session_state["suspect_run"] = False
        st.stop()

    results: dict = {"consumed_messages": consumed, "total_logins": len(df_all)}

    # 1 — Shared fingerprints
    results["shared_fingerprints"] = detect_shared_fingerprints(df_all)

    # 2 — Shared MACs
    results["shared_macs"] = detect_shared_macs(df_all)

    # 3 — Off-hours logins
    results["off_hours"] = detect_off_hours(df_all)

    # 4 — Rapid IP switching
    results["rapid_ip"] = detect_rapid_ip_switching(df_all)

    # 5 — High failure rate
    results["high_failure"] = detect_high_failure_rate(df_all)

    # 6 — Logins during absences (optional, calls curio)
    if st.session_state.get("suspect_check_abs", True):
        if TARGET_MATRICULAS:
            target_set = {m.upper() for m in TARGET_MATRICULAS}
            df_absence_scope = df_all[df_all["chave"].isin(target_set)]
        else:
            df_absence_scope = df_all[df_all["chave"] != ""]

        if df_absence_scope.empty:
            results["absence_logins"] = []
            results["absence_matriculas_checked"] = 0
        else:
            matriculas_found = df_absence_scope["chave"].unique().tolist()
            now = datetime.now()
            years_to_check = sorted({now.year, now.year - 1})
            suspect_rows = []
            status_text = st.empty()

            for i, mat in enumerate(matriculas_found):
                status_text.text(f"Consultando ausencias para {mat} ({i + 1}/{len(matriculas_found)})...")
                all_absences = []
                for year in years_to_check:
                    all_absences.extend(fetch_absences(mat, year))
                if not all_absences:
                    continue
                mat_logins = df_absence_scope[df_absence_scope["chave"] == mat]
                for _, login_row in mat_logins.iterrows():
                    ts = login_row["timestamp"]
                    if not isinstance(ts, datetime):
                        ts = pd.Timestamp(ts).to_pydatetime()
                    match = check_login_during_absence(ts, all_absences)
                    if match:
                        suspect_rows.append({
                            "chave": mat,
                            "usuario": login_row.get("user", ""),
                            "timestamp_login": ts,
                            "hostname": login_row.get("hostname", ""),
                            "src_ip": login_row.get("src_ip", ""),
                            "os": login_row.get("os", ""),
                            "ausencia": match.get("nomeAusencia", ""),
                            "inicio_ausencia": match.get("dataInicioAusencia", ""),
                            "fim_ausencia": match.get("dataFimAusencia", ""),
                            "dias_ausencia": match.get("quantidadeDiaAusencia", 0),
                        })
            status_text.empty()
            results["absence_logins"] = suspect_rows
            results["absence_matriculas_checked"] = len(matriculas_found)
    else:
        results["absence_logins"] = []
        results["absence_matriculas_checked"] = 0

    st.session_state["suspect_results"] = results
    st.session_state["suspect_run"] = False
    st.rerun()


if "suspect_results" not in st.session_state:
    st.info("Clique em **Analisar sinais de acesso** para iniciar a análise.")
    st.stop()


# ── Display results ──────────────────────────────────────────

results = st.session_state["suspect_results"]

df_shared_fp = results["shared_fingerprints"]
df_shared_mac = results["shared_macs"]
df_off_hours = results["off_hours"]
df_rapid_ip = results["rapid_ip"]
df_high_fail = results["high_failure"]
absence_rows = results["absence_logins"]

n_fp = df_shared_fp["fingerprint"].nunique() if not df_shared_fp.empty else 0
n_mac = df_shared_mac["mac_address"].nunique() if not df_shared_mac.empty else 0
n_off = len(df_off_hours) if not df_off_hours.empty else 0
n_rapid = df_rapid_ip["chave"].nunique() if not df_rapid_ip.empty else 0
n_fail = len(df_high_fail) if not df_high_fail.empty else 0
n_absence = len(absence_rows)

st.caption(
    f"{results['consumed_messages']:,} mensagens Kafka | "
    f"{results['total_logins']:,} logins analisados"
)

# KPIs
k1, k2, k3, k4, k5, k6 = st.columns(6)
k1.metric("Fingerprints Compartilhados", n_fp)
k2.metric("MACs Compartilhados", n_mac)
k3.metric("Logins Fora de Horario", n_off)
k4.metric("Troca Rapida de IP", n_rapid)
k5.metric("Alta Taxa de Falha", n_fail)
k6.metric("Logins em Ausencia", n_absence)

total_findings = n_fp + n_mac + (1 if n_off else 0) + n_rapid + n_fail + n_absence
if total_findings == 0:
    st.success("Nenhuma ocorrência foi sinalizada no período analisado.")
    st.stop()

st.markdown("---")

# ── Tabs ─────────────────────────────────────────────────────

tab_names = [
    f"Fingerprints ({n_fp})",
    f"MACs ({n_mac})",
    f"Fora de Horário ({n_off})",
    f"Troca de IP ({n_rapid})",
    f"Alta Falha ({n_fail})",
    f"Ausências ({n_absence})",
    "VPN + Rede Física",
]
tab_fp, tab_mac, tab_off, tab_ip, tab_fail, tab_abs, tab_vpn_mta = st.tabs(tab_names)


# ── Tab: Shared Fingerprints ────────────────────────────────
with tab_fp:
    st.subheader("Fingerprints Compartilhados entre Funcionarios")
    st.markdown(
        "O mesmo fingerprint de dispositivo foi utilizado por **funcionarios distintos**. "
        "Esta associação pode ter causas legítimas e deve ser revisada com o contexto do dispositivo."
    )
    if df_shared_fp.empty:
        st.success("Nenhum fingerprint compartilhado detectado.")
    else:
        fp_groups = df_shared_fp.groupby("fingerprint")["chave"].nunique().reset_index()
        fp_groups.columns = ["Fingerprint", "Funcionarios"]
        fp_groups = fp_groups.sort_values("Funcionarios", ascending=False)

        m1, m2 = st.columns(2)
        m1.metric("Fingerprints Compartilhados", n_fp)
        m2.metric("Funcionarios Envolvidos", df_shared_fp["chave"].nunique())

        st.dataframe(
            df_shared_fp, use_container_width=True, hide_index=True,
            column_config={
                "primeiro_login": st.column_config.DatetimeColumn("Primeiro Login", format=_DT_COL_FORMAT),
                "ultimo_login": st.column_config.DatetimeColumn("Ultimo Login", format=_DT_COL_FORMAT),
            },
        )
        render_csv_downloads(
            [("fingerprints compartilhados", df_shared_fp, "suspeitos_fingerprints.csv")],
            heading="Exportar", columns=1,
        )


# ── Tab: Shared MACs ────────────────────────────────────────
with tab_mac:
    st.subheader("Enderecos MAC Compartilhados entre Funcionarios")
    st.markdown(
        "O mesmo endereco MAC foi utilizado por **funcionarios distintos**. "
        "Pode refletir equipamento compartilhado autorizado, mudança de cadastro ou spoofing; "
        "a regra apenas sinaliza o caso para análise."
    )
    if df_shared_mac.empty:
        st.success("Nenhum MAC compartilhado detectado.")
    else:
        m1, m2 = st.columns(2)
        m1.metric("MACs Compartilhados", n_mac)
        m2.metric("Funcionarios Envolvidos", df_shared_mac["chave"].nunique())

        st.dataframe(
            df_shared_mac, use_container_width=True, hide_index=True,
            column_config={
                "primeiro_login": st.column_config.DatetimeColumn("Primeiro Login", format=_DT_COL_FORMAT),
                "ultimo_login": st.column_config.DatetimeColumn("Ultimo Login", format=_DT_COL_FORMAT),
            },
        )
        render_csv_downloads(
            [("macs compartilhados", df_shared_mac, "suspeitos_macs.csv")],
            heading="Exportar", columns=1,
        )


# ── Tab: Off-Hours ──────────────────────────────────────────
with tab_off:
    st.subheader("Logins Fora do Horario Comercial")
    st.markdown(
        "Logins realizados antes das **06:00**, apos as **22:00** ou em **fins de semana**. "
        "Turnos, escalas, feriados e exceções não são representados nesta regra; "
        "atividade fora desse intervalo não é, por si só, irregular."
    )
    if df_off_hours.empty:
        st.success("Nenhum login fora de horario detectado.")
    else:
        reason_counts = df_off_hours["motivo"].value_counts().reset_index()
        reason_counts.columns = ["Motivo", "Quantidade"]
        by_user = df_off_hours.groupby(["chave", "user"]).size().reset_index(name="logins_fora_horario")
        by_user["label"] = by_user["chave"] + " - " + by_user["user"]
        top = by_user.nlargest(20, "logins_fora_horario")

        m1, m2, m3 = st.columns(3)
        m1.metric("Total de Logins", n_off)
        m2.metric("Usuarios Afetados", df_off_hours["chave"].nunique())
        m3.metric("Em Fins de Semana", int((df_off_hours["motivo"].str.contains("semana")).sum()))

        ch1, ch2 = st.columns(2)
        with ch1:
            st.subheader("Distribuicao por Motivo")
            fig = px.pie(reason_counts, names="Motivo", values="Quantidade", hole=0.4)
            fig.update_layout(height=350, margin=dict(l=20, r=20, t=10, b=20))
            st.plotly_chart(fig, use_container_width=True)
        with ch2:
            st.subheader("Top 20 Usuarios")
            fig2 = px.bar(
                top, x="logins_fora_horario", y="label", orientation="h",
                color="logins_fora_horario", color_continuous_scale="OrRd",
                labels={"logins_fora_horario": "Logins", "label": "Usuario"},
            )
            fig2.update_layout(height=350, margin=dict(l=20, r=20, t=10, b=20), yaxis=dict(autorange="reversed"))
            st.plotly_chart(fig2, use_container_width=True)

        display_cols = [
            "hora_local", "chave", "user", "motivo", "src_ip",
            "hostname", "os", "tunnel",
        ]
        display_cols = [c for c in display_cols if c in df_off_hours.columns]
        st.dataframe(
            df_off_hours[display_cols].sort_values("hora_local", ascending=False).head(500),
            use_container_width=True, hide_index=True,
            column_config={
                "hora_local": st.column_config.DatetimeColumn("Horario Local", format=_DT_COL_FORMAT_SEC),
            },
        )
        render_csv_downloads(
            [
                ("logins fora de horario", df_off_hours[display_cols], "suspeitos_fora_horario.csv"),
                ("ranking por usuario", by_user[["chave", "user", "logins_fora_horario"]], "suspeitos_fora_horario_usuarios.csv"),
            ],
            heading="Exportar", columns=2,
        )


# ── Tab: Rapid IP Switching ─────────────────────────────────
with tab_ip:
    st.subheader("Troca Rapida de IP de Origem")
    st.markdown(
        "Usuarios que efetuaram login a partir de **3 ou mais IPs distintos** em uma "
        "janela de **2 horas**. Rede móvel, NAT, proxy, VPN e reconexões também "
        "podem produzir essa ocorrência."
    )
    if df_rapid_ip.empty:
        st.success("Nenhuma troca rapida de IP detectada.")
    else:
        m1, m2, m3 = st.columns(3)
        m1.metric("Usuários Sinalizados", n_rapid)
        m2.metric("Ocorrencias Totais", len(df_rapid_ip))
        m3.metric("Max IPs na Janela", int(df_rapid_ip["qtd_ips"].max()))

        # Show IP distance stats for flagged occurrences
        if "ip_dist_min" in df_rapid_ip.columns and "ip_dist_max" in df_rapid_ip.columns:
            min_dist = df_rapid_ip["ip_dist_min"].min()
            max_dist = df_rapid_ip["ip_dist_max"].max()
            st.info(f"Distância mínima entre IPs sinalizados: {min_dist:,} | máxima: {max_dist:,}")

        by_user = df_rapid_ip.groupby(["chave", "usuario"]).agg(
            ocorrencias=("timestamp", "size"),
            max_ips=("qtd_ips", "max"),
            min_ip_dist=("ip_dist_min", "min"),
            max_ip_dist=("ip_dist_max", "max"),
        ).reset_index().sort_values("max_ips", ascending=False)
        by_user["label"] = by_user["chave"] + " - " + by_user["usuario"]

        fig = px.bar(
            by_user.head(20), x="max_ips", y="label", orientation="h",
            color="max_ips", color_continuous_scale="Reds",
            labels={"max_ips": "Max IPs (2h)", "label": "Usuario"},
        )
        fig.update_layout(height=350, margin=dict(l=20, r=20, t=10, b=20), yaxis=dict(autorange="reversed"))
        st.plotly_chart(fig, use_container_width=True)

        st.dataframe(
            df_rapid_ip.head(500), use_container_width=True, hide_index=True,
            column_config={
                "timestamp": st.column_config.DatetimeColumn("Horario", format=_DT_COL_FORMAT_SEC),
                "ip_dist_min": st.column_config.NumberColumn("Distância IP Mínima"),
                "ip_dist_max": st.column_config.NumberColumn("Distância IP Máxima"),
            },
        )
        render_csv_downloads(
            [
                ("troca rapida de ip", df_rapid_ip, "suspeitos_troca_ip.csv"),
                ("resumo por usuario", by_user[["chave", "usuario", "ocorrencias", "max_ips", "min_ip_dist", "max_ip_dist"]], "suspeitos_troca_ip_resumo.csv"),
            ],
            heading="Exportar", columns=2,
        )


# ── Tab: High Failure Rate ──────────────────────────────────
with tab_fail:
    st.subheader("Alta Taxa de Falha de Login")
    st.markdown(
        "Usuarios com **50% ou mais** de tentativas de login falhadas (minimo 5 tentativas). "
        "Erros de configuração, senha expirada e repetição legítima também podem explicar o resultado."
    )
    if df_high_fail.empty:
        st.success("Nenhum usuario com alta taxa de falha detectado.")
    else:
        m1, m2 = st.columns(2)
        m1.metric("Usuários Sinalizados", n_fail)
        m2.metric("Maior Taxa de Falha", f"{df_high_fail['taxa_falha_pct'].max():.0f}%")

        fig = px.bar(
            df_high_fail.head(20),
            x="taxa_falha_pct", y="chave", orientation="h",
            color="taxa_falha_pct", color_continuous_scale="Reds",
            hover_data=["usuario", "total_tentativas", "falhas"],
            labels={"taxa_falha_pct": "Taxa Falha (%)", "chave": "Matricula"},
        )
        fig.update_layout(height=350, margin=dict(l=20, r=20, t=10, b=20), yaxis=dict(autorange="reversed"))
        st.plotly_chart(fig, use_container_width=True)

        st.dataframe(df_high_fail, use_container_width=True, hide_index=True)
        render_csv_downloads(
            [("alta taxa de falha", df_high_fail, "suspeitos_alta_falha.csv")],
            heading="Exportar", columns=1,
        )


# ── Tab: Absence Logins ─────────────────────────────────────
with tab_abs:
    st.subheader("Logins Durante Ferias ou Ausencias")
    st.markdown(
        "Logins VPN realizados durante periodos formais de ferias, licenca ou afastamento, "
        "com base nos registros de ausencia do RH via curio op2076328v2."
    )
    if not results.get("suspect_check_abs", True) and not absence_rows:
        st.info("O cruzamento com ferias/ausencias nao foi selecionado nesta analise.")
    elif not absence_rows:
        checked = results.get("absence_matriculas_checked", 0)
        st.success(
            "Nenhum login durante ausencia detectado"
            + (f" ({checked} matriculas verificadas)." if checked else ".")
        )
    else:
        df_abs = pd.DataFrame(absence_rows)
        m1, m2, m3 = st.columns(3)
        m1.metric("Logins Sinalizados", len(df_abs))
        m2.metric("Matrículas Sinalizadas", df_abs["chave"].nunique())
        m3.metric("Matriculas Verificadas", results.get("absence_matriculas_checked", 0))

        ch1, ch2 = st.columns(2)
        with ch1:
            st.subheader("Por Matricula")
            by_mat = df_abs.groupby(["chave", "usuario"]).size().reset_index(name="Logins")
            by_mat["label"] = by_mat["chave"] + " - " + by_mat["usuario"]
            fig = px.bar(
                by_mat.sort_values("Logins", ascending=False),
                x="Logins", y="label", orientation="h",
                color="Logins", color_continuous_scale="Reds",
                labels={"label": "Funcionario"},
            )
            fig.update_layout(height=350, margin=dict(l=20, r=20, t=10, b=20), yaxis=dict(autorange="reversed"))
            st.plotly_chart(fig, use_container_width=True)
        with ch2:
            st.subheader("Tipo de Ausencia")
            by_type = df_abs["ausencia"].value_counts().reset_index()
            by_type.columns = ["Ausencia", "Quantidade"]
            fig2 = px.pie(by_type, names="Ausencia", values="Quantidade", hole=0.4)
            fig2.update_layout(height=350, margin=dict(l=20, r=20, t=10, b=20))
            st.plotly_chart(fig2, use_container_width=True)

        st.dataframe(
            df_abs.sort_values("timestamp_login", ascending=False),
            use_container_width=True, hide_index=True,
            column_config={
                "timestamp_login": st.column_config.DatetimeColumn("Horario Login", format=_DT_COL_FORMAT_SEC),
            },
        )
        render_csv_downloads(
            [("logins durante ausencia", df_abs, "suspeitos_ausencias.csv")],
            heading="Exportar", columns=1,
        )


# ── Tab: VPN + Rede Física (backtest MTA_AUT_CLI_TRAN) ──────
with tab_vpn_mta:
    st.subheader("Correlação temporal entre evento VPN e autenticação OpenAM")
    st.markdown(
        "Regra R5 do backtest offline: correlaciona um evento em `DB2PEP.AUT_CPTV` "
        "com uma autenticação bem-sucedida em `DB2PEP.MTA_AUT_CLI_TRAN`, para o "
        "mesmo usuário, em IP privado diferente e dentro da janela configurada. "
        "As fontes não fornecem início/fim confiáveis de sessão; portanto, a "
        "correlação não comprova simultaneidade. "
        "Não há ação executada no LDAP; a página apenas consome o bundle "
        "produzido pelo backtest."
    )
    import json as _json
    import glob as _glob
    _static_dir = os.path.join(
        os.path.dirname(__file__), "..", "..", "static", "backtest_vpn"
    )
    _static_dir = os.path.abspath(_static_dir)
    _bundles = sorted(_glob.glob(os.path.join(_static_dir, "results_bundle_*.json")))
    if not _bundles:
        st.info(
            "Nenhum bundle de backtest disponível em "
            f"`{_static_dir}`. Rode `backtest_vpn_local` e copie o "
            "`results_bundle_*.json` para este diretório."
        )
    else:
        _latest_bundle = _bundles[-1]
        try:
            with open(_latest_bundle, "r", encoding="utf-8") as _fh:
                _bundle = _json.load(_fh)
        except Exception as _exc:  # noqa: BLE001
            st.error(f"Falha ao ler o bundle: {_exc}")
            _bundle = {}
        try:
            _bundle_version = int(_bundle.get("bundle_version") or 0)
        except (TypeError, ValueError):
            _bundle_version = 0
        if _bundle and _bundle_version < 2:
            st.warning(
                "O bundle disponível usa a semântica legada e não é compatível "
                "com as regras atuais. Execute novamente o backtest para gerar "
                "um bundle versão 2; o artefato antigo não foi alterado."
            )
            st.stop()
        _r5 = (_bundle.get("rules") or {}).get("R5", {}) or {}
        _params = _bundle.get("parameters") or {}
        _generated = _bundle.get("generated_at", "?")
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Status", str(_r5.get("status", "?")))
        c2.metric("Ocorrências (fluxos OpenAM)", int(_r5.get("flagged") or 0))
        c3.metric("Usuários sinalizados", int(_r5.get("flagged_users") or 0))
        c4.metric("Janela de correlação (± min)", int((_params.get("mta_table_config") or {}).get("delta_minutes", 0)))
        st.caption(
            f"Bundle: `{os.path.basename(_latest_bundle)}` · gerado em {_generated} · "
            f"período {_params.get('start','?')} → {_params.get('end','?')}"
        )
        if _r5.get("note"):
            st.info(_r5["note"])
        _samples = None
        for _case in ((_bundle.get("summary") or {}).get("cases") or []):
            if _case.get("name") == "vpn_ativa_com_login_em_rede_fisica_mta":
                _samples = _case.get("sample")
                break
        if _samples:
            _df_mta = pd.DataFrame(_samples)
            _rename_mta = {
                "USER_KEY": "Identificador autenticado do usuário",
                "VPN_TS": "Data e hora do evento VPN",
                "VPN_CPTV_IP": "IP corporativo/túnel da VPN",
                "MTA_TS": "Data e hora da autenticação OpenAM",
                "MTA_IP_CLIENTE": "IP cliente informado pelo OpenAM",
                "MTA_CD_UNCO_TRAN": "Identificador do fluxo OpenAM",
                "MTA_NM_ETP": "Etapa de decisão OpenAM",
            }
            _df_mta = _df_mta.rename(columns={k: v for k, v in _rename_mta.items() if k in _df_mta.columns})
            st.subheader("Evidências disponíveis no bundle")
            st.caption(
                "Cada linha é uma correlação R5. O identificador do usuário é "
                "exibido exatamente como foi gravado no bundle."
            )
            st.dataframe(_df_mta, use_container_width=True, hide_index=True)
            render_csv_downloads(
                [("VPN + rede fisica", _df_mta, "vpn_mta_amostra.csv")],
                heading="Exportar", columns=1,
            )
        else:
            st.success(
                "Nenhuma correlação R5 foi sinalizada no período coberto pelo último backtest."
            )
        _htm = os.path.join(_static_dir, "latest.fragment.htm")
        if os.path.isfile(_htm):
            with st.expander("Relatório HTML completo do backtest"):
                st.components.v1.html(
                    open(_htm, "r", encoding="utf-8").read(),
                    height=900,
                    scrolling=True,
                )
