import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import timedelta
import threading
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from kafka_service import KafkaStore, start_realtime_consumer, MAX_EVENTS, consume_logins_since
from auth_token import resolve_authenticated_user
from export_utils import render_csv_downloads, set_export_audit_context
from audit_service import record_action

_DT_COL_FORMAT = "DD/MM/YYYY HH:mm"
_LABEL_PRIMEIRO_LOGIN = "Primeiro Login"
_LABEL_ULTIMO_LOGIN = "Último Login"
_LABEL_USUARIOS = "Usuários"
_LABEL_USUARIO = "Usuário"
_LABEL_IPS_ORIGEM = "IPs Origem"
_LABEL_TOTAL_LOGINS = "Total Logins"
_LABEL_QTD_IPS = "Qtd IPs"
_LABEL_QTD_HOSTNAMES = "Qtd Hostnames"
_LABEL_EXPORTAR_ABA = "Exportar dados desta aba"

st.set_page_config(page_title="Múltiplos IPs + Hostnames", layout="wide")

# ── Auth gate ─────────────────────────────────────────────────
_user_id = resolve_authenticated_user()
if _user_id is None:
    st.error("Acesso não autorizado. Faça login novamente pelo portal principal do dashboard.")
    st.stop()
set_export_audit_context(_user_id, "multiplos_ips_hostnames")

st.title("⚠️ Usuários com Múltiplos IPs + Hostnames")


@st.cache_resource
def get_store_and_thread():
    store = KafkaStore(max_events=MAX_EVENTS)
    stop_event = threading.Event()
    t = threading.Thread(target=start_realtime_consumer, args=(store, stop_event), daemon=True)
    t.start()
    return store, stop_event


# ── Shared analysis logic ────────────────────────────────────

def render_multi_analysis(df):
    """Multi-IP and multi-hostname analysis with tabs."""
    if df.empty:
        st.info("Nenhum dado disponível.")
        return

    # KPIs
    k1, k2, k3, k4 = st.columns(4)
    total_users = df["chave"].nunique()

    user_ip_counts = df.groupby("chave")["src_ip"].nunique()
    user_host_counts = df.groupby("chave")["hostname"].nunique()
    multi_ip_chaves = set(user_ip_counts[user_ip_counts > 1].index)
    multi_host_chaves = set(user_host_counts[user_host_counts > 1].index)
    both_chaves = multi_ip_chaves & multi_host_chaves

    k1.metric("Usuários Totais", total_users)
    k2.metric("Múltiplos IPs", len(multi_ip_chaves))
    k3.metric("Múltiplos Hostnames", len(multi_host_chaves))
    k4.metric("Ambos (IP + Hostname)", len(both_chaves))

    render_csv_downloads(
        [("base analisada", df.sort_values("timestamp", ascending=False), "multiplos_ips_hostnames_base.csv")],
        heading="Exportar base analisada",
        columns=1,
    )

    st.markdown("---")

    tab_ips, tab_hosts, tab_both = st.tabs([
        "🌐 Múltiplos IPs",
        "💻 Múltiplos Hostnames",
        "🚨 Ambos",
    ])

    # ── Tab: Múltiplos IPs ────────────────────────────────────
    with tab_ips:
        multi_ip = (
            user_ip_counts[user_ip_counts > 1]
            .reset_index()
            .rename(columns={"src_ip": "ips_unicos"})
            .sort_values("ips_unicos", ascending=False)
        )

        if multi_ip.empty:
            st.success("Nenhum usuário logou de múltiplos IPs.")
        else:
            st.error(f"🚨 **{len(multi_ip)}** usuário(s) logaram de múltiplos IPs!")
            detail = df[df["chave"].isin(multi_ip_chaves)]
            dist = multi_ip["ips_unicos"].value_counts().sort_index().reset_index()
            dist.columns = ["IPs", _LABEL_USUARIOS]
            top = multi_ip.merge(
                df[["chave", "user"]].drop_duplicates(subset=["chave"]),
                on="chave", how="left",
            ).head(20)
            top["label"] = top["chave"] + " - " + top["user"].fillna("")

            ch1, ch2 = st.columns(2)
            with ch1:
                st.subheader("Distribuição: IPs por Usuário")
                fig = px.bar(dist, x="IPs", y=_LABEL_USUARIOS, color=_LABEL_USUARIOS,
                             color_continuous_scale="Reds",
                             labels={"IPs": "Nº de IPs", _LABEL_USUARIOS: "Nº de Usuários"})
                fig.update_layout(height=350, margin=dict(l=20, r=20, t=10, b=20))
                st.plotly_chart(fig, use_container_width=True)

            with ch2:
                st.subheader("Top 20 Usuários (mais IPs)")
                fig2 = px.bar(top, x="ips_unicos", y="label", orientation="h",
                              color="ips_unicos", color_continuous_scale="OrRd",
                              labels={"ips_unicos": "IPs", "label": _LABEL_USUARIO})
                fig2.update_layout(height=350, margin=dict(l=20, r=20, t=10, b=20),
                                   yaxis=dict(autorange="reversed"))
                st.plotly_chart(fig2, use_container_width=True)

            st.markdown("---")
            st.subheader("Detalhamento")
            rows = []
            for chave in multi_ip["chave"]:
                ud = detail[detail["chave"] == chave]
                ips = sorted(ud["src_ip"].dropna().unique())
                hostnames = sorted(ud["hostname"].dropna().unique())
                rows.append({
                    "Chave": chave,
                    _LABEL_USUARIO: ud["user"].iloc[0] if not ud.empty else "",
                    _LABEL_IPS_ORIGEM: " | ".join(ip for ip in ips if ip),
                    "Hostnames": " | ".join(h for h in hostnames if h),
                    _LABEL_PRIMEIRO_LOGIN: ud["timestamp"].min(),
                    _LABEL_ULTIMO_LOGIN: ud["timestamp"].max(),
                    _LABEL_TOTAL_LOGINS: len(ud),
                    _LABEL_QTD_IPS: len([ip for ip in ips if ip]),
                })
            multi_ip_detail_df = pd.DataFrame(rows).sort_values(_LABEL_QTD_IPS, ascending=False)
            st.dataframe(
                multi_ip_detail_df,
                use_container_width=True, hide_index=True,
                column_config={
                    _LABEL_PRIMEIRO_LOGIN: st.column_config.DatetimeColumn(format=_DT_COL_FORMAT),
                    _LABEL_ULTIMO_LOGIN: st.column_config.DatetimeColumn(format=_DT_COL_FORMAT),
                },
            )
            render_csv_downloads(
                [
                    ("distribuicao de ips", dist, "multiplos_ips_distribuicao.csv"),
                    ("top usuarios por ips", top[["chave", "user", "ips_unicos"]], "multiplos_ips_top_usuarios.csv"),
                    ("detalhamento de ips", multi_ip_detail_df, "multiplos_ips_detalhamento.csv"),
                ],
                heading=_LABEL_EXPORTAR_ABA,
            )

    # ── Tab: Múltiplos Hostnames ──────────────────────────────
    with tab_hosts:
        multi_host = (
            user_host_counts[user_host_counts > 1]
            .reset_index()
            .rename(columns={"hostname": "hostnames_unicos"})
            .sort_values("hostnames_unicos", ascending=False)
        )

        if multi_host.empty:
            st.success("Nenhum usuário logou de múltiplos hostnames.")
        else:
            st.error(f"🚨 **{len(multi_host)}** usuário(s) logaram de múltiplos hostnames!")
            detail = df[df["chave"].isin(multi_host_chaves)]
            dist = multi_host["hostnames_unicos"].value_counts().sort_index().reset_index()
            dist.columns = ["Hostnames", _LABEL_USUARIOS]
            top = multi_host.merge(
                df[["chave", "user"]].drop_duplicates(subset=["chave"]),
                on="chave", how="left",
            ).head(20)
            top["label"] = top["chave"] + " - " + top["user"].fillna("")

            ch1, ch2 = st.columns(2)
            with ch1:
                st.subheader("Distribuição: Hostnames por Usuário")
                fig = px.bar(dist, x="Hostnames", y=_LABEL_USUARIOS, color=_LABEL_USUARIOS,
                             color_continuous_scale="Reds",
                             labels={"Hostnames": "Nº de Hostnames", _LABEL_USUARIOS: "Nº de Usuários"})
                fig.update_layout(height=350, margin=dict(l=20, r=20, t=10, b=20))
                st.plotly_chart(fig, use_container_width=True)

            with ch2:
                st.subheader("Top 20 Usuários (mais hostnames)")
                fig2 = px.bar(top, x="hostnames_unicos", y="label", orientation="h",
                              color="hostnames_unicos", color_continuous_scale="OrRd",
                              labels={"hostnames_unicos": "Hostnames", "label": _LABEL_USUARIO})
                fig2.update_layout(height=350, margin=dict(l=20, r=20, t=10, b=20),
                                   yaxis=dict(autorange="reversed"))
                st.plotly_chart(fig2, use_container_width=True)

            st.markdown("---")
            st.subheader("Detalhamento")
            rows = []
            for chave in multi_host["chave"]:
                ud = detail[detail["chave"] == chave]
                hostnames = sorted(ud["hostname"].dropna().unique())
                ips = sorted(ud["src_ip"].dropna().unique())
                macs = sorted(ud["mac_address"].dropna().unique())
                rows.append({
                    "Chave": chave,
                    _LABEL_USUARIO: ud["user"].iloc[0] if not ud.empty else "",
                    "Hostnames": " | ".join(h for h in hostnames if h),
                    _LABEL_IPS_ORIGEM: " | ".join(ip for ip in ips if ip),
                    "MACs": " | ".join(m for m in macs if m),
                    _LABEL_PRIMEIRO_LOGIN: ud["timestamp"].min(),
                    _LABEL_ULTIMO_LOGIN: ud["timestamp"].max(),
                    _LABEL_TOTAL_LOGINS: len(ud),
                    _LABEL_QTD_HOSTNAMES: len([h for h in hostnames if h]),
                })
            multi_host_detail_df = pd.DataFrame(rows).sort_values(_LABEL_QTD_HOSTNAMES, ascending=False)
            st.dataframe(
                multi_host_detail_df,
                use_container_width=True, hide_index=True,
                column_config={
                    _LABEL_PRIMEIRO_LOGIN: st.column_config.DatetimeColumn(format=_DT_COL_FORMAT),
                    _LABEL_ULTIMO_LOGIN: st.column_config.DatetimeColumn(format=_DT_COL_FORMAT),
                },
            )
            render_csv_downloads(
                [
                    ("distribuicao de hostnames", dist, "multiplos_hostnames_distribuicao.csv"),
                    ("top usuarios por hostnames", top[["chave", "user", "hostnames_unicos"]], "multiplos_hostnames_top_usuarios.csv"),
                    ("detalhamento de hostnames", multi_host_detail_df, "multiplos_hostnames_detalhamento.csv"),
                ],
                heading=_LABEL_EXPORTAR_ABA,
            )

    # ── Tab: Ambos ────────────────────────────────────────────
    with tab_both:
        if not both_chaves:
            st.success("Nenhum usuário logou de múltiplos IPs E múltiplos hostnames simultaneamente.")
        else:
            st.error(
                f"🚨 **{len(both_chaves)}** usuário(s) logaram de "
                "múltiplos IPs **e** múltiplos hostnames!"
            )

            both_detail = df[df["chave"].isin(both_chaves)].copy()
            rows = []
            for chave in sorted(both_chaves):
                ud = both_detail[both_detail["chave"] == chave]
                hostnames = sorted(ud["hostname"].dropna().unique())
                ips = sorted(ud["src_ip"].dropna().unique())
                macs = sorted(ud["mac_address"].dropna().unique())
                rows.append({
                    "Chave": chave,
                    _LABEL_USUARIO: ud["user"].iloc[0] if not ud.empty else "",
                    _LABEL_IPS_ORIGEM: " | ".join(ip for ip in ips if ip),
                    "Hostnames": " | ".join(h for h in hostnames if h),
                    "MACs": " | ".join(m for m in macs if m),
                    _LABEL_PRIMEIRO_LOGIN: ud["timestamp"].min(),
                    _LABEL_ULTIMO_LOGIN: ud["timestamp"].max(),
                    _LABEL_TOTAL_LOGINS: len(ud),
                    _LABEL_QTD_IPS: len([ip for ip in ips if ip]),
                    _LABEL_QTD_HOSTNAMES: len([h for h in hostnames if h]),
                })
            summary = pd.DataFrame(rows).sort_values(_LABEL_QTD_IPS, ascending=False)
            st.dataframe(
                summary, use_container_width=True, hide_index=True,
                column_config={
                    _LABEL_PRIMEIRO_LOGIN: st.column_config.DatetimeColumn(format=_DT_COL_FORMAT),
                    _LABEL_ULTIMO_LOGIN: st.column_config.DatetimeColumn(format=_DT_COL_FORMAT),
                },
            )
            render_csv_downloads(
                [
                    ("resumo de usuarios com ambos", summary, "multiplos_ips_hostnames_ambos_resumo.csv"),
                    ("detalhamento de usuarios com ambos", both_detail.sort_values(["chave", "timestamp"]), "multiplos_ips_hostnames_ambos_detalhado.csv"),
                ],
                heading=_LABEL_EXPORTAR_ABA,
                columns=2,
            )

            st.markdown("---")
            st.subheader("Timeline por Usuário")
            for chave in sorted(both_chaves):
                ud = both_detail[both_detail["chave"] == chave].sort_values("timestamp")
                user_name = ud["user"].iloc[0] if not ud.empty else ""
                hn_count = ud["hostname"].nunique()
                ip_count = ud["src_ip"].nunique()
                with st.expander(
                    f"**{chave}** — {user_name} "
                    f"({ip_count} IPs, {hn_count} hostnames, {len(ud)} logins)"
                ):
                    st.dataframe(
                        ud[["timestamp", "hostname", "src_ip", "mac_address", "os", "tunnel"]],
                        use_container_width=True, hide_index=True,
                        column_config={
                            "timestamp": st.column_config.DatetimeColumn(
                                "Horário", format="DD/MM/YYYY HH:mm:ss",
                            ),
                        },
                    )
                    render_csv_downloads(
                        [("timeline do usuario", ud, f"multiplos_ips_hostnames_{chave}.csv")],
                        heading="Exportar dados deste usuário",
                        columns=1,
                    )
                    if len(ud) > 1:
                        fig = px.scatter(
                            ud, x="timestamp", y="hostname", color="src_ip",
                            hover_data=["mac_address"],
                            labels={"timestamp": "Horário", "hostname": "Hostname", "src_ip": "IP"},
                        )
                        fig.update_layout(height=250, margin=dict(l=20, r=20, t=10, b=20))
                        st.plotly_chart(fig, use_container_width=True)


# ── Mode selection ────────────────────────────────────────────
mode = st.radio("Modo", ["Tempo Real", "Retroativo"], horizontal=True, key="multi_mode")


# ══════════════════════════════════════════════════════════════
# TEMPO REAL
# ══════════════════════════════════════════════════════════════
if mode == "Tempo Real":
    store, _stop = get_store_and_thread()

    refresh_rate = st.selectbox(
        "Atualização (s)", [3, 5, 10, 15, 30], index=1, key="multi_refresh",
    )

    @st.fragment(run_every=timedelta(seconds=refresh_rate))
    def live_multi():
        df = store.get_logins_df()
        if df.empty:
            st.info("Aguardando mensagens do Kafka... O consumer está rodando em background.")
            return
        render_multi_analysis(df)

    live_multi()


else:
    TIME_OPTIONS = {
        "30 minutos": 30,
        "1 hora": 60,
        "2 horas": 120,
        "4 horas": 240,
        "8 horas": 480,
        "12 horas": 720,
        "24 horas": 1440,
        "3 dias": 3 * 24 * 60,
        "7 dias": 7 * 24 * 60,
    }

    ctrl1, ctrl2 = st.columns([2, 1])
    with ctrl1:
        time_window = st.selectbox(
            "Janela de tempo", list(TIME_OPTIONS.keys()), index=2, key="multi_window",
        )
    with ctrl2:
        st.markdown("<br>", unsafe_allow_html=True)
        if st.button("🔍 Buscar", type="primary", key="multi_buscar"):
            record_action(_user_id, "BUSCA_MULTIPLOS", "multiplos_ips_hostnames", {"janela": time_window})
            st.session_state["multi_run"] = True
            st.session_state["multi_minutes"] = TIME_OPTIONS[time_window]
            st.session_state.pop("multi_df", None)
            st.session_state.pop("multi_msg_count", None)

    # ── Consume ───────────────────────────────────────────────
    if st.session_state.get("multi_run") and "multi_df" not in st.session_state:
        minutes = st.session_state["multi_minutes"]
        st.info("Consumindo mensagens do Kafka...")
        progress_bar = st.progress(0, text="Conectando ao Kafka...")

        def _on_progress(consumed, total):
            pct = consumed / total if total else 0
            progress_bar.progress(min(pct, 1.0), text=f"{consumed:,} / {total:,} mensagens")

        df, consumed_messages = consume_logins_since(
            minutes, max_messages=500_000, on_progress=_on_progress,
        )

        if consumed_messages == 0:
            st.warning("Nenhuma mensagem encontrada no período selecionado.")
            st.session_state["multi_run"] = False
            st.stop()

        progress_bar.progress(1.0, text=f"{consumed_messages:,} mensagens consumidas")
        st.session_state["multi_df"] = df
        st.session_state["multi_msg_count"] = consumed_messages
        st.session_state["multi_run"] = False
        st.rerun()

    if "multi_df" not in st.session_state:
        st.info("Selecione a janela de tempo e clique em **Buscar**.")
        st.stop()

    # ── Display ───────────────────────────────────────────────
    df = st.session_state["multi_df"]
    msg_count = st.session_state.get("multi_msg_count", 0)

    if df.empty:
        st.warning("Nenhum login encontrado no período selecionado.")
        st.stop()

    st.caption(f"{msg_count:,} mensagens consumidas — {len(df):,} logins correlacionados")
    render_multi_analysis(df)
