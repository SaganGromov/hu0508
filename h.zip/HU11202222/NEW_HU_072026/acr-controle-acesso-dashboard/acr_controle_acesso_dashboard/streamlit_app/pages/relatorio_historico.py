import streamlit as st
import pandas as pd
import plotly.express as px
import re
import io
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from kafka_service import consume_all_logins
from auth_token import resolve_authenticated_user
from export_utils import render_csv_downloads, render_csv_download_button, set_export_audit_context
from audit_service import record_action

_COL_HOSTNAMES_UNICOS = "hostnames_unicos"
_LBL_USUARIOS_UNICOS = "Usuários Únicos"
_LBL_HORARIO = "Horário"
_LBL_USUARIO = "Usuário"
_LBL_USUARIOS = "Usuários"
_LBL_IP_ORIGEM = "IP Origem"
_LBL_IPS_UNICOS = "IPs Únicos"

st.set_page_config(page_title="Relatório Histórico VPN", layout="wide")

# ── Auth gate ─────────────────────────────────────────────────
_user_id = resolve_authenticated_user()
if _user_id is None:
    st.error("Acesso não autorizado. Faça login novamente pelo portal principal do dashboard.")
    st.stop()
set_export_audit_context(_user_id, "relatorio_historico")

st.title("📊 Relatório Histórico — Logins VPN")

def _to_csv(df):
    return df.to_csv(index=False).encode("utf-8")

def _to_excel(df):
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Dados")
    return buf.getvalue()

c1, c2, c3, c4 = st.columns([1, 1, 1, 2])
with c1:
    max_msgs = st.number_input(
        "Limite de mensagens (deixe 0 para ilimitado)", min_value=0, max_value=5_000_000,
        value=0, step=50_000,
    )
with c2:
    target_chave = st.text_input(
        "Filtrar por chave",
        placeholder="Ex: F1234567",
        key="hist_target_input",
    ).strip().upper()
with c3:
    st.markdown("<br>", unsafe_allow_html=True)
    if st.button("🔄 Consumir Dados Históricos", type="primary"):
        if target_chave and not re.fullmatch(r'[A-Za-z]\d{7}', target_chave):
            st.warning("Para filtro otimizado, informe a matrícula no formato F1234567.")
            st.stop()
        record_action(_user_id, "CONSUMIR_HISTORICO", "relatorio_historico", {
            "limite_msgs": max_msgs, "chave": target_chave,
        })
        st.session_state["run_historical"] = True
        st.session_state["hist_target_chave"] = target_chave
        st.session_state["hist_local_search"] = target_chave
        st.session_state.pop("hist_df", None)
with c4:
    st.caption(
        "Cria um consumidor temporário que lê a fila desde o início. "
        "Se uma matrícula for informada, a busca usa o mesmo caminho otimizado "
        "da página Busca por Matrícula."
    )


# ── Consume ───────────────────────────────────────────────────

if st.session_state.get("run_historical") and "hist_df" not in st.session_state:
    st.info("Consumindo mensagens históricas do Kafka... Isso pode levar alguns minutos.")
    progress_bar = st.progress(0, text="Conectando ao Kafka...")
    status_text = st.empty()

    def _on_progress(consumed, total):
        pct = consumed / total if total else 0
        progress_bar.progress(min(pct, 1.0), text=f"{consumed:,} / {total:,} mensagens")

    target_chave = st.session_state.get("hist_target_chave", "")
    df, consumed_messages = consume_all_logins(
        None if max_msgs == 0 else max_msgs,
        on_progress=_on_progress,
        target_chave=target_chave or None,
    )

    if consumed_messages == 0:
        st.warning("Nenhuma mensagem encontrada no tópico.")
        st.session_state["run_historical"] = False
        st.stop()

    progress_bar.progress(1.0, text=f"{consumed_messages:,} mensagens consumidas")
    status_text.text("Dados agregados em memória.")
    st.session_state["hist_df"] = df
    st.session_state["hist_msg_count"] = consumed_messages
    st.session_state["run_historical"] = False
    status_text.empty()
    st.rerun()


if "hist_df" not in st.session_state:
    st.info("Clique em **Consumir Dados Históricos** para gerar o relatório.")
    st.stop()


# ── Report ────────────────────────────────────────────────────
df = st.session_state["hist_df"]
msg_count = st.session_state.get("hist_msg_count", 0)

if df.empty:
    st.warning("Nenhum login encontrado nos dados consumidos.")
    st.stop()

# Search filter
search_col, _ = st.columns([1, 3])
with search_col:
    search = st.text_input(
        "Filtrar por chave",
        placeholder="Ex: F1234567",
        key="hist_local_search",
    ).strip().upper()

if search:
    if search != st.session_state.get("_audit_hist_last_search"):
        record_action(_user_id, "FILTRO_CHAVE", "relatorio_historico", {"chave": search})
        st.session_state["_audit_hist_last_search"] = search
    if re.match(r'^[A-Za-z]\d{0,7}$', search):
        df = df[df["chave"].str.startswith(search, na=False)]
    else:
        df = df[df["chave"] == search]
    if df.empty:
        st.warning(f"Nenhum resultado para '{search}'")
        st.stop()

st.markdown("---")

if st.session_state.get("hist_target_chave"):
    st.caption(
        f"Busca otimizada aplicada no consumo para a matrícula "
        f"**{st.session_state['hist_target_chave']}**."
    )

# KPIs
k1, k2, k3, k4, k5, k6 = st.columns(6)
total_logins = len(df)
unique_users = df["chave"].nunique()
unique_hosts = df["hostname"].nunique()
success = len(df[df["status"] == "Success"])
success_rate = success / total_logins * 100 if total_logins > 0 else 0
multi_host_count = (df.groupby("chave")["hostname"].nunique() > 1).sum()

k1.metric("Mensagens Kafka", f"{msg_count:,}")
k2.metric("Logins Únicos", f"{total_logins:,}")
k3.metric(_LBL_USUARIOS_UNICOS, f"{unique_users:,}")
k4.metric("Hosts Únicos", f"{unique_hosts:,}")
k5.metric("Taxa de Sucesso", f"{success_rate:.1f}%")
k6.metric("Usuários Multi-Host", f"{multi_host_count:,}", help="Usuários que logaram de mais de um hostname")

st.markdown("---")

tab_overview, tab_multihost, tab_alerts, tab_data = st.tabs([
    "📈 Visão Geral", "🔍 Múltiplos Hostnames", "⚠️ Alertas", "📋 Dados Completos"
])


# ── Tab 1: Visão Geral ───────────────────────────────────────
with tab_overview:
    df_time = df.copy()
    df_time["hora"] = df_time["timestamp"].dt.floor("h")
    rate = df_time.groupby("hora").size().reset_index(name="logins")
    top = df.groupby(["chave", "user"]).size().reset_index(name="Logins")
    top["label"] = top["chave"] + " - " + top["user"]
    top = top.nlargest(20, "Logins")
    os_ct = df["os"].value_counts().reset_index()
    os_ct.columns = ["SO", "Qty"]
    tn = df["tunnel"].value_counts().reset_index()
    tn.columns = ["Protocolo", "Qty"]
    cv = df["client_version"].value_counts().head(15).reset_index()
    cv.columns = ["Versão", "Qty"]
    lo = df["login_option"].value_counts().reset_index()
    lo.columns = ["Opção", "Qty"]

    c1, c2 = st.columns(2)
    with c1:
        st.subheader("Logins ao Longo do Tempo")
        fig = px.area(rate, x="hora", y="logins", labels={"hora": _LBL_HORARIO, "logins": "Logins/hora"})
        fig.update_layout(height=350, margin=dict(l=20, r=20, t=10, b=20))
        st.plotly_chart(fig, width='stretch')

    with c2:
        st.subheader("Top 20 Usuários")
        fig2 = px.bar(top, x="Logins", y="label", orientation="h", color="Logins",
                       color_continuous_scale="Blues", labels={"label": _LBL_USUARIO})
        fig2.update_layout(height=350, margin=dict(l=20, r=20, t=10, b=20), yaxis=dict(autorange="reversed"))
        st.plotly_chart(fig2, width='stretch')

    c3, c4 = st.columns(2)
    with c3:
        st.subheader("Distribuição por SO")
        fig3 = px.pie(os_ct, names="SO", values="Qty", hole=0.4)
        fig3.update_layout(height=350, margin=dict(l=20, r=20, t=10, b=20))
        st.plotly_chart(fig3, width='stretch')

    with c4:
        st.subheader("Protocolo de Túnel")
        fig4 = px.pie(tn, names="Protocolo", values="Qty", hole=0.4)
        fig4.update_layout(height=350, margin=dict(l=20, r=20, t=10, b=20))
        st.plotly_chart(fig4, width='stretch')

    c5, c6 = st.columns(2)
    with c5:
        st.subheader("Versão do Cliente")
        fig5 = px.bar(cv, x="Qty", y="Versão", orientation="h", color="Qty", color_continuous_scale="Greens")
        fig5.update_layout(height=350, margin=dict(l=20, r=20, t=10, b=20), yaxis=dict(autorange="reversed"))
        st.plotly_chart(fig5, width='stretch')

    with c6:
        st.subheader("Opção de Login")
        fig6 = px.pie(lo, names="Opção", values="Qty", hole=0.4)
        fig6.update_layout(height=350, margin=dict(l=20, r=20, t=10, b=20))
        st.plotly_chart(fig6, width='stretch')

    render_csv_downloads(
        [
            ("logins por hora", rate, "historico_logins_por_hora.csv"),
            ("top usuarios", top[["chave", "user", "Logins"]], "historico_top_usuarios.csv"),
            ("distribuicao por so", os_ct, "historico_distribuicao_so.csv"),
            ("protocolos de tunel", tn, "historico_protocolos_tunel.csv"),
            ("versoes do cliente", cv, "historico_versoes_cliente.csv"),
            ("opcoes de login", lo, "historico_opcoes_login.csv"),
        ],
        heading="Exportar dados da visão geral",
    )


# ── Tab 2: Múltiplos Hostnames ────────────────────────────────
with tab_multihost:
    st.subheader("Análise Detalhada — Usuários com Múltiplos Hostnames")
    st.markdown(
        "Usuários que efetuaram login de **mais de um hostname** distinto. "
        "Isso pode indicar uso compartilhado de credenciais, troca de máquina "
        "ou comportamento anômalo."
    )

    user_host_count = df.groupby("chave")["hostname"].nunique().reset_index()
    user_host_count.columns = ["chave", _COL_HOSTNAMES_UNICOS]
    multi = user_host_count[user_host_count[_COL_HOSTNAMES_UNICOS] > 1].sort_values(
        _COL_HOSTNAMES_UNICOS, ascending=False
    )

    if multi.empty:
        st.success("Nenhum usuário logou de múltiplos hostnames no período analisado.")
    else:
        st.error(f"🚨 **{len(multi)}** usuário(s) logaram de múltiplos hostnames!")

        m1, m2, m3 = st.columns(3)
        m1.metric("Usuários Afetados", len(multi))
        m2.metric("Média de Hostnames/Usuário", f"{multi[_COL_HOSTNAMES_UNICOS].mean():.1f}")
        m3.metric("Máximo de Hostnames", int(multi[_COL_HOSTNAMES_UNICOS].max()))

        st.markdown("---")

        ch1, ch2 = st.columns(2)
        with ch1:
            st.subheader("Distribuição: Hostnames por Usuário")
            dist = multi[_COL_HOSTNAMES_UNICOS].value_counts().sort_index().reset_index()
            dist.columns = ["Hostnames", _LBL_USUARIOS]
            fig_dist = px.bar(dist, x="Hostnames", y=_LBL_USUARIOS, color=_LBL_USUARIOS,
                              color_continuous_scale="Reds",
                              labels={"Hostnames": "Nº de Hostnames", _LBL_USUARIOS: "Nº de Usuários"})
            fig_dist.update_layout(height=350, margin=dict(l=20, r=20, t=10, b=20))
            st.plotly_chart(fig_dist, width='stretch')

        with ch2:
            st.subheader("Top 20 Usuários (mais hostnames)")
            top_multi = multi.merge(
                df[["chave", "user"]].drop_duplicates(subset=["chave"]),
                on="chave", how="left",
            ).head(20)
            top_multi["label"] = top_multi["chave"] + " - " + top_multi["user"].fillna("")
            fig_top = px.bar(top_multi, x=_COL_HOSTNAMES_UNICOS, y="label", orientation="h",
                             color=_COL_HOSTNAMES_UNICOS, color_continuous_scale="OrRd",
                             labels={_COL_HOSTNAMES_UNICOS: "Hostnames", "label": _LBL_USUARIO})
            fig_top.update_layout(height=350, margin=dict(l=20, r=20, t=10, b=20),
                                  yaxis=dict(autorange="reversed"))
            st.plotly_chart(fig_top, width='stretch')

        render_csv_downloads(
            [
                ("distribuicao de hostnames", dist, "historico_multi_host_distribuicao.csv"),
                ("top usuarios por hostname", top_multi[["chave", "user", _COL_HOSTNAMES_UNICOS]], "historico_multi_host_top_usuarios.csv"),
            ],
            heading="Exportar dados dos gráficos",
            columns=2,
        )

        st.markdown("---")
        st.subheader("Detalhamento por Usuário")

        multi_chaves = set(multi["chave"])
        detail_df = df[df["chave"].isin(multi_chaves)].copy()
        detail_df = detail_df.sort_values(["chave", "timestamp"])

        summary_rows = []
        for chave in multi["chave"]:
            user_data = detail_df[detail_df["chave"] == chave]
            user_name = user_data["user"].iloc[0] if not user_data.empty else ""
            hostnames = sorted(user_data["hostname"].dropna().unique())
            ips = sorted(user_data["src_ip"].dropna().unique())
            macs = sorted(user_data["mac_address"].dropna().unique())
            summary_rows.append({
                "Chave": chave,
                _LBL_USUARIO: user_name,
                "Hostnames": " | ".join(h for h in hostnames if h),
                "IPs Origem": " | ".join(ip for ip in ips if ip),
                "MACs": " | ".join(m for m in macs if m),
                "Primeiro Login": user_data["timestamp"].min(),
                "Último Login": user_data["timestamp"].max(),
                "Total Logins": len(user_data),
                "Qtd Hostnames": len([h for h in hostnames if h]),
            })

        summary_df = pd.DataFrame(summary_rows).sort_values("Qtd Hostnames", ascending=False)

        st.dataframe(
            summary_df, width='stretch', hide_index=True,
            column_config={
                "Primeiro Login": st.column_config.DatetimeColumn(format="DD/MM/YYYY HH:mm"),
                "Último Login": st.column_config.DatetimeColumn(format="DD/MM/YYYY HH:mm"),
            },
        )

        st.markdown("##### Exportar dados de Múltiplos Hostnames")
        exp1, exp2, exp3 = st.columns(3)
        with exp1:
            render_csv_download_button(
                "📥 Resumo (CSV)",
                summary_df,
                "multi_hostname_resumo.csv",
                export_label="resumo multi hostnames",
                key="csv-multi-host-resumo",
            )
        with exp2:
            detail_export = detail_df[[
                "timestamp", "chave", "user", "hostname", "src_ip",
                "mac_address", "os", "tunnel", "client_version",
                "login_option", "office_mode_ip", "fingerprint", "user_group",
            ]].sort_values(["chave", "timestamp"])
            render_csv_download_button(
                "📥 Detalhado (CSV)",
                detail_export,
                "multi_hostname_detalhado.csv",
                export_label="detalhamento multi hostnames",
                key="csv-multi-host-detalhado",
            )
        with exp3:
            st.download_button("📥 Resumo (Excel)", _to_excel(summary_df),
                               "multi_hostname_resumo.xlsx",
                               "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

        st.markdown("---")
        st.subheader("Timeline por Usuário")
        for _, row in summary_df.head(50).iterrows():
            chave = row["Chave"]
            with st.expander(f"**{chave}** — {row['Usuário']} ({row['Qtd Hostnames']} hostnames, {row['Total Logins']} logins)"):
                user_rows = detail_df[detail_df["chave"] == chave].sort_values("timestamp")
                st.dataframe(
                    user_rows[["timestamp", "hostname", "src_ip", "mac_address", "os", "tunnel", "client_version"]],
                    width='stretch', hide_index=True,
                    column_config={
                        "timestamp": st.column_config.DatetimeColumn(_LBL_HORARIO, format="DD/MM/YYYY HH:mm:ss"),
                        "hostname": "Hostname", "src_ip": _LBL_IP_ORIGEM,
                        "mac_address": "MAC", "os": "SO", "tunnel": "Túnel",
                        "client_version": "Versão Cliente",
                    },
                )
                render_csv_downloads(
                    [("timeline do usuario", user_rows, f"historico_multi_host_{chave}.csv")],
                    heading="Exportar dados deste usuário",
                    columns=1,
                )
                if len(user_rows) > 1:
                    fig_tl = px.scatter(user_rows, x="timestamp", y="hostname", color="hostname",
                                        hover_data=["src_ip", "mac_address"],
                                        labels={"timestamp": _LBL_HORARIO, "hostname": "Hostname"})
                    fig_tl.update_layout(height=250, margin=dict(l=20, r=20, t=10, b=20), showlegend=False)
                    st.plotly_chart(fig_tl, width='stretch')


# ── Tab 3: Alertas ────────────────────────────────────────────
with tab_alerts:
    a1, a2 = st.columns(2)

    with a1:
        st.subheader("Hostnames com Múltiplos Usuários")
        host_user = df.groupby("hostname")["chave"].nunique().reset_index()
        host_user.columns = ["Hostname", _LBL_USUARIOS_UNICOS]
        host_user = host_user[host_user["Hostname"] != ""].sort_values(_LBL_USUARIOS_UNICOS, ascending=False)
        muh = host_user[host_user[_LBL_USUARIOS_UNICOS] > 1]
        if not muh.empty:
            st.warning(f"{len(muh)} hostname(s) compartilhado(s)")
            rows = []
            for hostname in muh["Hostname"]:
                users = df[df["hostname"] == hostname][["chave", "user"]].drop_duplicates()
                for _, u in users.iterrows():
                    rows.append({"Hostname": hostname, "Chave": u["chave"], _LBL_USUARIO: u["user"]})
            shared_df = pd.DataFrame(rows)
            st.dataframe(shared_df, width='stretch', hide_index=True)
            render_csv_download_button(
                "📥 Exportar (CSV)",
                shared_df,
                "hostnames_compartilhados.csv",
                export_label="hostnames compartilhados",
                key="csv-hostnames-compartilhados",
            )
        else:
            st.success("Nenhum hostname compartilhado")

    with a2:
        st.subheader("Usuários com Múltiplos IPs")
        user_ips = df.groupby("chave")["src_ip"].nunique().reset_index()
        user_ips.columns = ["Chave", _LBL_IPS_UNICOS]
        user_ips = user_ips[user_ips["Chave"] != ""].sort_values(_LBL_IPS_UNICOS, ascending=False)
        mip = user_ips[user_ips[_LBL_IPS_UNICOS] > 1]
        if not mip.empty:
            st.warning(f"{len(mip)} usuário(s) com múltiplos IPs")
            rows = []
            for chave in mip["Chave"]:
                rr = df[df["chave"] == chave][["chave", "user", "src_ip", "hostname"]].drop_duplicates(subset=["chave", "src_ip"])
                for _, r in rr.iterrows():
                    rows.append({"Chave": r["chave"], _LBL_USUARIO: r["user"], _LBL_IP_ORIGEM: r["src_ip"], "Hostname": r["hostname"]})
            ip_df = pd.DataFrame(rows)
            st.dataframe(ip_df, width='stretch', hide_index=True)
            render_csv_download_button(
                "📥 Exportar (CSV)",
                ip_df,
                "usuarios_multiplos_ips.csv",
                export_label="usuarios com multiplos ips",
                key="csv-usuarios-multiplos-ips",
            )
        else:
            st.success("Nenhum usuário com múltiplos IPs")


# ── Tab 4: Dados Completos ────────────────────────────────────
with tab_data:
    st.subheader("Todos os Logins Históricos")
    display_cols = [
        "timestamp", "chave", "user", "status", "src_ip",
        "office_mode_ip", "hostname", "os", "tunnel", "login_option",
        "client_version", "mac_address", "fingerprint", "user_group", "eventos",
    ]
    display_cols = [c for c in display_cols if c in df.columns]
    display_df = df.sort_values("timestamp", ascending=False)

    st.dataframe(
        display_df[display_cols], width='stretch', hide_index=True,
        column_config={
            "timestamp": st.column_config.DatetimeColumn(_LBL_HORARIO, format="DD/MM/YYYY HH:mm:ss"),
            "chave": "Chave", "user": _LBL_USUARIO, "status": "Status",
            "src_ip": _LBL_IP_ORIGEM, "hostname": "Hostname", "os": "SO",
            "tunnel": "Túnel", "login_option": "Opção Login",
            "client_version": "Versão Cliente", "mac_address": "MAC",
            "office_mode_ip": "IP Office Mode", "fingerprint": "Fingerprint",
            "user_group": "Grupo", "eventos": "Eventos",
        },
    )

    st.markdown("##### Exportar Dados Completos")
    e1, e2 = st.columns(2)
    with e1:
        render_csv_download_button(
            "📥 Todos os Logins (CSV)",
            display_df[display_cols],
            "logins_historicos.csv",
            export_label="todos os logins historicos",
            key="csv-logins-historicos",
        )
    with e2:
        st.download_button("📥 Todos os Logins (Excel)", _to_excel(display_df[display_cols]),
                           "logins_historicos.xlsx",
                           "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
