"""Orquestrador de execuções sob demanda do ``backtest-vpn``.

Este módulo é usado pelas rotas FastAPI ``/backtest/executar*`` para lançar
uma execução do CLI ``backtest-vpn`` (do projeto ``backtest_vpn_local``) em
uma janela definida pelo usuário, acompanhar o progresso em tempo real e,
ao término, copiar o bundle e os HTM gerados para o diretório servido pelo
dashboard (``static/backtest_vpn/``).

Concorrência
------------
* Cada job roda em um subprocess (``subprocess.Popen``) e é acompanhado por
  um único thread daemon que faz o *tail* da saída padrão. O estado do job
  fica em um dicionário compartilhado protegido por um lock global.
* Somente **um job pode estar em execução por vez**. Novas requisições
  enquanto há um job ativo devolvem ``409 Conflict`` na camada HTTP.

Segurança
---------
* Todos os parâmetros aceitos pelo usuário são validados (regex/int range)
  antes de compor o argv do subprocess; nada é passado por ``shell=True``.
* Se o binário do backtest não estiver disponível nos caminhos fixos
  conhecidos da aplicação, o módulo reporta a indisponibilidade sem
  tentar executar.
"""

from __future__ import annotations

import glob
import os
import re
import shutil
# Processo é a fronteira necessária com o CLI de backtest. O executável é
# resolvido/validado e cada argumento externo passa por tipo, regex ou faixa.
import subprocess  # noqa: S404  # nosec B404
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

# Regex para validar timestamps ``YYYY-MM-DD HH:MM:SS`` fornecidos pelo usuário.
_TS_RE = re.compile(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$")


@dataclass
class BacktestJob:
    """Estado local (deste pod) de um subprocesso de backtest.

    O estado **autoritativo** do job fica no armazenamento durável
    compartilhado (:mod:`backtest_vpn.jobstore`) e é lido pelo painel de
    progresso a partir de qualquer pod. Esta estrutura guarda apenas o que é
    inerentemente local: o subprocesso e o *tail* da sua saída.
    """

    job_id: str
    start_window: str
    end_window: str
    params: dict
    status: str = "pending"  # pending | running | success | failed | cancelled
    log_lines: list[str] = field(default_factory=list)
    started_at: Optional[str] = None
    finished_at: Optional[str] = None
    stamp: Optional[str] = None
    bundle_path: Optional[str] = None
    html_path: Optional[str] = None
    fragment_path: Optional[str] = None
    error: Optional[str] = None
    exit_code: Optional[int] = None
    subcommand: str = "full"

    def public_view(self) -> dict:
        """Snapshot serializável para consumo pelo endpoint JSON/SSE."""
        return {
            "job_id": self.job_id,
            "status": self.status,
            "start_window": self.start_window,
            "end_window": self.end_window,
            "params": self.params,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "stamp": self.stamp,
            "bundle": os.path.basename(self.bundle_path) if self.bundle_path else None,
            "html": os.path.basename(self.html_path) if self.html_path else None,
            "fragment": os.path.basename(self.fragment_path) if self.fragment_path else None,
            "error": self.error,
            "exit_code": self.exit_code,
            "log_size": len(self.log_lines),
            "subcommand": self.subcommand,
        }


class BacktestUnavailable(RuntimeError):
    """Erro levantado quando o CLI do backtest não está disponível."""


class BacktestBusy(RuntimeError):
    """Erro levantado quando já há um job em execução."""


class BacktestRunner:
    """Registro thread-safe de jobs de backtest com no máximo um ativo."""

    def __init__(self, *, bin_path_override: Optional[str] = None) -> None:
        self._jobs: dict[str, BacktestJob] = {}
        self._lock = threading.Lock()
        self._active_job_id: Optional[str] = None
        self._max_jobs = 20  # LRU trim
        self._max_log_lines = 5000
        self._bin_path_override = None
        if bin_path_override:
            self._bin_path_override = self._resolve_executable_path(bin_path_override)

    # ── configuração ─────────────────────────────────
    # Allowlist for individual path characters. Checkmarx recognises
    # character-by-character reconstruction from a hard-coded allowlist
    # as a sanitiser boundary; the resulting string is treated as
    # untainted at every downstream sink (file ops, subprocess argv).
    _BIN_PATH_ALLOWED_CHARS = frozenset(
        "abcdefghijklmnopqrstuvwxyz"
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "0123456789"
        "._@/-"
    )
    _BIN_PATH_MAX_LEN = 4096

    def _sanitize_bin_path(self, raw: str) -> Optional[str]:
        """Reconstruct ``raw`` from a hard-coded character allowlist.

        Any character outside the allowlist causes rejection (returns
        ``None``). Reconstructing the string character-by-character
        breaks taint propagation from the environment source into every
        downstream sink — filesystem operations (``os.path.isfile``,
        ``os.access``) as well as subprocess argv construction.
        """
        if not isinstance(raw, str) or not raw or len(raw) > self._BIN_PATH_MAX_LEN:
            return None
        cleaned_chars = []
        for ch in raw:
            if ch in self._BIN_PATH_ALLOWED_CHARS:
                cleaned_chars.append(ch)
            else:
                return None
        return "".join(cleaned_chars)

    def _resolve_executable_path(self, candidate: str) -> Optional[str]:
        """Return ``candidate`` only when it resolves to an executable file."""
        try:
            resolved = os.path.realpath(candidate)
        except (OSError, ValueError):
            return None
        if not os.path.isabs(resolved):
            return None
        sanitized = self._sanitize_bin_path(resolved)
        if not sanitized:
            return None
        if not os.path.isfile(sanitized) or not os.access(sanitized, os.X_OK):
            return None
        return sanitized

    def _candidate_bin_paths(self) -> tuple[str, ...]:
        """Return fixed, code-defined candidate locations for the CLI wrapper."""
        app_root = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        return (
            "/app/scripts/backtest-vpn",
            os.path.join(app_root, "scripts", "backtest-vpn"),
            os.path.join(os.getcwd(), "scripts", "backtest-vpn"),
        )

    def bin_path(self) -> Optional[str]:
        """Return a sanitised path to the ``backtest-vpn`` binary.

        Production no longer reads the executable path from an environment
        variable. This removes the tainted ``environ -> file operation`` flow
        entirely for Checkmarx similarity ``-338222676``. The runner only
        probes fixed, code-defined paths and a constructor-only override used
        by unit tests.
        """
        if self._bin_path_override:
            return self._bin_path_override
        for candidate in self._candidate_bin_paths():
            resolved = self._resolve_executable_path(candidate)
            if resolved:
                return resolved
        return None

    def reports_dir(self) -> str:
        app_root = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        return os.environ.get(
            "BACKTEST_VPN_REPORTS_DIR",
            os.path.join(app_root, "reports"),
        )

    def static_dir(self) -> str:
        return os.path.abspath(
            os.path.join(
                os.path.dirname(__file__),
                "static",
                "backtest_vpn",
            )
        )

    def is_available(self) -> bool:
        return self.bin_path() is not None

    def credentials_ok(self) -> bool:
        """Aceita credenciais DB2 via arquivo JSON *ou* via variaveis de ambiente.

        Suporta duas configurações:

        * ``DB2_CREDENTIALS_FILE`` apontando para um JSON
          ``{"username": ..., "password": ...}``; ou
        * ``DB2_USERNAME`` + ``DB2_PASSWORD`` (padrão preferido no k8s,
          espelhando como as credenciais do Kafka são injetadas).
        """
        raw = os.environ.get("DB2_CREDENTIALS_FILE", "").strip()
        if raw and os.path.isfile(raw):
            return True
        user = os.environ.get("DB2_USERNAME") or os.environ.get("DB2_USER")
        pwd = os.environ.get("DB2_PASSWORD") or os.environ.get("DB2_PASS")
        return bool(user and pwd)

    # ── introspecção de jobs ─────────────────────────────────
    def get_job(self, job_id: str) -> Optional[BacktestJob]:
        with self._lock:
            return self._jobs.get(job_id)

    def list_jobs(self, limit: int = 20) -> list[BacktestJob]:
        with self._lock:
            items = list(self._jobs.values())
        items.sort(key=lambda j: j.started_at or "", reverse=True)
        return items[:limit]

    def active_job_id(self) -> Optional[str]:
        with self._lock:
            return self._active_job_id

    # ── lançamento ───────────────────────────────────────────
    def submit(
        self,
        start_window: str,
        end_window: str,
        *,
        mta_delta_minutes: int = 15,
        mta_max_users: int = 400,
        mta_users_per_batch: int = 8,
        mta_chunk_hours: int = 4,
        active_window_hours: int = 8,
        distinct_limit: int = 2,
        daily_login_limit: int = 2,
        enabled_rules: str = "R1,R2,R3,R4,R5,R6,R7,R8,R9",
        job_id: Optional[str] = None,
    ) -> BacktestJob:
        """Valida os parâmetros e enfileira um novo job.

        Quando ``job_id`` é informado, o subprocesso executa ``run-job`` sobre
        um job **já enfileirado no estado durável compartilhado**, de modo que
        o identificador usado pela interface é o mesmo legível de qualquer pod.
        Sem ``job_id`` o comportamento anterior (``full``) é preservado.

        Levanta :class:`BacktestUnavailable` quando o binário não está
        disponível ou as credenciais DB2 não estão configuradas, e
        :class:`BacktestBusy` quando já há um job em execução.
        """
        if not self.is_available():
            raise BacktestUnavailable(
                "O executável do backtest não está disponível nesta implantação. "
                "Garanta que o wrapper ``backtest-vpn`` exista em um dos caminhos "
                "fixos suportados pela aplicação."
            )
        if not self.credentials_ok():
            raise BacktestUnavailable(
                "Credenciais DB2 não configuradas: defina "
                "``DB2_USERNAME``+``DB2_PASSWORD`` via Secret (padrão k8s) "
                "ou ``DB2_CREDENTIALS_FILE`` apontando para um arquivo JSON."
            )
        _validate_ts(start_window, "start")
        _validate_ts(end_window, "end")
        if start_window >= end_window:
            raise ValueError("Janela inválida: ``start`` deve ser anterior a ``end``.")
        params = {
            "mta_delta_minutes": _int_in_range(mta_delta_minutes, 1, 120, "mta_delta_minutes"),
            "mta_max_users": _int_in_range(mta_max_users, 1, 5000, "mta_max_users"),
            "mta_users_per_batch": _int_in_range(mta_users_per_batch, 1, 40, "mta_users_per_batch"),
            "mta_chunk_hours": _int_in_range(mta_chunk_hours, 1, 168, "mta_chunk_hours"),
            "active_window_hours": _int_in_range(active_window_hours, 1, 168, "active_window_hours"),
            "distinct_limit": _int_in_range(distinct_limit, 1, 1000, "distinct_limit"),
            "daily_login_limit": _int_in_range(daily_login_limit, 1, 100000, "daily_login_limit"),
            "enabled_rules": _validate_rules(enabled_rules),
        }

        with self._lock:
            if self._active_job_id and self._jobs.get(self._active_job_id, BacktestJob("", "", "", {})).status in ("pending", "running"):
                raise BacktestBusy(
                    "Já existe um job de backtest em execução. Aguarde a "
                    "conclusão antes de disparar um novo."
                )
            resolved_job_id = _validate_job_id(job_id) if job_id else uuid.uuid4().hex
            job = BacktestJob(
                job_id=resolved_job_id,
                start_window=start_window,
                end_window=end_window,
                params=params,
                status="pending",
                started_at=datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                subcommand="run-job" if job_id else "full",
            )
            job_id = resolved_job_id
            self._jobs[job_id] = job
            self._active_job_id = job_id
            # Trim LRU
            if len(self._jobs) > self._max_jobs:
                for old in sorted(self._jobs.values(), key=lambda j: j.started_at or "")[:-self._max_jobs]:
                    self._jobs.pop(old.job_id, None)

        t = threading.Thread(target=self._run, args=(job_id,), daemon=True, name=f"backtest-{job_id[:8]}")
        t.start()
        return job

    # ── execução ────────────────────────────────────────────
    def _run(self, job_id: str) -> None:
        job = self.get_job(job_id)
        if job is None:
            return
        try:
            self._execute(job)
        except Exception as exc:  # noqa: BLE001
            self._append_log(
                job, "[runner] erro inesperado ({0})".format(type(exc).__name__)
            )
            self._finalize(
                job,
                "failed",
                error="A execução não pôde ser concluída; consulte o log operacional.",
            )
        finally:
            with self._lock:
                if self._active_job_id == job_id:
                    self._active_job_id = None

    def _execute(self, job: BacktestJob) -> None:
        bin_path = self.bin_path()
        if bin_path is None:
            raise BacktestUnavailable(
                "O executável validado deixou de estar disponível antes da execução."
            )
        cmd = [
            bin_path,
            job.subcommand,
        ]
        if job.subcommand == "run-job":
            cmd += ["--job-id", job.job_id]
        cmd += [
            "--start", job.start_window,
            "--end", job.end_window,
            "--mta-delta-minutes", str(job.params["mta_delta_minutes"]),
            "--mta-max-users", str(job.params["mta_max_users"]),
            "--mta-users-per-batch", str(job.params["mta_users_per_batch"]),
            "--mta-chunk-hours", str(job.params["mta_chunk_hours"]),
            "--active-window-hours", str(job.params["active_window_hours"]),
            "--distinct-limit", str(job.params["distinct_limit"]),
            "--daily-login-limit", str(job.params["daily_login_limit"]),
            "--rules", job.params["enabled_rules"],
            # Sempre exibir matriculas explicitas — nenhum dado deve aparecer
            # pseudonimizado nas paginas de backtest.
            "--no-pseudonymize",
        ]
        env = os.environ.copy()
        env.setdefault("MTA_DELTA_MINUTES", str(job.params["mta_delta_minutes"]))
        env.setdefault("MTA_MAX_USERS", str(job.params["mta_max_users"]))
        env.setdefault("MTA_USERS_PER_BATCH", str(job.params["mta_users_per_batch"]))
        env.setdefault("MTA_CHUNK_HOURS", str(job.params["mta_chunk_hours"]))

        self._append_log(job, f"[runner] iniciando: {' '.join(cmd)}")
        job.status = "running"

        # A tag do bundle é composta pelo timestamp da execução; capturamos do stdout.
        stamp_re = re.compile(r"results_bundle_(\d{8}_\d{6})\.json")

        proc = subprocess.Popen(  # noqa: S603  # nosec B603
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            env=env,
            text=True,
            bufsize=1,
        )
        if proc.stdout is None:
            proc.terminate()
            proc.wait()
            raise BacktestUnavailable(
                "O processo de backtest não disponibilizou a saída monitorada."
            )
        for line in proc.stdout:
            line = line.rstrip()
            self._append_log(job, line)
            m = stamp_re.search(line)
            if m and not job.stamp:
                job.stamp = m.group(1)
        proc.wait()
        job.exit_code = proc.returncode
        self._append_log(job, f"[runner] backtest-vpn {job.subcommand} exit={proc.returncode}")
        if proc.returncode != 0:
            self._finalize(
                job, "failed",
                error=f"backtest-vpn {job.subcommand} retornou {proc.returncode}",
            )
            return

        # Ensure we know which stamp to promote: fall back to the newest bundle.
        reports = self.reports_dir()
        if not job.stamp:
            candidates = sorted(glob.glob(os.path.join(reports, "results_bundle_*.json")))
            if candidates:
                latest = os.path.basename(candidates[-1])
                m = stamp_re.match(latest)
                if m:
                    job.stamp = m.group(1)
        if not job.stamp:
            self._finalize(job, "failed", error="Não foi possível localizar o bundle gerado.")
            return

        # Renderiza HTML (fragmento + standalone) se ainda não existir.
        html_dir = os.path.join(reports, "html")
        os.makedirs(html_dir, exist_ok=True)
        bundle_path = os.path.join(reports, f"results_bundle_{job.stamp}.json")
        htm_path = os.path.join(html_dir, f"relatorio_backtest_vpn_{job.stamp}.htm")
        fragment_path = os.path.join(html_dir, f"relatorio_backtest_vpn_{job.stamp}.fragment.htm")
        if not os.path.isfile(htm_path):
            self._append_log(job, "[runner] gerando relatório HTML…")
            proc2 = subprocess.Popen(  # noqa: S603  # nosec B603
                [bin_path, "report-html", "--bundle", bundle_path, "--out-dir", html_dir],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env, text=True, bufsize=1,
            )
            if proc2.stdout is None:
                proc2.terminate()
                proc2.wait()
                raise BacktestUnavailable(
                    "O gerador de relatório não disponibilizou a saída monitorada."
                )
            for line in proc2.stdout:
                self._append_log(job, line.rstrip())
            proc2.wait()
            if proc2.returncode != 0:
                self._finalize(job, "failed", error=f"report-html retornou {proc2.returncode}")
                return

        # Publica no diretório servido pelo dashboard.
        dest = self.static_dir()
        os.makedirs(dest, exist_ok=True)
        shutil.copy2(bundle_path, os.path.join(dest, os.path.basename(bundle_path)))
        shutil.copy2(htm_path, os.path.join(dest, os.path.basename(htm_path)))
        shutil.copy2(fragment_path, os.path.join(dest, os.path.basename(fragment_path)))
        shutil.copy2(htm_path, os.path.join(dest, "latest.htm"))
        shutil.copy2(fragment_path, os.path.join(dest, "latest.fragment.htm"))
        job.bundle_path = os.path.join(dest, os.path.basename(bundle_path))
        job.html_path = os.path.join(dest, os.path.basename(htm_path))
        job.fragment_path = os.path.join(dest, os.path.basename(fragment_path))
        self._append_log(job, f"[runner] artefatos publicados em {dest}")
        self._finalize(job, "success")

    # ── helpers ──────────────────────────────────────────────
    def _append_log(self, job: BacktestJob, line: str) -> None:
        with self._lock:
            job.log_lines.append(line)
            if len(job.log_lines) > self._max_log_lines:
                job.log_lines = job.log_lines[-self._max_log_lines:]

    def _finalize(self, job: BacktestJob, status: str, error: Optional[str] = None) -> None:
        with self._lock:
            job.status = status
            job.finished_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            if error:
                job.error = error


_JOB_ID_RE = re.compile(r"^(?:bt-[0-9a-f]{40}|[0-9a-f]{32})$")


def _validate_job_id(value) -> str:
    """Aceita apenas identificadores gerados pela camada de comandos.

    A validação impede que qualquer entrada externa componha o argv do
    subprocesso ou nomes de arquivo de publicação.
    """
    text = str(value or "").strip()
    if not _JOB_ID_RE.match(text):
        raise ValueError(
            "``job_id`` inválido: use o identificador emitido pela camada de comandos."
        )
    return text


def _validate_ts(value: str, label: str) -> None:
    if not isinstance(value, str) or not _TS_RE.match(value):
        raise ValueError(
            f"Formato inválido para ``{label}``: use ``YYYY-MM-DD HH:MM:SS`` (24 h)."
        )


def _int_in_range(value, lo: int, hi: int, label: str) -> int:
    try:
        n = int(value)
    except (TypeError, ValueError):
        raise ValueError(f"``{label}`` deve ser um inteiro entre {lo} e {hi}.")
    if not (lo <= n <= hi):
        raise ValueError(f"``{label}`` fora do intervalo permitido [{lo}, {hi}].")
    return n


def _validate_rules(value) -> str:
    allowed = {"R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8", "R9"}
    parts = [item.strip().upper() for item in str(value or "").split(",") if item.strip()]
    if not parts:
        raise ValueError("Selecione pelo menos uma regra.")
    unknown = sorted(set(parts) - allowed)
    if unknown:
        raise ValueError("Regras inválidas: {0}.".format(", ".join(unknown)))
    return ",".join(rule for rule in ("R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8", "R9") if rule in set(parts))


# Instância única (singleton) usada pelas rotas FastAPI.
RUNNER = BacktestRunner()


__all__ = [
    "BacktestBusy",
    "BacktestJob",
    "BacktestRunner",
    "BacktestUnavailable",
    "RUNNER",
    "_validate_job_id",
]
