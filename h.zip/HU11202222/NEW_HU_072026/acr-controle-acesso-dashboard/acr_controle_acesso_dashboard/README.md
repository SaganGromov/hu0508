# ACR Controle Acesso Dashboard

O pacote Python deste repositório é executado pelo dashboard principal descrito no [README da raiz](../README.md).

Para desenvolvimento local:

```bash
cd ..
./setup_env.sh
./local_test.sh
```

Para gerar ou atualizar o lock file:

```bash
cd ..
./scripts/generate-uv-lock.sh
```
