# Necessário para coordenar os dois servidores do contêiner. Todos os
# executáveis abaixo usam ``sys.executable``, argv fixo e ``shell=False``.
import subprocess  # nosec B404
import sys
import signal
import os


def start():
    base_url_path = os.environ.get("STREAMLIT_BASE_URL_PATH", "/streamlit")
    streamlit_proc = subprocess.Popen(  # nosec B603
        [
            sys.executable, "-m", "streamlit", "run",
            "acr_controle_acesso_dashboard/streamlit_app/real_time_dashboard.py",
            "--server.port=8501",
            "--server.address=0.0.0.0",
            "--server.headless=true",
            f"--server.baseUrlPath={base_url_path}",
        ],
    )

    def cleanup(signum, frame):
        streamlit_proc.terminate()
        sys.exit(0)

    signal.signal(signal.SIGTERM, cleanup)
    signal.signal(signal.SIGINT, cleanup)

    try:
        subprocess.run(  # nosec B603
            [
                sys.executable, "-m", "uvicorn",
                "app:app",
                # Bind intencional do servidor no contêiner; exposição externa
                # continua controlada por Service/Route e autenticação.
                "--host", "0.0.0.0",  # nosec B104
                "--port", "8000",
            ],
            check=True,
        )
    finally:
        streamlit_proc.terminate()


if __name__ == '__main__':
    start()
