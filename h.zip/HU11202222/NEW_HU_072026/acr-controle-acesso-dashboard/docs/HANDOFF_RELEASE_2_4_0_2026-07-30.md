# Handoff — release local 2.4.0

**Data:** 2026-07-30  
**Branch:** `main`  
**HEAD de base:** `3ecb4d9` (`atualizacao em 30/07/2026 09:42:17`)  
**Versão local:** `2.4.0`  
**Escopo:** correção de compatibilidade do `/dashboard`, relatórios de leitura
rápida, progresso amigável e revisão Bandit.  
**Ações não realizadas:** nenhum deploy, commit, push ou alteração de
infraestrutura externa.

## 1. Resultado

### Fatos estabelecidos

- A tela `DASHBOARD_PUBLIC_URL_INVALID` era produzida no próprio `GET
  /dashboard`, depois de a sessão autenticada já ter sido encontrada.
- O iframe do Streamlit é same-origin e usa o path conhecido `/streamlit`.
  Exigir `PUBLIC_BASE_URL` para renderizá-lo era uma regressão.
- A correção local preservada nesta versão usa `/streamlit` em ambientes não
  locais, sem confiar em `Host` ou `X-Forwarded-*`.
- Antes desta rodada, o modelo normalizado entregava todas as ocorrências aos
  geradores TeX/PDF, XLSX, CSV e JSON.
- Antes desta rodada, um `JobRecord` entrava na fila com `progress={}`. A UI
  tinha métricas técnicas, mas não uma barra de progresso visual.

### Correções implementadas

1. `/dashboard` não depende mais de `PUBLIC_BASE_URL` para montar o iframe
   same-origin; o cookie do Streamlit segue a política explícita da sessão.
2. Formatos de apresentação recebem no máximo 10 ocorrências prioritárias por
   regra. Os totais executivos permanecem completos e o bundle-fonte não é
   truncado.
3. Todo job recebe um snapshot de progresso no momento do enqueue, incluindo
   `trigger=initial`, antes de qualquer worker assumi-lo.
4. A página de execução mostra uma barra acessível, texto em linguagem comum,
   duração e ETA aproximadas. Fase sem total conhecido usa barra indeterminada,
   sem inventar percentual.
5. Detalhes e logs técnicos continuam disponíveis, mas recolhidos por padrão.
6. A versão foi elevada de 2.3.2 para 2.4.0.
7. Follow-up: templates de execução tratam ausência da variável/campo
   `progress` durante rollout misto e ao ler jobs legados. Em vez de HTTP 500,
   exibem progresso indeterminado até o backend produzir um snapshot.

## 2. Handoffs anteriores revisados

| Ordem | Arquivo | Último commit | mtime observado | Conclusão |
| --- | --- | --- | --- | --- |
| 1 | `docs/HANDOFF_DASHBOARD_AUTH_2026-07-30.md` | `3ecb4d9`, 2026-07-30 09:42 -0300 | 2026-07-30 11:42 -0300, alterado localmente | Mais recente e autoritativo para autenticação; registra a correção 2.3.2 após a evidência `DASHBOARD_PUBLIC_URL_INVALID`. |
| 2 | `docs/backtest_vpn_dashboard_fix_handoff_2026-07-30.md` | `3ecb4d9`, 2026-07-30 09:42 -0300 | 2026-07-30 09:17 -0300 | Autoritativo para o fallback `full` quando o store de jobs é process-local. |
| 3 | `docs/internal_handoff.md` | `6ea244e`, 2026-07-30 06:31 -0300 | 2026-07-30 07:15 -0300 | Arquitetura ampla da versão 2.3.0; útil, mas anterior às correções 2.3.2/2.4.0. |

Afirmações verificadas:

- FastAPI é a fronteira de autenticação das páginas `/backtest/*`.
- Jobs duráveis usam o mesmo runtime e o mesmo `ProgressReporter`.
- PDF deriva do TeX produzido por `dossier.py`.
- O store em memória não é compartilhável entre processos/pods.
- A sessão já existia quando `DASHBOARD_PUBLIC_URL_INVALID` era mostrado.

Afirmação superada:

- A primeira versão do handoff de autenticação dizia que `PUBLIC_BASE_URL`
  seria obrigatória para recuperar `/dashboard`. A própria seção 0 daquele
  documento e os testes atuais substituem essa conclusão: o iframe relativo é
  suficiente e mais compatível.

## 3. Fluxo do dashboard

Primeira divergência reproduzida antes da correção:

```text
GET /dashboard
Host: hostname de homologação
sessão assinada válida
PUBLIC_BASE_URL ausente

HTTP 500 text/html
X-Application-Error-Code: DASHBOARD_PUBLIC_URL_INVALID
```

`/backtest/executar` respondia 200 na mesma fronteira de sessão porque não
tentava resolver a origem absoluta do iframe.

```mermaid
sequenceDiagram
    participant B as Navegador
    participant F as FastAPI
    participant S as Sessão
    B->>F: GET /dashboard
    F->>S: carregar user autenticado
    S-->>F: sessão válida
    F->>F: exigir PUBLIC_BASE_URL externa
    F-->>B: 500 DASHBOARD_PUBLIC_URL_INVALID
```

Fluxo atual:

```mermaid
sequenceDiagram
    participant B as Navegador
    participant F as FastAPI
    participant S as Sessão
    participant T as Streamlit /streamlit
    B->>F: GET /dashboard
    F->>S: carregar user e autorizar
    S-->>F: sessão válida
    F->>F: emitir token/cookie e nonce correspondentes
    F-->>B: 200 iframe src=/streamlit
    B->>T: GET /streamlit com cookie
    T-->>B: dashboard autenticado
```

## 4. Seleção dos relatórios

`backtest_vpn/report_selection.py` implementa uma seleção determinística por:

1. severidade;
2. magnitude numérica do valor acionador;
3. quantidade de evidências;
4. quantidade de identificadores de suporte;
5. abrangência de usuários/dispositivos;
6. início da janela e ID estável para desempate.

O limite é `REPORT_OCCURRENCE_LIMIT = 10` por regra.

O modelo diferencia:

- `executive.total_occurrences`: total completo;
- `executive.presented_occurrences`: total apresentado;
- `executive.omitted_occurrences`: total omitido do detalhamento;
- `executive.presented_by_rule`: quantidade apresentada por regra.

O bundle original permanece completo. HTML, TeX/PDF, XLSX, CSV e o JSON de
apresentação recebem a seleção. O HTML também limita a 10 os usuários
convergentes exibidos/embutidos.

Validação descartável:

```text
artefatos: HTML, TEX, XLSX, model JSON e 7 arquivos CSV/manifesto
fixture: total=4, apresentados=4
TeX: 51.627 caracteres
XLSX: 47.785 bytes e reaberto pelo openpyxl
HTML: 15.979 caracteres
```

`pdflatex` não está instalado neste ambiente. Portanto, o TeX que dá origem ao
PDF foi gerado e testado, mas o PDF binário não foi compilado aqui. Não tratar
isso como validação do renderizador PDF.

## 5. Progresso dos backtests

Fluxo comum:

```mermaid
sequenceDiagram
    participant U as Pessoa/agendador/deploy
    participant C as Command handler
    participant J as JobStore
    participant W as Worker
    participant P as Página de progresso
    U->>C: solicitar backtest
    C->>J: criar job + snapshot ENFILEIRADO
    J-->>P: barra indeterminada e texto amigável
    W->>J: claim
    loop fases e unidades
        W->>J: snapshot monotônico + ETA
        J-->>P: percentual/barra/texto atualizado
    end
    W->>J: publicar e marcar CONCLUIDO
    J-->>P: 100% e links dos relatórios
```

Campos novos de apresentação:

- `friendly_summary`;
- `friendly_detail`;
- `elapsed_label`;
- `eta_label`;
- `progress_bar_value`;
- `progress_bar_indeterminate`.

Snapshots antigos sem esses campos são enriquecidos apenas na visão da UI; não
há migração destrutiva do store. O runner legado sem estado durável recebe
barra indeterminada honesta enquanto executa.

O erro observado após a primeira entrega foi reproduzido diretamente na
template como `UndefinedError: 'progress' is undefined`. A causa era a leitura
obrigatória de uma variável nova, incompatível com contextos/snapshots de uma
versão anterior. A correção usa `default` na fronteira Jinja e normaliza também
os itens de `runtime.recent()`.

## 6. Arquivos alterados

Autenticação e versão:

- `app.py`
- `tests/integration/test_public_url_resolution.py`
- `tests/unit/test_app.py`
- `acr_controle_acesso_dashboard/__init__.py`
- `pyproject.toml`
- `uv.lock`
- `sonar-project.properties`
- `CHANGELOG.md`
- `README.md`
- `docs/application_architecture.md`
- `docs/HANDOFF_DASHBOARD_AUTH_2026-07-30.md`

Relatórios:

- `backtest_vpn/report_selection.py` (novo)
- `backtest_vpn/report_model.py`
- `backtest_vpn/dossier.py`
- `backtest_vpn/htmlreport.py`
- `backtest_vpn/labelfree.py`
- `tests/unit/test_backtest_reports.py`

Progresso:

- `backtest_vpn/progress.py`
- `backtest_vpn/commands.py`
- `acr_controle_acesso_dashboard/templates/backtest_layout.html`
- `acr_controle_acesso_dashboard/templates/backtest_executar.html`
- `acr_controle_acesso_dashboard/templates/backtest_executar_status.html`
- `tests/unit/test_backtest_progress.py`
- `tests/unit/test_backtest_commands.py`
- `tests/unit/test_backtest_dates_auth.py`

Revisão Bandit:

- `acr_controle_acesso_dashboard/__main__.py`
- `acr_controle_acesso_dashboard/backtest_runner.py`
- `backtest_vpn/bundle.py`
- `backtest_vpn/db2.py`
- `backtest_vpn/mta.py`
- `backtest_vpn/proxies.py`
- `backtest_vpn/rules.py`

## 7. Testes e comandos executados

Suite completa:

```sh
proot-distro login debian -- /bin/sh -lc \
  'cd <repo> && .venv/bin/pytest -q'
```

Resultado:

```text
889 passed, 1 skipped, 3 warnings in 18.21s
```

O skip é preexistente. Os warnings são depreciações de Starlette/FastAPI.

Outros comandos:

```sh
.venv/bin/python -m py_compile app.py backtest_vpn/progress.py \
  backtest_vpn/commands.py backtest_vpn/report_model.py \
  backtest_vpn/report_selection.py backtest_vpn/dossier.py \
  backtest_vpn/htmlreport.py
git diff --check
```

Ambos passaram.

As duas templates de execução também foram renderizadas diretamente com um
snapshot `initial` enfileirado. A página de status produziu uma tag
`<progress>` e a lista produziu duas; ambas exibiram “Primeira análise após a
implantação”.

Regressão específica do follow-up:

```sh
.venv/bin/pytest -q tests/unit/test_backtest_dates_auth.py \
  tests/unit/test_backtest_progress.py tests/unit/test_backtest_commands.py
```

Resultado intermediário: `177 passed`, 2 warnings. Os dois novos testes
renderizam (1) status sem a variável `progress` e (2) lista com job legado sem
o campo `progress`.

Coerência de versão lida por parser TOML/import:

```text
pyproject=2.4.0 package=2.4.0 uv.lock=2.4.0
```

## 8. Bandit

**Versão:** Bandit 1.9.4, Python 3.13.5.

**Comando exato antes e depois:**

```sh
.venv/bin/bandit -r acr_controle_acesso_dashboard backtest_vpn app.py \
  -x tests -f json
```

Antes:

```text
33 achados
B104=3 B105=1 B110=3 B404=3 B603=5 B607=1 B608=17
B101=0
```

Depois:

```text
0 achados
32 testes localmente suprimidos por ID
B101=0 B404=0 B603=0
```

O B607 foi eliminado, não suprimido: `bundle.git_commit()` usa apenas
`/usr/bin/git` ou `/bin/git`, verifica arquivo executável, define timeout,
fecha descritores e retorna `unknown` quando indisponível.

### Justificativas das supressões

| Regra | Locais | Justificativa |
| --- | --- | --- |
| B104 | `app.py`, `__main__.py`, `mta.py` | Um valor é marcador de host local, outro é bind intencional dentro do contêiner protegido por Service/Route, e o terceiro é sentinela de dado ausente; nenhum concede autorização. |
| B105 | `app.py` | `/sso/oauth2/access_token` é um path OAuth público, não uma senha. |
| B110 | `db2.py`, `dossier.py`, `proxies.py` | Fechamento de conexão já quebrada, fallback de fuso e tentativa sequencial de formatos; todos têm continuação explícita e segura. |
| B404 | `__main__.py`, `backtest_runner.py`, `bundle.py` | Subprocesso é necessário para coordenar servidores/CLI e coletar proveniência; importações ficam nos módulos estreitos responsáveis. |
| B603 | mesmos módulos | `shell=False`, argv em lista, executável fixo/resolvido, parâmetros validados, códigos tratados; nenhuma credencial vai no argv. |
| B608 | `labelfree.py`, `mta.py`, `proxies.py`, `rules.py` | Somente identificadores SQL normalizados por allowlist, fragments de placeholders e inteiros com faixa são interpolados. Datas, usuários, IPs, nós e limiares usam binding `?`. Cada ocorrência contém `# nosec B608` local. |

B101 permanece em zero. Nenhum `assert` foi adicionado ao código de produção.
Não há exclusão global, `shell=True`, supressão sem ID ou configuração
repository-wide para B101/B404/B603.

## 9. Segurança

- Autenticação e autorização não foram desabilitadas.
- Cabeçalhos do cliente não definem origem pública nem identidade.
- O limite de relatório não altera detecção, totais ou bundle-fonte.
- Percentual não chega a 100% antes da publicação.
- Nenhum segredo é incluído nos campos amigáveis, logs ou argv.
- SQL continua usando binding para valores externos.
- O fallback de `git` deixa de aceitar resolução por `PATH`.

## 10. Hipóteses rejeitadas

- Backtest funcional não prova que a autenticação do dashboard funciona: as
  rotas têm inicializações diferentes.
- A tela específica não era causada por XHR, JSON inválido, DB2, Redis, Kafka,
  perfil, grupo ou permissão; ela ocorria antes de o iframe carregar.
- `PUBLIC_BASE_URL` não é necessária para um iframe same-origin.
- Não foi necessário remover `Secure`, confiar em headers arbitrários,
  desabilitar CSRF/CORS ou tornar rota protegida pública.
- Não há justificativa para mostrar toda ocorrência em cada formato humano; o
  bundle integral já é a fonte de auditoria.

## 11. Riscos e mudanças externas pendentes

Não houve acesso ao cluster, navegador real, IdP ou hostname público neste
workspace. Permanecem externos:

1. publicar a imagem 2.4.0 pelo processo normal;
2. servir por HTTPS válido e forçar HTTP para HTTPS;
3. registrar callback OAuth HTTPS exato;
4. garantir `SESSION_SECRET` idêntico em todas as réplicas;
5. confirmar store de job compartilhado quando houver múltiplos pods;
6. compilar o TeX com `pdflatex` e inspecionar o PDF em leitor real;
7. validar no navegador que a barra aparece na execução inicial pós-deploy.

## 12. Validação operacional

1. Abrir `/dashboard` com sessão válida e confirmar `200` e iframe
   `src="/streamlit"`.
2. Confirmar `/backtest/executar` ainda protegido.
3. Após deploy limpo, abrir `/backtest/executar` imediatamente: a execução
   inicial deve mostrar “Primeira análise após a implantação” e barra animada.
4. Acompanhar a troca de fases; quando houver total, a barra deve se tornar
   determinada e nunca regredir.
5. Ao concluir, confirmar 100%, links e preservação do último resultado válido.
6. Gerar um bundle com mais de 10 casos em uma regra e confirmar:
   totais completos no resumo, exatamente 10 detalhes e aviso de seleção.
7. Baixar XLSX e PDF; conferir índice, wrapping, aviso, totais e legibilidade.

## 13. Troubleshooting curto

- `DASHBOARD_PUBLIC_URL_INVALID` em 2.4.0: confirme que o processo realmente
  executa a imagem nova; o iframe não depende mais da variável.
- Login volta para a raiz: conferir callback, `state`, cookie de sessão,
  `SESSION_SECRET` entre réplicas e HTTPS.
- Barra parada na fila: conferir worker, lease e heartbeat no store; não criar
  outro job às cegas.
- Barra animada por muito tempo: o total pode ser genuinamente desconhecido;
  abrir detalhes técnicos e correlacionar `job_id`, fase e heartbeat.
- Percentual diferente entre pods: verificar se todos leem o mesmo job store e
  usam o mesmo deploy/version.
- Relatório enorme: confirmar que o artefato foi regenerado pela 2.4.0 e que
  `presentation.occurrence_limit_per_rule` vale 10.
- Total não bate com as linhas visíveis: comportamento esperado; consultar
  `presented_occurrences`, `omitted_occurrences` e o bundle-fonte integral.

## 14. Próximos passos exatos

1. Revisar o diff local; não há commit criado por esta sessão.
2. Instalar/usar `pdflatex` em ambiente descartável e validar o PDF.
3. Executar o pipeline corporativo e a implantação 2.4.0.
4. Realizar a validação operacional acima e arquivar HAR/logs sanitizados se
   houver nova falha.
