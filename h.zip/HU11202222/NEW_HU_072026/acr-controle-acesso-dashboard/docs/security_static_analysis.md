# Segurança e análise estática

## Estado verificável

Esta revisão removeu defeitos que normalmente são reportados por Checkmarx,
SonarQube ou revisão manual, mas **não declara zero findings**. O executável do
Checkmarx, o SonarScanner e a política/quality gate corporativa não estavam
disponíveis nesta máquina. Resultado “sem vulnerabilidades” ou “sem code
smells” só é verificável depois que os dois produtos, nas versões e perfis
usados pela organização, finalizarem com sucesso.

O `Jenkinsfile` volta a habilitar validação estática, validação de segurança,
testes unitários, testes de integração e Sonar. `sonar-project.properties`
inclui `app.py`, o pacote da aplicação e todo `backtest_vpn`; testes e artefatos
gerados são classificados/excluídos explicitamente.

## Correções desta versão

- `.gitignore` e `.dockerignore` cobrem novos `.env`, relatórios, staging e
  caches. Arquivos, segredos, allowlists e relatórios históricos que já eram
  versionados foram restaurados por instrução explícita do proprietário;
- o destino DB2, o caminho de credenciais, endpoints e registries internos
  históricos foram preservados como defaults;
- TLS passa a exigir verificação e CA confiável;
- eventos de log de login, busca e auditoria foram minimizados e
  pseudonimizados;
- a allowlist incorporada à página foi preservada, com possibilidade de
  substituição por configuração externa;
- removidos `chmod 0777` e permissões excessivas da imagem;
- CronJob/Job desabilitam token de service account, usam seccomp
  `RuntimeDefault`, impedem escalonamento de privilégio e removem capabilities;
- consultas DB2 vinculam valores e validam separadamente cada identificador SQL;
- o formulário manual de backtest exige token CSRF vinculado à sessão e
  comparado em tempo constante antes de enfileirar qualquer trabalho;
- downloads usam allowlist de publicação, rejeitam travessia e symlink;
- XLSX/CSV neutralizam `=`, `+`, `-` e `@`; LaTeX escapa caracteres e bloqueia
  comandos derivados de dados;
- limites de data, regra, job, tentativa, lote, saída e concorrência são
  validados no servidor.

## Validação exigida no ambiente autorizado

1. Executar o pipeline corporativo completo e guardar o ID/versão da análise,
   preset Checkmarx, quality profile Sonar e resultado do quality gate.
2. Tratar cada finding no código ou marcar falso positivo somente com
   justificativa técnica revisada; não excluir diretórios de fonte para obter
   um resultado verde.
3. Confirmar que branch analysis inclui arquivos novos e que nenhuma baseline
   antiga oculta findings “existing”.
4. Executar SCA/container scan sobre `uv.lock` e a imagem realmente construída;
   atualizar dependências conforme o repositório interno aprovado.
5. Fazer secret scan no estado atual e no histórico Git. A política corporativa
   pode reportar os arquivos e defaults restaurados; qualquer aceite exige
   exceção formal do proprietário/segurança.
6. Fazer DAST em ambiente isolado para OAuth2, sessão, CSRF, autorização
   horizontal, headers, proxy confiável e downloads.

## Pontos que exigem decisão operacional

- A chave `SESSION_SECRET` deve ser a mesma em todos os pods, ter entropia
  adequada e vir de Secret; o fallback aleatório é apenas seguro para processo
  único e invalida sessões entre pods.
- Credenciais DB2, OAuth2, Kafka, MongoDB e chaves HMAC precisam de rotação e
  menor privilégio. Não devem aparecer em manifesto renderizado, log ou
  relatório.
- Links, registries, destinos, allowlists e arquivos de segredo históricos
  permanecem incorporados por decisão explícita do proprietário. Checkmarx,
  Sonar ou secret scanners podem reportá-los independentemente de o
  repositório ser privado; esta revisão não suprime esses achados.

## Comandos

Na máquina interna, use os comandos/pipeline aprovados pela organização. Para
as verificações open source já declaradas pelo projeto:

```sh
uv sync --frozen --group dev
uv run pytest
uv run flake8 app.py acr_controle_acesso_dashboard backtest_vpn tests
uv run bandit -r app.py acr_controle_acesso_dashboard backtest_vpn
uv run python -m compileall -q app.py acr_controle_acesso_dashboard backtest_vpn
```

O SonarScanner deve ler `sonar-project.properties`; credenciais e URL do
servidor ficam apenas no mecanismo seguro do CI. O comando Checkmarx depende do
cliente e preset corporativos e, por isso, não é inventado neste documento.
