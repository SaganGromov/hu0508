# Handoff — falha de autenticação/preparação do `/dashboard`

**Data:** 2026-07-30  
**Repositório:** `acr-controle-acesso-dashboard`  
**Branch inspecionada:** `main`  
**HEAD inspecionado:** `6ea244e15794f3e6e877986f6871e257836c63d4` (`commit inicial`)  
**Versão local após a correção:** `2.3.2`
**Escopo:** diagnóstico e correção local; nenhum deploy, commit, push ou alteração de infraestrutura externa foi realizado.

## 0. Atualização após evidência do ambiente — conclusão autoritativa

Depois da primeira entrega, o ambiente continuou retornando
`DASHBOARD_PUBLIC_URL_INVALID`. Essa evidência confirmou que exigir
`PUBLIC_BASE_URL` no próprio `/dashboard` era uma regressão de compatibilidade,
não um requisito inevitável da arquitetura.

O iframe do Streamlit é same-origin e já possui um path explícito,
`STREAMLIT_BASE_URL_PATH=/streamlit`. Ele não precisa de hostname ou scheme
absolutos. A correção 2.3.2, que substitui a conclusão operacional inicial:

- usa somente o path relativo `/streamlit` no deploy, exista ou não
  `PUBLIC_BASE_URL`;
- continua sem confiar em `Host` ou `X-Forwarded-*` para construir a origem;
- faz o cookie Streamlit seguir a política explícita
  `SESSION_COOKIE_SECURE` do cookie de sessão FastAPI;
- mantém `PUBLIC_BASE_URL` necessária para gerar callback OAuth externo apenas
  quando `OAUTH2_REDIRECT_URI` também não estiver configurada.

Com a forma exata do values arquivado — `PUBLIC_BASE_URL` ausente,
`STREAMLIT_URL=/streamlit` obsoleta e
`STREAMLIT_BASE_URL_PATH=/streamlit` — o teste de integração agora obtém
`GET /dashboard -> 200` e `GET /backtest/executar -> 200`.

As seções abaixo preservam a investigação inicial. Onde afirmam que adicionar
`PUBLIC_BASE_URL` era a única forma de recuperar o dashboard, esta seção as
substitui. HTTPS e callback HTTPS continuam sendo o estado de produção
recomendado, mas não são mais pré-condição artificial para renderizar o iframe
same-origin.

## 1. Resultado executivo

### Fato estabelecido

O texto observado no navegador só pode ser produzido pelo `except` do `GET
/dashboard` quando a aplicação já encontrou `request.session["user"]`, mas não
conseguiu resolver a URL pública do Streamlit. Ele não é produzido por um
`fetch`, XHR, banco de dados, Kafka, Redis, DB2, lookup de perfil ou autorização
de grupo.

### Causa raiz verificada

Existe uma incompatibilidade de contrato entre o código atual e a última
configuração Helm disponível no pacote de entrega:

1. o código atual exige `PUBLIC_BASE_URL` para qualquer host não local e recusa
   derivar uma origem confiável de `Host` ou `X-Forwarded-*`;
2. o `values.yaml` de homologação disponível no arquivo `HU.zip`, branch
   `cloud/homologacao`, commit `8368f16`, não injeta `PUBLIC_BASE_URL`;
3. o mesmo values ainda contém `OAUTH2_REDIRECT_URI` em HTTP e `ingress.tls: []`;
4. com uma sessão real assinada, host de homologação e cabeçalhos equivalentes
   ao proxy, a ausência de `PUBLIC_BASE_URL` reproduz exatamente `GET
   /dashboard -> 500 text/html` com “Não foi possível preparar o acesso ao
   painel”, enquanto `/backtest/executar -> 200`;
5. ao fornecer a origem HTTPS confiável, a mesma fronteira de sessão retorna
   `GET /dashboard -> 200` e produz o iframe same-origin esperado.

Portanto, o gatilho era uma **falha fechada de configuração da origem
pública**, mas a causa de software mais profunda era uma dependência
desnecessária de origem absoluta para um iframe same-origin. A autenticação
OAuth já havia criado uma sessão suficiente para entrar no ramo protegido.

### Defeito secundário encontrado e corrigido

Depois de corrigir a origem pública, havia um segundo defeito determinístico:
o HTML era renderizado com o nonce CSRF anterior da sessão e, em seguida, o
handler gerava outro token/cookie do Streamlit. O iframe enviaria o nonce A e o
cookie autenticado produziria o nonce B; a validação double-submit do Streamlit
rejeitaria a carga. Agora um único token é criado antes da renderização, seu
nonce vai para o iframe e o mesmo token é gravado no cookie.

### Hardening externo originalmente indicado

O fragmento `deploy/values-dashboard-auth.patch.yaml` foi criado apenas para
revisão. O responsável pelo chart/cluster ainda precisa:

- mesclar `PUBLIC_BASE_URL=https://acr-vpn-dashboard.acr.hml.bb.com.br`;
- substituir o callback por
  `https://acr-vpn-dashboard.acr.hml.bb.com.br/auth/callback`;
- registrar exatamente esse callback no cliente OAuth2;
- anexar ao Ingress o Secret TLS correto e forçar HTTP → HTTPS;
- confirmar que todas as réplicas recebem o mesmo `SESSION_SECRET`;
- reiniciar/rolar os pods pelo processo de implantação normal.

Essas ações continuam recomendadas para uma implantação HTTPS íntegra. A
versão 2.3.2, porém, não exige mais a variável apenas para montar o iframe.

## 2. Limites da evidência

O hostname público não resolveu DNS neste workspace:

```text
curl: (6) Could not resolve host: acr-vpn-dashboard.acr.hml.bb.com.br
```

Também não havia credencial/contexto de cluster, HAR do navegador ou logs do
Ingress/IdP disponíveis. Assim:

- o status e conteúdo do primeiro request foram reproduzidos na aplicação
  real via `TestClient` e `SessionMiddleware`, não capturados do cluster;
- a configuração Helm arquivada é a última configuração disponível, mas não é
  uma leitura do estado efetivo atual do cluster;
- “Não seguro” é consistente com o values arquivado (`HTTP`, callback HTTP e
  `tls: []`), mas a causa visual exata — HTTP puro, certificado inválido,
  cadeia incompleta ou mixed content — continua pendente de inspeção no
  navegador/cluster;
- múltiplas réplicas e reinício não puderam ser exercitados contra pods reais.

As conclusões acima não dependem de supor um problema de cookie ou proxy: elas
decorrem do ponto exato que produz a mensagem, do contrato do código, do values
arquivado e da reprodução automatizada.

## 3. Handoffs e documentos anteriores

### Ordem relativa

| Ordem | Arquivo | Git / contexto | mtime aparente | Conclusões e situação |
|---|---|---|---|---|
| 1 (mais novo) | `docs/backtest_vpn_dashboard_fix_handoff_2026-07-30.md` | não rastreado; trabalho local sobre `main` | 2026-07-30 09:17 -0300 | Handoff completo do conserto de jobs/backtest. Registra 875 testes + 7 shims, estado compartilhado e janela configurável. Não diagnostica o erro de `/dashboard`. Consistente com as alterações locais de backtest. |
| 2 | `docs/internal_handoff.md` | `6ea244e`, 2026-07-30 06:31 -0300 | 2026-07-30 07:15 -0300 | Arquitetura OAuth2, state, HMAC de matrícula, sessão assinada, autorização de backtest, exigência de URL pública HTTPS e `SESSION_SECRET` comum. Em geral consistente. A descrição fixa de 33 dias foi superada pelas alterações locais documentadas no handoff mais novo. |
| 3 | `MATRICULA_AUTH_OPENSHIFT.md` | `6ea244e`, mesma base | 2026-07-30 07:15 -0300 | Procedimento de Secrets HMAC e OAuth/OpenShift. Continua compatível; não contém a causa da tela. |
| 4 | `README.md` | `6ea244e`, modificado localmente | 2026-07-30 09:32 -0300 antes desta investigação | Execução, OAuth, URL pública e build. Foi atualizado para tornar a obrigação de `PUBLIC_BASE_URL` explícita. |
| 5 | `deploy/README.md` | `6ea244e`, modificado localmente | 2026-07-30 09:32 -0300 antes desta investigação | Operação de backtest/CronJob. Foi acrescentada a referência ao fragmento local de autenticação/TLS. |
| 6 | `docs/application_architecture.md` | `6ea244e`, modificado localmente | 2026-07-30 09:30 -0300 antes desta investigação | Arquitetura atual. Versão atualizada para 2.3.2. |
| Arquivo histórico | `HU.zip/.../handoff/{README,00..06}` | pacote mais antigo, varredura de relevância | anterior ao repositório atual | Materiais da metodologia/backtest. A busca de conteúdo não encontrou investigação do erro de autenticação do `/dashboard`; não foram tratados como handoff autoritativo desta falha. |
| Configuração histórica relevante | `HU.zip/.../deploy-acr-controle-acesso-dashboard/values.yaml` | branch `cloud/homologacao`, `8368f16e...`, 2026-07-28 16:45 -0300 | extraída em diretório temporário | Evidência do callback HTTP, ausência de `PUBLIC_BASE_URL`, `tls: []`, HPA 2–5 e rotas `/` e `/streamlit`. |

### Afirmações verificadas

- OAuth2 usa authorization code e `state`.
- A sessão FastAPI é cookie assinado, `HttpOnly`, `SameSite=Lax`, path `/`; o
  padrão atual é `Secure`.
- Matrícula é normalizada e verificada por HMAC/allow-list.
- `/backtest/*` revalida a matrícula em cada request.
- O token FastAPI → Streamlit é HMAC e depende do mesmo `SESSION_SECRET`.
- A origem pública externa deve ser HTTPS e explícita.
- O estado durável de jobs do backtest não é o estado da sessão de autenticação.

### Afirmações rejeitadas ou superadas

- O intervalo fixo de 33 dias descrito no handoff interno foi superado pelo
  trabalho local mais recente, que tornou a janela configurável.
- Nenhum documento anterior demonstra que o erro observado era DB2, Redis,
  frontend compilado, CORS, CSRF ou indisponibilidade do IdP.
- `STREAMLIT_URL=/streamlit` no values histórico não corrige a origem: o código
  atual não lê essa variável para construir o iframe.

### Trabalho/avisos anteriores preservados

O repositório já estava sujo antes desta investigação. Foram preservadas as
alterações locais de backtest em `.env.example`, `app.py`,
`backtest_vpn/period.py`, `backtest_vpn/scheduler.py`, `test_local.sh` e seus
testes, além do handoff de backtest não rastreado. Não houve reset, checkout ou
reversão.

## 4. Arquitetura de autenticação e autorização

1. `GET /` mostra login ou redireciona uma sessão existente para `/dashboard`.
2. `GET /login` cria `oauth_state` na sessão e redireciona para o endpoint
   corporativo de autorização.
3. `GET /auth/callback` compara `state`, troca `code` por access token, chama
   `userinfo`, extrai a matrícula e verifica a allow-list HMAC.
4. A aplicação grava um usuário mínimo no cookie de sessão assinado.
5. O access token OAuth completo não entra no cookie: uma chave aleatória
   referencia `_ACCESS_TOKENS`, dicionário em memória usado apenas para tentar
   logout remoto.
6. `/dashboard` exige `session["user"]`, resolve a origem pública, emite um
   token HMAC do Streamlit no cookie `dashboard_streamlit_auth` e inclui no
   iframe o nonce derivado desse mesmo token.
7. O Streamlit recebe o iframe em `/streamlit`, valida cookie, TTL,
   Origin/Referer/Host e nonce.
8. Não há grupos/roles adicionais no dashboard além da allow-list de matrícula.
   Os endpoints de backtest revalidam essa allow-list a cada request.

O dicionário `_ACCESS_TOKENS` é local ao processo e pode impedir somente o
logout remoto depois de troca de pod/restart. Ele não estabelece a identidade
usada por `/dashboard`. A sessão assinada e o token Streamlit são
criptograficamente autocontidos, desde que todas as réplicas compartilhem o
mesmo `SESSION_SECRET`.

## 5. Call graph conciso

```text
GET /dashboard
└─ SessionMiddleware(secret=SESSION_SECRET, Secure, SameSite=Lax)
   └─ correlation-id middleware
      └─ dashboard(request)
         ├─ request.session["user"]? senão 307 /
         ├─ _resolve_streamlit_base_url
         │  ├─ _streamlit_base_path
         │  └─ _request_origin
         │     ├─ _validated_external_url(PUBLIC_BASE_URL), ou
         │     ├─ fallback somente localhost, ou
         │     └─ AppConfigurationError(PUBLIC_BASE_URL_MISSING)
         ├─ _new_streamlit_auth
         │  ├─ generate_token(user_id)
         │  └─ generate_csrf_nonce(exatamente esse token)
         ├─ TemplateResponse(dashboard.html)
         └─ _write_streamlit_auth_cookie(exatamente esse token)
            └─ browser carrega /streamlit?csrf_nonce=...
               └─ Streamlit auth_token valida cookie + nonce + origem
```

`templates/error.html` contém “Erro na Autenticação” e “Tentar novamente”.
`app.dashboard` fornece “Não foi possível preparar o acesso ao painel.” no
erro da origem pública. Antes da correção, a exceção era apenas capturada e a
tela retornava 500; não existia XHR anterior.

## 6. Fluxo quebrado

```mermaid
sequenceDiagram
    participant B as Navegador
    participant I as Ingress/Route
    participant F as FastAPI
    participant S as SessionMiddleware
    participant ST as Streamlit

    B->>I: GET /dashboard + cookie de sessão
    I->>F: HTTP interno + Host/X-Forwarded-*
    F->>S: decodifica sessão com SESSION_SECRET
    S-->>F: user autenticado
    F->>F: _resolve_streamlit_base_url()
    F->>F: PUBLIC_BASE_URL ausente
    Note over F: Headers forwarded não são origem confiável
    F-->>B: 500 text/html<br/>Erro na Autenticação<br/>Não foi possível preparar...
    Note over B,ST: dashboard.html não é renderizado;<br/>nenhum iframe/XHR chega ao Streamlit
```

### Primeiro request divergente

```http
GET /dashboard HTTP/1.1
Host: acr-vpn-dashboard.acr.hml.bb.com.br
Cookie: session=<redigido>
X-Forwarded-Host: acr-vpn-dashboard.acr.hml.bb.com.br
X-Forwarded-Proto: https
```

Resposta reproduzida, sanitizada:

```http
HTTP/1.1 500 Internal Server Error
Content-Type: text/html; charset=utf-8
X-Application-Error-Code: DASHBOARD_PUBLIC_URL_INVALID
X-Request-ID: <id>
Cache-Control: no-store

... Erro na Autenticação ...
... Não foi possível preparar o acesso ao painel. ...
```

Não houve “HTML onde JSON era esperado”: o request inicial recebeu HTML por
design. Não houve request subsequente porque o `src` do iframe não chegou a ser
renderizado.

## 7. Fluxo corrigido

```mermaid
sequenceDiagram
    participant B as Navegador
    participant I as Ingress TLS
    participant F as FastAPI
    participant S as SessionMiddleware
    participant ST as Streamlit

    B->>I: HTTPS GET /dashboard + cookie Secure
    I->>F: HTTP interno; host público roteado
    F->>S: valida sessão assinada
    S-->>F: user autenticado
    F->>F: usa /streamlit relativo<br/>ou PUBLIC_BASE_URL explícita
    F->>F: gera token T e nonce HMAC(T)
    F-->>B: 200 dashboard.html + cookie Streamlit=T<br/>iframe /streamlit?csrf_nonce=HMAC(T)
    B->>I: GET /streamlit?csrf_nonce=HMAC(T) + cookie T
    I->>ST: rota /streamlit
    ST->>ST: valida assinatura, TTL, origem e HMAC(T)
    ST-->>B: dashboard autorizado
```

## 8. Comparação de rotas

| Aspecto | `/dashboard` | `/backtest/executar` | `/backtest/executar/{job_id}/status` |
|---|---|---|---|
| Sessão | exige `session.user` | exige sessão e allow-list atual | exige sessão e allow-list atual |
| Autorização | allow-list foi verificada no login | revalida matrícula HMAC por request | revalida e responde JSON 401/403 |
| Origem pública | **sim**, chama `_resolve_streamlit_base_url` | não | não |
| Streamlit | gera cookie + nonce e iframe `/streamlit` | não | não |
| Banco/cache | nenhum antes do HTML | store/runtime de jobs quando necessário | store de jobs |
| Frontend | Jinja + iframe same-origin | Jinja/forms | JSON polling |
| CSRF | nonce double-submit FastAPI → Streamlit | token de formulário para mutações | não muta |
| Variáveis exclusivas | `PUBLIC_BASE_URL`, `STREAMLIT_BASE_URL_PATH`, `SESSION_SECRET` | store/runtime/backtest | store/runtime/backtest |
| Resultado sem `PUBLIC_BASE_URL` | 500 após autenticação | continua alcançável | continua alcançável |

Essa diferença explica por que os endpoints de backtest não demonstram que o
bootstrap do dashboard está saudável.

## 9. Hipóteses testadas

### Confirmada

- `PUBLIC_BASE_URL` ausente no chart disponível, incompatível com o código
  atual: confirmada por código, values histórico e reprodução.

### Defeito secundário confirmado

- nonce do iframe e cookie Streamlit gerados em momentos diferentes:
  confirmado pela ordem antiga do handler; teste de integração agora decodifica
  o `Set-Cookie` e recalcula o nonce.

### Rejeitadas como causa da tela específica

- frontend ainda chama localhost: não há bundle/API bootstrap; a URL vem do
  Jinja e a falha ocorre antes do iframe;
- CORS/CSRF do iframe: nenhum request ao iframe foi emitido no fluxo observado;
- DB2, Kafka, Redis, MongoDB ou lookup de perfil: não são chamados nesse ramo;
- path rewrite incorreto de `/streamlit`: o values histórico roteia
  `/streamlit` para 8501 e `/` para 8000; a falha antecede o Ingress dessa rota;
- autorização/grupo: a sessão autenticada alcança a resolução da URL; não há
  lookup de grupo nesse handler;
- cookie path permite backtest e exclui dashboard: a sessão usa path `/`;
- `X-Forwarded-Proto` incorreto como causa direta: a política deliberada não
  confia nesse header para a origem externa; fornecer headers corretos sem
  `PUBLIC_BASE_URL` continua falhando.

### Ainda não verificadas no ambiente real

- tipo exato do aviso “Não seguro”;
- Secret TLS realmente presente/válido no namespace;
- callback HTTPS registrado no IdP;
- igualdade efetiva do `SESSION_SECRET` em todas as réplicas;
- retenção da sessão após restart/scale real;
- propagação de request ID e headers pelo Ingress;
- estado efetivo do chart implantado versus o chart arquivado.

## 10. Correções implementadas

### Código

- Criada `AppConfigurationError` com código e nome do setting, sem incluir
  valores secretos na resposta.
- A origem/callback externos continuam exigindo URL absoluta HTTPS fora de
  localhost.
- O dashboard usa sempre `STREAMLIT_BASE_URL_PATH` relativo fora do
  desenvolvimento local; origem pública ausente, HTTP ou malformada não quebra
  essa fronteira.
- A política `Secure` do cookie Streamlit segue `SESSION_COOKIE_SECURE`, a
  mesma política explícita da sessão FastAPI; `X-Forwarded-Proto` arbitrário
  não a controla.
- Token e nonce do Streamlit são gerados uma vez e usados juntos.
- Erros de configuração recebem `X-Application-Error-Code`, `X-Request-ID`,
  `Cache-Control: no-store` e log estruturado com pod/PID/fase, sem cookies,
  tokens, headers Authorization ou URL configurada.
- O erro permanente do dashboard oferece “Encerrar sessão” em vez de repetir
  indefinidamente o mesmo request.
- `/login` e `/auth/callback` classificam origem/callback inválidos como 503.
- Três `assert` de invariantes de subprocesso foram substituídos por exceções
  explícitas; elas continuam ativas sob `python -O`.

### Configuração/documentação

- Criado `deploy/values-dashboard-auth.patch.yaml`, não aplicado.
- README e deploy README documentam o contrato de origem/callback/TLS.
- Versão elevada de 2.3.0 para 2.3.2 em `pyproject.toml`, pacote, `uv.lock`,
  Sonar, arquitetura e changelog.

### Arquivos modificados por esta investigação

- `app.py` (sobreposto cuidadosamente a trabalho local anterior)
- `acr_controle_acesso_dashboard/templates/error.html`
- `acr_controle_acesso_dashboard/backtest_runner.py`
- `tests/integration/test_public_url_resolution.py` (sobreposto)
- `tests/unit/test_app.py` (sobreposto)
- `deploy/values-dashboard-auth.patch.yaml` (novo)
- `deploy/README.md`
- `README.md`
- `CHANGELOG.md`
- `pyproject.toml`
- `acr_controle_acesso_dashboard/__init__.py`
- `uv.lock`
- `sonar-project.properties`
- `docs/application_architecture.md`
- este handoff

Não foram alteradas regras ou semântica do backtest para reparar autenticação.

## 11. Testes e comandos

### Estado inicial

```sh
git status --short
git diff
git diff --staged
git branch --show-current
git log --oneline --decorate -n 30
```

Branch `main`, um commit, mudanças locais preexistentes, nada staged.

### Teste focado antes da correção

```sh
.venv/bin/pytest -q \
  tests/integration/test_public_url_resolution.py \
  tests/unit/test_app.py \
  tests/unit/test_auth_token.py \
  tests/unit/test_backtest_dates_auth.py
```

Resultado: `199 passed`, 3 warnings.

### Teste focado depois da correção

```sh
.venv/bin/pytest -q \
  tests/integration/test_public_url_resolution.py \
  tests/unit/test_app.py \
  tests/unit/test_auth_token.py \
  tests/unit/test_backtest_runner.py \
  tests/unit/test_backtest_dates_auth.py
```

Resultado: `216 passed`, 3 warnings.

Follow-up 2.3.2:

```sh
.venv/bin/pytest -q \
  tests/integration/test_public_url_resolution.py \
  tests/unit/test_app.py \
  tests/unit/test_auth_token.py \
  tests/unit/test_backtest_runner.py
```

Resultado: `151 passed`, 3 warnings.

### Suite completa

```sh
.venv/bin/pytest -q tests
```

Resultado: `879 passed, 1 skipped`, 3 warnings em 17,39 s.

O skip é preexistente. Os warnings são depreciações Starlette/FastAPI
(`TestClient/httpx` e `on_event`), não falhas.

### Verificações adicionais

```sh
.venv/bin/python -m compileall -q app.py \
  acr_controle_acesso_dashboard \
  tests/integration/test_public_url_resolution.py \
  tests/unit/test_app.py
git diff --check
```

Ambos passaram sem saída.

Uma repetição sanitizada da versão intermediária 2.3.1, pela fronteira ASGI
real e com cookie `SessionMiddleware` assinado, produziu:

```text
sem PUBLIC_BASE_URL:
  dashboard=500, content-type=text/html,
  error=DASHBOARD_PUBLIC_URL_INVALID, iframe=false, backtest=200

com PUBLIC_BASE_URL HTTPS e SESSION_SECRET explícitos:
  dashboard=200, iframe público HTTPS=true,
  nonce corresponde ao cookie=true, Secure=true, HttpOnly=true,
  X-Forwarded-Host hostil ignorado=true
```

A primeira tentativa desse replay deliberadamente partiu do ambiente sem
`SESSION_SECRET` e classificou o segundo request como
`DASHBOARD_SESSION_INVALID`; o replay final definiu um segredo descartável
consistente, como exigido em produção. Nenhum valor de cookie/segredo foi
impresso.

Na 2.3.2, o mesmo replay sem `PUBLIC_BASE_URL` passou a produzir:

```text
dashboard=200, iframe=/streamlit, backtest=200,
cookie Secure de acordo com SESSION_COOKIE_SECURE
```

`flake8` não executou devido a incompatibilidade da instalação:
`AttributeError: module 'flake8' has no attribute 'configure_logging'`.
Não foi mascarado como sucesso.

`uv lock --offline` não pôde recalcular o lock porque o cache não continha
`confluent-kafka` para todos os markers. `uv lock --check --offline` também não
estava disponível dentro do proot (`uv: not found`). O registro do pacote
editável no lock foi atualizado para 2.3.2 e a coerência de versão foi
verificada por parser TOML/script.

## 12. Testes adicionados/fortalecidos

- sessão autenticada real assinada pelo mesmo formato do `SessionMiddleware`;
- reprodução cloud-like sem `PUBLIC_BASE_URL`;
- comparação no mesmo teste com `/backtest/executar`;
- dashboard bem-sucedido com origem HTTPS;
- nonce renderizado calculado do token realmente emitido no cookie;
- atributos `Secure`, `HttpOnly`, `SameSite=Lax` e `Path=/streamlit`;
- headers forwarded conflitantes não alteram URL ou cookie;
- origem HTTP externa é rejeitada e seu valor não vaza;
- fragmento Helm contém origem/callback HTTPS, TLS e não contém callback HTTP;
- fixture de callback bem-sucedido agora satisfaz o contrato de origem pública;
- regressões de runner exercitam as verificações explícitas existentes.

## 13. Bandit

**Versão:** Bandit 1.9.4, Python 3.13.5.

**Comando exato antes e depois:**

```sh
.venv/bin/bandit -r app.py acr_controle_acesso_dashboard backtest_vpn
```

O exit code 1 significa achados, não falha de execução.

| Momento | Total | Low | Medium | High | B101 | B404 | B603 |
|---|---:|---:|---:|---:|---:|---:|---:|
| Antes | 36 | 16 | 20 | 0 | 3 | 3 | 5 |
| Depois | 33 | 13 | 20 | 0 | 0 | 3 | 5 |

Outras regras finais: B104=3, B105=1, B110=3, B607=1, B608=17.
São achados anteriores fora do reparo de autenticação.

### B101

As três asserções de produção em `backtest_runner.py` validavam a disponibilidade
do executável e dos pipes. Foram substituídas por checks e
`BacktestUnavailable`. Resultado final: zero B101 no código de produção
escaneado. Os `assert` dos testes permanecem intencionalmente como mecanismo do
pytest; a varredura estabelecida do projeto não inclui `tests`.

### B404 e B603

Nenhum import/call de subprocesso foi adicionado. Os três B404 e cinco B603
existiam antes e permanecem:

1. `acr_controle_acesso_dashboard/__main__.py`: inicia Streamlit e Uvicorn com
   `sys.executable`, módulos/argumentos literais, argv e shell padrão `False`.
   `STREAMLIT_BASE_URL_PATH` é argumento, nunca executável/comando shell.
2. `backtest_runner.py`: propósito do módulo é orquestrar o CLI de backtest. O
   executável passa pela resolução/validação do runner; job ID, datas, limites e
   regras são normalizados/validados antes do argv; comandos são listas;
   `shell=True` não é usado; stdout/stderr e exit codes são tratados. O processo
   é deliberadamente longo, por isso não há timeout artificial. O ambiente
   herdado é necessário hoje para credenciais/configuração DB2 do mesmo
   executável confiável, mas continua sendo risco residual de menor privilégio.
3. `backtest_vpn/bundle.py`: executa `git rev-parse HEAD` com argv literal e
   shell `False` apenas para proveniência; B607 registra que `git` vem do
   `PATH`. Substituição maliciosa do `PATH` é um risco residual preexistente.

Os argumentos não contêm tokens/senhas e o reparo não passou segredo por linha
de comando. O log do runner mostra o argv do backtest, que contém apenas job,
período, limites e regras.

### Supressões

Bandit informou `Total lines skipped (#nosec): 0`. Não há supressão Bandit
restante nem nova. Os comentários preexistentes `# noqa: S404/S603` são marcação
de outro linter e não suprimiram Bandit. Logo não existe supressão a justificar,
e nenhuma exclusão global foi criada.

### Conclusão Bandit

A alteração não introduziu B101, B404 ou B603. Removeu todos os três B101 e
manteve inalteradas as contagens B404/B603.

## 14. Segurança da correção

- Autenticação e autorização não foram desativadas.
- Nenhum usuário/role foi criado ou concedido automaticamente.
- Headers de identidade/proxy fornecidos pelo cliente não são confiados como
  origem pública.
- HTTPS continua obrigatório fora de localhost.
- Cookies continuam `Secure`, `HttpOnly`, `SameSite=Lax`, com paths mínimos.
- CSRF não foi desligado; o vínculo nonce/cookie foi corrigido.
- CORS não foi ampliado.
- TLS verification do OAuth continua obrigatório.
- Respostas/logs não contêm token, cookie, client secret, matrícula em claro ou
  valor de configuração.
- Não há retry cego para erro persistente.
- Backtest protegido continua protegido e seus testes passaram.

## 15. Validação manual production-like

### Antes de implantar

1. Revisar e mesclar, sem duplicar nomes de env,
   `deploy/values-dashboard-auth.patch.yaml`.
2. Confirmar que o Secret TLS existe e cobre o hostname.
3. Confirmar que o IdP aceita exatamente o callback HTTPS.
4. Confirmar presença (não valor) e igualdade do hash de `SESSION_SECRET` em
   todas as réplicas.
5. Confirmar que o Ingress roteia `/` ao FastAPI e `/streamlit` ao Streamlit,
   sem rewrite que remova o base path.

### Requests sem segredo

```sh
curl -v -i http://acr-vpn-dashboard.acr.hml.bb.com.br/
curl -v -i -L http://acr-vpn-dashboard.acr.hml.bb.com.br/
curl -v -i https://acr-vpn-dashboard.acr.hml.bb.com.br/
curl -v -i https://acr-vpn-dashboard.acr.hml.bb.com.br/dashboard
curl -v -i https://acr-vpn-dashboard.acr.hml.bb.com.br/backtest/executar
```

Esperado: HTTP redireciona a HTTPS; uma sessão anônima não obtém conteúdo
protegido; o certificado e a cadeia são válidos.

### Navegador

1. Limpar cookies do hostname.
2. Abrir DevTools/Network com “Preserve log”.
3. Navegar em HTTPS, iniciar login e registrar a cadeia `/login` → IdP →
   `/auth/callback` → `/dashboard`.
4. Confirmar callback com hostname/scheme exatos e nenhuma URL interna/local.
5. Confirmar cookie de sessão aceito e enviado a `/dashboard`.
6. Confirmar `GET /dashboard -> 200`, depois primeiro
   `GET /streamlit?csrf_nonce=... -> 200`.
7. Confirmar cookies Secure/HttpOnly/SameSite=Lax; sessão path `/`; Streamlit
   path `/streamlit`.
8. Confirmar ausência de mixed content, CORS, CSRF e redirect bloqueado.
9. Testar usuário fora da allow-list: 403/login negado, nunca dashboard.
10. Testar página e status de backtest.

### Réplicas/restart

1. Registrar pod, request ID e cookie de uma autenticação iniciada no pod A.
2. Direcionar o request seguinte ao pod B sem revelar o cookie em logs.
3. Esperar dashboard 200 e Streamlit 200.
4. Reiniciar A, repetir.
5. Escalar, repetir em todas as réplicas.
6. Se falhar, comparar presença/hash do `SESSION_SECRET`, versão da imagem e
   env `PUBLIC_BASE_URL`/base path. Não usar sticky session como correção.
7. Verificar separadamente que logout remoto pode se perder após troca de pod,
   por causa do `_ACCESS_TOKENS` em memória; logout local ainda deve limpar a
   sessão.

## 16. Troubleshooting operacional

1. Capture `X-Request-ID` e `X-Application-Error-Code` da primeira resposta.
2. `DASHBOARD_PUBLIC_URL_INVALID`: verifique presença e formato HTTPS de
   `PUBLIC_BASE_URL`; não “corrija” confiando em headers de cliente.
3. `DASHBOARD_SESSION_INVALID`: compare `SESSION_SECRET` entre web e Streamlit,
   presença em todas as réplicas e versão da imagem.
4. 307 para `/`: cookie de sessão ausente/rejeitado/inválido; inspecione
   Secure, scheme público, domínio/path e segredo entre pods.
5. `/dashboard` 200 mas `/streamlit` 404: confira path/routing/baseUrlPath.
6. `/streamlit` 401/403: correlacione nonce do query com cookie, origem,
   `SESSION_SECRET` e relógio/TTL.
7. callback 403: confira state/cookie e SameSite; não desative CSRF.
8. callback 502/503: separe configuração, token exchange, TLS/CA e userinfo
   pelos logs; nunca registre Authorization/token.
9. backtest funciona mas dashboard falha: compare primeiro a resolução da
   origem e a fronteira FastAPI → Streamlit; são caminhos diferentes.
10. Sempre correlacione navegador, Ingress e todos os pods pelo request ID.

## 17. Riscos residuais e próximos passos exatos

1. Aplicar externamente, após revisão, a origem/callback/TLS; este repositório
   local sozinho não muda o cluster.
2. Capturar HAR sanitizado e logs correlacionados do ambiente real.
3. Verificar certificado/cadeia e resolver definitivamente “Não seguro”.
4. Executar teste cross-pod e restart com o mesmo segredo.
5. Mover `_ACCESS_TOKENS` para mecanismo compartilhado/criptograficamente
   autocontido se logout remoto garantido após troca de pod for requisito.
6. Classificar em uma tarefa própria as exceções de transporte/JSON do token e
   userinfo, hoje parcialmente genéricas.
7. Corrigir a instalação local do flake8 e executar o lint CI equivalente.
8. Em hardening separado, resolver `git` por caminho confiável e avaliar um
   ambiente mínimo explícito para o runner, sem retirar as credenciais de que o
   CLI realmente precisa.
9. Atualizar o lock com a versão oficial do `uv` e cache/índice de dependências
   disponível, depois executar `uv lock --check`.

## 18. Estado final

- Código e configuração local preparados.
- Versão 2.3.2.
- `879 passed, 1 skipped`.
- Bandit: 33 findings preexistentes/aceitos para acompanhamento, zero High,
  zero B101, B404/B603 sem aumento, zero `#nosec`.
- Nenhum deploy, commit, push ou mutação externa.
- A afirmação “corrigido em produção” **não** é feita: a integração local foi
  verificada, mas a configuração e a validação do cluster continuam externas.
