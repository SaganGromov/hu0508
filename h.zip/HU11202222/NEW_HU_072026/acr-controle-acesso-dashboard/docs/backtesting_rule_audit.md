# Auditoria técnica das regras de backtesting

## Escopo e modelo de dados

A aplicação possui FastAPI para autenticação, páginas HTML e orquestração; Streamlit para o dashboard operacional; e o pacote `backtest_vpn` para consultas DB2 somente leitura, regras, bundle e relatórios. O backtest lê `DB2PEP.AUT_CPTV` (configurável) pelos campos `CD_USU_AUT`, `TS_TRAN`, `CD_END_LGC_OGM`, `CD_END_LGC_CPTV`, `NM_DSVO` e `CD_IDFC_DSVO`. R5/R6 também leem `DB2PEP.MTA_AUT_CLI_TRAN`.

O código e os artefatos existentes sustentam somente estas interpretações:

- uma linha de `AUT_CPTV` é tratada pela aplicação como evento de autenticação VPN;
- `CD_USU_AUT` é a chave do usuário autenticado;
- `TS_TRAN` é o horário do evento;
- `CD_END_LGC_OGM` é o IP de origem;
- `CD_END_LGC_CPTV` é o IP corporativo/tunelado;
- `NM_DSVO` é o nome do dispositivo/computador;
- `CD_IDFC_DSVO` é o identificador de dispositivo.

Não há, entre as colunas consultadas de `AUT_CPTV`, identificador explícito de login, sessão, tentativa, refresh ou reconexão. Portanto:

- **linha do banco** é o registro bruto;
- **evento** é uma linha válida após normalização e deduplicação exata;
- **login VPN qualificável** é um evento deduplicado de `AUT_CPTV`;
- **sessão** só existe quando a fonte fornece identificador/início/fim; não é inferida;
- **ocorrência** é um achado consolidado de regra e pode conter vários eventos;
- **alerta** é a apresentação de uma ocorrência para revisão humana.

A chave natural de deduplicação de `AUT_CPTV` é a tupla normalizada `usuário + timestamp + IP de origem + IP corporativo/túnel + hostname + dispositivo`. Ela remove apenas linhas idênticas. Eventos no mesmo segundo que diferem em qualquer campo continuam distintos. Sem semântica adicional da fonte, refresh, retry e reconexão não podem ser descartados com segurança.

Timestamps DB2 sem offset são interpretados como horário local `America/Sao_Paulo`. O intervalo técnico é `[início, fim)`. A interface recebe datas inclusivas e converte a data final para meia-noite do dia seguinte, evitando perda do último dia.

### Política única para endereços IP

Todos os caminhos modificados — normalização do backtest, R1, R5, R9,
ingestão Kafka, cálculo de distância IPv4 e detecção rápida do Streamlit —
usam `ipaddress.ip_address` e a propriedade `is_unspecified`. Portanto,
`0.0.0.0`, `::`, `::0`, `0:0:0:0:0:0:0:0` e qualquer outra grafia
equivalente de endereço não especificado são tratados como **ausência de
dado**. Eles:

- não contam como IP distinto;
- não disparam R1, R5 ou R9;
- não entram em listas de evidência nem em cálculos de distância;
- incrementam contadores de qualidade específicos, além do contador geral de
  IP inválido/ausente.

IPs válidos são comparados em forma canônica (`compressed`, minúscula), o que
evita tratar duas grafias IPv6 equivalentes como endereços diferentes. Não são
excluídos automaticamente endereço de loopback, link-local, privado ou
reservado: esses atributos têm significado contextual e só podem virar
exclusão por política de negócio documentada.

## Período, corte de dados e ciclo de execução

Toda a semântica de período está centralizada em `backtest_vpn/period.py` e é a
mesma na interface, na API, no CLI, no agendador, na persistência, nos
relatórios e nos testes.

| Item | Valor |
| --- | --- |
| Janela padrão | **33 datas locais inclusivas** |
| Cálculo | `start_date = data_local_atual - 32 dias`, `end_date = data_local_atual` |
| Janela técnica | `[start_date 00:00:00, end_date+1 dia 00:00:00)` |
| Fuso | `America/Sao_Paulo` (configurável em `BACKTEST_TIMEZONE`) |
| Corte automático padrão | `completed_day` — a janela automática termina no **último dia local completo**; o dia corrente, ainda parcial, é excluído |
| Corte da interface | `current_day` — o padrão exibido termina na data local corrente, conforme o pedido de “33 dias mais recentes” |

O corte efetivo de cada execução é gravado no job, no bundle, no modelo
normalizado, no dossiê, na planilha e no manifesto CSV, nos campos
`data_cutoff` e `data_cutoff_description`. Nenhum relatório apresenta um dia
parcial como se estivesse completo sem declarar isso.

O ciclo é: um job padrão enfileirado de forma idempotente na implantação; a
partir daí, uma execução automática por dia após o horário de corte local. Uma
execução perdida é recuperada por uma única janela rolante, que reprocessa todo
o período de 33 dias — isso também resolve as regras cujas janelas móveis (R7,
R8, R9) e cuja deduplicação dependem de eventos anteriores. A marca d'água só
avança após publicação validada, portanto uma falha parcial nunca faz o
processamento pular dias.

Execuções manuais **não** movem a marca d'água: elas podem cobrir qualquer
período escolhido pela pessoa autorizada e não representam o avanço do ciclo
diário. Execuções manuais e automáticas nunca corrompem o resultado uma da
outra porque cada publicação é atômica, versionada por `job_id` e protegida por
token de *fencing*.

## R1 — Alteração de endereço IP no mesmo dia

- **Propósito:** localizar usuário que muda de IP durante o mesmo dia, para análise contextual.
- **Condição anterior:** por usuário, no período inteiro, `COUNT(DISTINCT CD_END_LGC_OGM) > distinct_limit OR COUNT(DISTINCT CD_END_LGC_CPTV) > distinct_limit`; padrão `distinct_limit=2`.
- **Entradas:** `CD_USU_AUT`, `TS_TRAN`, `CD_END_LGC_OGM`, `CD_END_LGC_CPTV`, e os demais campos da chave de deduplicação.
- **Janela anterior:** período inteiro; isso podia sinalizar uma pessoa que usou um IP em um dia e outro em dia posterior.
- **Agrupamento final:** usuário + data local.
- **Limiar final:** pelo menos 2 IPs válidos distintos no campo de origem **ou** pelo menos 2 no campo corporativo/túnel.
- **Exclusões:** nulos, vazios, malformados e IPs não especificados (`0.0.0.0`, `::`); duplicatas exatas; contas incluídas na allowlist configurada.
- **Severidade:** média.
- **Limitações:** os dois campos representam dimensões simultâneas e não são misturados; faixas corporativas/VPN só recebem classificação de rede quando configuradas. Mudança de rede móvel, NAT, renovação do túnel e failover podem ser legítimos.
- **Problemas encontrados:** agregação no período inteiro; texto sugeria prova de compartilhamento; ausência de sequência/evidência; amostra limitada podia ocultar usuários; IPv4/IPv6 não eram normalizados.
- **Mudança implementada:** ocorrência por usuário-dia com sequência temporal, conjuntos distintos separados, classificações, dispositivos e identificadores estáveis de evento.
- **Condição final:** `distinct(source_ip no usuário-dia) >= 2 OR distinct(corporate_tunnel_ip no usuário-dia) >= 2`.

## R2 — Múltiplos nomes de computador no período

- **Propósito:** localizar uma chave associada a vários valores de `NM_DSVO`.
- **Condição anterior/final:** por usuário no período, mais de `distinct_limit` valores não vazios distintos; padrão `> 2`.
- **Entradas:** `CD_USU_AUT`, `TS_TRAN`, `NM_DSVO` e chave natural completa.
- **Janela:** período selecionado.
- **Agrupamento:** usuário.
- **Exclusões:** valores nulos, vazios, placeholders, controle ou acima de 256 caracteres; duplicatas exatas; contas incluídas na allowlist configurada.
- **Severidade:** baixa.
- **Limitações:** `NM_DSVO` pode mudar por reinstalação, política de nomes ou substituição legítima. Não há cadastro de ativos para confirmar identidade.
- **Problemas encontrados:** contagem de linhas brutas, pouca evidência e linguagem acusatória.
- **Mudança implementada:** normalização, deduplicação, evidência integral e explicação neutra.
- **Condição final:** `distinct(valid NM_DSVO por usuário no período) > limite configurado`.

## R3 — Múltiplos dispositivos no período

- **Propósito:** localizar uma chave associada a vários `CD_IDFC_DSVO`.
- **Condição anterior/final:** por usuário no período, mais de `distinct_limit` dispositivos distintos; padrão `> 2`.
- **Entradas/janela/agrupamento:** usuário, período completo, `CD_IDFC_DSVO`.
- **Exclusões:** identificadores ausentes, placeholders, malformados de forma objetiva, duplicatas exatas e contas incluídas na allowlist configurada.
- **Severidade:** baixa.
- **Limitações:** confiabilidade e ciclo de vida de `CD_IDFC_DSVO` não estão documentados no repositório. Troca de equipamento é causa legítima.
- **Problemas encontrados:** ausência de validação/explicação e contagem de linhas brutas.
- **Mudança implementada:** mecanismo conservador de validade, evidência e parâmetros centralizados.
- **Condição final:** `distinct(valid CD_IDFC_DSVO por usuário no período) > limite configurado`.

## R4 — Mais de dois logins VPN no mesmo dia

- **Propósito:** localizar volume diário de logins VPN acima da política informada.
- **Condição anterior:** linhas de `AUT_CPTV` por usuário e `DATE(TS_TRAN)`, `COUNT(1) > daily_login_limit`; padrão 10.
- **Entradas:** as seis colunas de `AUT_CPTV`.
- **Janela/agrupamento final:** usuário + dia local.
- **Limiar final:** `> 2`: zero, um e dois não sinalizam; três ou mais sinalizam.
- **Exclusões:** duplicatas exatas, eventos sem usuário/timestamp válido e contas incluídas na allowlist configurada.
- **Severidade:** variável e independente do alerta UOR: 3–10 eventos =
  `MÉDIA`; 11–20 = `ALTA`; 21 ou mais = `CRÍTICA`. Os pontos de corte são
  configuráveis por `r4_high_severity_above` (10) e
  `r4_critical_severity_above` (20), mas devem permanecer estritamente acima
  do limiar de detecção e em ordem crescente.
- **Limitações:** a fonte consultada não permite diferenciar refresh, retry, heartbeat ou reconexão além de duplicatas exatas. Essa decisão exige confirmação do dono da fonte.
- **Problemas encontrados:** limiar 10 divergente do requisito, `DATE` sem convenção explícita, contagem de linhas duplicadas e ausência dos horários de suporte.
- **Mudança implementada:** contagem deduplicada no fuso da aplicação,
  horários e evidências completos, severidade graduada com justificativa e
  estilos distintos em LaTeX/PDF e XLSX.
- **Condição final:** `count(eventos VPN deduplicados por usuário-dia) > 2`.
- **Fronteiras verificadas:** 2 não sinaliza; 3 e 10 são médias; 11 e 20 são
  altas; 21 é crítica. “Mais de 10” e “mais de 20” são operadores estritos,
  conforme solicitado.

## R5 — Evento VPN e autenticação OpenAM próximos, em IPs diferentes

- **Propósito:** correlacionar evento VPN com autenticação OpenAM bem-sucedida do mesmo usuário em outro IP privado.
- **Condição atual/final:** para cada evento VPN com IP corporativo/túnel válido, procura fluxo OpenAM bem-sucedido em `MTA_AUT_CLI_TRAN`, nos decision nodes configurados, dentro de `±15 minutos` por padrão, com `ipCliente` em CIDR privado configurado e diferente do IP tunelado.
- **Deduplicação:** eventos VPN idênticos por usuário+timestamp+IP corporativo/túnel; OpenAM por `CD_UNCO_TRAN`, com fallback para `CD_IDFR_MTA` quando o fluxo não existe; a ocorrência usa o par VPN+fluxo.
- **Exclusões:** IPs inválidos/não especificados em qualquer grafia e IP
  OpenAM fora dos CIDRs configurados.
- **Severidade:** alta.
- **Limitações:** correlação simétrica ao redor de um evento não comprova que
  uma sessão VPN estava ativa; a consulta usa aproximação de faixa de PK para
  respeitar o ASUTIME do DB2.
- **Problemas encontrados:** interface afirmava simultaneidade/sessão ativa sem dados de início/fim.
- **Mudança implementada:** terminologia de correlação temporal, ocorrência
  estável e ressalva explícita; IPs comparados em forma canônica; todos os
  usuários processados em rodadas, sem truncamento; eventos candidatos
  encontrados por busca binária; exceder `MTA_FETCH_FIRST_ROWS` aborta a regra
  em vez de publicar resultado parcial.

## R6 — R5 com múltiplos equipamentos no período

- **Propósito:** priorizar ocorrência R5 cujo usuário também apresenta diversidade de equipamentos.
- **Condição:** ocorrência R5 e, no período,
  `hostnames distintos > r2_distinct_hostname_limit OR dispositivos distintos
  > r3_distinct_device_limit`.
- **Problema encontrado:** o universo de R6 era construído apenas de `R5.sample`, limitado por `sample_limit`; usuários fora da amostra eram falso-negativos.
- **Mudança implementada:** R6 usa todas as ocorrências R5, mantém a evidência
  R5 e acrescenta contagens. O número exibido é de ocorrências; usuários
  únicos são calculados separadamente. Usuários são consultados em lotes
  limitados; nulos/vazios não contam; uma falha DB2 aborta sem devolver o
  subconjunto já processado.
- **Severidade:** alta.
- **Limitações:** diversidade é medida no período, não necessariamente na janela R5.

## R7 — Dispositivo associado a múltiplos usuários

- **Propósito:** localizar `CD_IDFC_DSVO` válido associado a pelo menos dois `CD_USU_AUT` válidos.
- **Entradas:** as seis colunas `AUT_CPTV`; detalhes organizacionais somente quando fornecidos de fonte autorizada.
- **Janelas:** mesmo dia, móvel de 7 dias e móvel de 30 dias por padrão; a lista é configurável, exige o horizonte diário e ao menos uma janela maior.
- **Agrupamento:** dispositivo; usuários repetidos contam uma vez.
- **Consolidação:** janelas sobrepostas com o mesmo conjunto de usuários e evidência sobreposta são unidas. Uma ocorrência recebe o horizonte mais curto observado.
- **Exclusões:** dispositivos compartilhados e contas de serviço/teste somente quando listados no JSON de configuração; nenhuma entrada é inventada.
- **Severidade:** alta para mesmo dia, média até 7 dias, baixa até 30 dias.
- **Limitações:** sem início/fim de sessão, concorrência é “não determinável”; horários distintos só demonstram ordem observada.
- **Condição final:** `distinct(valid CD_USU_AUT por valid CD_IDFC_DSVO dentro de uma das janelas) >= 2`.

## R8 — Usuário em múltiplos dispositivos em curto intervalo

- **Propósito:** diferenciar uma transição aguda de dispositivos de substituição de longo prazo.
- **Condição:** ao menos 2 dispositivos válidos para o mesmo usuário em uma janela móvel de 60 minutos.
- **Exclusões:** identificadores inválidos, duplicatas e allowlists configuradas aplicáveis.
- **Severidade:** média.
- **Causas legítimas:** troca entre estação e equipamento móvel, suporte técnico, failover ou nova estação.
- **Consolidação:** janelas qualificadas com evidência temporal sobreposta são
  unidas em um episódio. `triggering_value` é o máximo de dispositivos
  distintos observado em uma única janela válida; a lista de evidência do
  episódio pode ser maior e é identificada separadamente.

## R9 — Troca rápida de endereços IP

- **Propósito:** localizar várias mudanças de IP em curto intervalo, distinta da agregação diária de R1.
- **Base do parâmetro:** a página Streamlit preexistente `logins_suspeitos.py` já usava 3 IPs em 2 horas; a regra de backtest adota essa convenção, agora configurável.
- **Condição:** ao menos 3 IPs de origem válidos distintos para o mesmo usuário em 120 minutos.
- **Exclusões:** IP inválido/não especificado, duplicatas; campos origem e corporativo/túnel não são misturados.
- **Severidade:** média.
- **Causas legítimas:** rede móvel, balanceamento, reconexão e NAT.
- **Consolidação:** igual a R8; o valor acionador é o máximo observado em uma
  janela qualificável, sem inflar a contagem pela união de várias janelas.

## Caso legado sem identificador de regra

`vpn_ativa_com_login_em_rede_fisica` correlaciona uma tabela física opcional com um evento VPN durante a janela posterior configurada (8 horas por padrão). Ele permanece por compatibilidade, mas não recebe novo identificador porque R5 já ocupa a finalidade correlata e a intenção de negócio não autoriza renumeração. Quando a tabela não está configurada, o caso é explicitamente ignorado.

## Detecções relacionadas no dashboard em tempo real

Estas funções existem no arquivo Streamlit `logins_suspeitos.py`, cuja interface agora se apresenta como “Sinais de acesso para análise”, mas não faziam parte do backtest DB2 nem do bundle R1–R6:

- login durante ausência formal: data local do login dentro do intervalo inclusivo retornado por Curio `op2076328v2`;
- fingerprint compartilhado: `fingerprint` não vazio usado por mais de uma `chave`;
- MAC compartilhado: `mac_address` não vazio e diferente de `00:00:00:00:00:00`, usado por mais de uma `chave`;
- horário atípico: antes de 06:00, a partir de 22:00 ou sábado/domingo no fuso `America/Sao_Paulo`;
- troca rápida: pelo menos 3 `src_ip` distintos em janela móvel de 2 horas;
- alta taxa de falha: pelo menos 5 tentativas e 50% de `status != "Success"`.

Essas detecções usam o modelo Kafka, que contém campos não disponíveis nas seis colunas DB2 do backtest. R9 reutiliza apenas a convenção defensável de 3 IPs/2 horas. As demais não foram copiadas para o backtest sem os campos correspondentes. A detecção de horário atípico permanece limitada por não representar turnos, feriados ou escalas.

## Modelo comum de resultado

Toda ocorrência de qualquer regra carrega os mesmos campos, verificados por
teste (`test_backtest_detection_boundaries.py::test_every_occurrence_carries_the_common_result_model`):

`occurrence_id`, `rule_id`, `rule_title`, `rule_version`, `severity`,
`user_id`, `device_id`, `local_date`, `window_start`, `window_end`,
`triggering_value`, `configured_threshold`, `explanation`,
`supporting_event_identifiers`, `evidence_records`, `relevant_ips`,
`relevant_devices`, `relevant_sessions`, `deduplication_key`,
`deduplication_method`, `first_event_timestamp`, `last_event_timestamp`,
`applicable_exclusions` e `details`.

O modelo normalizado do relatório acrescenta, por execução: `report_id`,
`job_id`, `trigger_type`, `execution_attempt`, `configuration_hash`,
`rule_versions`, `period_start_date`, `period_end_inclusive`,
`total_calendar_days`, `data_cutoff`, `data_cutoff_mode` e
`data_cutoff_description`; e, por usuário, a classificação de UOR
(`uor_alert_code`, `uor_alert_label`, `uor_alert_reason`).

### Consolidação entre regras

Ocorrências de regras diferentes são agrupadas em uma consolidação apenas
quando **compartilham identificadores de evento** e **a mesma entidade**
(usuário ou dispositivo). Coincidência apenas de data nunca consolida nada.
Cada consolidação recebe um `consolidation_id` estável e preserva todos os
`occurrence_id` originais; nada é fundido de forma destrutiva.

### Determinismo

Para a mesma entrada e a mesma configuração: a ordem de leitura das linhas não
altera o resultado; os `occurrence_id` e `deduplication_key` são estáveis; a
execução com 1 worker e com N workers produz conteúdo idêntico em todos os
formatos. Há teste para cada uma dessas propriedades.

## Regras candidatas não implementadas

- **Sessões concorrentes/impossible travel:** rejeitada porque não existem início/fim de sessão nem geolocalização confiável.
- **Falhas seguidas de sucesso:** rejeitada porque `AUT_CPTV` não distingue falha e sucesso.
- **Primeiro dispositivo/IP:** rejeitada porque o período consultado não garante baseline histórico completo.
- **Volume relativo a baseline:** rejeitada porque não há baseline comparável por função/turno com cobertura documentada.
- **Fora de horário/fim de semana:** rejeitada porque turnos, escalas, feriados e exceções não são representados.
- **Muitos usuários em IP externo:** rejeitada porque não há classificação/allowlist confiável de NAT, proxy, VPN e redes de escritório.
- **Burst VPN adicional:** não criado para evitar duplicar R4 sem política aprovada de limiar curto.
- **Anomalia de volume relativo a baseline robusto:** rejeitada nesta rodada porque o período consultado (33 dias) não constitui baseline histórico documentado por função, turno ou escala, e um baseline calculado sobre a própria janela sinalizaria variação sazonal normal.
- **Dispositivo com identificador reutilizado por hostnames divergentes:** avaliada e **não implementada** como regra. O sinal é calculável com os campos existentes (`CD_IDFC_DSVO` associado a vários `NM_DSVO`), mas o significado de negócio depende do ciclo de vida do identificador de dispositivo, que não está documentado na fonte. Sem essa definição, a regra produziria alerta para reinstalação e renomeação legítimas. **Decisão necessária do dono da fonte:** confirmar se `CD_IDFC_DSVO` é estável ao longo da vida do equipamento; em caso afirmativo, a regra pode ser adicionada com limiar configurável.

R8 e R9 continuam sendo as duas regras adicionais determinísticas e explicáveis
exigidas, ambas sustentadas apenas pelos campos realmente disponíveis.

## Revisão de eficiência e complexidade

Não existe uma implementação universalmente “melhor” sem medir o volume e os
planos DB2 internos, mas foram removidos os custos assintóticos evitáveis:

| Área | Antes | Agora | Observação |
| --- | --- | --- | --- |
| R1–R4 | agrupamentos lineares após ordenação | mantido | custo dominado pela leitura/ordenação determinística |
| R7 | comparação repetida de pares/janelas | janela deslizante com `Counter`, O(n) amortizado por dispositivo | consolidação evita um alerta por posição da janela |
| R8/R9 | reconstrução de conjuntos em toda janela, O(n²) no pior caso | dois ponteiros + contador, O(n) amortizado por usuário | episódios sobrepostos consolidados |
| menor intervalo entre usuários de R7 | todos os pares, O(n²) | pares temporais adjacentes, O(n) | preserva o menor intervalo entre categorias distintas |
| R5, evento OpenAM × eventos VPN | varredura completa por resultado | `bisect_left`/`bisect_right`, O(log n + k) | cada usuário tem timestamps ordenados |
| R5, limite de usuários | truncava após N | N é tamanho da rodada; todo o universo é percorrido | evita falso negativo silencioso |
| R5, limite de linhas | podia parecer completo no teto | consulta `limite+1` e falha fechada | exige ajuste interno consciente |
| R6 | lista `IN` potencialmente grande e limiar único | lotes de 200 e limites independentes | reduz risco do driver/DB2 |

A aplicação mantém `BACKTEST_RULE_WORKERS=1` como padrão. As regras de memória
podem usar um executor limitado, mas consultas DB2 não compartilham cursor ou
conexão entre threads. Aumentar workers só deve ocorrer após medição interna:
em CPython, o GIL e o custo de cópia/ordenação podem tornar threads mais lentas.

### Limites que dependem da máquina interna

- validar `EXPLAIN` e índice/plano das consultas `AUT_CPTV`;
- medir a precisão da aproximação PK→timestamp de R5 em períodos de carga
  irregular;
- calibrar `MTA_USERS_PER_BATCH`, `MTA_CHUNK_HOURS` e
  `MTA_FETCH_FIRST_ROWS` contra ASUTIME e pool;
- confirmar se `CD_UNCO_TRAN` é realmente a chave natural de fluxo;
- obter um identificador confiável de login/sessão para melhorar a
  deduplicação de R4.

## Dados organizacionais, allowlists e armazenamento

UOR e demais campos organizacionais são consultados pelo sidecar Curio a partir da matrícula, combinando duas operações: `op292018v3` (ATC) devolve nome, matrícula, UOR, prefixo, comissão, tipo de usuário e referências organizacionais; `op5360402v1` (ARH) devolve o nome do funcionário, o nome da dependência de lotação (`nomeDependenciaLotacao`, exibido como local de trabalho) e o nome da função exercida (`nomeFuncaoLotacao`, exibido como cargo). Departamento, unidade e hierarquia são derivados por separação do nome da dependência (`"PTT/PLAT. GEST DF"` → `PTT` + `PLAT. GEST DF`), sem inventar dados.

A resposta da `op5360402v1` é uma lista de tamanho fixo preenchida com registros vazios; os registros de preenchimento são descartados pelo consumidor. Campos sem fonte em nenhuma das duas operações — nome da UOR, UOR pai, centro de custo e status da conta — foram removidos dos relatórios em vez de exibidos como "Não informado". No dossiê, qualquer campo sem valor é omitido da tabela do perfil, de modo que o relatório mostra apenas o que o Curio efetivamente devolveu.

Não havia allowlist de dispositivo compartilhado, quiosque, sala de treinamento, terminal de serviço, conta de teste/serviço, IP corporativo ou VPN no backtest. Foi implementado mecanismo em `config/backtest_rules.example.json`, vazio por padrão. A allowlist de contas exclui essas contas de todas as regras de evento; a allowlist de dispositivo compartilhado é aplicada a R7. O relatório registra apenas a quantidade de entradas/configuração aplicada.

Resultados são mantidos como JSON/Markdown, bundle JSON e HTML. A nova camada gera, do mesmo modelo normalizado, `reports/backtesting_dossier.tex`, `reports/backtesting_dossier.xlsx` e `reports/backtesting_report_model.json`. A interface web oferece o dossiê somente em LaTeX; PDFs não são listados nem aceitos pela rota autenticada de download. Artefatos são ignorados pelo Git. Bundles versão 1 já existentes são preservados, mas não são exibidos nem aceitos pelo novo gerador, porque suas agregações R1/R4 não correspondem às descrições atuais.
