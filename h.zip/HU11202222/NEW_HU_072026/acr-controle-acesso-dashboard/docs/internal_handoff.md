# Handoff para a máquina da rede interna

Versão da aplicação: **2.3.0**.

Nada neste repositório executa implantação, acesso a rede, DB2 ou Git. Todos os
comandos abaixo devem ser executados por pessoa autorizada, na máquina interna.

---

## 1. Arquitetura descoberta e fluxo de dados

```
                 OAuth2 (SSO intranet)          Curio sidecar (op292018v3)
                        │                                 │
                        ▼                                 ▼
  navegador ──► FastAPI (app.py) ──► páginas /backtest/* e API de status
                        │                    ▲
                        │ enfileira comando   │ lê estado durável
                        ▼                    │
      backtest_vpn/commands.py  ◄────────────┤
        (handlers de caso de uso)            │
              │            │                 │
              │            └────► backtest_vpn/jobstore.py
              │                     (MongoDB: telemetria.BACKTEST_VPN_JOBS)
              ▼
   backtest_vpn/pipeline.py ──► db2.py / rules.py / detection.py  (somente leitura)
              │
              ▼
   report_model.py ─► dossier.py (LaTeX + XLSX) ─► csvpackage.py (CSV + manifesto)
              │
              ▼
   publication.py  ──► reports/published/<job_id>/ + published/latest.json
```

Camadas:

| Camada | Arquivos | Responsabilidade |
| --- | --- | --- |
| Adaptadores de entrada | `app.py`, `backtest_vpn/cli.py`, `acr_controle_acesso_dashboard/backtest_runner.py`, `deploy/backtest-scheduler-cronjob.yaml` | HTTP, CLI, subprocesso local e CronJob. Nenhuma regra de negócio. |
| Raiz de composição | `backtest_vpn/runtime.py` | Único lugar que lê variáveis de ambiente e monta o caso de uso. |
| Comandos e handlers | `backtest_vpn/commands.py` | Casos de uso; dependem apenas de interfaces. |
| Domínio | `backtest_vpn/detection.py`, `rules.py`, `period.py`, `scheduler.py` | Regras, período e política de agendamento. Sem HTTP/CLI/Kubernetes. |
| Infraestrutura | `jobstore.py`, `publication.py`, `db2.py`, `concurrency.py`, `progress.py` | Estado durável, publicação, acesso a dados, concorrência, observabilidade. |
| Relatórios | `report_model.py`, `dossier.py`, `csvpackage.py` | Um modelo normalizado; três formatos derivados dele. |

Fonte de dados: `DB2PEP.AUT_CPTV` (seis colunas configuráveis) e, para R5/R6,
`DB2PEP.MTA_AUT_CLI_TRAN`. **Acesso somente leitura.**

A visão completa de componentes e fronteiras está em
`docs/application_architecture.md`; a condição e a complexidade de cada regra
estão em `docs/backtesting_rule_audit.md`.

## 2. Autenticação e autorização

* OAuth2 *authorization code* contra o SSO da intranet; `state` validado.
* A matrícula extraída do `userinfo` precisa constar em
  `ALLOWED_MATRICULA_DIGESTS` (comparação HMAC-SHA256 em tempo constante).
* Todas as rotas `/backtest/*` reavaliam a allow-list **a cada requisição**
  (`_require_backtest_user` / `_require_backtest_user_json`), de modo que uma
  revogação tem efeito imediato na próxima requisição.
* Superfícies protegidas nesta versão, além das já existentes:
  `/backtest/status`, `/backtest/reports` (índice) e
  `/backtest/reports/{arquivo}` incluindo `detalhamento_csv/*.csv`.
* Não existe endpoint público de agendamento. O agendamento é feito por
  CronJob/worker fora do processo HTTP. Essa foi uma decisão deliberada para
  não criar uma superfície de execução remota.
* Usuário sem permissão recebe a resposta padrão (302 para páginas, 401/403
  para JSON) e **não** aprende período, achados, nomes, UOR, dispositivos, IPs,
  existência de relatório nem caminho de arquivo.
* Erros técnicos detalhados ficam nos logs operacionais; a interface mostra um
  resumo curto e não sensível (`error_summary`).

## 3. Período de 33 dias

```
start_date = data_local_atual - 32 dias      (inclusiva)
end_date   = data_local_atual                (inclusiva)
=> exatamente 33 datas locais distintas
janela técnica processada: [start_date 00:00:00, end_date + 1 dia 00:00:00)
```

* Interface, API, CLI, agendador, persistência e relatórios usam a mesma
  implementação (`backtest_vpn/period.py`).
* Períodos parametrizados continuam disponíveis, limitados a 400 dias por
  execução para evitar consulta ilimitada.
* Datas inválidas, invertidas e inexistentes (por exemplo `2026-02-30`) são
  recusadas com mensagem em português.

## 4. Ciclo de vida: execução inicial e atualização de 24 h

### 4.1 Execução inicial após a implantação

1. Na subida, o pod web chama `ensure_initial_job`, que **apenas enfileira** o
   job padrão de 33 dias, de forma idempotente, e retorna imediatamente.
2. Nenhum trabalho de DB2 acontece na thread HTTP de startup.
3. A aplicação fica pronta na hora. A página “Executar” e `/health/ready`
   informam explicitamente “o conjunto de dados inicial está sendo preparado”.
4. Se já existir resultado publicado, o job inicial não é recriado.
5. A execução é feita pelo `Job`/`CronJob` de `deploy/`, ou manualmente por
   `backtest-vpn worker --drain`.

### 4.2 Atualização automática

* Um disparo por dia (`CronJob`), avaliado por
  `backtest_vpn/scheduler.evaluate` contra a marca d'água publicada.
* Antes do corte local configurado, a decisão é “aguardando o horário de corte”
  e nada roda.
* Janela já publicada não é reprocessada.
* Execuções perdidas são recuperadas por **uma** janela rolante de 33 dias, que
  reprocessa todo o período. Correção prevalece sobre economia de processamento:
  isso garante que R7/R8/R9 e a deduplicação vejam o contexto anterior completo.
* A marca d'água (`last_published_end_date`) é gravada **somente** após
  publicação validada. Falha parcial nunca faz pular dias.
* Corte de dados: `completed_day` por padrão (termina no último dia local
  completo). `current_day` disponível por configuração. O corte efetivo é
  registrado em cada resultado e relatório.

## 5. Coordenação entre vários pods

O chart usa `hpa.minReplicas: 2`. As garantias:

| Requisito | Como é atendido |
| --- | --- |
| Efeito exatamente-uma-vez com entrega ≥1 vez | Chave de idempotência = `_id` do documento |
| Chave de idempotência estável | `sha256(gatilho + data inicial + data final + fuso + regras + versões de regra + hash de configuração)` |
| Reserva atômica | `find_one_and_update` com filtro de estado/lease |
| Expiração de lease e recuperação | `lease_expires_at`; outro pod assume após expirar, com `attempt` incrementado |
| Heartbeat | Cada evento de progresso renova o lease |
| Fencing | `fence` incrementa em cada reserva; publicação e `mark_succeeded` exigem o `fence` vigente |
| Sem publicação duplicada | Diretório versionado por `job_id` + ponteiro atômico |
| Tentativas limitadas e falha terminal | `BACKTEST_MAX_ATTEMPTS` com backoff exponencial determinístico |
| Encerramento graceful | `SIGTERM` cancela e **devolve o job à fila**; nunca marca sucesso |
| Sem dependência de sticky session | Status lido do estado durável por qualquer pod |
| Menor privilégio | Sem endpoint de agendamento; o CronJob usa apenas os Secrets necessários |

**Escolha do mecanismo.** Não existe fila de tarefas distribuída no projeto. O
DB2 é somente leitura, portanto uma tabela de jobs em DB2 exigiria privilégio de
escrita que não está concedido. O MongoDB de auditoria já é provisionado e
gravável, com `pymongo` já nas dependências. Por isso o estado durável fica em
`telemetria.BACKTEST_VPN_JOBS` e o disparo fica em um `CronJob`.

**Decisão pendente do dono da fonte:** se a instituição preferir uma tabela DB2
dedicada a jobs, a abstração `JobStore` já isola isso — basta implementar a
interface. O checklist da seção 14 traz o que precisa ser confirmado.

**Migração e rollback.** Não há migração de esquema. A coleção é criada na
primeira escrita, com índices em `(state, lease_expires_at)`,
`(trigger, created_at)` e `finished_at`. Para reverter, basta
`BACKTEST_SCHEDULE_ENABLED=false` ou suspender o CronJob; nada é apagado.

## 6. Decisão sobre arquitetura de comandos

**Adotada.** Justificativa: havia três pontos de entrada com risco real de
divergência (rota HTTP, CLI e, novo, agendamento). Os comandos são *dataclasses*
imutáveis validadas na construção; os handlers dependem só de interfaces
(relógio, repositório de jobs, reserva/lease, pipeline, gerador de relatórios,
publicador, reporter de progresso).

Comandos: `RunInitialBacktestCommand`, `RunScheduledBacktestCommand`,
`RunManualBacktestCommand`, `ResumeOrRetryBacktestCommand`,
`GenerateBacktestReportsCommand`, `PublishBacktestResultCommand`.

Responsabilidades que mudaram de lugar:

* orquestração de execução saiu do CLI e do runner HTTP para `ExecuteBacktestHandler`;
* geração de relatórios saiu do CLI para `GenerateReportsHandler`;
* publicação saiu do runner para `PublishResultHandler` + `publication.py`;
* leitura de ambiente ficou concentrada em `runtime.py`.

**Não** foi introduzido framework de CQRS. A separação é apenas comando
(execução/escrita) versus consultas de status, que leem o mesmo estado durável.

## 7. Decisão sobre concorrência

**Implementada como concorrência limitada e opcional, desligada por padrão.**

Evidência que sustenta a decisão:

* a avaliação de regras é CPU-bound em estruturas Python puras; com o GIL do
  CPython, threads não aumentam a vazão desse trecho;
* o driver `ibm_db` não documenta segurança de thread para uma mesma conexão, e
  o limite do pool DB2 do ambiente não é conhecido fora da rede interna;
* a geração de relatórios é I/O com escritores independentes e pode paralelizar
  com segurança, mas o ganho é pequeno frente ao custo de log menos linear.

Modelo: `backtest_vpn/concurrency.run_bounded`, com no máximo `max_workers`
tarefas em voo (backpressure), resultado **na ordem de submissão**, cancelamento
cooperativo e propagação da primeira exceção. Nada mutável é compartilhado:
cada tarefa de regra recebe a lista de eventos apenas para leitura e devolve
lista nova; cada escritor de relatório possui o seu arquivo.

Configuração e orientação de dimensionamento:

| Variável | Padrão | Orientação |
| --- | --- | --- |
| `BACKTEST_RULE_WORKERS` | `1` | Só aumente se a medição interna mostrar ganho; o GIL limita o benefício. |
| `BACKTEST_REPORT_WORKERS` | `1` | Até `3` (um por formato) é seguro. |
| `BACKTEST_DB2_POOL_LIMIT` | `1` | Nunca configure acima do limite real de conexões concedido ao usuário DB2. |

Há teste provando que 1 worker e N workers produzem conteúdo idêntico. Mudar a
concorrência muda o hash de configuração e, portanto, a identidade lógica da
execução — isso é intencional e rastreável.

Concorrência de threads **não** substitui coordenação entre pods.

As otimizações de 2.3.0 são algorítmicas, não aumento cego de threads: R7–R9
usam janelas deslizantes O(n) amortizadas, R5 indexa timestamps por usuário e
usa busca binária, e R6 consulta lotes limitados. R5 percorre todos os usuários;
`MTA_MAX_USERS` é tamanho de rodada, não corte do universo.

## 8. Fases de progresso, campos de log e ETA

### Fases

| Fase | Significado | Unidades |
| --- | --- | --- |
| `ENFILEIRADO` | Na fila do estado compartilhado | — |
| `RESERVADO` | Lease adquirido por um processador | 1 |
| `VALIDANDO_CONFIGURACAO` | Período, regras e parâmetros | 1 |
| `CONECTANDO_FONTE` | Abertura de conexão somente leitura | 1 |
| `VALIDANDO_ESQUEMA` | Colunas exigidas na fonte | 1 |
| `CONSULTANDO_EVENTOS` | Leitura das linhas do período | linhas (indeterminado até o total ser conhecido) |
| `NORMALIZANDO_EVENTOS` | Normalização e deduplicação | linhas |
| `AVALIANDO_REGRAS` | Regras de evento selecionadas | regras |
| `CORRELACIONANDO_OPENAM` | R5 e R6 | 2 |
| `CONSOLIDANDO_OCORRENCIAS` | Consolidação e evidências | casos |
| `MONTANDO_MODELO_RELATORIO` | Modelo normalizado | 1 |
| `GERANDO_LATEX` / `GERANDO_XLSX` / `GERANDO_CSV` | Formatos | 1 cada |
| `VALIDANDO_SAIDA` | Integridade dos arquivos | 1 |
| `PUBLICANDO_RESULTADO` | Troca atômica | 1 |
| `CONCLUIDO` / `FALHOU` / `CANCELADO` | Terminal | — |

O percentual global é ponderado por fase (soma 100) e **nunca** chega a 100%
antes de a publicação concluir. Fase sem total conhecido é publicada como
indeterminada, com o rótulo “em andamento, total ainda não conhecido”, em vez de
um percentual enganoso.

### Dicionário dos campos de log estruturado

Cada linha é `backtest_progress <json>` no logger `backtest_vpn.runtime`.

| Campo | Descrição |
| --- | --- |
| `updated_at`, `started_at`, `timezone` | Horários no fuso configurado |
| `application_version`, `worker` | Versão e identidade do pod/PID |
| `job_id`, `attempt`, `trigger` | Identidade e origem da execução |
| `config_hash` | Primeiros 16 caracteres do hash de configuração |
| `period_start`, `period_end_inclusive`, `total_calendar_days`, `data_cutoff` | Período e corte |
| `rules` | Regras selecionadas |
| `phase`, `phase_label`, `subphase` | Fase e subfase |
| `indeterminate`, `indeterminate_label` | Fase sem total conhecido |
| `completed_units`, `total_units`, `phase_percent`, `overall_percent` | Progresso |
| `elapsed_seconds` | Tempo transcorrido (relógio injetado) |
| `eta_seconds_remaining`, `eta_method`, `eta_is_estimate`, `eta_samples`, `eta_throughput_per_second`, `eta_suppressed_reason` | Estimativa e por que ela está ausente |
| `current_rule`, `current_partition` | Onde a execução está |
| `counters` | `input_rows`, `duplicate_rows`, `invalid_*_rows`, `deduplicated_events`, `distinct_valid_users`, `distinct_valid_devices`, `excluded_user_events`, `database_rows_read`, `expected_database_rows` |
| `occurrences_by_rule`, `occurrences_by_severity` | Achados acumulados |
| `worker_limits` | Concorrência efetiva |
| `message` | Mensagem curta em português |

Exemplo, sem qualquer dado sensível:

```json
{"application_version":"2.3.0","attempt":1,"completed_units":4,
 "config_hash":"f010a925dc8bb194","counters":{"database_rows_read":1240,
 "deduplicated_events":1198,"duplicate_rows":42},"current_rule":"R4",
 "data_cutoff":"2026-07-30 00:00:00","elapsed_seconds":37,
 "eta_is_estimate":true,"eta_method":"vazão suavizada (EWMA) da fase",
 "eta_samples":4,"eta_seconds_remaining":26,"indeterminate":false,
 "job_id":"bt-…","overall_percent":58.4,"phase":"AVALIANDO_REGRAS",
 "period_end_inclusive":"2026-07-29","period_start":"2026-06-27",
 "timezone":"America/Sao_Paulo","total_calendar_days":33,"total_units":7,
 "trigger":"scheduled","worker":"pod-abc#12"}
```

Nenhuma linha de evidência, parâmetro SQL, credencial ou dado de autenticação é
registrado. Caracteres de controle e quebras de linha são removidos de qualquer
texto derivado de dados, impedindo injeção de log.

### Método do ETA

Média exponencial (EWMA, α = 0,3) da vazão de unidades **dentro da fase
corrente**. A estimativa só é publicada com pelo menos 3 amostras e 5% de
progresso da fase. É zerada a cada troca de fase, suprimida em fase
indeterminada, e limitada a 30 dias. Valores negativos, `NaN`, infinitos ou
obsoletos nunca são exibidos. O rótulo sempre diz “estimativa”. Nos testes o
relógio é injetado (`FixedClock`), portanto nada depende do relógio de parede.

### Throttling

Logs de rotina são limitados a 1 a cada 15 s ou 5 pontos percentuais. Fronteiras
de fase, mudança de total, marcos materiais, falha e cancelamento são **sempre**
registrados.

## 9. Status e controle de acesso

| Rota | Método | Autorização | Conteúdo |
| --- | --- | --- | --- |
| `/backtest/executar` | GET/POST | allow-list de matrícula | Formulário e submissão |
| `/backtest/executar/{job_id}` | GET | allow-list | Painel de progresso |
| `/backtest/executar/{job_id}/status` | GET | allow-list (401/403 em JSON) | Fase, unidades, ETA, tentativa, heartbeat |
| `/backtest/status` | GET | allow-list | Ciclo, agendamento, execuções recentes |
| `/backtest/reports` | GET | allow-list | Índice do pacote publicado |
| `/backtest/reports/{arquivo}` | GET | allow-list | Download do arquivo publicado |
| `/health/live`, `/healthz`, `/health` | GET | pública | Apenas vivacidade do processo |
| `/health/ready` | GET | pública | Prontidão web + estado textual do dataset |

`job_id` aceita apenas `bt-<40 hex>` (camada de comandos) ou `<32 hex>`
(subprocesso local). Nome de arquivo de relatório aceita apenas a allowlist
derivada do ponteiro de publicação, ou os quatro nomes fixos de trabalho, e
nunca symlink. O painel encerra o *polling* ao receber 401/403 em vez de
insistir.

## 10. Modelo de relatório, publicação e pacote CSV

Um único modelo normalizado (`report_model.build_report_model`) alimenta LaTeX,
XLSX e CSV, portanto totais e classificações não podem divergir.

Publicação:

```
<reports>/.staging/<job_id>-<fence>/    → escrita
<reports>/published/<job_id>/           → promoção por os.replace (atômica)
<reports>/published/latest.json         → ponteiro (ponto de commit)
```

Arquivos por execução:

```
backtesting_dossier.tex
backtesting_dossier.pdf            (compilado por generate_reports.sh)
backtesting_dossier.xlsx
backtesting_report_model.json
detalhamento_csv/evidencias_por_ocorrencia.csv
detalhamento_csv/r1_sequencia_de_ips.csv
detalhamento_csv/r4_logins_vpn_por_dia.csv
detalhamento_csv/r7_uso_de_dispositivo_por_usuario.csv
detalhamento_csv/cronologia_consolidada.csv
detalhamento_csv/dicionario_de_dados.csv
detalhamento_csv/manifest.json
```

Pacote CSV: UTF-8 sem BOM (BOM opcional via `BACKTEST_CSV_BOM`), delimitador
`,`, fim de linha `\n`, ausente = `Não informado`, política antifórmula igual à
do XLSX, divisão determinística em `_parteNNN` acima de 500 000 linhas.
O manifesto traz finalidade, esquema, versão de esquema, contagem de linhas,
SHA-256, `report_id`, `job_id` e o link relativo de cada arquivo.
`csvpackage.verify_package` revalida tudo — inclusive **depois de mover o pacote
para outra máquina**, porque os links são relativos.

Retenção: `BACKTEST_REPORTS_RETENTION_KEEP` (padrão `0` = nada é removido). O
diretório apontado pelo ponteiro nunca é removido.

### Classificação visual de UOR

| Código | Rótulo | Condição |
| --- | --- | --- |
| `YELLOW_UOR_20259` | `ALERTA AMARELO — UOR 20259` | UOR válida normalizada exatamente `20259` |
| `RED_OTHER_UOR` | `ALERTA VERMELHO — UOR diferente de 20259` | UOR válida diferente de `20259` |
| `GRAY_UNKNOWN_UOR` | `UOR NÃO INFORMADA OU NÃO DETERMINADA` | Nula, vazia, malformada, indisponível, conflitante ou não determinada |

Normaliza espaços e zeros à esquerda, aceita numérico e texto, e nunca inventa
UOR. Dado ausente ou inválido é **sempre cinza, nunca vermelho**. É uma
classificação organizacional e não altera a severidade da anomalia. No PDF o
selo combina cor **e rótulo textual** (mais um sufixo A/V/N), garantindo leitura
em tons de cinza; no XLSX há coluna dedicada `Alerta UOR` com estilo direto que
sobrevive a salvar e reabrir, sem sobrescrever a formatação de severidade.

## 11. Requisitos e variáveis de ambiente

### Requisitos

- Python 3.11 ou superior.
- `uv` compatível com o `uv.lock` corporativo, ou ambiente Python com as
  dependências de `pyproject.toml`.
- DB2 client/driver compatível com `ibm-db`.
- Base de fusos IANA do sistema (`tzdata`) para `America/Sao_Paulo`, inclusive
  datas históricas com horário de verão.
- `pdflatex` com: `babel` (português), `inputenc`, `fontenc`, `lmodern`,
  `geometry`, `xcolor`, `booktabs`, `longtable`, `array`, `tabularx`,
  `pdflscape`, `fancyhdr`, `hyperref` e `enumitem`.
- MongoDB gravável para o estado compartilhado de jobs (mesma instância da
  auditoria).
- Acesso somente leitura às tabelas DB2 configuradas.
- Sidecar Curio para enriquecimento organizacional, se autorizado.
- Kafka, MongoDB e OAuth/SSO para executar a aplicação completa.

Em Debian/Ubuntu, base típica para LaTeX:

```sh
sudo apt-get install tzdata texlive-latex-base texlive-latex-recommended \
    texlive-latex-extra texlive-lang-portuguese lmodern
```

Dependências Python, sem segredos:

```sh
uv sync --frozen
```

### Variáveis de ambiente (nomes, sem valores)

Fonte de dados e regras:
`DB2_JDBC_URL`, `DB2_SCHEMA`, `DB2_TABLE`, `DB2_USERNAME`, `DB2_PASSWORD`,
`DB2_CREDENTIALS_FILE`, `VPN_USER_COLUMN`, `VPN_TIMESTAMP_COLUMN`,
`VPN_SOURCE_IP_COLUMN`, `VPN_CORPORATE_IP_COLUMN`, `VPN_HOSTNAME_COLUMN`,
`VPN_DEVICE_COLUMN`, `BACKTEST_RULES_CONFIG`, `BACKTEST_ENABLED_RULES`,
`MTA_SCHEMA`, `MTA_TABLE`, `MTA_DECISION_NODES`, `MTA_DELTA_MINUTES`,
`MTA_MAX_USERS`, `MTA_USERS_PER_BATCH`, `MTA_FETCH_FIRST_ROWS`,
`MTA_CHUNK_HOURS`,
`PHYSICAL_IP_CIDRS`, `DB2_FETCH_RETRY_ATTEMPTS`,
`DB2_FETCH_RETRY_DELAY_SECONDS`.

Ciclo contínuo (novas nesta versão):
`BACKTEST_TIMEZONE`, `BACKTEST_WINDOW_DAYS`, `BACKTEST_SCHEDULE_ENABLED`,
`BACKTEST_SCHEDULE_INTERVAL_HOURS`, `BACKTEST_SCHEDULE_CUTOFF_TIME`,
`BACKTEST_SCHEDULE_CUTOFF_MODE`, `BACKTEST_SCHEDULE_CATCH_UP`,
`BACKTEST_RUN_INITIAL_ON_STARTUP`, `BACKTEST_LEASE_SECONDS`,
`BACKTEST_MAX_ATTEMPTS`, `BACKTEST_RETRY_BASE_SECONDS`,
`BACKTEST_RETRY_MAX_SECONDS`, `BACKTEST_REQUIRE_CLUSTER_STORE`,
`BACKTEST_RULE_WORKERS`, `BACKTEST_REPORT_WORKERS`, `BACKTEST_DB2_POOL_LIMIT`,
`BACKTEST_REPORT_FORMATS`, `BACKTEST_CSV_BOM`,
`BACKTEST_REPORTS_RETENTION_KEEP`, `BACKTEST_VPN_REPORTS_DIR`.

Aplicação e segurança:
`OAUTH2_CLIENT_ID`, `OAUTH2_CLIENT_SECRET`, `OAUTH2_ISSUER_BASE_URL`,
`OAUTH2_REDIRECT_URI`,
`SESSION_SECRET`, `SESSION_COOKIE_SECURE`, `MATRICULA_HMAC_KEY` ou
`MATRICULA_HMAC_KEY_FILE`,
`ALLOWED_MATRICULA_DIGESTS` ou `ALLOWED_MATRICULA_DIGESTS_FILE`,
`STREAMLIT_BASE_URL_PATH`, `PUBLIC_BASE_URL`, `SSL_CA_BUNDLE`,
`CURIO_BASE_URL`, `MONGODB_AUDIT_URI`, e as variáveis Kafka do README.

`PUBLIC_BASE_URL` é obrigatória fora de localhost e deve ser HTTPS. A aplicação
não constrói callback OAuth nem URL do Streamlit a partir de `Host` ou
`X-Forwarded-Host`, evitando envenenamento de cabeçalho.

`SUSPECT_MATRICULAS` contém, quando formalmente autorizado, uma lista externa
separada por vírgula/espaço que substitui a allowlist histórica incorporada.
Arquivos de segredo, identificadores e artefatos históricos também foram
restaurados por instrução explícita do proprietário; scanners podem exigir
exceção formal para esse conteúdo.

`SSL_CA_BUNDLE` deve ser omitida para usar a cadeia padrão ou apontar para um
arquivo CA confiável. Valores falsos como `false`, `0` e `no` encerram a
inicialização: desabilitar validação TLS não é suportado.

Não coloque credenciais no JSON de regras. Copie
`config/backtest_rules.example.json` para um arquivo local não versionado
(`config/backtest_rules.local.json`, já em `.gitignore`) e preencha somente
allowlists e CIDRs formalmente aprovados.

## 12. Comandos

### Testes, lint, tipos e build

```sh
uv run pytest
uv run flake8 .
uv run bandit -r app.py acr_controle_acesso_dashboard backtest_vpn
uv run python -m compileall app.py acr_controle_acesso_dashboard backtest_vpn
uv build            # build de distribuição, sem iniciar nada
```

### Geração de relatórios com fixture sintética

```sh
uv run python -m backtest_vpn.cli generate-reports \
    --safe-fixture --output-dir /tmp/backtesting-fixture
uv run python -c 'from openpyxl import load_workbook; \
    load_workbook("/tmp/backtesting-fixture/backtesting_dossier.xlsx").close()'
uv run python -c 'from backtest_vpn.csvpackage import verify_package; \
    print(verify_package("/tmp/backtesting-fixture") or "pacote CSV íntegro")'
pdflatex -halt-on-error -interaction=nonstopmode \
    -output-directory /tmp/backtesting-fixture \
    /tmp/backtesting-fixture/backtesting_dossier.tex
```

### Aplicação

```sh
./setup_env.sh      # preparar ambiente
./run.sh            # iniciar (somente na máquina autorizada)
```

### Backtest manual parametrizado

```sh
uv run backtest-vpn full \
  --start "2026-06-27 00:00:00" \
  --end   "2026-07-30 00:00:00" \
  --rules-config config/backtest_rules.local.json \
  --rules R1,R2,R3,R4,R5,R6,R7,R8,R9 \
  --output-dir reports
```

Na interface as duas datas são inclusivas; internamente a data final vira
meia-noite do dia seguinte.

### Execução inicial, automática, worker e status

```sh
# Enfileira (idempotente) e executa o backtest padrão de 33 dias
uv run backtest-vpn run-initial

# Apenas enfileira; a execução fica para o worker
uv run backtest-vpn run-initial --enqueue-only

# Avalia a política de 24 h e executa a janela devida, se houver
uv run backtest-vpn run-scheduled

# Força a janela devida, ignorando a marca d'água
uv run backtest-vpn run-scheduled --force

# Worker: reserva e executa jobs pendentes
uv run backtest-vpn worker --once           # um job e encerra
uv run backtest-vpn worker --drain          # até a fila esvaziar
uv run backtest-vpn worker --poll-seconds 30

# Executa um job específico já enfileirado (usado pela rota HTTP)
uv run backtest-vpn run-job --job-id bt-<40hex>

# Status, sempre lido do estado compartilhado
uv run backtest-vpn job-status --limit 10
uv run backtest-vpn job-status --job-id bt-<40hex>
uv run backtest-vpn schedule-status
```

Todos os subcomandos aceitam `--fixture` para exercitar o fluxo completo com
dados sintéticos, sem qualquer acesso a banco.

### Dossiê completo com PDF

```sh
./generate_reports.sh --bundle reports/results_bundle_AAAAMMDD_HHMMSS.json

./generate_reports.sh \
  --start 2026-06-27 --end 2026-07-29 \
  --rules R1,R2,R3,R4,R5,R6,R7,R8,R9 \
  --config config/backtest_rules.local.json

./generate_reports.sh \
  --bundle reports/results_bundle_AAAAMMDD_HHMMSS.json \
  --employee-data /caminho/seguro/dados_funcionais.json
```

Downloads autenticados: `/backtest/reports/backtesting_dossier.pdf`,
`/backtest/reports/backtesting_dossier.xlsx`,
`/backtest/reports/backtesting_report_model.json`,
`/backtest/reports/detalhamento_csv/<arquivo>.csv` e o índice
`/backtest/reports`.

### Implantação (executar depois, por operador autorizado)

```sh
# 1. Mesclar deploy/values-backtest.patch.yaml no values.yaml do chart e
#    implantar pelo pipeline vigente.
# 2. Substituir REGISTRO/…:TAG e a URL JDBC, revisar e então:
oc apply -f deploy/backtest-scheduler-cronjob.yaml
# 3. Conferir a decisão do agendador sem executar nada:
oc exec deploy/acr-controle-acesso-dashboard -- \
    /app/scripts/backtest-vpn schedule-status
```

## 13. Solução de problemas

| Sintoma | Diagnóstico e ação |
| --- | --- |
| Primeira execução demora | Esperado. `/backtest/executar` e `/health/ready` informam “preparando o conjunto de dados inicial”. Confirme que o `Job`/`CronJob` de `deploy/` está aplicado; sem worker o job fica em `QUEUED`. |
| DB2 indisponível | O job vai para `FAILED_RETRYABLE` com backoff; o último resultado publicado continua servido, com a data da última atualização bem-sucedida. `backtest-vpn job-status --job-id …` mostra `error_summary`. |
| Job parece travado | Compare `heartbeat_at` com `lease_expires_at`. Após a expiração, outro pod reserva automaticamente e `attempt` incrementa. |
| Lease expirado repetidamente | Aumente `BACKTEST_LEASE_SECONDS` ou reduza o volume por execução; verifique o tempo real das consultas R5/MTA. |
| Disparo duplicado | Esperado e inofensivo: a chave de idempotência absorve e a reserva atômica garante um único efeito. Confira `created=False` no log `backtest_job_enqueued`. |
| `BACKTEST_REQUIRE_CLUSTER_STORE` falhando | `MONGODB_AUDIT_URI` ausente ou MongoDB inacessível. É falha proposital: sem estado compartilhado não há garantia de efeito único entre pods. |
| Status `404` no painel | `job_id` fora do formato aceito, ou job removido do estado compartilhado. |
| ETA ausente ou “indisponível” | Correto por projeto: faltam amostras, o progresso da fase é menor que 5% ou a fase é indeterminada. O motivo aparece em `eta_suppressed_reason`. |
| ETA parece impreciso | É estimativa por vazão da fase e é reiniciada a cada troca de fase; fases muito heterogêneas produzem variação. |
| PDF falha | O script imprime as últimas 40 linhas do `.log`. Rode `pdflatex` manualmente no `.tex` para diagnóstico. |
| XLSX enorme | Reduza o período ou desative o XLSX (`BACKTEST_REPORT_FORMATS=tex,csv`); o detalhamento completo permanece no pacote CSV. |
| Pacote CSV inconsistente após mover | Rode `verify_package`; SHA-256 e contagem de linhas apontam o arquivo divergente. |
| UOR cinza | Confirme cobertura e autorização dos dados funcionais. Valor ausente ou malformado nunca é vermelho. |
| Bundle legado | Gere um novo backtest; bundles versão 1 são preservados mas rejeitados pelos geradores atuais. |
| Vários pods, comportamento estranho | Confirme `store_cluster_safe: true` em `/backtest/status`. Se estiver `false`, a aplicação caiu para estado em memória e **não** coordena pods. |

## 14. Checklist obrigatório na máquina da rede interna

Estes itens **não** podem ser verificados fora da rede interna:

1. Conectividade e esquema real do DB2; existência das seis colunas de
   `AUT_CPTV` e das colunas de `MTA_AUT_CLI_TRAN`.
2. Semântica operacional de refresh, retry, heartbeat e reconexão na fonte
   (**decisão pendente do dono da fonte** para R4).
3. Estabilidade e ciclo de vida de `CD_IDFC_DSVO` (**decisão pendente** para R3,
   R7, R8 e para a regra candidata de identificador reutilizado).
4. Conteúdo formal das allowlists: estações compartilhadas, quiosques, salas de
   treinamento, terminais de serviço, contas de teste/serviço, dispositivos de
   unidade, CIDRs corporativos e de VPN.
5. Se o MongoDB de auditoria pode receber a coleção `BACKTEST_VPN_JOBS`, ou se
   a instituição exige tabela DB2 dedicada (com privilégio de escrita).
6. Se o horário de corte `01:30` local e o modo `completed_day` atendem à
   política; caso contrário, ajuste e registre a decisão.
7. Limite real de conexões do usuário DB2, para dimensionar
   `BACKTEST_DB2_POOL_LIMIT` e os workers.
8. Volume e desempenho reais de 33 dias, para calibrar
   `BACKTEST_LEASE_SECONDS` e `activeDeadlineSeconds` do CronJob.
9. Autenticação SSO real e a allow-list de matrículas em vigor.
10. Cobertura do Curio para os campos organizacionais.
11. Presença de `pdflatex` e dos pacotes LaTeX na imagem de execução.
12. Validação estática dos manifestos Kubernetes com as ferramentas do
    ambiente (`oc apply --dry-run=server`, `kubeconform` ou equivalente).
13. Checkmarx com o preset corporativo e SonarQube com o quality profile/gate
    vigentes. Esta máquina não possuía os dois scanners; consulte
    `docs/security_static_analysis.md`.
14. Plano `EXPLAIN`, ASUTIME e completude de R5 para calibrar
    `MTA_USERS_PER_BATCH`, `MTA_CHUNK_HOURS` e `MTA_FETCH_FIRST_ROWS`.
15. Secret scan do histórico e rotação de qualquer material que tenha sido
    versionado no passado. Remover o arquivo atual não apaga o histórico.

Nenhum relatório gerado com fixture sintética deve ser apresentado como
relatório interno real.

## 15. Riscos, limitações e reversão

* **Estado em memória silencioso.** Se `MONGODB_AUDIT_URI` não estiver
  configurada e `BACKTEST_REQUIRE_CLUSTER_STORE` estiver desligado, a aplicação
  usa estado em memória, que não coordena pods. Mitigação: manter
  `BACKTEST_REQUIRE_CLUSTER_STORE=true` em produção e observar
  `store_cluster_safe` em `/backtest/status`.
* **Sem volume compartilhado.** `persistenceVolume` está desabilitado no chart,
  portanto os artefatos publicados ficam no filesystem do pod que executou. O
  download funciona no pod que publicou. Recomendação: executar a geração no
  `CronJob` e, se o download de qualquer pod for requisito, habilitar um volume
  compartilhado ou publicar em armazenamento de objetos. **Decisão pendente.**
* **Ausência de alerta não é ausência de comportamento.** Toda regra é limitada
  pelos campos realmente disponíveis.
* **R4 e refresh/retry.** Sem semântica de sessão na fonte, apenas linhas
  exatamente idênticas são deduplicadas.
* **R5 não prova simultaneidade.** É correlação temporal.
* **R5 e aproximação por PK.** O bracketing é necessário porque a fonte
  conhecida não oferece índice temporal utilizável dentro do ASUTIME. Validar
  precisão e plano na máquina interna. Atingir o teto MTA agora falha sem
  publicar parcial.
* **R7 não determina concorrência.** Sem início e fim de sessão.
* **Scanners.** Não existe garantia defensável de zero finding até Checkmarx e
  SonarQube corporativos concluírem com sucesso; a configuração de CI foi
  reabilitada para tornar esse resultado obrigatório e visível.
* **Reversão.** `BACKTEST_SCHEDULE_ENABLED=false` ou suspender o CronJob
  desliga o ciclo sem apagar nada. Voltar à versão anterior da imagem é seguro:
  não há migração de esquema e os bundles continuam legíveis. Publicações
  antigas permanecem em `published/<job_id>/` porque a retenção automática vem
  desativada.

## 16. Validação offline desta entrega

Somente fixtures sintéticas foram usadas. Nenhuma consulta ao DB2, MongoDB,
Kafka, OAuth2, diretório de empregados, cluster ou dado interno foi realizada.

Executado com sucesso:

```text
PYTHONPATH=. pytest -q <11 módulos focados de backtest/IP>
410 passed, 13 skipped in 1.17s

/usr/bin/python3 <stub somente para import de ibm_db> test_backtest_r5_r6.py
7 passed in 0.03s

python3 -m py_compile app.py setup.py <fontes Python>
sucesso

git diff --check
sucesso

PyYAML/JSON parse de todos os descritores encontrados
8 YAML e 11 JSON válidos

sh -n e bash -n nos scripts principais
sucesso

uv lock --check --offline
78 pacotes resolvidos; lock consistente sem acesso à rede

gerador LaTeX chamado diretamente com fixture sintética; pdflatex duas vezes
PDF não vazio e compilação bem-sucedida
```

O teste completo `PYTHONPATH=. pytest -q` foi tentado e interrompeu a coleta
com `12 errors` e `1 skipped`: o ambiente não contém `itsdangerous`, `pymongo`,
`plotly` e `confluent_kafka`. O módulo `ibm_db` também não está instalado; os
sete testes R5/R6 foram executados com um módulo vazio injetado apenas para
permitir que os doubles dos testes substituíssem a API. `openpyxl` não está
disponível, portanto os 13 testes que inspecionam XLSX foram pulados. Não houve
instalação ou download para contornar essas ausências.

Não estavam instalados `flake8`, `bandit`, `ruff`, `mypy`, `sonar-scanner`,
cliente Checkmarx, `shellcheck`, `hadolint`, `yamllint` ou `kubeconform`.
Consequentemente, não existe declaração de quality gate Sonar ou scan
Checkmarx aprovado nesta máquina. O teste CSRF novo foi compilado, mas seu
módulo não pôde ser coletado devido à ausência de `itsdangerous`; deve ser
executado com a instalação congelada no ambiente interno.

Por restrição do trabalho, `generate_reports.sh` não foi executado; somente o
gerador subjacente foi testado com fixture segura. Também não houve start da
aplicação, implantação, commit, push, pull, fetch, acesso à rede ou validação
contra produção/dados internos.
