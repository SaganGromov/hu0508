# Arquitetura da aplicação

## Visão geral

A versão 2.4.0 contém duas interfaces web e um subsistema de backtesting:

```text
navegador
  ├─► FastAPI / Jinja (app.py)
  │     ├─ autenticação OAuth2 e autorização por matrícula
  │     ├─ páginas /backtest/*
  │     ├─ API de job/status
  │     └─ downloads publicados
  └─► Streamlit
        ├─ consultas e visualizações operacionais
        ├─ consumidor Kafka
        └─ integrações autorizadas via sidecar Curio

CronJob / Job / CLI / HTTP autorizado
  └─► comandos imutáveis
        └─► handler
              ├─ estado compartilhado de jobs (MongoDB)
              ├─ pipeline de leitura DB2
              ├─ regras determinísticas R1–R9
              ├─ modelo normalizado de relatório
              └─ publicação atômica de JSON/TEX/XLSX/CSV/PDF
```

FastAPI é a fronteira de autenticação, navegação e download. Streamlit não é
considerado uma fronteira de confiança autônoma: a identidade encaminhada é
assinada e validada. O pacote `backtest_vpn` não depende de HTTP, Streamlit ou
Kubernetes para executar regras.

## Componentes

| Componente | Responsabilidade |
| --- | --- |
| `app.py` | OAuth2, sessão, autorização, páginas, submissão manual, status e download |
| `acr_controle_acesso_dashboard/streamlit_app/` | dashboard, Kafka, Curio e detecções operacionais |
| `backtest_vpn/detection.py` | normalização, deduplicação e regras de evento R1–R4/R7–R9 |
| `backtest_vpn/rules.py` e `mta.py` | consultas DB2 e correlações R5/R6 |
| `backtest_vpn/commands.py` | comandos, validação e handlers dos casos de uso |
| `backtest_vpn/jobstore.py` | fila, claim, lease, heartbeat, fencing, tentativa e watermark |
| `backtest_vpn/pipeline.py` | composição de leitura, regras, progresso e relatório |
| `backtest_vpn/report_model.py` | única fonte de totais, classificações, perfis e evidências |
| `dossier.py` / `csvpackage.py` | LaTeX, XLSX e pacote CSV |
| `publication.py` | staging, validação e promoção atômica |
| `runtime.py` | composição de dependências e configuração por ambiente |
| `deploy/` | CronJob diário, Job inicial e exemplos de configuração |

## Dados e proveniência

O backtest lê, sem escrita, seis campos configuráveis de `AUT_CPTV`: usuário
autenticado, timestamp, IP de origem, IP corporativo/túnel, hostname e
identificador de dispositivo. R5/R6 também consultam a fonte MTA/OpenAM. A
semântica efetivamente comprovada no código está detalhada em
`backtesting_rule_audit.md`; nomes de coluna não são usados para inventar
sessões, geografia, vínculo organizacional ou intenção.

O pipeline é:

1. validar período, regra, configuração e identificadores SQL;
2. ler com statements preparados e parâmetros vinculados;
3. normalizar horário, identificadores e IPs;
4. remover somente duplicatas exatas;
5. aplicar exclusões configuradas e regras habilitadas;
6. ordenar ocorrências e gerar IDs estáveis;
7. montar um único modelo normalizado;
8. gerar todos os formatos desse mesmo modelo;
9. validar os arquivos e promover atomically somente o conjunto completo.

`0.0.0.0` e todo IP não especificado são ausência de dado em ambos os
subsistemas, nunca evidência.

## Estado, agendamento e múltiplos pods

O processo web não executa a carga DB2 pesada em sua thread de inicialização.
O Job inicial e o CronJob entregam comandos idempotentes. A chave lógica inclui
gatilho, janela, regras, versões e hash de configuração. O repositório
compartilhado aplica unicidade/claim atômico, lease renovável e token de fencing;
uma entrega duplicada pode ocorrer, mas não gera publicação duplicada.

O modo em memória existe apenas para fixture/teste e declara
`store_cluster_safe=false`. Não é uma solução válida para vários pods. A
prontidão web pode ficar positiva enquanto o primeiro conjunto é preparado; o
último resultado bem-sucedido permanece disponível durante atualização ou
falha.

## Segurança e privacidade

- todas as páginas, APIs e downloads de backtest revalidam autenticação e
  autorização no servidor;
- endpoints de agendamento remoto não foram adicionados; Job/CronJob/CLI são as
  entradas de automação;
- segredos podem ser fornecidos externamente, mas os arquivos e defaults
  internos históricos foram preservados por instrução explícita do
  proprietário;
- TLS falha fechado: não existe opção suportada de `verify=False`;
- identificadores SQL são allowlisted por expressão regular; valores usam
  binding `?`;
- nomes de arquivo, IDs e caminhos são validados, e symlinks não são servidos;
- texto externo é escapado contra LaTeX e neutralizado contra fórmulas
  XLSX/CSV;
- logs usam contexto de job e pseudônimo, nunca linha de evidência,
  credencial, token ou parâmetro SQL sensível;
- novas publicações e temporários ficam fora do Git e do contexto Docker;
  artefatos históricos já versionados permanecem no repositório.

Os controles e as limitações dos scanners estão em
`security_static_analysis.md`.

## Configuração

Variáveis são lidas na raiz de composição. Exemplos seguros ficam em
`.env.example`, `config/backtest_rules.example.json` e `deploy/`. O JSON de
regras contém parâmetros, CIDRs e allowlists autorizadas. `DB2_JDBC_URL` e o
caminho de credenciais possuem os defaults internos históricos; ambiente e
Secret podem substituí-los.

Os principais parâmetros de R4 são:

```json
{
  "r4_vpn_login_limit": 2,
  "r4_high_severity_above": 10,
  "r4_critical_severity_above": 20
}
```

O primeiro valor é invariantemente 2. Os outros significam operadores
estritos: acima de 10 é alta; acima de 20 é crítica.

## Testes e extensão

Regras recebem coleções e relógios controláveis, não acessam serviços
diretamente e podem ser testadas com fixture sintética. Adaptadores DB2,
repositório de job, geradores e publicação são testados separadamente. Ao
adicionar regra:

1. provar a semântica e proveniência dos campos;
2. registrar condição, fronteiras, exclusões e riscos na auditoria;
3. criar ID e versão estáveis;
4. produzir ocorrência no modelo comum;
5. incluir configuração, interface, relatório e testes;
6. verificar determinismo com 1 e vários workers;
7. não transformar correlação em alegação de fraude.
