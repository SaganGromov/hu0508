# Changelog

Todas as mudanças notáveis serão documentadas neste arquivo.

O formato é baseado em [Keep a Changelog](http://keepachangelog.com/pt-BR/1.0.0/) e este projeto adere ao padrão [Semantic Versioning](http://semver.org/lang/pt-BR/spec/v2.0.0.html).

- [Não liberado]
- Adicionado
- Corrigido
- Modificado
- Obsoleto
- Removido

## [2.4.0](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.4.0) - 2026-07-30

### Adicionado

- Barra de progresso acessível e texto em linguagem comum para toda execução
  manual, agendada ou inicial pós-implantação, visíveis desde a fila.
- Duração e previsão aproximadas em formato humano; métricas e logs técnicos
  ficam recolhidos por padrão, mas continuam disponíveis para diagnóstico.

### Modificado

- HTML, TeX/PDF, XLSX, CSV e o modelo JSON de apresentação exibem no máximo as
  10 ocorrências mais prioritárias de cada regra. Totais executivos continuam
  abrangendo a execução completa, e o bundle-fonte permanece integral.
- Achados Bandit revisados recebem supressões locais por regra e justificativa
  de ameaça; o executável `git` de proveniência deixou de ser resolvido por
  `PATH`.

### Corrigido

- Jobs recém-enfileirados, incluindo a primeira análise após o deploy, passam a
  ter snapshot de progresso imediatamente, antes de um worker assumir o pedido.
- A página de execução não levanta mais `UndefinedError: 'progress' is
  undefined` ao ler jobs criados por versões anteriores ou durante rollout
  misto; snapshots ausentes recebem uma apresentação indeterminada segura.
- A correção 2.3.2 do `/dashboard` permanece incorporada: a URL do iframe é
  relativa e não depende de `PUBLIC_BASE_URL` em ambientes não locais.

## [2.3.2](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.3.2) - 2026-07-30

### Corrigido

- O iframe same-origin do `/dashboard` usa sempre `/streamlit` fora do
  desenvolvimento local, restaurando compatibilidade com deployments sem
  `PUBLIC_BASE_URL` ou com valor legado HTTP, sem derivar a origem de `Host` ou
  `X-Forwarded-*`.
- O cookie de autenticação do Streamlit segue exatamente a política explícita
  `SESSION_COOKIE_SECURE` da sessão FastAPI; cabeçalhos de proxy enviados pelo
  cliente não alteram esse atributo.

## [2.3.1](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.3.1) - 2026-07-30

### Corrigido

- `/dashboard` passa a emitir o cookie autenticado do Streamlit e o nonce CSRF
  renderizado no iframe a partir do mesmo token, evitando rejeição na fronteira
  FastAPI → Streamlit após o login.
- A configuração de homologação é documentada em fragmento Helm local com
  `PUBLIC_BASE_URL` e callback OAuth2 HTTPS, cookie seguro, rota `/streamlit` e
  terminação TLS. Cabeçalhos `X-Forwarded-*` fornecidos pelo cliente continuam
  sem autoridade para definir origem pública ou política de cookie.
- Falhas de configuração do bootstrap do painel recebem código operacional e
  ID de correlação sem expor URL configurada, segredo, cookie ou token.
- As asserções de invariantes do runner de subprocessos foram substituídas por
  verificações explícitas que permanecem ativas com Python otimizado.

## [2.3.0](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.3.0) - 2026-07-30

### Adicionado

- Severidade graduada e configurável de R4: 3–10 logins VPN qualificáveis no
  dia são `MÉDIA`, 11–20 são `ALTA` e 21 ou mais são `CRÍTICA`, com cores
  independentes da classificação UOR em PDF e XLSX.
- Contadores explícitos de qualidade para endereços IP não especificados e
  testes para `0.0.0.0`, `::`, `::0` e IPv6 expandido.
- Sentinela de limite nas consultas MTA: exceder
  `MTA_FETCH_FIRST_ROWS` encerra R5 sem publicar resultado parcial.

### Corrigido

- A tela em tempo real, a ingestão Kafka e a detecção de troca rápida passam a
  aplicar a mesma canonicalização do backtest: IP inválido ou não especificado
  é ausência de dado e nunca eleva uma contagem.
- R5 canonicaliza IPv4/IPv6 antes da comparação, processa todos os usuários em
  rodadas e usa busca binária por intervalo; o antigo limite deixou de truncar
  silenciosamente o universo.
- R6 usa os limites independentes de hostname e dispositivo, consulta usuários
  em lotes e falha fechada quando uma consulta não pode ser completada.
- Logs de autenticação, busca e auditoria foram minimizados e pseudonimizados.
  Arquivos, segredos, allowlists e artefatos históricos incorporados foram
  preservados/restaurados conforme instrução explícita do proprietário.
- Verificação TLS deixa de aceitar configuração permissiva, o contexto Docker
  exclui segredos/relatórios e o contêiner deixa de usar permissão `0777`.

### Modificado

- R7, R8 e R9 usam janelas deslizantes com contadores, substituindo comparações
  quadráticas e consolidando janelas qualificadas sobrepostas de modo
  determinístico.
- O destino DB2, o arquivo de credenciais e os endpoints internos históricos
  continuam disponíveis como defaults; variáveis de ambiente ainda podem
  substituí-los.
- Validações de segurança, testes e Sonar foram reabilitados no pipeline, com
  escopo de análise ampliado para a aplicação FastAPI e o motor de backtest.

## [2.2.0](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.2.0) - 2026-07-30

### Adicionado
- **Ciclo contínuo de backtesting.** Execução padrão enfileirada de forma
  idempotente na implantação e atualização automática a cada 24 h, com corte de
  dados configurável (`BACKTEST_SCHEDULE_CUTOFF_MODE`, padrão conservador
  `completed_day`), recuperação de execuções perdidas e marca d'água gravada
  somente após publicação validada.
- **Estado durável compartilhado de jobs** (`backtest_vpn/jobstore.py`) em
  MongoDB (`telemetria.BACKTEST_VPN_JOBS`), com chave de idempotência, reserva
  atômica, lease, heartbeat, retomada de lease expirado, token de fencing e
  limite de tentativas com backoff determinístico. A implementação em memória
  declara explicitamente que não coordena vários pods.
- **Camada de comandos** (`backtest_vpn/commands.py`): `RunInitial`,
  `RunScheduled`, `RunManual`, `ResumeOrRetry`, `GenerateBacktestReports` e
  `PublishBacktestResult`, com handlers que dependem apenas de interfaces.
  HTTP, CLI, worker e agendador executam o mesmo caso de uso.
- **Publicação atômica e versionada** (`backtest_vpn/publication.py`): staging
  por `job_id`+`fence`, validação de saída, promoção por `os.replace` e
  ponteiro `published/latest.json` como ponto de commit. Uma falha nunca
  sobrescreve o último resultado válido.
- **Progresso detalhado, fases nomeadas e ETA explicável**
  (`backtest_vpn/progress.py`): unidades monotônicas, fases explicitamente
  indeterminadas, ETA por vazão suavizada com amostragem mínima, log
  estruturado com throttling e sanitização contra injeção de linha.
- **Pacote de detalhamento em CSV** (`backtest_vpn/csvpackage.py`) com
  manifesto, SHA-256, contagem de linhas, dicionário de dados, divisão
  determinística, proteção antifórmula e links relativos portáveis.
- **Concorrência limitada** (`backtest_vpn/concurrency.py`), padrão 1 worker,
  com ordem de resultado igual à de submissão, backpressure e cancelamento
  cooperativo.
- Novos subcomandos: `run-initial`, `run-scheduled`, `run-job`, `worker`,
  `job-status` e `schedule-status`.
- Endpoints autenticados `/backtest/status` e `/backtest/reports` (índice), e
  download autenticado dos arquivos do pacote publicado.
- Descritores de implantação em `deploy/` (CronJob diário, Job de drenagem
  inicial e trecho de `values.yaml`).

### Modificado
- **Período padrão passa de 20 para 33 dias de calendário local inclusivos**
  (`start = data_local_atual - 32 dias`), com semântica única em interface,
  API, CLI, agendador, persistência, relatórios e testes.
- Dossiê PDF/LaTeX redesenhado com divulgação progressiva: “Como ler este
  relatório”, resumo executivo, catálogo de regras com condição exata,
  consolidações entre regras, detalhe por ocorrência, perfis, cronologia em
  paisagem, índice do pacote CSV e legendas com rótulo textual além da cor.
- Workbook XLSX ganhou as planilhas `Índice`, `Cronologia`, `Consolidações` e
  `Detalhamento CSV`, mais colunas de negócio no catálogo de regras e formato
  de data brasileiro.
- Página “Executar” e painel de acompanhamento passam a mostrar fase, unidades,
  ETA, tentativa, heartbeat e último resultado publicado, lidos do estado
  compartilhado e funcionando quando a requisição chega a outro pod.
- `/health/live` e `/health/ready` deixam de depender do backtest de forma
  intencional e documentada; a prontidão informa o preparo do dataset inicial.
- `generate_reports.sh` passa a verificar o modelo normalizado, o pacote CSV e
  o manifesto (presença, contagem de linhas e SHA-256).

### Corrigido
- Identificador de job exibido pela interface passa a ser o identificador
  durável, eliminando `404` quando a requisição de status chega a outro pod.
- Downloads de relatório passam a resolver apenas nomes presentes no ponteiro
  de publicação, fechando referência direta insegura a objetos e travessia de
  caminho; symlinks nunca são servidos.
- `parse_cutoff_time` passa a exigir `HH:MM` com dois dígitos, evitando
  ambiguidade de configuração.
- Perfil de dispositivo passa a usar `details.per_user` calculado pela regra
  R7, em vez de reconstruir apenas a partir dos registros de evidência.
- Fixture de teste de R5 completada com as colunas de IP que faltavam.

## [2.1.0](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.1.0) - 2026-07-29

### Adicionado
- Modelo determinístico de ocorrências, deduplicação e evidências para R1–R9.
- R7 (dispositivo com múltiplos usuários), R8 (múltiplos dispositivos em
  curto intervalo) e R9 (troca rápida de IP).
- Modelo unificado e geradores LaTeX/XLSX com classificação visual de UOR.
- Script offline `generate_reports.sh`, auditoria de regras e handoff interno.

### Corrigido
- R1 agora agrega por usuário e dia local, sem combinar IPs de dias distintos.
- R4 agora aplica exatamente mais de dois logins VPN deduplicados no dia.
- R6 deixa de depender da amostra limitada de R5.
- Período padrão da interface passa a 20 dias de calendário inclusivos.
- Downloads de dossiê e todo o fluxo de backtesting usam a guarda de
  autenticação/autorização do FastAPI.

## [2.0.52](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.52) - 2026-07-28

### Corrigido
- **Backtest parametrizável / DB2** — consultas via ``fetch_all`` agora
  reabrem a conexão e repetem a query em falhas transitórias do DB2
  (``SQL1224N``, ``SQL30081N``, ``CLI0106E`` / conexão fechada). Isso evita
  abortar execuções longas de R5/MTA quando o DB2 encerra uma requisição em
  progresso. O retry é limitado e configurável por
  ``DB2_FETCH_RETRY_ATTEMPTS`` (padrão ``3``, máximo ``6``) e
  ``DB2_FETCH_RETRY_DELAY_SECONDS`` (padrão ``2``, máximo ``30``).

## [2.0.51](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.51) - 2026-07-28

### Corrigido
- **Backtest parametrizável local + cloud** — ``bin_path()`` agora retorna
  apenas candidatos fixos que realmente existem e possuem permissão de
  execução. Isso evita retornar cegamente ``/app/scripts/backtest-vpn`` em
  execução local, permitindo fallback para ``scripts/backtest-vpn`` dentro
  do repositório, enquanto mantém o caminho ``/app/scripts/backtest-vpn``
  funcionando no container. A mensagem de indisponibilidade também deixou
  de mencionar ``BACKTEST_VPN_BIN``.

## [2.0.50](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.50) - 2026-07-28

### Corrigido
- **Segurança (Checkmarx CWE-73, similarity ``-338222676``)** — removido
  completamente o fluxo ``os.environ.get("BACKTEST_VPN_BIN")`` de
  ``backtest_runner.py``. O runner agora procura o wrapper ``backtest-vpn``
  somente em caminhos fixos definidos em código (``/app/scripts/backtest-vpn``
  e variantes locais derivadas de ``__file__`` / ``cwd``), com override
  explícito apenas via construtor para testes unitários. Assim, nenhum valor
  vindo de ``environ`` chega a ``os.path.isfile``, ``os.access`` ou
  ``subprocess.Popen``.

## [2.0.49](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.49) - 2026-07-28

### Corrigido
- **Segurança (Checkmarx CWE-73, similarity ``-338222676``)** — a
  sanitização de ``BACKTEST_VPN_BIN`` foi trocada de ``re.fullmatch`` +
  ``match.group(0)`` para reconstrução caractere-a-caractere via
  ``_sanitize_bin_path`` a partir de um allowlist explícito
  (``[A-Za-z0-9._@/-]``). A reconstrução caractere-a-caractere é
  propagada pelo rastreador de taint para **todos** os sinks
  ``os.path.isfile`` / ``os.access`` / ``subprocess.Popen`` que
  consomem ``bin_path()``, resolvendo o achado em ``is_available`` e
  em ``_execute``. Mesmo padrão já utilizado em ``_sanitize_user_id``
  para o cookie do Streamlit.

## [2.0.48](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.48) - 2026-07-28

### Corrigido
- **Testes unitários (regressão em 2.0.47)** — a validação de
  ``BACKTEST_VPN_BIN`` estava exigindo basename literal ``backtest-vpn``,
  o que quebrava fixtures dos testes (``fake-bin``, ``sleepy``) e
  qualquer implantação que renomeasse o executável. A verificação de
  basename foi removida; a barreira de sanitização segue garantida
  pelo ``re.fullmatch`` contra ``_BIN_PATH_RE``, que já exclui todos os
  metacaracteres de shell (``;``, ``&``, espaços, ``$``, backticks,
  aspas). Suite ``tests/unit/test_backtest_runner.py`` volta a passar.

## [2.0.47](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.47) - 2026-07-28

### Corrigido
- **Segurança (Checkmarx CWE-73 / path injection, similarity
  ``-338222676``)** — a validação de ``BACKTEST_VPN_BIN`` em
  ``BacktestRunner.bin_path`` foi endurecida com um sanitizador
  reconhecido pelo scanner: além de ``os.path.realpath``, o caminho
  canônico agora precisa ter basename exatamente igual a
  ``backtest-vpn`` (allowlist rígido) e passar por
  ``re.fullmatch`` contra ``_BIN_PATH_RE``; o valor retornado é o
  ``match.group(0)``, quebrando a propagação de taint até
  ``os.path.isfile`` / ``os.access`` / ``subprocess.Popen``.

## [2.0.46](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.46) - 2026-07-28

### Corrigido
- **Segurança (Checkmarx CWE-73 / path injection)** — o valor de
  ``BACKTEST_VPN_BIN`` lido em ``BacktestRunner.bin_path`` agora é
  validado antes de ser usado em operações de filesystem/subprocess:
  ``NUL`` bytes são rejeitados, ``os.path.realpath`` normaliza
  segmentos ``..`` e symlinks, e apenas caminhos absolutos canônicos
  são retornados.
- **Segurança (Checkmarx CWE-89 / CWE-943, injeção via cookie de
  autenticação Streamlit)** — ``validate_token`` agora reconstrói o
  ``user_id`` caractere a caractere a partir de um allowlist explícito
  (``[A-Za-z0-9._@-]``) via a nova função ``_sanitize_user_id``. A
  reconstrução caractere a caractere quebra a propagação de taint até
  o ``insert_one`` do serviço de auditoria MongoDB, mesmo em scanners
  que não modelam ``re.sub`` como sanitizador.

## [2.0.45](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.45) - 2026-07-28

### Modificado
- Regra **R5** — registros cujo IP é ``0.0.0.0`` (placeholder de IP ausente),
  bem como as variantes IPv6 equivalentes (``::`` / ``::0``), são agora
  tratados como se não existissem. O filtro é aplicado em ambos os lados
  da correlação: no ``SELECT`` da tabela VPN (``CD_END_LGC_CPTV``) e na
  extração de ``ipCliente`` do ``JS_INF_CLI`` em
  ``DB2PEP.MTA_AUT_CLI_TRAN``. Como R6 é subconjunto de R5, a exclusão
  se propaga automaticamente.

## [2.0.44](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.44) - 2026-07-23

### Modificado
- Bundle republicado com janela de **33 dias** (2026-06-20 → 2026-07-23),
  substituindo o bundle anterior de 14 dias.

## [2.0.43](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.43) - 2026-07-23

### Modificado
- Regra **R5** — coluna de métrica (Sumário Negocial + CSV
  `impacto_r5_afetados.csv`) agora também expõe os identificadores
  ``CD_IDFR_MTA`` (PK da linha em ``DB2PEP.MTA_AUT_CLI_TRAN``) e
  ``CD_CLI_TRAN`` (código do cliente na transação) associados a cada
  correlação VPN ↔ OpenAM. Formato:
  ``IPs: VPN=<ip> ↔ OpenAM=<ip> · CD_IDFR_MTA: <n>, ... · CD_UNCO_TRAN: <uuid>, ... · CD_CLI_TRAN: <n>, ...``.
  Cabeçalho renomeado para
  "IPs (VPN ↔ OpenAM), CD_IDFR_MTA, CD_UNCO_TRAN e CD_CLI_TRAN".

### Backtest CLI
- ``backtest_vpn.mta`` agora seleciona ``CD_CLI_TRAN`` além de
  ``CD_IDFR_MTA`` e ``CD_UNCO_TRAN``; ambos são propagados no
  sample R5 do bundle (chaves ``MTA_CD_IDFR_MTA`` e ``MTA_CD_CLI_TRAN``).

## [2.0.42](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.42) - 2026-07-22

### Modificado
- Enriquecimento **UOR** via curio (`codigoUnidadeOrganizacionalDependenciaUsuario`)
  agora aparece na tabela "Usuários convergentes" da página
  `/backtest/vpn`, além do Sumário Negocial. Cabeçalho renomeado
  para "UOR (Unidade Organizacional · curio)" para deixar explícita
  a origem do dado.

## [2.0.41](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.41) - 2026-07-22

### Modificado
- Regra **R5** — a coluna de métrica (Sumário Negocial + CSV) agora
  também expõe todos os ``CD_UNCO_TRAN`` distintos observados em
  ``DB2PEP.MTA_AUT_CLI_TRAN`` para cada funcionário no período,
  no formato ``IPs: VPN=<ip> ↔ OpenAM=<ip> · CD_UNCO_TRAN: <uuid>, ...``.
  Cabeçalho renomeado para "IPs (VPN ↔ OpenAM) e CD_UNCO_TRAN".

## [2.0.40](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.40) - 2026-07-22

### Modificado
- Regra **R5** — a coluna "Métrica" no Sumário Negocial e no CSV
  `impacto_r5_afetados.csv` deixa de mostrar apenas a contagem de
  correlações e passa a listar explicitamente os pares de IPs
  registrados em cada tabela (`VPN=<ip da AUT_CPTV> ↔
  OpenAM=<ip da MTA_AUT_CLI_TRAN>`), agregando todos os pares
  distintos observados no período por funcionário. Cabeçalho da
  coluna renomeado para "Pares de IPs (VPN ↔ OpenAM)".

## [2.0.39](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.39) - 2026-07-22

- Adicionado
  - `run_distinct_limit_case` (CLI) passa a selecionar
    ``MAX(TS_TRAN) AS LAST_SEEN`` no sample, e o Sumário Negocial passa
    a preencher a coluna "Última ocorrência" para R1, R2 e R3 (antes
    ficava em branco porque o sample não trazia timestamp).
- Modificado
  - Removida a sigla **"MTA"** dos textos visíveis. Em vez disso, as
    descrições referenciam explicitamente a tabela
    ``DB2PEP.MTA_AUT_CLI_TRAN`` e esclarecem que é a "tabela de
    produção dos logins do OpenAM". Ajustes propagados nas descrições
    R5/R6, títulos das regras, labels de métrica ("Correlações VPN ↔
    OpenAM"), parâmetros exibidos em `/backtest/vpn` e notas do
    bundle (`rules.py`, `htmlreport.py`).
  - Rerun de 14d publicado com o novo campo ``LAST_SEEN`` em R1/R2/R3.



## [2.0.38](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.38) - 2026-07-22

- Adicionado
  - Todas as páginas do backtest (`/backtest/vpn`, `/backtest/sumario`,
    `/backtest/segmentacao`, `/backtest/executar` e suas telas de status)
    exibem explicitamente a **tag de release do dashboard** — no cabeçalho
    (topbar) e em um rodapé unificado ao final da página. A tag também
    aparece como métrica destacada no cabeçalho técnico de
    `/backtest/vpn` e nas captions do Sumário/Segmentação, ao lado do
    nome do bundle publicado.
- Modificado
  - Descrições das regras R5 e R6 no Sumário Negocial e no Relatório
    Técnico passam a **explicitar a janela de correlação temporal**
    aplicada (``± mta_delta_minutes`` minutos em torno de cada evento
    VPN, lido do bundle — por padrão ±10 min). Também deixam claras as
    faixas privadas aceitas (10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16)
    e a dedupe por ``CD_UNCO_TRAN``.
  - Descrições de R1..R4 agora incluem explicitamente o período de
    análise (`start → end`) e a coluna DB2 usada como métrica (ex.:
    ``NM_DSVO`` para hostnames, ``CD_IDFC_DSVO`` para dispositivos).
  - Página `/backtest/vpn` (Relatório Técnico) mostra os parâmetros em
    português (ex.: "Janela de correlação VPN↔MTA (R5/R6)"), incluindo
    a janela em `±minutos`, faixas privadas aceitas, limiares R1..R4 e
    limites de execução (chunk temporal, máx. usuários).



## [2.0.37](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.37) - 2026-07-22

- Adicionado
  - Sumário Negocial passa a exibir uma coluna dedicada à métrica-chave
    de cada regra ("IPs distintos" p/ R1, "Hostnames distintos" p/ R2,
    "Dispositivos distintos" p/ R3, "Logins no dia" p/ R4, etc.), com o
    valor observado no sample. A coluna "Última ocorrência" agora
    preenche corretamente para R4 (via `LOGIN_DATE`) e R5/R6 (via
    `VPN_TS`/`MTA_TS`).
  - Descrições das regras R1..R4 no Sumário Negocial passam a incluir
    explicitamente os limiares aplicados (`distinct_limit`,
    `daily_login_limit`) lidos dos `parameters` do bundle — deixa claro,
    por exemplo, que R4 dispara com "mais de 10 logins/dia".
  - Nova página `/backtest/vpn` completamente reescrita no mesmo layout
    unificado do Sumário/Segmentação: parâmetros do bundle, resumo por
    regra, detalhes técnicos (estabilidade temporal, controle negativo,
    varredura de limiar, limiar sugerido) e matriz de cruzamento entre
    regras. Sem gráficos SVG/plotly na página técnica. O relatório HTML
    autocontido antigo continua acessível em `/backtest/vpn/raw`.
  - Página de Segmentação ganha tooltip explicando a métrica "Cobertura
    curio" e a caption esclarece por que a cobertura pode ficar abaixo
    de 100% (matrículas desligadas, chaves técnicas, falhas transitórias
    da API).
  - `fetch_org_data` (curio) agora faz uma nova tentativa em caso de
    falha transitória, reduzindo lacunas espúrias na cobertura.
- Modificado
  - Coluna "Matrícula (pseudo)" renomeada para "Matrícula" no Sumário
    Negocial (matrículas nunca são pseudonimizadas nesta implantação).
  - CSV `/backtest/sumario/csv/impacto_<regra>_afetados.csv` agora inclui
    também a coluna da métrica principal da regra.

## [2.0.36](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.36) - 2026-07-21

- Modificado
    VPN ativa em `DB2PEP.AUT_CPTV` cujo IP tunelado (`CD_END_LGC_CPTV`)
    é **diferente** do `ipCliente` privado observado em
    `DB2PEP.MTA_AUT_CLI_TRAN` na mesma janela — indica presença simultânea
    em duas redes distintas (VPN + rede física), sinal forte de sessão
    paralela.
- Adicionado
  - **Nova regra R6** `vpn_ativa_com_login_em_rede_fisica_mta_multiplos_dispositivos`:
    subconjunto de R5 em que o mesmo usuário também apresentou, no período,
    **mais de `distinct_limit` hostnames OU mais de `distinct_limit`
    dispositivos distintos** na tabela VPN. Reforça o cenário de sessão
    paralela com múltiplos equipamentos ativos ao mesmo tempo. Executada
    automaticamente após R5 em `run_backtest_cases`; propagada por
    `RULES`, `FAMILIES`, `flag_sets`, `_temporal_stability`,
    `_negative_controls`, `_cross_rule.family_vol` e por
    `RULE_ORDER`/`RULE_CASE_NAMES`/`RULE_TITLES_PT`/`RULE_DESCRIPTIONS_PT`
    no `backtest_bundle` do dashboard, aparecendo automaticamente nas
    páginas `/backtest/sumario` e `/backtest/segmentacao`.
  - Bundle republicado com contagens da janela de 14 dias sob a nova
    semântica de R5 + R6.

## [2.0.35](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.35) - 2026-07-21

- Corrigido
    apenas em `[project.optional-dependencies].db2`, então `uv sync
    --no-dev` não o instalava e o pod quebrava ao rodar
    `/backtest/executar` com `ModuleNotFoundError: No module named
    'ibm_db'`). O wheel oficial já embute o DB2 CLI driver, então basta a
    dependência estar em `dependencies` para o backtest funcionar.
- Adicionado
  - Bundle publicado atualizado (`results_bundle_20260721_154852.json`)
    com a nova semântica de R5 (cruzamento por IP idêntico). Contagens:
    R1=24843, R2=10, R3=13, R4=133, **R5=146** usuários com VPN + login
    físico no mesmo IP privado corporativo. Aliases `latest.htm`/`latest.fragment.htm`
    também atualizados.

## [2.0.34](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.34) - 2026-07-21

- Corrigido
  - `BACKTEST_VPN_BIN` agora aponta para o wrapper `/app/scripts/backtest-vpn`
    (novo). A imagem é construída com `uv sync --no-install-project`, que
    não instala o entry point `[project.scripts]` em `.venv/bin/`, causando
    o erro `Executável /app/.venv/bin/backtest-vpn inexistente ou sem
    permissão`. O wrapper invoca `python -m backtest_vpn.cli "$@"` e é
    marcado como executável no Dockerfile.
- Modificado
  - **Regra R5 redefinida**: agora o cruzamento VPN × MTA sinaliza quando
    o `IP_CLIENTE` do MTA é **idêntico** ao `CD_END_LGC_CPTV` tunelado
    pela VPN (antes exigia IPs diferentes). O critério passa a ser um
    cruzamento estrito por IP + usuário, confirmando presença física e
    sessão VPN simultâneas na mesma máquina/rede corporativa.
    - `backtest_vpn/mta.py`: condição `ip == cptv` → `ip != cptv` (skip
      quando não são iguais) invertida para skip quando `ip != cptv`.
    - Documentação e descrições atualizadas em `backtest_vpn/rules.py`,
      `streamlit_app/backtest_bundle.py` e no relatório HTML gerado.

## [2.0.33](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.33) - 2026-07-21

- Adicionado
  - Bundle shipped agora reflete a janela de **14 dias** (2026-07-06 →
    2026-07-20) com matrículas explícitas. R5 detecta 33 usuários com
    VPN + login físico via MTA. Arquivos publicados em
    `acr_controle_acesso_dashboard/static/backtest_vpn/`:
    `results_bundle_20260721_150632.json`,
    `relatorio_backtest_vpn_20260721_150632.htm` (+fragment) e os aliases
    `latest.htm`/`latest.fragment.htm`.
  - CLI `backtest-vpn` passa a aceitar as credenciais DB2 via variáveis
    de ambiente `DB2_USERNAME`/`DB2_PASSWORD`, alinhando com o padrão
    usado pelas credenciais Kafka. O modo `DB2_CREDENTIALS_FILE`
    continua suportado como fallback.
- Modificado
  - `BacktestRunner.credentials_ok()` valida as duas formas de
    provisionamento (env vars **ou** arquivo JSON).
  - `deploy-acr-controle-acesso-dashboard/values.yaml`: substitui o mount
    do arquivo JSON por dois `secretKeyRef` (`DB2_USERNAME`,
    `DB2_PASSWORD`) apontando para o Secret `db2-credentials`,
    espelhando o padrão `kafka-credentials`. `DB2_JDBC_URL` continua
    disponível como chave opcional no mesmo Secret. Volume/mount
    removido.
  - Mensagem exibida na tela `/backtest/executar` agora explica ambos os
    caminhos de configuração DB2.
- Removido
  - Bundle antigo de 48h (`results_bundle_20260720_173446.json` e HTMs
    correspondentes) do diretório `static/backtest_vpn/`, para que a UI
    reflita imediatamente a nova janela de 14d.

## [2.0.32](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.32) - 2026-07-21

- Corrigido
  - Corrige o build do CI (`pip install -e .`), que quebrava em 2.0.31 com
    `ERROR: Could not find a version that satisfies the requirement
    backtest-vpn-local`. O pacote CLI `backtest-vpn` foi reestruturado como
    módulo de primeiro nível `backtest_vpn/` no próprio repositório do
    dashboard e registrado via `[project.scripts]`; a pasta intermediária
    `vendor-backtest-vpn/` e a entrada `[tool.uv.sources]` foram removidas.
    Agora tanto `pip` quanto `uv` resolvem a distribuição sem depender de
    um pacote extra no artifactory.

## [2.0.31](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.31) - 2026-07-21

- Adicionado
  - Empacota o CLI `backtest-vpn` dentro da própria imagem (dependência local
    `vendor-backtest-vpn/`), fazendo com que `BACKTEST_VPN_BIN` deixe de ser
    uma variável opcional externa e passe a apontar automaticamente para
    `/app/.venv/bin/backtest-vpn` a partir da configuração do Helm chart.
  - `deploy-acr-controle-acesso-dashboard/values.yaml`: novas variáveis
    `BACKTEST_VPN_BIN`, `BACKTEST_VPN_REPORTS_DIR` e `DB2_CREDENTIALS_FILE`,
    além de mount opcional do Secret `db2-credentials`
    (`db2_credentials.json`) em `/etc/db2/`.
  - Novo flag `--no-pseudonymize` no CLI do backtest: quando presente, todas
    as amostras publicadas no bundle exibem a matrícula real (ex.:
    `F1234567`) em vez do valor pseudonimizado `U-<hash>`. Introduzido para
    atender ao requisito de nunca ocultar matrículas nas telas de backtest.
- Modificado
  - `backtest_runner` sempre executa `backtest-vpn full` com
    `--no-pseudonymize`, garantindo que qualquer bundle gerado a partir da
    tela `/backtest/executar` contenha matrículas explícitas.
  - Janela padrão da tela `/backtest/executar` alterada de 48 horas para
    **14 dias**. O usuário continua livre para ajustar `start`/`end` no
    formulário; o padrão apenas reflete o novo requisito operacional.
  - `templates/backtest_executar.html` deixa explícito na descrição que a
    janela padrão é de 14 dias e que as matrículas são sempre exibidas sem
    pseudonimização.

## [2.0.30](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.30) - 2026-07-21

- Corrigido
  - Adiciona a dependência `python-multipart`, exigida pelo FastAPI para
    resolver parâmetros `Form(...)` no `POST /backtest/executar`. Sem ela o
    processo falhava na importação com
    `RuntimeError: Form data requires "python-multipart" to be installed`
    e os pods entravam em CrashLoopBackOff. `uv.lock` regenerado.

## [2.0.29](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.29) - 2026-07-21

- Corrigido
  - Adiciona a dependência `python-multipart`, exigida pelo FastAPI para
    resolver parâmetros `Form(...)` no `POST /backtest/executar`. Sem ela o
    processo falhava na importação com
    `RuntimeError: Form data requires "python-multipart" to be installed`
    e os pods entravam em CrashLoopBackOff. `uv.lock` regenerado.

## [2.0.28](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.28) - 2026-07-21

- Adicionado
  - Rotas FastAPI nativas para as páginas negociais do backtest, dispensando
    o gate CSRF do Streamlit:
    - `GET /backtest/sumario` — Sumário Negocial renderizado server-side
      (Jinja2), com métricas consolidadas, impacto de bloqueio por regra,
      matriz regras × usuários, top reincidentes e enriquecimento
      organizacional via curio `op292018v3`.
    - `GET /backtest/sumario/csv/<nome>` — downloads sob demanda dos CSVs
      (`impacto_r{n}_afetados.csv`, `todos_afetados_unicos.csv`,
      `matriz_regras_x_usuarios.csv`, `top_reincidentes.csv`).
    - `GET /backtest/segmentacao` — Segmentação de suspeitos por dados
      organizacionais, com gráficos Plotly renderizados server-side
      (top prefixos, tipos, empilhado, heatmap) e fallback quando a
      cobertura do curio for inferior a 70 %.
    - `GET /backtest/segmentacao/csv/segmentacao_suspeitos.csv` — download
      da tabela consolidada.
    - `GET /backtest/executar` — formulário para disparar uma nova execução
      do backtest com janela e parâmetros configuráveis
      (`--mta-delta-minutes`, `--mta-max-users`, `--mta-users-per-batch`,
      `--mta-chunk-hours`, `--active-window-hours`, `--distinct-limit`,
      `--daily-login-limit`).
    - `POST /backtest/executar` — valida os parâmetros, dispara o subprocess
      em background e redireciona para a página de progresso.
    - `GET /backtest/executar/<job_id>` — página de progresso em tempo real:
      status, log em janela rolável, links para os artefatos gerados.
    - `GET /backtest/executar/<job_id>/status` — endpoint JSON de polling
      incremental do log.
  - Módulo `acr_controle_acesso_dashboard/backtest_runner.py` com
    orquestrador thread-safe de jobs de backtest em subprocess, validação
    estrita de parâmetros, no máximo 1 job ativo por vez, promoção
    automática do bundle + HTM para `static/backtest_vpn/` ao concluir.
  - Templates Jinja2 novos: `backtest_layout.html`, `backtest_sumario.html`,
    `backtest_segmentacao.html`, `backtest_executar.html`,
    `backtest_executar_status.html`.
  - Testes unitários `tests/unit/test_backtest_runner.py` (validação de
    parâmetros, indisponibilidade, execução end-to-end com CLI fake,
    exclusão mútua de jobs, snapshot serializável).
  - Variáveis de ambiente novas usadas pelo runner:
    `BACKTEST_VPN_BIN`, `BACKTEST_VPN_REPORTS_DIR` (opcionais em
    `docker-compose.local.yml`); a execução sob demanda só é habilitada
    quando o executável do backtest e o `DB2_CREDENTIALS_FILE` estão
    ambos disponíveis. Sem eles, as páginas de leitura seguem funcionando
    com o bundle publicado, e a página `Executar` exibe o motivo da
    indisponibilidade.
- Modificado
  - `templates/dashboard.html`: substitui as abas Streamlit
    `sumario_negocial` e `segmentacao_suspeitos` por links para as novas
    rotas FastAPI `/backtest/sumario`, `/backtest/segmentacao` e
    `/backtest/executar` (evita o gate CSRF do iframe do Streamlit).
- Removido
  - Páginas Streamlit `pages/sumario_negocial.py` e
    `pages/segmentacao_suspeitos.py` (substituídas pelas rotas FastAPI
    equivalentes).

## [2.0.27](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.27) - 2026-07-20

- Adicionado
  - Nova página **Sumário Negocial** (`pages/sumario_negocial.py`): consolida
    os resultados do backtest label-free (R1..R5) em métricas negociais,
    mostra o impacto potencial de bloqueio por regra (funcionários e eventos
    afetados), redundância entre regras e disponibiliza CSVs por regra e no
    rodapé (`impacto_r{n}_afetados.csv`, `todos_afetados_unicos.csv`,
    `matriz_regras_x_usuarios.csv`, `top_reincidentes.csv`).
  - Nova página **Segmentação de Suspeitos**
    (`pages/segmentacao_suspeitos.py`): agrupa os funcionários sinalizados por
    Prefixo de Dependência, Unidade Organizacional, Tipo de Usuário e Regra,
    com filtros na barra lateral, gráficos de barras, empilhado e heatmap
    Prefixo × Regra. Enriquece cada matrícula com dados organizacionais via
    curio `op292018v3` e cai em fallback quando a cobertura do curio for
    inferior a 70 %.
  - Módulo compartilhado `streamlit_app/org_enrichment.py` com
    `is_matricula`, `fetch_org_data` (cacheado 10 min via `st.cache_data`),
    `flatten_org` e o dicionário `ORG_COLUMNS_PT` de rótulos em pt-BR.
  - Módulo `streamlit_app/backtest_bundle.py` com funções puras de agregação
    do bundle (regras × usuários, top reincidentes, cobertura curio, etc.),
    permitindo testes unitários sem carregar Streamlit.
  - Bundle e HTM do backtest atualizados para uma janela recente de ~48 h
    (`results_bundle_20260720_173446.json`, R5 status=`ok`).
  - Testes unitários novos:
    `tests/unit/test_org_enrichment.py`,
    `tests/unit/test_sumario_negocial.py`,
    `tests/unit/test_segmentacao_suspeitos.py`.
- Corrigido
  - Varredura de acentos e grafia pt-BR nos artefatos HTML servidos por
    `/backtest/vpn` (relatório e fragmento) e nas novas páginas.

## [2.0.26](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.26) - 2026-07-20

- Adicionado
  - Nova aba **VPN + Rede Física** em `pages/logins_suspeitos.py` que consome o
    bundle do backtest label-free e exibe usuários com sessão VPN ativa em
    `DB2PEP.AUT_CPTV` correlacionada, na mesma janela (±Δ minutos), a fluxos
    de autenticação bem-sucedidos em `DB2PEP.MTA_AUT_CLI_TRAN` a partir de
    IP privado corporativo distinto do IP tunelado (regra R5 reimplementada).
    A página apenas lê o `results_bundle_*.json` publicado em
    `static/backtest_vpn/`; nenhuma ação é executada no LDAP.
- Corrigido
  - Varredura de acentos e grafia pt-BR nos artefatos HTML servidos por
    `/backtest/vpn` (relatório e fragmento) e nos rótulos das abas de
    `logins_suspeitos.py`.

## [2.0.25](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/2.0.25) - 2026-07-20

- Adicionado
  - Rota `/backtest/vpn` que serve o relatório HTML consolidado (standalone, pt-BR)
    do backtest de regras VPN produzido pelo projeto `backtest_vpn_local`
    (metodologia label-free, `next-best-thing/1.0`). Autenticação exigida
    (redireciona para `/` se não houver sessão).
  - Rota `/backtest/vpn/fragment` que devolve o fragmento embutível
    (`<div class="vpnbt-root">…</div>`) para inclusão server-side em outras
    páginas do domínio.
  - Diretório `acr_controle_acesso_dashboard/static/backtest_vpn/` com os
    artefatos do relatório (`latest.htm`, `latest.fragment.htm`, versão
    carimbada `relatorio_backtest_vpn_<stamp>.htm` e o bundle JSON
    `results_bundle_<stamp>.json` que originou a página).
- Observações
  - A página traz as camadas executiva (pt-BR, sem jargão) e técnica
    (R1–R5 + transversal). R5 (`vpn_ativa_com_login_em_rede_fisica`) aparece
    explicitamente como não executado nesta rodada por falta de configuração
    da tabela de login em rede física; Phase B (injeção sintética) e Phase C
    (adjudicação) permanecem como "não executado nesta rodada".
  - Todos os identificadores de usuário na página estão pseudonimizados
    (HMAC-SHA256, `key_id` embutido no rodapé) e o disclaimer sobre
    `not_available_without_validated_labels` permanece visível.

## [0.1.0-rc0](https://fontes.intranet.bb.com.br/acr/acr-controle-acesso-dashboard/acr-controle-acesso-dashboard/tags/0.1.0-rc0) - aaaa-mm-dd

- Adicionado
  - Primeira versão
