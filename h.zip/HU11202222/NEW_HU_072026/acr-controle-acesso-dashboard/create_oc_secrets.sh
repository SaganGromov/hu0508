#!/usr/bin/env bash
set -euo pipefail

# Creates/updates Kubernetes Secrets required by values.yaml:
# - kafka-credentials
# - acr-dashboard-auth-secrets
#
# Usage examples:
#   ./create_oc_secrets.sh -n <namespace>
#   KAFKA_BOOTSTRAP_SERVERS='broker:9093' KAFKA_SASL_USERNAME='user' KAFKA_SASL_PASSWORD='pass' ./create_oc_secrets.sh -n <namespace>
#   ./create_oc_secrets.sh -n <namespace> --secrets-dir ./secrets
#   ./create_oc_secrets.sh --env-file ./.env --namespace my-project

NAMESPACE=""
SECRETS_DIR="./secrets"
ENV_FILE="./.env"
UPDATE_EXISTING="false"

print_help() {
  cat <<'EOF'
Usage: create_oc_secrets.sh [-n <namespace>] [--secrets-dir <dir>] [--env-file <file>]

Namespace resolution order:
  1) -n/--namespace argument
  2) OPENSHIFT_NAMESPACE in env file
  3) NAMESPACE in env file
  4) K8S_NAMESPACE in env file
  5) Current oc project from context

Optional:
  --secrets-dir              Directory containing files:
                             - matricula_hmac_key
                             - allowed_matricula_digests
                             (default: ./secrets)
  --env-file                 Env file to load values from (default: ./.env)
  --update-existing          Try to update existing secrets (requires patch/update RBAC)
  -h, --help                 Show this help

Environment variables (Kafka):
  KAFKA_BOOTSTRAP_SERVERS
  KAFKA_SASL_USERNAME
  KAFKA_SASL_PASSWORD

Environment variables (Dashboard auth secret):
  OAUTH2_CLIENT_SECRET
  MONGODB_AUDIT_URI
  SESSION_SECRET

If Kafka env vars are not set in shell or env file, the script will ask interactively.
EOF
}

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "Error: required command not found: $1" >&2
    exit 1
  fi
}

create_or_update_secret() {
  local name="$1"
  local manifest="$2"

  if oc -n "$NAMESPACE" get secret "$name" >/dev/null 2>&1; then
    if [[ "$UPDATE_EXISTING" != "true" ]]; then
      echo "Secret '$name' already exists in namespace '$NAMESPACE'. Skipping update (default mode)."
      return 0
    fi

    if echo "$manifest" | oc -n "$NAMESPACE" apply -f - >/dev/null 2>&1; then
      echo "Secret '$name' updated."
      return 0
    fi

    echo "Error: secret '$name' exists but could not be updated."
    echo "Hint: your user may not have patch/update permission for secrets in '$NAMESPACE'."
    echo "Use default mode (without --update-existing) to skip existing secrets, or request RBAC permission."
    return 1
  fi

  if echo "$manifest" | oc -n "$NAMESPACE" create -f - >/dev/null 2>&1; then
    echo "Secret '$name' created."
    return 0
  fi

  echo "Error: failed to create secret '$name' in namespace '$NAMESPACE'."
  return 1
}

load_env_file() {
  local file_path="$1"
  local cli_namespace="$2"

  if [[ ! -f "$file_path" ]]; then
    return 0
  fi

  while IFS= read -r line || [[ -n "$line" ]]; do
    # Ignore comments and blank lines.
    [[ -z "${line//[[:space:]]/}" ]] && continue
    [[ "$line" =~ ^[[:space:]]*# ]] && continue

    # Support optional "export KEY=VALUE" prefix.
    line="${line#export }"

    if [[ "$line" != *"="* ]]; then
      continue
    fi

    local key="${line%%=*}"
    local value="${line#*=}"

    # Trim spaces around key and value.
    key="${key#${key%%[![:space:]]*}}"
    key="${key%${key##*[![:space:]]}}"
    value="${value#${value%%[![:space:]]*}}"
    value="${value%${value##*[![:space:]]}}"

    # Remove one pair of matching surrounding quotes, if present.
    if [[ ( "$value" == \"*\" && "$value" == *\" ) || ( "$value" == \'*\' && "$value" == *\' ) ]]; then
      value="${value:1:${#value}-2}"
    fi

    # Import only variables needed by this script.
    case "$key" in
      KAFKA_BOOTSTRAP_SERVERS|KAFKA_SASL_USERNAME|KAFKA_SASL_PASSWORD|OAUTH2_CLIENT_SECRET|MONGODB_AUDIT_URI|SESSION_SECRET)
        export "$key=$value"
        ;;
      OPENSHIFT_NAMESPACE|K8S_NAMESPACE)
        export "$key=$value"
        ;;
      NAMESPACE)
        # Keep -n/--namespace argument precedence over env file values.
        if [[ -z "$cli_namespace" ]]; then
          export NAMESPACE="$value"
        fi
        ;;
    esac
  done < "$file_path"
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -n|--namespace)
      NAMESPACE="${2:-}"
      shift 2
      ;;
    --secrets-dir)
      SECRETS_DIR="${2:-}"
      shift 2
      ;;
    --env-file)
      ENV_FILE="${2:-}"
      shift 2
      ;;
    --update-existing)
      UPDATE_EXISTING="true"
      shift
      ;;
    -h|--help)
      print_help
      exit 0
      ;;
    *)
      echo "Error: unknown argument: $1" >&2
      print_help
      exit 1
      ;;
  esac
done

load_env_file "$ENV_FILE" "$NAMESPACE"

if [[ -z "$NAMESPACE" ]]; then
  NAMESPACE="${OPENSHIFT_NAMESPACE:-${NAMESPACE:-${K8S_NAMESPACE:-}}}"
fi

require_cmd oc

if ! oc whoami >/dev/null 2>&1; then
  echo "Error: not logged in. Run 'oc login ...' first." >&2
  exit 1
fi

if [[ -z "$NAMESPACE" ]]; then
  NAMESPACE="$(oc project -q 2>/dev/null || true)"
fi

if [[ -z "$NAMESPACE" ]]; then
  echo "Error: namespace is required. Use -n/--namespace, set OPENSHIFT_NAMESPACE (or NAMESPACE/K8S_NAMESPACE) in $ENV_FILE, or select a project with 'oc project <name>'." >&2
  print_help
  exit 1
fi

KEY_FILE="${SECRETS_DIR}/matricula_hmac_key"
DIGESTS_FILE="${SECRETS_DIR}/allowed_matricula_digests"

if [[ ! -f "$KEY_FILE" ]]; then
  echo "Error: missing file: $KEY_FILE" >&2
  exit 1
fi

if [[ ! -f "$DIGESTS_FILE" ]]; then
  echo "Error: missing file: $DIGESTS_FILE" >&2
  exit 1
fi

if [[ -z "${KAFKA_BOOTSTRAP_SERVERS:-}" ]]; then
  read -r -p "KAFKA_BOOTSTRAP_SERVERS: " KAFKA_BOOTSTRAP_SERVERS
fi

if [[ -z "${KAFKA_SASL_USERNAME:-}" ]]; then
  read -r -p "KAFKA_SASL_USERNAME: " KAFKA_SASL_USERNAME
fi

if [[ -z "${KAFKA_SASL_PASSWORD:-}" ]]; then
  read -r -s -p "KAFKA_SASL_PASSWORD: " KAFKA_SASL_PASSWORD
  echo
fi

if [[ -z "$KAFKA_BOOTSTRAP_SERVERS" || -z "$KAFKA_SASL_USERNAME" || -z "$KAFKA_SASL_PASSWORD" ]]; then
  echo "Error: Kafka values cannot be empty." >&2
  exit 1
fi

if [[ -z "${OAUTH2_CLIENT_SECRET:-}" ]]; then
  read -r -s -p "OAUTH2_CLIENT_SECRET: " OAUTH2_CLIENT_SECRET
  echo
fi

if [[ -z "${OAUTH2_CLIENT_SECRET:-}" ]]; then
  echo "Error: OAUTH2_CLIENT_SECRET cannot be empty." >&2
  exit 1
fi

if [[ -z "${SESSION_SECRET:-}" ]]; then
  SESSION_SECRET="$(head -c 32 /dev/urandom | base64 | tr -d '\n')"
  echo "SESSION_SECRET not provided; generated a random secret for this deployment."
fi

if [[ -z "${MONGODB_AUDIT_URI:-}" ]]; then
  echo "Warning: MONGODB_AUDIT_URI not provided; audit logging secret key will be created empty."
fi

# Ensure target project exists/access is valid and switch context.
oc project "$NAMESPACE" >/dev/null

# Build kafka-credentials secret manifest.
KAFKA_SECRET_MANIFEST="$(oc -n "$NAMESPACE" create secret generic kafka-credentials \
  --from-literal=KAFKA_BOOTSTRAP_SERVERS="$KAFKA_BOOTSTRAP_SERVERS" \
  --from-literal=KAFKA_SASL_USERNAME="$KAFKA_SASL_USERNAME" \
  --from-literal=KAFKA_SASL_PASSWORD="$KAFKA_SASL_PASSWORD" \
  --dry-run=client -o yaml)"

# Build acr-dashboard-auth-secrets secret manifest.
MATRICULA_SECRET_MANIFEST="$(oc -n "$NAMESPACE" create secret generic acr-dashboard-auth-secrets \
  --from-literal=oauth2_client_secret="$OAUTH2_CLIENT_SECRET" \
  --from-literal=mongodb_audit_uri="${MONGODB_AUDIT_URI:-}" \
  --from-literal=session_secret="$SESSION_SECRET" \
  --from-file=matricula_hmac_key="$KEY_FILE" \
  --from-file=allowed_matricula_digests="$DIGESTS_FILE" \
  --dry-run=client -o yaml)"

create_or_update_secret "kafka-credentials" "$KAFKA_SECRET_MANIFEST"
create_or_update_secret "acr-dashboard-auth-secrets" "$MATRICULA_SECRET_MANIFEST"

echo "Secrets applied successfully in namespace: $NAMESPACE"
echo "- kafka-credentials"
echo "- acr-dashboard-auth-secrets"
