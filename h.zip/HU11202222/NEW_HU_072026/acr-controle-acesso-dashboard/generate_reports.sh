#!/bin/sh
set -eu

fail() {
    printf '%s\n' "Erro: $*" >&2
    exit 1
}

[ -f "pyproject.toml" ] || fail "execute este script na raiz do repositório."
[ -d "backtest_vpn" ] || fail "pacote backtest_vpn não encontrado."

command -v python3 >/dev/null 2>&1 || fail "python3 não está instalado."
command -v pdflatex >/dev/null 2>&1 || fail "pdflatex não está instalado."
python3 -c 'import openpyxl' >/dev/null 2>&1 || fail "dependência Python openpyxl não está instalada."

bundle=""
start_date=""
end_date=""
output_dir="reports"
selected_rules=""
rules_config=""
employee_data=""

while [ "$#" -gt 0 ]; do
    case "$1" in
        --bundle|--start|--end|--output-dir|--rules|--config|--employee-data)
            [ "$#" -ge 2 ] || fail "falta valor para $1."
            option=$1
            value=$2
            shift 2
            case "$option" in
                --bundle) bundle=$value ;;
                --start) start_date=$value ;;
                --end) end_date=$value ;;
                --output-dir) output_dir=$value ;;
                --rules) selected_rules=$value ;;
                --config) rules_config=$value ;;
                --employee-data) employee_data=$value ;;
            esac
            ;;
        --help)
            printf '%s\n' "Uso: ./generate_reports.sh [--bundle ARQUIVO] [--start AAAA-MM-DD --end AAAA-MM-DD] [--output-dir DIRETÓRIO] [--rules R1,R4,R7] [--config JSON] [--employee-data JSON]"
            exit 0
            ;;
        *) fail "argumento desconhecido: $1" ;;
    esac
done

case "$output_dir" in
    ""|"/"|"."|"..") fail "diretório de saída inseguro ou vazio." ;;
esac

if [ -n "$start_date" ] || [ -n "$end_date" ]; then
    [ -n "$start_date" ] && [ -n "$end_date" ] || fail "--start e --end devem ser usados juntos."
    [ -z "$bundle" ] || fail "--bundle não pode ser combinado com --start/--end."
    python3 -c 'from datetime import date; import sys; a=date.fromisoformat(sys.argv[1]); b=date.fromisoformat(sys.argv[2]); assert a <= b, "data inicial posterior à final"' "$start_date" "$end_date" \
        || fail "período inválido."
    start_ts="${start_date} 00:00:00"
    end_exclusive=$(python3 -c 'from datetime import date,timedelta; import sys; print((date.fromisoformat(sys.argv[1])+timedelta(days=1)).isoformat()+" 00:00:00")' "$end_date")
    set -- python3 -m backtest_vpn.cli full --start "$start_ts" --end "$end_exclusive" --output-dir "$output_dir"
    if [ -n "$selected_rules" ]; then
        set -- "$@" --rules "$selected_rules"
    fi
    if [ -n "$rules_config" ]; then
        [ -f "$rules_config" ] || fail "arquivo de configuração não encontrado: $rules_config"
        set -- "$@" --rules-config "$rules_config"
    fi
    "$@"
    bundle=$(ls -1t "$output_dir"/results_bundle_*.json 2>/dev/null | sed -n '1p')
else
    [ -z "$selected_rules" ] || fail "--rules só pode ser usado com --start/--end."
    [ -z "$rules_config" ] || fail "--config só pode ser usado com --start/--end."
fi

if [ -z "$bundle" ]; then
    bundle=$(ls -1t "$output_dir"/results_bundle_*.json 2>/dev/null | sed -n '1p')
fi
[ -n "$bundle" ] && [ -s "$bundle" ] || fail "nenhum bundle válido foi informado ou encontrado."

set -- python3 -m backtest_vpn.cli generate-reports --bundle "$bundle" --output-dir "$output_dir"
if [ -n "$employee_data" ]; then
    [ -f "$employee_data" ] || fail "arquivo de dados funcionais não encontrado: $employee_data"
    set -- "$@" --employee-data "$employee_data"
fi
"$@"

tex_path="$output_dir/backtesting_dossier.tex"
xlsx_path="$output_dir/backtesting_dossier.xlsx"
pdf_path="$output_dir/backtesting_dossier.pdf"
model_path="$output_dir/backtesting_report_model.json"
csv_dir="$output_dir/detalhamento_csv"
csv_manifest="$csv_dir/manifest.json"
[ -s "$tex_path" ] || fail "o gerador não produziu $tex_path."
[ -s "$xlsx_path" ] || fail "o gerador não produziu $xlsx_path."
[ -s "$model_path" ] || fail "o gerador não produziu $model_path."
[ -d "$csv_dir" ] || fail "o gerador não produziu o pacote CSV em $csv_dir."
[ -s "$csv_manifest" ] || fail "o gerador não produziu $csv_manifest."

# Revalida o manifesto: presença dos arquivos, contagem de linhas e SHA-256.
python3 -c 'import sys; from backtest_vpn.csvpackage import verify_package; problems = verify_package(sys.argv[1]); sys.stderr.write("\n".join(problems) + "\n") if problems else None; sys.exit(1 if problems else 0)' "$output_dir" \
    || fail "o pacote CSV não passou na verificação de manifesto/SHA-256."

for csv_file in "$csv_dir"/*.csv; do
    [ -s "$csv_file" ] || fail "arquivo CSV vazio: $csv_file"
done

build_dir=$(mktemp -d "${TMPDIR:-/tmp}/backtesting-latex.XXXXXX")
cleanup() {
    rm -rf "$build_dir"
}
trap cleanup EXIT HUP INT TERM

if ! pdflatex -halt-on-error -interaction=nonstopmode -output-directory "$build_dir" "$tex_path" >/dev/null; then
    [ ! -f "$build_dir/backtesting_dossier.log" ] || tail -n 40 "$build_dir/backtesting_dossier.log" >&2
    fail "falha na primeira compilação LaTeX."
fi
if ! pdflatex -halt-on-error -interaction=nonstopmode -output-directory "$build_dir" "$tex_path" >/dev/null; then
    [ ! -f "$build_dir/backtesting_dossier.log" ] || tail -n 40 "$build_dir/backtesting_dossier.log" >&2
    fail "falha na segunda compilação LaTeX."
fi

[ -s "$build_dir/backtesting_dossier.pdf" ] || fail "pdflatex não produziu um PDF não vazio."
cp "$build_dir/backtesting_dossier.pdf" "$pdf_path"
[ -s "$pdf_path" ] || fail "não foi possível copiar o PDF final."

printf '%s\n' "Relatórios concluídos:"
printf '  %s\n' "$tex_path" "$xlsx_path" "$pdf_path" "$model_path" "$csv_manifest"
printf '%s\n' "Pacote de detalhamento em CSV (caminhos relativos ao diretório de saída):"
for csv_file in "$csv_dir"/*.csv; do
    printf '  %s\n' "detalhamento_csv/$(basename "$csv_file")"
done
printf '%s\n' "Auxiliares LaTeX ficaram isolados em um diretório temporário e foram removidos."
