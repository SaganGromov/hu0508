# Integração do relatório HTML VPN

Opções de inclusão:

1. **Iframe do arquivo standalone** (`relatorio_backtest_vpn_*.htm`) — recomendado e de menor risco.
2. **Include server-side do fragmento** (`*.fragment.htm`) dentro da página hospedeira.
3. **Renderizar o fragmento como template/string** no aplicativo hospedeiro.

A página não faz requisições externas. Para estilo inline, a CSP do host precisa permitir `style-src 'unsafe-inline'`; sem `script-src 'unsafe-inline'`, o conteúdo degrada graciosamente e permanece visível em layout empilhado. Cada execução gera um arquivo imutável com carimbo; o host pode montar o diretório e apontar para o mais recente. Identificadores de usuário estão pseudonimizados; mapear de volta exige autorização e o mapa reverso local, quando gerado.
