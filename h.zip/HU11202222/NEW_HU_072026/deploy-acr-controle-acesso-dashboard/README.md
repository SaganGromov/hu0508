# deploy-acr-controle-acesso-dashboard

Repositório de deploy Helm/OpenShift do `acr-controle-acesso-dashboard`.

## Escopo

Este repositório controla:

- tag da imagem do app
- variáveis de ambiente de runtime
- probes HTTP do container principal
- habilitação e configuração do sidecar Curio
- ingress, HPA e recursos do deployment

O comportamento da aplicação continua sendo implementado no repositório `acr-controle-acesso-dashboard`.

## Arquivos principais

- `values.yaml`: configuração do deployment e do sidecar Curio
- `Chart.yaml`: dependências Helm compartilhadas
- `.github/workflows/cd.yml`: pipeline de entrega

## Contrato de health check aplicado

### Container principal

O container principal expõe HTTP em `:8000` e usa:

- liveness: `GET /health/live`
- readiness: `GET /health/ready`

Esses endpoints são servidos pelo FastAPI do `acr-controle-acesso-dashboard`.

### Sidecar Curio

O sidecar Curio expõe HTTP em `:8081` e usa:

- liveness: `GET /health/live`
- readiness: `GET /health/ready`

Além disso, o Curio verifica a saúde do microsserviço principal usando:

- `CURIO_APLICACAO_HOST=http://localhost:8000`

### Comunicação app -> Curio

O app principal acessa o sidecar no mesmo pod usando:

- `CURIO_BASE_URL=http://localhost:8081`

Isso evita depender do hostname padrão `curio-sidecar` dentro do pod.

## Valores relevantes em `values.yaml`

- `acr-controle-acesso-dashboard.deployment.containers.environments`
  - `CURIO_BASE_URL=http://localhost:8081`
- `acr-controle-acesso-dashboard.deployment.containers.livenessProbe`
  - `httpGet.path=/health/live`
  - `httpGet.port=8000`
- `acr-controle-acesso-dashboard.deployment.containers.readinessProbe`
  - `httpGet.path=/health/ready`
  - `httpGet.port=8000`
- `acr-controle-acesso-dashboard.curio.environments`
  - `CURIO_APLICACAO_HOST=http://localhost:8000`
- `acr-controle-acesso-dashboard.curio.livenessProbe`
  - `httpGet.path=/health/live`
  - `httpGet.port=8081`
- `acr-controle-acesso-dashboard.curio.readinessProbe`
  - `httpGet.path=/health/ready`
  - `httpGet.port=8081`

## Validação após deploy

Depois do rollout, valide os dois containers:

```bash
oc -n <namespace> rollout status deploy/acr-controle-acesso-dashboard
oc -n <namespace> get pods
oc -n <namespace> exec deploy/acr-controle-acesso-dashboard -- curl -s http://localhost:8000/health/live
oc -n <namespace> exec deploy/acr-controle-acesso-dashboard -- curl -s http://localhost:8000/health/ready
oc -n <namespace> exec deploy/acr-controle-acesso-dashboard -c curio-sidecar -- curl -s http://localhost:8081/health/live
oc -n <namespace> exec deploy/acr-controle-acesso-dashboard -c curio-sidecar -- curl -s http://localhost:8081/health/ready
```

Se o Curio continuar falhando, compare as variáveis efetivamente injetadas no pod com o arquivo `.env_curio` usado localmente no repositório da aplicação.
