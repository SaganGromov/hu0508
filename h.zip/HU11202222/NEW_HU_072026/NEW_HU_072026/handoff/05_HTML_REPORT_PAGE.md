# 05 — Phase D: the modular HTML report page (`htmlreport.py`)

Deliverable: a single self-contained `.htm` artifact presenting the entire
backtest — measured, estimated, and bounded results — with an **executive/business
layer** and a **technical layer**, generated in pure Python from the results
bundle, and embeddable into any web application already running on some domain
(e.g., `acr-alert-context.com`) by pasting one fragment or serving one file.

## 1. Inputs, outputs, invocation

```
backtest-vpn report-html --bundle reports/results_bundle_<stamp>.json
                          [--out-dir reports/html]
                          [--standalone-only | --fragment-only]
                          [--lang pt-BR]            # default and only required lang
                          [--title "..."]
```

Outputs (default: both):

- `relatorio_backtest_vpn_<stamp>.htm` — **standalone**: complete document
  (`<!doctype html><html><head>...` etc.), openable from disk with zero network
  access, printable.
- `relatorio_backtest_vpn_<stamp>.fragment.htm` — **fragment**: exactly one
  `<div class="vpnbt-root" id="vpnbt-<stamp>">...</div>` containing scoped
  `<style>` and `<script>` inside it. The host application includes it by
  server-side inclusion, by rendering the string into a template, or via
  `<iframe src=".../relatorio_....htm">` of the standalone file. No build step, no
  assets directory, no framework assumptions on the host.

The generator reads **only the bundle** (plus its own static template strings in
Python). It must never touch DB2, the extract, or the adjudication DB — this keeps
the page free of raw user keys by construction (the bundle is already
pseudonymized; assert at generation time that no value matches the raw-key pattern
if the operator provides one via `--key-regex`, and warn otherwise).

## 2. Embeddability rules (strict)

1. **Namespace everything.** Every CSS selector starts with `.vpnbt-` (e.g.
   `.vpnbt-root`, `.vpnbt-card`, `.vpnbt-chip--bounded`). No selectors on `body`,
   `html`, `*`, bare element names, or anything outside `.vpnbt-root`. Set an
   explicit baseline on `.vpnbt-root` (font-family, font-size, line-height, color,
   background, `box-sizing: border-box` on `.vpnbt-root *`) so the page looks the
   same regardless of host CSS.
2. **No global JavaScript.** One `<script>` per fragment, wrapped in an IIFE,
   discovering its root via `document.currentScript.closest('.vpnbt-root')` — no
   `window.*` assignments, no IDs referenced globally except the root's own. JS is
   progressive enhancement only (tab switching, collapsibles); with JS disabled all
   content must be visible stacked (default state = everything expanded, JS
   collapses on load).
3. **Zero external requests.** No CDN, fonts, images, or XHR — inline CSS, inline
   SVG, system font stack (`system-ui, -apple-system, "Segoe UI", Roboto,
   sans-serif`). This makes the fragment CSP-safe on any host and viewable
   air-gapped. (If the host's CSP forbids inline scripts, the no-JS stacked layout
   is the graceful result — that is acceptable and should be noted in the README.)
4. **Data island.** Embed the full bundle as
   `<script type="application/json" class="vpnbt-data">...</script>` inside the
   root (escape `</` as `<\/`). The visible HTML is server-rendered by Python from
   the same data — the island exists so the host app or auditors can extract the
   machine-readable results from the page itself. Strip `parameters.credentials_file`
   and any filesystem paths from the island (paths reveal internal structure);
   keep them in the local bundle only.
5. **Self-identifying.** Root carries `data-generated-at`, `data-period`,
   `data-methodology-version`, `data-bundle-stamp` attributes.
6. Responsive: cards in a CSS grid (`repeat(auto-fit, minmax(280px, 1fr))`), tables
   wrapped in `.vpnbt-scroll { overflow-x: auto; }`; no fixed pixel widths on
   content. Include a `@media print` block (expand all sections, black-on-white,
   hide interactive chrome).

## 3. Page structure (in order)

### Header (`.vpnbt-header`)
Title, analysis period, generation timestamp, methodology version, and the
**status legend** — three chips that the whole page reuses:
`Medido` (measured — solid), `Estimado` (estimated — outlined, shows CI),
`Limite` (bounded — dashed, shows assumption on hover/`<details>`).

### Section 1 — Resumo executivo (business layer, pt-BR, no jargon)
Audience: gestores. Rules of writing: no acronyms without expansion, no "precision/
recall" — use "dos alertas revisados, X de cada 10 tinham indício real de problema"
and "das simulações de ataque do tipo Y, a regra detectou Z%". Content:

- **Three headline tiles**: total de logins analisados; total de usuários; total de
  alertas no período (sum of flagged across rules, with the overlap-deduplicated
  user count).
- **Per-rule cards (5)**, each with: plain-language rule name (e.g. R1 → "Usuário
  com IPs demais"), one-sentence "o que esta regra procura", the alert count and
  alert rate, a **confidence verdict** derived mechanically (see §5), and one
  "próximo passo" line (e.g. "Recomenda-se revisar os N casos convergentes").
  R5 skipped ⇒ card renders in a muted state saying the physical-login table was
  not configured.
- **"Casos convergentes"** highlight: count of users flagged by ≥ 2 rule families,
  presented as the highest-priority review queue (pseudonymized IDs in a
  collapsible list).
- **A mandatory plain-language limitation box** (`.vpnbt-disclaimer`), always
  visible, non-collapsible: "Não existem registros confirmados de fraude neste
  período; os números desta página são medições diretas, estimativas por
  amostragem/simulação e limites sob premissas declaradas — as taxas verdadeiras de
  falso positivo/negativo permanecem indisponíveis." This is the business
  translation of `not_available_without_validated_labels` and must never be
  removed or hidden by default.

### Section 2 — Painel técnico (technical layer)
Tabbed per rule (R1–R5) plus a "Transversal" tab. Per-rule tab contains, in order:

1. The full metric table from the paper's reporting template: flagged count, alert
   rate, percentile extremity, precision ceiling (3 prevalence assumptions), proxy
   agreement (surrogate precision/recall with CIs and the admissible-proxy list),
   injected recall per scenario (CI, `caught_by`), adjudicated precision (CI,
   m, kappa context), near-threshold FN-probe result and recommendation,
   negative-control FPR bound (cohort definition shown in a `<details>`), and the
   literal `true FP/FN: not_available_without_validated_labels` row.
   Every row carries its status chip and, for estimated/bounded, a `<details>`
   with the assumptions list from the bundle.
2. **Threshold sweep chart** — inline SVG line chart (log-scaled y), current
   threshold marked with a vertical line, suggested knee (if any) marked; caption
   states "sem cotovelo claro — limiar arbitrário" when applicable.
3. **Temporal stability chart** — inline SVG bar/line of flagged per bucket with
   the CV and verdict.

"Transversal" tab: overlap matrix rendered as an HTML table heatmap (background
opacity ∝ Jaccard; print-safe since it is inline style), Lincoln–Petersen estimate
with its independence caveat, benign-twin (S5) trigger rates, adjudication
meta (reviewers, overlap fraction, pooled kappa), and parity report summary
(green/red with per-case counts).

### Section 3 — Metodologia e premissas
Static prose (Python string constants, pt-BR): one short subsection per layer
(what it is, what it can and cannot claim), the full assumptions list from the
bundle's `limitations`, and the roadmap-to-real-labels summary (shadow mode, SOC
loop, adjudication store). Link nothing external; cite the .tex by filename.

### Footer
Reproducibility block: parameters table (thresholds, window, period, table — no
credentials, no filesystem paths), git commit, seed, bundle stamp.

## 4. SVG chart helper (inside `htmlreport.py` or `svgchart.py`)

Pure-Python, no deps: `line_chart(series, *, width=560, height=240, x_label,
y_label, marks=[]) -> str` and `bar_chart(...)`. Requirements: viewBox-based
(scales in the grid), axis ticks computed from data range (use 1-2-5 tick
stepping), every chart preceded by a `<figcaption>` and carrying
`role="img"` + `aria-label` describing the takeaway in words, and a data table
fallback in a `<details>` under each chart (accessibility + copy-paste).
Colors: use a colour-blind-safe set (e.g. `#0072B2` measured/series,
`#E69F00` thresholds/marks, `#009E73` positive verdicts, `#D55E00` warnings) and
never encode meaning by colour alone (pair with shape/dash/label).

## 5. Mechanical verdict logic (business layer must not be hand-tuned)

`verdict(rule) -> ("alta" | "média" | "baixa" | "indefinida", reasons[])`,
implemented exactly so the page cannot oversell:

- `alta confiança` requires ALL of: adjudicated precision CI lower bound ≥ 0.5;
  injected recall ≥ 0.8 on every scenario expected to hit the rule; negative-control
  FPR bound ≤ 0.01; temporal verdict `stable`; kappa ≥ 0.4.
- `baixa confiança` if ANY of: adjudicated precision CI upper bound < 0.3;
  negative-control FPR bound > 0.05; benign-twin trigger rate CI lower bound > 0.5
  for this rule; temporal verdict `unstable`.
- `indefinida` if adjudication and injection are both absent (Phase A only).
- else `média`.
- If `reviewer_reliability == "low"`, cap the verdict at `média` and append the
  reason "concordância baixa entre revisores".

Reasons are rendered under the verdict chip. Unit-test this function exhaustively —
it is the single point where numbers become business language.

## 6. Rendering implementation rules

- Build HTML via small pure functions returning strings; escape **every** dynamic
  value with `html.escape` (including pseudonyms and notes — bundle content is
  data, not markup). No f-string interpolation of unescaped values anywhere.
- Handle every optional bundle field gracefully: missing phase ⇒ the corresponding
  blocks render as "não executado nesta rodada" (muted), never as blank or crash.
  The page must render correctly from a Phase-A-only bundle.
- Deterministic output: same bundle ⇒ byte-identical HTML (no timestamps beyond
  those in the bundle).
- Size guard: warn if the artifact exceeds 3 MB (usually an oversized sample list;
  cap embedded lists at 100 entries with "e mais N…" and keep the full data in the
  JSON island only if within budget, else reference the bundle file).
- Tests: assert fragment contains no `<html>`/`<body>` tags, no `http://`/`https://`
  references, no unprefixed class attributes (regex `class="(?!vpnbt-)`), JSON
  island parses back to the bundle subset, and a golden-file test on a fixture
  bundle.

## 7. Host integration notes (write these into `reports/html/README.md`)

Document for the team that owns the host application, in pt-BR: the three inclusion
options (iframe of standalone file — zero risk, recommended; server-side include of
the fragment; template-render of the fragment), the CSP posture (needs
`style-src 'unsafe-inline'`; degrades gracefully without `script-src
'unsafe-inline'`), that each run produces a new immutable stamped file (host can
mount a directory and link the latest), and that the page contains pseudonymized
identifiers only — mapping back to real users requires the on-machine reverse map
and appropriate authorization.
