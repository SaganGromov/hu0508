# 04 — Phase C: adjudicated sampling (expert-relative precision, FN probe)

Implements Layer 3 of the methodology paper. This is the only phase involving
humans; build it so the analyst can run it in three steps: `prepare` → (humans
review offline) → `ingest` → `summarize`.

## 1. Storage

Local SQLite `adjudication/adjudication.db` (gitignored, stays on the company
machine — it contains raw user keys):

```sql
CREATE TABLE samples (
  sample_id TEXT PRIMARY KEY,        -- e.g. 'R1-A-017'
  rule_id TEXT NOT NULL,             -- R1..R5
  stratum TEXT NOT NULL,             -- 'alert' | 'near_threshold'
  user_key TEXT NOT NULL,
  pseudonym TEXT NOT NULL,
  period_start TEXT, period_end TEXT,
  evidence_json TEXT NOT NULL,       -- the numbers that triggered/nearly triggered
  drawn_at TEXT, draw_seed INTEGER
);
CREATE TABLE dispositions (
  sample_id TEXT NOT NULL REFERENCES samples(sample_id),
  reviewer_id TEXT NOT NULL,         -- opaque label: 'REV1', 'REV2'
  disposition TEXT NOT NULL CHECK (disposition IN
    ('plausibly_malicious','benign_explained','undeterminable')),
  rationale TEXT,
  reviewed_at TEXT,
  PRIMARY KEY (sample_id, reviewer_id)
);
```

This database is the seed of the future labelled dataset — it is append-only
(never delete dispositions; corrections are new rows from the same reviewer, latest
`reviewed_at` wins; state this in the module docstring).

## 2. `adjudicate prepare`

Inputs: period, per-rule sample budget `m` (default 50), seed.

For each rule:

- **Alert stratum**: simple random sample (seeded `random.Random`) of `m` flagged
  units — users for R1–R3, user-days for R4, match-pairs for R5. If flagged ≤ m,
  take all (census; record it).
- **Near-threshold stratum** (FN probe): `m/2` units sampled from the band just
  under the threshold — for R1–R3 users with distinct-count exactly equal to the
  threshold (i.e., the maximum non-flagged value) and, if that band is thin, also
  threshold−1; for R4 user-days in `[limit−3, limit]`; for R5 pairs where the
  physical login falls in `(window, 2×window]` hours after the VPN event
  (requires one extra query or extract computation).

Draw everything from the Phase B extract when it exists (cheaper, reproducible);
fall back to DB2 queries otherwise. `evidence_json` must contain everything a
reviewer needs (counts, distinct values involved, first/last timestamps, sample of
the actual events — capped at 20) so review does not require DB2 access.

Outputs, per reviewer (`--reviewers 2` default):

- `adjudication/packet_<reviewer>_<stamp>.csv` — one row per sample:
  `sample_id`, evidence columns flattened, empty `disposition` and `rationale`
  columns to fill in. **Pseudonyms only, no raw user keys**, unless the operator
  passes `--reveal-keys` (for reviewers with data access).
- `adjudication/packet_<reviewer>_<stamp>.md` — the same content in readable form,
  with the three disposition definitions and instructions at the top.
- **Blinding**: shuffle sample order per reviewer (seeded per reviewer); do not
  include `rule_id` or `stratum` in the packet (they stay in `samples` only).
  Both reviewers receive the same overlap subsample: 20% of samples (min 10 per
  rule) go to both, the rest split — this yields the kappa data without doubling
  total effort.

## 3. `adjudicate ingest`

Read a filled packet CSV; validate every `sample_id` exists, disposition is one of
the three values, and reject rows with empty disposition (report them as pending).
Insert into `dispositions`. Idempotent per (sample_id, reviewer): re-ingesting a
corrected packet appends newer rows; latest wins at summarize time.

## 4. `adjudicate summarize`

Per rule and stratum, using each sample's latest disposition per reviewer and
majority across reviewers (ties or lone `undeterminable` ⇒ excluded, counted as
`excluded`):

- **Alert stratum** → `adjudicated_precision`:
  `p̂ = plausibly_malicious / (plausibly_malicious + benign_explained)` with Wilson
  95% CI; report `m_effective`, `excluded`, and — when `plausibly_malicious == 0` —
  the rule-of-three upper bound note.
- **Near-threshold stratum** → `near_threshold_malicious_rate` with Wilson CI, and
  the derived recommendation string: rate CI lower bound > 0.1 ⇒
  `"threshold likely too loose"`; CI upper bound < 0.05 ⇒ `"threshold supported"`;
  else `"inconclusive"`.
- **Inter-rater agreement**: Cohen's kappa on the overlap subsample
  (`stats.cohen_kappa`, 3 categories). Report per rule and pooled. Pooled
  kappa < 0.4 ⇒ set `"reviewer_reliability": "low"` and the report layer must
  soften precision claims (see `05_...`).

Merge into the bundle:

```json
"rules": {"R1": {"adjudicated_precision": {
  "estimate": 0.62, "wilson95": [0.48, 0.74], "m_effective": 47,
  "excluded": 3, "census": false,
  "near_threshold": {"rate": 0.04, "wilson95": [0.01, 0.13],
                       "recommendation": "threshold supported"},
  "status": "estimated",
  "assumptions": ["expert judgement as truth surrogate",
                   "reviewers blinded to triggering rule"]}}},
"adjudication": {"reviewers": 2, "overlap_fraction": 0.2,
                  "cohen_kappa_pooled": 0.71,
                  "reviewer_reliability": "acceptable",
                  "budget": {"R1": 50}, "packets": ["..."]}
```

## 5. Statistics module requirements (`stats.py`, used by all phases)

Implement with stdlib `math` only, each with unit tests against known values:

- `wilson(x, m, z=1.96) -> (lower, upper)`; handle `m == 0` (return `None`) and
  the `x == 0` / `x == m` edges exactly (no division blowups).
- `rule_of_three(m) -> 3/m` (95% upper bound when x=0).
- `sample_size(epsilon, z=1.96) -> ceil(z^2 / (4 * epsilon**2))`.
- `cohen_kappa(pairs) -> float` over category pairs; return `None` when either
  marginal is degenerate (all same category) — do not return 0/NaN silently.
- `percentile_of(sorted_values, x) -> fraction <= x` (used by Phase A).
- `chapman(n1, n2, m) -> N̂` with the `m == 0 ⇒ None` guard.

## 6. Human-facing text in packets (pt-BR)

The packet header must define the three dispositions operationally, e.g.:

- **plausibly_malicious** → "Comportamento incompatível com uso legítimo pelo
  titular (compartilhamento de credencial, automação não autorizada, acesso
  simultâneo impossível). Não exige certeza — exige plausibilidade predominante."
- **benign_explained** → "Há explicação operacional plausível (técnico de suporte,
  múltiplas estações, migração de máquina, rede instável causando relogins)."
- **undeterminable** → "As evidências do pacote não permitem inclinar-se para
  nenhum dos lados."

Also instruct reviewers: judge each case independently, do not discuss cases with
the other reviewer until both packets are returned.
