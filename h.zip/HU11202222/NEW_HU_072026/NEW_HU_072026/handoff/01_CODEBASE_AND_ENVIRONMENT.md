# 01 — Codebase contracts, environment, and CLI refactor

Read this before writing any code. It describes the exact contracts of the existing
modules you will build on, and the one structural refactor (CLI subcommands) that
every phase depends on.

## 1. Environment bootstrap on the company machine

```sh
cd backtest_vpn_local
cp .env.example .env        # then fill in values below
uv sync                     # or: uv run backtest-vpn --help (uv resolves on demand)
```

Connectivity prerequisites (verify before coding; if any fails, stop and report):

1. `../gravar_dados_vpn/db2_credentials.json` exists with non-empty
   `{"username": ..., "password": ...}`.
2. `uv run python -c "import ibm_db"` succeeds (the DB2 driver is a native wheel;
   if it is missing and there is no internet, ask the operator for the wheel file).
3. Smoke query — run the existing backtest over one day and confirm it writes
   reports: `./run_backtest.sh --start 2026-06-01 --end 2026-06-02`.

Default configuration (from `cli.py`; override via `.env` or flags):

| Setting | Default | Env var |
|---|---|---|
| JDBC URL | `jdbc:db2://b2db2g5.plexbs2.bb.com.br:61250/B2DB2G5` | `DB2_JDBC_URL` |
| Schema.table | `DB2PEP.AUT_CPTV` | `DB2_SCHEMA` / `DB2_TABLE` |
| User key column | `CD_USU_AUT` | `VPN_USER_COLUMN` |
| Timestamp column | `TS_TRAN` | `VPN_TIMESTAMP_COLUMN` |
| Source IP column | `CD_END_LGC_OGM` | `VPN_SOURCE_IP_COLUMN` |
| Corporate IP column | `CD_END_LGC_CPTV` | `VPN_CORPORATE_IP_COLUMN` |
| Hostname column | `NM_DSVO` | `VPN_HOSTNAME_COLUMN` |
| Device column | `CD_IDFC_DSVO` | `VPN_DEVICE_COLUMN` |
| Physical table | unset ⇒ R5 skipped | `PHYSICAL_SCHEMA/TABLE/...` |
| Thresholds | distinct=2, daily=10, window=8h, sample=50 | CLI flags only |

## 2. Module contracts you must reuse (not duplicate)

- `db2.fetch_all(conn, sql, params) -> list[dict]` — the **only** way to query DB2.
  Keys are uppercased column names. Values may be `str`, `int`, `Decimal`,
  `datetime`, or `None`; normalize with `report.json_default` semantics when
  serializing.
- `config.normalize_identifier(value, label)` — mandatory gate for every identifier
  you interpolate into SQL. New identifiers (e.g., a geolocation column) must pass
  through it in the config-building step, exactly like the existing ones.
- `rules.qualified`, `rules.ts_params`, `rules.validate_columns` — reuse for any new
  query; `rules._count_wrapping` shows the count-over-subquery pattern.
- `rules.BacktestCaseResult(name, status, count, sample, note)` — keep returning
  this shape for anything case-like so `report.py` keeps working.
- `report.write_json` / `report.json_default` — use for all JSON artifacts.

DB2 SQL dialect notes that will bite you if forgotten:

- Timestamp arithmetic: `TS + 8 HOURS`, `TS + 5 MINUTES` (labeled durations).
- Pagination: `FETCH FIRST n ROWS ONLY` (no `LIMIT`).
- `TRIM()` user keys everywhere (columns are CHAR-padded); `NULLIF(TRIM(x), '')`
  before `COUNT(DISTINCT ...)` — see `rules._distinct_expr`.
- The catalog check falls back from `SYSCAT.COLUMNS` (LUW) to `SYSIBM.SYSCOLUMNS`
  (z/OS) — this codebase may be talking to z/OS; do not use LUW-only SQL features
  (e.g., `LISTAGG` availability differs; prefer plain aggregation + Python).
- Window functions (`ROW_NUMBER() OVER ...`) are available on both platforms and
  may be used; `LAG/LEAD` availability on old z/OS versions is uncertain — prefer
  self-joins or Python post-processing when in doubt, and verify with a probe query
  before committing to a construct.

## 3. New modules to create (all under `src/backtest_vpn/`)

| Module | Phase | Purpose |
|---|---|---|
| `stats.py` | A–C | Wilson CI, rule of three, Cohen's kappa, Lincoln–Petersen, percentile helpers. Pure stdlib, fully unit-tested. |
| `pseudonym.py` | A | HMAC-SHA256 pseudonymizer with key management (§7 of `02_...`). |
| `labelfree.py` | A | Alert rates, threshold sweeps, temporal stability, overlap matrix, negative-control cohort. |
| `proxies.py` | A | The four proxy labelling functions + admissibility matrix + agreement computation. |
| `extract.py` | B | DB2 → local SQLite extract of the analysis period. |
| `local_rules.py` | B | Pure-Python reimplementation of R1–R5 over the extract + parity check vs DB2. |
| `scenarios.py` | B | Synthetic scenario generators (seeded RNG). |
| `inject.py` | B | Injection harness: augment extract copy, rerun `local_rules`, compute recall. |
| `adjudication.py` | C | Sample drawing, reviewer packet writer, disposition ingestion, precision/kappa. |
| `bundle.py` | A–C | Builds/merges `results_bundle_<stamp>.json` (single source for HTML). |
| `htmlreport.py` | D | Bundle → standalone + fragment HTML (spec in `05_...`). |

Add unit tests under `backtest_vpn_local/tests/` (stdlib `unittest`, run with
`uv run python -m unittest discover -s tests`). Statistical functions, scenario
generators, `local_rules` (against fixture rows), and the HTML generator (string
assertions) are all testable without DB2. Anything needing DB2 gets a
`@unittest.skipUnless(os.environ.get("DB2_TESTS"), ...)` guard.

## 4. CLI refactor (do this first)

Convert `cli.py` to subcommands while preserving the legacy invocation:

```
backtest-vpn run          --start S --end E [existing flags]   # today's behavior
backtest-vpn labelfree    --start S --end E [flags] [--sweep ...]
backtest-vpn extract      --start S --end E --out extracts/period.sqlite
backtest-vpn parity       --start S --end E --extract extracts/period.sqlite
backtest-vpn inject       --extract ... --scenarios all --n 30 --seed 20260719
backtest-vpn adjudicate   prepare|ingest|summarize [flags]
backtest-vpn bundle       --from reports/ --out reports/results_bundle_<stamp>.json
backtest-vpn full         --start S --end E [flags]   # run+labelfree+extract+parity+inject+bundle
backtest-vpn report-html  --bundle ... [--fragment-only|--standalone-only] [--lang pt-BR]
```

Compatibility shim: if `argv` contains no known subcommand but does contain
`--start`, prepend `"run"`. Keep `run_backtest.sh` working without edits.

Shared flags (`--start/--end`, table config, credentials) move to a parent parser
reused by subcommands. `_build_config` stays the single place that produces
`BacktestConfig`; extend the dataclass rather than passing loose kwargs. New config
fields needed later (add now, with defaults): `sweep_distinct_limits: list[int]`
(default `[1,2,3,5,8,13,21]`), `sweep_daily_limits: list[int]` (default
`[5,10,20,50,100]`), `sweep_window_hours: list[int]` (default `[1,2,4,8,12,24]`),
`stability_granularity: str` (`"week"`), `velocity_minutes: int` (default 5),
`dormancy_days: int` (default 60), `seed: int` (default 20260719),
`clean_cohort_min_events: int` (default 20).

## 5. Operational cautions for DB2 queries

- The auth table may be large. Every new query must be bounded by the period
  predicate on the timestamp column (`>= ? AND < ?`), like the existing ones.
  Self-joins (velocity proxy) must carry the period predicate **on both sides**
  plus the tight time-window join condition.
- Run heavyweight queries once on a 1-day window first; only then on the full
  period. If a query is unacceptably slow, fall back to computing that metric on
  the local extract (Phase B) instead of in DB2 — the extract is the same data.
- Never `SELECT *`; name columns explicitly (also keeps the extract schema stable).
