# Handoff package — VPN backtest without ground truth

Instructions for an AI coding agent on the **company machine** (with DB2 access) to
implement the label-free backtest methodology defined in
`docs/vpn_backtest_without_ground_truth.tex` and produce the final embeddable HTML
report.

Reading order (the agent must read 00 first; the rest are phase specs):

| File | Contents |
|---|---|
| `00_MISSION.md` | Goal, repo map, security invariants, conventions, definition of done |
| `01_CODEBASE_AND_ENVIRONMENT.md` | Existing module contracts, DB2 dialect notes, environment bootstrap, CLI subcommand refactor |
| `02_LABELFREE_METRICS_AND_PROXIES.md` | Phase A: alert rates, sweeps, stability, overlap, negative controls, proxy labels; results-bundle schema; pseudonymization |
| `03_SYNTHETIC_INJECTION.md` | Phase B: DB2→SQLite extract, pure-Python rule parity gate, seeded attack scenarios, recall with CIs |
| `04_ADJUDICATION.md` | Phase C: blinded reviewer sampling, disposition ingestion, precision/kappa; `stats.py` spec |
| `05_HTML_REPORT_PAGE.md` | Phase D: the modular business+technical HTML page (standalone + embeddable fragment) |
| `06_ACCEPTANCE_CHECKLIST.md` | Acceptance checks per phase and the final run book |

Suggested kickoff prompt for the agent:

> Read `handoff/00_MISSION.md` and follow the handoff package in order. Do not
> violate the security invariants in §"Security & correctness invariants". Ask me
> the questions listed in §"Things you must ask the human operator" before running
> anything against DB2.
