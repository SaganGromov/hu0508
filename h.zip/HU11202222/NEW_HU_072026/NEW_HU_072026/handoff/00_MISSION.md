# MISSION BRIEF — Implement the "next best thing" VPN backtest without ground truth

You are an AI coding agent running on a **company computer with connectivity to DB2**.
Your job is to extend an existing, working Python application so that its VPN-rule
backtest — which today reports false-positive/false-negative rates as
`not_available_without_validated_labels` — instead delivers the best label-free
substitute evidence, and to generate a **modular HTML report page** consumable by both
technical and business audiences.

Read this file first, then the numbered files in order. Each file is self-contained
enough to implement its phase; this file gives the invariants that apply to all of them.

## Repository map (already implemented, do not break)

```
backtest_vpn_local/
  pyproject.toml            # package: backtest_vpn, runs with uv, Python >= 3.9
  run_backtest.sh           # wrapper: uv run backtest-vpn --start ... --end ...
  src/backtest_vpn/
    config.py               # dataclasses, .env loader, identifier validation
    db2.py                  # ibm_db connect / fetch_all(list[dict]) / close
    rules.py                # the 5 rule cases (R1..R5), read-only SQL
    report.py               # JSON + pt-BR Markdown report writers
    cli.py                  # single-command argparse CLI
docs/
  vpn_backtest_without_ground_truth.tex   # the methodology paper you are implementing
handoff/                    # these instructions
```

The methodology paper (`docs/vpn_backtest_without_ground_truth.tex`) is the
**normative source** for what to compute and why. These handoff files translate it
into an implementation plan. If they ever conflict, follow the paper's methodology
and the security invariants below.

## The five existing rules (names as emitted in reports)

| ID | Report name | Logic |
|----|-------------|-------|
| R1 | `ips_distintos_acima_do_limite` | user has > `distinct_limit` distinct source **or** corporate IPs in period |
| R2 | `hostnames_distintos_acima_do_limite` | user has > `distinct_limit` distinct hostnames |
| R3 | `dispositivos_distintos_acima_do_limite` | user has > `distinct_limit` distinct device IDs |
| R4 | `logins_diarios_acima_do_limite` | user-day pairs with > `daily_login_limit` logins |
| R5 | `vpn_ativa_com_login_em_rede_fisica` | VPN event followed within `active_window_hours` by a physical-network login for the same user key |

## What you will build (four phases + report)

1. **Phase A — Label-free metrics & proxy labels** (`handoff/02_...`): alert rates,
   percentile extremity, threshold sweeps, temporal stability, cross-rule overlap,
   negative-control cohort bound, plus 4 proxy labelling functions and the surrogate
   agreement matrix. All read-only SQL against DB2.
2. **Phase B — Synthetic injection** (`handoff/03_...`): extract the period to a local
   working copy, reimplement the 5 rules in pure Python, **prove parity** against the
   DB2 counts, inject synthetic attack scenarios into the copy, measure per-scenario
   recall with Wilson intervals.
3. **Phase C — Adjudication harness** (`handoff/04_...`): stratified random samples of
   alerts and near-threshold non-alerts, reviewer packets, ingestion of dispositions,
   precision estimates with Wilson CIs, Cohen's kappa.
4. **Phase D — HTML report page** (`handoff/05_...`): a single self-contained,
   embeddable `.htm` generated in Python from a consolidated JSON bundle, with an
   executive (business) layer and a technical layer.

Every phase writes its results into one consolidated
`reports/results_bundle_<stamp>.json` (schema in `handoff/02_...` §6, extended by
each later phase). The HTML generator reads **only** that bundle — never DB2.

## Security & correctness invariants (non-negotiable)

1. **DB2 is read-only.** Only `SELECT` statements. No DDL, DML, temp tables, or
   stored-procedure calls. Synthetic injection happens exclusively on the local
   extract file, never in DB2.
2. **No LDAP or any enforcement action.** This is simulation/backtesting only.
3. **SQL identifier discipline (existing convention — keep it):** every schema/table/
   column name interpolated into SQL must first pass
   `config.normalize_identifier` (regex `^[A-Z][A-Z0-9_]*$`). Every literal value
   (dates, thresholds, network value) goes through `?` parameter binding via
   `db2.fetch_all`. No exceptions, including in new modules.
4. **Credentials** come only from the JSON credentials file already supported by
   `config.load_credentials`. Never print, log, or serialize them; never put them in
   the results bundle or reports (follow `cli._parameters_payload`'s example).
5. **Pseudonymize user identifiers in every artifact that may leave the analyst's
   machine** (the HTML page, the results bundle, reviewer packets that go to
   non-privileged reviewers). Use HMAC-SHA256 over the trimmed user key with a local
   secret (see `02_...` §7). Raw keys may appear only in the local adjudication
   store, which stays on the company machine.
6. **Reproducibility:** every artifact embeds the run parameters (like the existing
   `parameters` payload), the git commit of the code, and a `methodology_version`
   string. Same inputs ⇒ same outputs (fix random seeds; see Phase B/C).
7. **Honest labelling of every number:** each metric in the bundle carries
   `"status": "measured" | "estimated" | "bounded"` and an `"assumptions"` list.
   The literal string `not_available_without_validated_labels` must still be
   reported for the *true* FP/FN rates. You are adding substitutes, not replacing
   the disclaimer.
8. **Backwards compatibility:** `backtest-vpn --start ... --end ...` (the current
   invocation and `run_backtest.sh`) must keep working unchanged.

## Conventions

- Python >= 3.9, stdlib-first. Allowed third-party deps: `ibm_db` (already used).
  Do **not** add pandas/numpy/matplotlib/jinja2 unless already installed and the
  operator approves — the company machine may have no internet for `pip`. Everything
  specified here is implementable with the stdlib (`sqlite3`, `random`, `statistics`,
  `hmac`, `json`, `html`, `math`).
- Match the existing code style: pt-BR docstrings/comments, `str.format()` strings,
  dataclasses, small pure functions, module-level SQL builders.
- User-facing report text (Markdown, HTML business layer) in **pt-BR**, consistent
  with `report.py`. Technical HTML layer may mix pt-BR prose with English terms
  (precision, recall, Wilson CI). Code identifiers in English is fine.
- CLI: refactor `cli.py` into subcommands (see `01_...` §4) while keeping the
  no-subcommand invocation working.
- Timestamps in artifacts: `YYYY-MM-DD HH:MM:SS`, stamps `YYYYMMDD_HHMMSS`
  (existing convention).

## Things you must ask the human operator (do not guess)

- The physical-login table configuration (`PHYSICAL_*` env/flags) if the R5 case is
  to run; without it, R5 stays `skipped` and every downstream artifact must show it
  as such, not fail.
- Whether IP-geolocation data is available in any DB2 table (it changes the velocity
  proxy from "simultaneous different IPs" to true impossible-travel; default to the
  geolocation-free variant).
- The HMAC pseudonymization secret's storage location (default:
  `backtest_vpn_local/.pseudonym_key`, chmod 600, gitignored).
- Who the adjudication reviewers are and the sample budget (default: 50 per rule).
- Approval before installing any package.

## Definition of done

All acceptance checks in `handoff/06_ACCEPTANCE_CHECKLIST.md` pass, and a full run

```sh
cd backtest_vpn_local
uv run backtest-vpn full --start 2026-06-01 --end 2026-07-01
uv run backtest-vpn report-html --bundle reports/results_bundle_<stamp>.json
```

produces: the legacy JSON+MD reports, the consolidated results bundle, and both the
standalone and fragment HTML artifacts, with no writes to DB2 and no raw user keys
in any of them.
