# 06 — Acceptance checklist and run book

Work through this top to bottom on the company machine. Every box must be checked
(or explicitly waived by the operator, recorded in `handoff/WAIVERS.md`) before the
task is considered delivered.

## A. Safety / invariants

- [ ] `grep` audit: no SQL string in the codebase contains `INSERT`, `UPDATE`,
      `DELETE`, `CREATE`, `DROP`, `MERGE`, `CALL`, or `TRUNCATE` targeting DB2
      (SQLite-local statements live only in `extract.py`, `inject.py`,
      `adjudication.py`, and are never passed to `db2.fetch_all`).
- [ ] Every DB2 query routes through `db2.fetch_all`/`fetch_iter`; every
      interpolated identifier passes `normalize_identifier`; every literal uses `?`
      binding. (Add a unit test that scans built SQL strings for date literals.)
- [ ] No credentials, passwords, or `.pseudonym_key` content in: reports, bundle,
      HTML, logs, git. `.gitignore` covers `extracts/`, `adjudication/`,
      `.pseudonym_key`, `reverse_map_*.json`, `reports/`.
- [ ] Raw user keys absent from: results bundle, both HTML artifacts, reviewer
      packets (default mode). Verified by the `--key-regex` assertion plus a manual
      spot check.
- [ ] Legacy invocation `./run_backtest.sh --start 2026-06-01 --end 2026-06-02`
      still produces the original JSON+MD reports unchanged in shape.

## B. Phase A — label-free metrics & proxies

- [ ] `backtest-vpn labelfree` completes on a 1-day window, then on the full
      period; partial bundle written after each section; a simulated query failure
      yields `status: "error"` for that metric and the run continues.
- [ ] Alert rates, percentile extremity, precision ceilings present for R1–R4
      (R5 present or cleanly `skipped`).
- [ ] Threshold sweeps monotone non-increasing in k (sanity), knee detection
      unit-tested, "no knee" case handled.
- [ ] Temporal stability buckets cover the period with no gaps; CV computed.
- [ ] Overlap matrix symmetric, diagonal = flagged counts; Chapman estimator
      guarded for m=0.
- [ ] Negative-control cohorts respect the circularity table (R2/R3 evaluated only
      on the alternative cohort); Wilson upper bounds reported.
- [ ] Proxy admissibility matrix enforced in code (attempting to compute agreement
      of P1 against R1 raises).
- [ ] Every metric leaf carries `status` and (for estimated/bounded) `assumptions`.

## C. Phase B — extract, parity, injection

- [ ] Extract row count equals the DB2 `run_summary` total for the same period
      (recorded in `extract_meta`).
- [ ] **Parity gate green**: all 5 case counts identical between DB2 and
      `local_rules` on the real extract. Parity report stored and referenced by
      hash in the injection output.
- [ ] `inject` refuses to run without a green parity report for the extract.
- [ ] Injection never modifies the original extract file (hash before/after).
- [ ] Clean-extract control run reproduces the parity flagged sets exactly.
- [ ] Same seed ⇒ byte-identical scenario rows and identical recall numbers.
- [ ] S1–S4 recall reported with Wilson CIs; S5 reported as benign-twin trigger
      rate, kept out of every recall aggregate.
- [ ] Synthetic user prefix collision check ran and is recorded.

## D. Phase C — adjudication

- [ ] `prepare` produces blinded, shuffled packets (no rule_id/stratum columns);
      overlap subsample ≥ 20% (min 10/rule) assigned to both reviewers.
- [ ] `ingest` rejects invalid dispositions and unknown sample_ids; re-ingestion is
      idempotent (latest wins).
- [ ] `summarize` computes Wilson CIs, rule-of-three note when x=0, kappa (with
      degenerate-marginal guard), and the three-way threshold recommendation.
- [ ] Adjudication DB is append-only in code (no DELETE/UPDATE statements).
- [ ] `stats.py` unit tests pass against hand-checked values (e.g.
      wilson(8,10) ≈ (0.490, 0.943); kappa of perfect agreement = 1.0; chapman
      guard returns None for m=0).

## E. Phase D — HTML page

- [ ] Standalone file opens from disk with network access disabled (verify: no
      requests in browser devtools; automated test: no `http` substring).
- [ ] Fragment contains exactly one root div, only `vpnbt-` classes, an IIFE-only
      script, and a parseable JSON island without credentials or filesystem paths.
- [ ] Page renders correctly from a Phase-A-only bundle (missing phases shown as
      "não executado"), and from the full bundle.
- [ ] With JavaScript disabled, all content is visible (stacked layout).
- [ ] Verdict function unit tests cover all branches, including the kappa cap.
- [ ] The `not_available_without_validated_labels` row and the non-collapsible
      limitation box are present in both artifacts (automated string assertion).
- [ ] Charts have aria-labels, captions, and `<details>` data tables; meaning never
      encoded by colour alone.
- [ ] Print preview: single-column, all sections expanded, legible in grayscale.
- [ ] `reports/html/README.md` written (host integration notes, pt-BR).
- [ ] Golden-file test: fixture bundle ⇒ byte-identical HTML.

## F. Final run book (execute in order, keep the outputs)

```sh
cd backtest_vpn_local
uv run python -m unittest discover -s tests                     # all green
./run_backtest.sh --start 2026-06-01 --end 2026-06-02           # legacy smoke
uv run backtest-vpn full --start 2026-06-01 --end 2026-07-01    # A+B+bundle
uv run backtest-vpn adjudicate prepare --budget 50 --reviewers 2
# ... human review happens; then:
uv run backtest-vpn adjudicate ingest --packet adjudication/packet_REV1_*.csv
uv run backtest-vpn adjudicate ingest --packet adjudication/packet_REV2_*.csv
uv run backtest-vpn adjudicate summarize --merge-bundle reports/results_bundle_*.json
uv run backtest-vpn report-html --bundle reports/results_bundle_*.json
```

- [ ] Deliverables present: legacy JSON+MD, `results_bundle_<stamp>.json`,
      `parity_<stamp>.json`, standalone + fragment HTML, host README, adjudication
      DB (on-machine only).
- [ ] Write `handoff/RUN_NOTES.md`: what ran, wall-clock per phase, any waived
      checks, any DB2 constructs that failed and their fallbacks, and open
      questions for the operator. Commit code + handoff notes; never commit
      extracts, adjudication data, keys, or reports containing pseudonym reverse
      maps.
