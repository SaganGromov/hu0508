# 03 — Phase B: local extract, rule parity, and synthetic attack injection

Implements Layer 2 of the methodology paper: recall estimation via seeded synthetic
attacks. **Nothing in this phase writes to DB2.** All mutation happens on local
SQLite copies.

## 1. Extract (`extract.py`, subcommand `extract`)

One pass over the period pulling the exact rule-relevant columns:

```sql
SELECT TRIM({user}) AS USER_KEY, {ts} AS TS,
       TRIM({src_ip}) AS SRC_IP, TRIM({corp_ip}) AS CORP_IP,
       TRIM({host}) AS HOSTNAME, TRIM({dev}) AS DEVICE_ID
FROM {table} WHERE {ts} >= ? AND {ts} < ?
```

plus, when configured, the physical table (`USER_KEY, TS, NETWORK` with the
network filter applied only at rule time, not at extract time — extract the raw
column). Write to `extracts/period_<start>_<end>.sqlite`:

- Table `vpn_events(user_key TEXT, ts TEXT, src_ip TEXT, corp_ip TEXT,
  hostname TEXT, device_id TEXT, synthetic INTEGER DEFAULT 0,
  scenario_id TEXT DEFAULT NULL)`.
- Table `physical_events(user_key TEXT, ts TEXT, network TEXT,
  synthetic INTEGER DEFAULT 0, scenario_id TEXT DEFAULT NULL)`.
- Table `extract_meta(key TEXT, value TEXT)` holding parameters, row counts,
  extraction timestamp, git commit.
- `ts` stored as `YYYY-MM-DD HH:MM:SS` strings (lexicographic order == time order).
- Indexes: `(user_key, ts)` on both tables.

Stream with `fetch_assoc` in the existing `fetch_all` style but **paged**: add
`db2.fetch_iter(conn, sql, params, batch=50_000)` (generator) to avoid holding the
period in memory; insert with `executemany` in transactions of 50k rows.

The extract contains raw user keys and stays on the company machine
(`extracts/` goes into `.gitignore`). Pseudonymization applies to *outputs*, not to
the working extract.

## 2. Pure-Python rules (`local_rules.py`) and the parity gate

Reimplement R1–R5 over the SQLite extract with **identical semantics** to
`rules.py` (same trims, same `NULLIF` empty-string exclusion, same `>` vs `>=`,
same OR over the two IP columns in R1, same half-open period, same
`[vpn_ts, vpn_ts + window_hours)` join window and network filter for R5, and the
same counting units — R1–R3 count users, R4 counts user-days, R5 counts matches).
SQLite SQL is fine (it is local); mirror the DB2 statements rather than inventing
new logic.

**Parity gate (subcommand `parity`, mandatory before any injection claim):** run
`rules.run_backtest_cases` against DB2 and the local rules against the extract for
the same period/thresholds; assert every case count matches exactly. Emit
`reports/parity_<stamp>.json` with per-case DB2 count, local count, and verdict.
If any case mismatches: stop, diagnose (usual causes: timestamp precision/timezone
formatting, CHAR padding, NULL vs empty string, boundary events at `end`), fix, and
rerun. Injection results are invalid without a green parity report, and
`inject` must refuse to run if the newest parity report for that extract is not
green (store the extract's file hash in the parity report to bind them).

## 3. Scenario library (`scenarios.py`)

Deterministic generators, all driven by `random.Random(seed + scenario_index)`.
Synthetic user keys: `ZSYN` + 4 digits — first **verify no real key matches
`ZSYN%`** in the extract; if collision, switch prefix and record it in meta.
Every synthetic row gets `synthetic=1` and its `scenario_id`.

Timestamps are drawn inside the extract period, weekday business hours by default,
with jitter; volumes drawn from the stated ranges. Each generator returns
`(vpn_rows, physical_rows, expected_rules)`.

| ID | Scenario | Signature (per instance) | expected_rules |
|----|----------|--------------------------|----------------|
| S1 | Credential sharing | 1 synthetic user; 3–6 source IPs, 3–6 hostnames, 2–4 devices interleaved over 5–15 days, 4–12 events/day | R1, R2, R3 |
| S2 | Scripted burst | 1 synthetic user; 50–200 logins in one day, inter-arrival = base 30–120 s with ±5% jitter, 1 IP/host/device | R4 |
| S3 | On-site hijack | 1 synthetic user; VPN event, then a physical event for the same key 10 min – (window−1 h) later, network column = configured `network_value`; 1–3 repetitions | R5 (only when physical table configured; else generator marks itself `skipped`) |
| S4 | Slow takeover | 1 synthetic user; baseline 1 device/host/IP for 2 weeks, then a second device+IP appears with 2–5 events/week | expected **none** at default thresholds — a sensitivity probe; report which rules fire anyway |
| S5 | Benign twin: heavy traveller | 1 synthetic user; 4–8 source IPs but exactly 1 hostname and 1 device, ≤ 6 logins/day | fires-expected: R1. Reported separately as **benign-twin trigger rate**, not recall |

`n >= 30` instances per scenario (config `--n`, default 30), each with an
independent sub-seed.

## 4. Injection harness (`inject.py`, subcommand `inject`)

1. Copy the extract file to `extracts/injected_<stamp>.sqlite` (never mutate the
   original; `shutil.copyfile`).
2. Generate all instances; insert their rows.
3. Run `local_rules` on the injected copy with production thresholds.
4. Per instance, detection = the instance's synthetic user key appears in the
   flagged set of an expected rule (for S3: any of its matches surfaces in R5's
   match set). Record which rules fired, expected or not.
5. Per scenario: `recall = detected / n` with Wilson 95% CI (`stats.wilson`);
   plus `caught_by` histogram. For S5: `trigger_rate` per rule with CI.
6. Sanity control: rerun local rules on the *clean* extract and assert the flagged
   sets are unchanged from the parity run (guards against harness bugs).
7. Merge into the bundle under `injection`:

```json
"injection": {
  "seed": 20260719, "n_per_scenario": 30,
  "parity_report": "parity_<stamp>.json", "parity_green": true,
  "scenarios": {
    "S1": {"name": "credential_sharing", "n": 30, "detected": 30,
            "recall": 1.0, "wilson95": [0.884, 1.0],
            "caught_by": {"R1": 30, "R2": 28, "R3": 22},
            "status": "estimated",
            "assumptions": ["synthetic pattern resembles real credential sharing"]},
    "S5": {"kind": "benign_twin", "trigger_rate": {"R1": [0.9, [0.74, 0.97]]}}
  }
}
```

Per-rule rollup: `rules.Ri.injected_recall` = recall over instances whose
`expected_rules` include Ri.

**Framing rule for all outputs:** injected recall is *conditional on the scenario
library*; the wording in reports must be "detecta X% dos cenários simulados de
<tipo>", never "detecta X% das fraudes".

## 5. Tests

- Generator determinism: same seed ⇒ identical rows.
- Each generator's output actually satisfies its signature (e.g., S2 inter-arrival
  CV < 0.1 — this also exercises `stats`).
- `local_rules` fixture tests: hand-built 20-row extracts with known expected
  flags for each rule, including boundary cases (exactly at threshold ⇒ not
  flagged, one above ⇒ flagged; event at `end` timestamp excluded).
- End-to-end on a fixture extract: inject S1–S5 with n=5 and assert the recall
  bookkeeping is consistent (no DB2 needed).
