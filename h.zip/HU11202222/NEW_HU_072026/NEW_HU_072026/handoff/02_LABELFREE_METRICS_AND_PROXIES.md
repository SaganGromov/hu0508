# 02 — Phase A: label-free metrics, negative controls, and proxy labels

Implements Layers 1 and 4 of the methodology paper. Everything here is read-only
SQL against DB2 (plus Python post-processing) and can run before any extract exists.
Deliverable: `labelfree` subcommand output merged into the results bundle.

## 1. Population and per-user base statistics

One grouped query over the period producing, per user key:
`events`, `distinct_source_ips`, `distinct_corporate_ips`, `distinct_hostnames`,
`distinct_devices`, `active_days`, `max_daily_logins`, `first_ts`, `last_ts`.

```sql
SELECT TRIM(u.{user}) AS USER_KEY,
       COUNT(1) AS EVENTS,
       COUNT(DISTINCT NULLIF(TRIM({src_ip}), ''))  AS D_SRC_IP,
       COUNT(DISTINCT NULLIF(TRIM({corp_ip}), '')) AS D_CORP_IP,
       COUNT(DISTINCT NULLIF(TRIM({host}), ''))    AS D_HOST,
       COUNT(DISTINCT NULLIF(TRIM({dev}), ''))     AS D_DEV,
       COUNT(DISTINCT DATE({ts}))                  AS ACTIVE_DAYS,
       MIN({ts}) AS FIRST_TS, MAX({ts}) AS LAST_TS
FROM {table} u
WHERE {ts} >= ? AND {ts} < ?
GROUP BY TRIM(u.{user})
```

`max_daily_logins` needs a second grouped query (`GROUP BY user, DATE(ts)` then a
Python max per user) — do that reduction in Python from the daily query you already
need for stability (§3). Hold the per-user table in memory (one dict per user); if
the user population is too large (> ~2M), stream to a temporary local SQLite table
instead — never a DB2 temp table.

From this table compute, in Python (`labelfree.py`):

- **Alert rate per rule**: `flagged_users / total_users` (R1–R3 from the distinct
  counts vs `distinct_limit`; R4 as both user-level and user-day-level rates; R5
  from the existing case count vs total users).
- **Percentile extremity**: for each rule, the percentile of each flagged user's
  triggering statistic within the full user population (empirical CDF; report
  median and minimum percentile among flagged users). Use `stats.percentile_of`.
- **Base-rate precision ceiling** (bounded): `min(1, pi / alert_rate)` for assumed
  prevalences `pi ∈ {0.0001, 0.001, 0.01}`. Report all three; label
  `status="bounded"`, assumption `"fraud prevalence <= pi"`.

## 2. Threshold sweeps

Recompute flagged counts across the configured grids **in Python from the per-user
table** (no extra DB2 queries needed for R1–R4):

- R1: users with `max(D_SRC_IP, D_CORP_IP) > k` for k in `sweep_distinct_limits`
  (match production semantics: the rule's HAVING is an OR over the two columns).
- R2/R3: same with `D_HOST` / `D_DEV`.
- R4: from the per-user-day counts, user-days `> k` for k in `sweep_daily_limits`.
- R5: needs DB2 (one query per window value in `sweep_window_hours`, reusing the
  existing R5 SQL with the window parameterized). Skip cleanly when the physical
  table is not configured.

Emit each sweep as `[{ "threshold": k, "flagged": n, "rate": r }, ...]` and compute
a knee point: the k maximizing the second difference of `log(1+flagged)`; report it
as `suggested_threshold` with `status="measured"`, and flag when the curve has no
knee (monotone smooth decay ⇒ threshold is arbitrary — the report must say so).

## 3. Temporal stability

One DB2 query grouped by user and day (also feeds §1 and R4 sweeps):

```sql
SELECT TRIM({user}) AS USER_KEY, DATE({ts}) AS D, COUNT(1) AS LOGINS
FROM {table} WHERE {ts} >= ? AND {ts} < ?
GROUP BY TRIM({user}), DATE({ts})
```

Bucket days into ISO weeks (or `stability_granularity`). Per bucket, recompute each
rule's flagged-user count **within that bucket alone** (R1–R3 need per-bucket
distinct counts — one more DB2 query grouped by user and week using
`VARCHAR_FORMAT({ts}, 'IYYY-IW')` if available, else compute from the extract in
Phase B and mark this metric `pending_extract` until then; probe the function first).
Report per rule: bucket series, mean, coefficient of variation. CV > 0.5 ⇒ flag
`"unstable"` in the bundle.

## 4. Cross-rule overlap and capture–recapture

From the flagged-user sets of R1–R4 (R5 flags user keys too — use its user set):

- **Overlap matrix**: 5×5 matrix of `|Ri ∩ Rj|`, plus Jaccard. Also emit the
  "convergent tier": users flagged by ≥ 2 rules from *different families*
  (families: {R1,R2,R3} counting-based; {R4} volume; {R5} contradiction), with
  pseudonymized IDs and which rules fired.
- **Lincoln–Petersen** (supplementary, `status="estimated"`, assumption
  `"independent detection families"`): with `n1 = |R1∪R2∪R3|`, `n2 = |R4∪R5|`,
  `m = |(R1∪R2∪R3) ∩ (R4∪R5)|`, use the Chapman estimator
  `N̂ = ((n1+1)(n2+1)/(m+1)) - 1`; implied recall of the union = `|union| / N̂`.
  If `m == 0`, emit `null` with note "no overlap; estimator undefined".

## 5. Negative-control cohort (FPR bound)

Cohort definition (pure SQL over §1's per-user table semantics): users with
`EVENTS >= clean_cohort_min_events`, `D_HOST = 1`, `D_DEV = 1`, `D_CORP_IP <= 1`,
and `ACTIVE_DAYS >= 10`. These are "one machine, steady rhythm" users.
**Circularity guard:** this cohort may only evaluate rules whose trigger columns are
not pinned by the cohort definition — that means it can evaluate **R1 (source IP
facet), R4, and R5** but NOT R2/R3 (hostname/device are fixed at 1 by construction).
For R2/R3 build the alternative cohort `D_SRC_IP = 1, D_CORP_IP <= 1, EVENTS >= 20,
ACTIVE_DAYS >= 10` (pins IPs, leaves hostnames/devices free).

Report per rule: cohort size, flagged-in-cohort count, `fpr_bound = flagged/size`
with a Wilson upper bound; `status="bounded"`, assumption
`"cohort fraud prevalence ~ 0"`. If cohort size < 200, also report the rule-of-three
caveat (`3/size` floor on detectable FPR).

## 6. Results bundle schema (started here, extended by later phases)

`reports/results_bundle_<stamp>.json` — top-level:

```json
{
  "bundle_version": 1,
  "methodology_version": "next-best-thing/1.0",
  "generated_at": "...", "git_commit": "...",
  "parameters": { ...same as legacy report... },
  "pseudonymization": {"algorithm": "HMAC-SHA256", "key_id": "..."},
  "summary": { ...legacy metrics incl. not_available_without_validated_labels... },
  "rules": {
    "R1": {
      "name": "ips_distintos_acima_do_limite",
      "flagged": 0, "alert_rate": 0.0,
      "percentile_extremity": {"median": 0.0, "min": 0.0},
      "precision_ceiling": [{"pi": 0.001, "ceiling": 0.0}],
      "threshold_sweep": [], "suggested_threshold": null,
      "temporal_stability": {"buckets": [], "cv": 0.0, "verdict": "stable"},
      "negative_control": {"cohort": "...", "size": 0, "flagged": 0,
                            "fpr_bound_wilson95_upper": 0.0},
      "proxy_agreement": null,        // filled by §8
      "injected_recall": null,        // Phase B
      "adjudicated_precision": null,  // Phase C
      "true_rates": "not_available_without_validated_labels",
      "status_tags": {"alert_rate": "measured", "fpr_bound": "bounded", "...": "..."}
    },
    "R2": {}, "R3": {}, "R4": {}, "R5": {}
  },
  "cross_rule": {"overlap_matrix": [], "jaccard": [], "convergent_users": [],
                  "lincoln_petersen": {}},
  "proxies": {},      // §8
  "injection": {},    // Phase B
  "adjudication": {}, // Phase C
  "limitations": ["..."]
}
```

Every numeric leaf that is not raw bookkeeping carries a status tag. `bundle.py`
owns this schema; phases merge into an existing bundle by stamp.

## 7. Pseudonymization (`pseudonym.py`)

- Key: 32 random bytes, hex-encoded, stored at `backtest_vpn_local/.pseudonym_key`
  (create with `os.urandom` on first use, `chmod 600`, add to `.gitignore`).
  `key_id` = first 8 hex chars of SHA-256 of the key.
- `pseudonymize(user_key) -> "U-" + hmac_sha256(key, trim(user_key).upper()).hexdigest()[:12]`.
- Deterministic within a key ⇒ joins across artifacts still work; the same key must
  be used for all phases of one engagement.
- A local, gitignored `reverse_map_<stamp>.json` (pseudonym → real key) may be
  written **only** when the operator passes `--write-reverse-map`, for internal
  investigation follow-up.

## 8. Proxy labels (`proxies.py`)

Four labelling functions over the period, each returning a set of pseudo-positive
user keys plus per-user evidence rows (samples capped at `sample_limit`):

| ID | Proxy | Definition | Admissible for (non-circular) |
|----|-------|------------|-------------------------------|
| P1 | Velocity / concurrency | Same user, two events from **different source IPs** within `velocity_minutes` (self-join; SQL in the paper §3.4 — use `+ {velocity_minutes} MINUTES` with the value validated as int, and period predicates on both aliases) | R2, R3, R4, R5 (NOT R1) |
| P2 | VPN–physical contradiction | R5's own condition | R1, R2, R3, R4 (NOT R5) |
| P3 | Dormancy break | No events in the `dormancy_days` before the period start (needs one lookback query bounded by `[start - dormancy_days, start)`) but ≥ 20 events inside the period | R1–R5 |
| P4 | Machine-like regularity | Users with ≥ 30 events whose inter-arrival deltas (computed in Python from per-user timestamps, one bounded query fetching `USER_KEY, TS` ordered) have coefficient of variation < 0.1 | R1, R2, R3, R5 (NOT R4 — volume-adjacent; document this judgement call) |

Implementation notes:

- P1's self-join can be heavy: restrict with `b.TS BETWEEN a.TS AND a.TS + m MINUTES`
  **and** `a.TS < b.TS` ordering to halve the pairs, and run the 1-day probe first
  (see `01_...` §5). If still too slow, defer P1 to the Phase B extract (same
  definition in Python) and tag it `computed_on="extract"`.
- P4 requires fetching raw timestamps per user; restrict to users with
  `EVENTS >= 30` (from §1's table) via a `WHERE TRIM(user) IN (...)` chunked into
  batches of ≤ 500 bound parameters, or compute on the extract. Prefer the extract
  if Phase B runs anyway; tag accordingly.

**Aggregation:** pseudo-positive = user with ≥ 2 *admissible-independent* proxies
firing. **Agreement report per rule** uses only that rule's admissible proxies:

```
proxy_agreement[Ri] = {
  "admissible_proxies": ["P1", ...],
  "flagged_and_proxy_positive": a,   # rule ∩ pseudo-positives
  "flagged_total": b,
  "proxy_positive_total": c,
  "agreement_precision_surrogate": a/b (Wilson CI),
  "agreement_recall_surrogate": a/c (Wilson CI),
  "status": "estimated",
  "assumptions": ["proxies independent of rule trigger columns",
                   "pseudo-positives are plausibly-malicious, not confirmed"]
}
```

Never label these fields "precision"/"recall" alone in any report — always
"agreement with proxy labels" / surrogate wording.

## 9. Runtime discipline

Emit progress lines per metric (`[labelfree] alert_rates ... ok (2.3s)`), and write
partial results to the bundle after each section so a slow query can be interrupted
without losing the rest. Every DB2 error must surface the failing metric name and
continue with the remaining metrics (record `{"status": "error", "note": ...}` for
the failed one) — mirror the resilience style of R5's `skipped` result.
